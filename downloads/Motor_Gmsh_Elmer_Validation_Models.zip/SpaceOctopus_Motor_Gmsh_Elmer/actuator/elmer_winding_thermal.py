"""Actual 24-wire cross-section: Elmer Dirichlet/Neumann conductivity bounds."""
import argparse,json,re,subprocess
from pathlib import Path
import gmsh
import numpy as np
from .gmsh_elmer_geometry import Geometry,polygon_properties
from .elmer_motor import ROOT,BASE,environment,block,common_header,output_solver,solve
from .run import dump


def prepare(folder,h=.00006):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    data=json.loads((BASE/"geometry/assembly.json").read_text())
    profile=np.array(data["winding_profile_local_m"])
    centers=np.array(data["wire_packing"]["centers_local_m"])
    g=Geometry()
    try:
        outer=g.polygon_face(profile)
        src=[]
        for x,y in centers:
            cu=g.occ.addDisk(x,y,0,.000475,.000475)
            coat=g.occ.addDisk(x,y,0,.0005,.0005)
            cut,_=g.occ.cut([(2,coat)],[(2,cu)],removeTool=False)
            src.extend([(cu,"copper"),(cut[0][1],"enamel")])
        _,maps=g.occ.fragment([(2,outer)],[(2,t) for t,_ in src])
        g.occ.synchronize()
        known={}
        for (tag,kind),mapped in zip(src,maps[1:]):
            for dim,t in mapped:
                if dim==2:
                    if t in known:raise RuntimeError("Overlapping wire regions")
                    known[t]=kind
        for rid,kind in [(1,"resin"),(2,"copper"),(3,"enamel")]:
            tags=[t for dim,t in gmsh.model.getEntities(2) if known.get(t,"resin")==kind]
            gmsh.model.addPhysicalGroup(2,tags,rid);gmsh.model.setPhysicalName(2,rid,kind)
        boundary=gmsh.model.getBoundary(gmsh.model.getEntities(2),combined=True,oriented=False)
        mids=(profile+np.roll(profile,-1,axis=0))/2
        for dim,tag in boundary:
            center=np.array(g.occ.getCenterOfMass(1,tag))[:2]
            i=int(np.argmin(np.linalg.norm(mids-center,axis=1)))
            gmsh.model.addPhysicalGroup(1,[tag],1000+i);gmsh.model.setPhysicalName(1,1000+i,"Edge%d"%i)
        gmsh.option.setNumber("Mesh.MeshSizeMin",h/3)
        gmsh.option.setNumber("Mesh.MeshSizeMax",h)
        gmsh.option.setNumber("Mesh.MshFileVersion",2.2)
        gmsh.option.setNumber("Mesh.Algorithm",6)
        gmsh.model.mesh.generate(2);gmsh.write(str(folder/"wires.msh"))
        n=len(gmsh.model.mesh.getNodes()[0])
    finally:g.close()
    with environment(),(folder/"grid.log").open("w") as log:
        subprocess.run([str(ROOT/".local/bin/ElmerGrid"),"14","2","wires.msh","-2d","-autoclean","-names","-out","mesh"],
                       cwd=folder,stdout=log,stderr=subprocess.STDOUT,check=True)
    # ElmerGrid's MSH2 reader loses names when the first physical group is 0D.
    # Add a documented point Dirichlet entity to the native mesh instead.
    nodes=np.loadtxt(folder/"mesh/mesh.nodes")
    pin=int(nodes[np.argmin(np.linalg.norm(nodes[:,2:4]-profile[0],axis=1)),0])
    bound=np.loadtxt(folder/"mesh/mesh.boundary",dtype=int)
    bid=int(bound[:,1].max())+1
    with (folder/"mesh/mesh.boundary").open("a") as f:
        f.write("%d %d 0 0 101 %d\n"%(int(bound[:,0].max())+1,bid,pin))
    header=(folder/"mesh/mesh.header").read_text().splitlines()
    first=list(map(int,header[0].split()));first[2]+=1;header[0]=" ".join(map(str,first))
    ntypes=int(header[1]);header[1]=str(ntypes+1);header.insert(2+ntypes,"101 1")
    (folder/"mesh/mesh.header").write_text("\n".join(header)+"\n")
    with (folder/"mesh/mesh.names").open("a") as f:f.write("$ Pin = %d\n"%bid)
    metadata=dict(status="meshed",nodes=n,profile_m=profile.tolist(),h_m=h,wire_count=24)
    dump(folder/"mesh_summary.json",metadata)
    return metadata


def one_case(folder,direction,kind="dirichlet",resin_k=.4):
    folder=Path(folder);case=folder/("%s_%d_resin%s"%(kind,direction,resin_k));case.mkdir(exist_ok=True)
    meta=json.loads((folder/"mesh_summary.json").read_text())
    names=dict((name,int(value)) for name,value in re.findall(r"\$\s+(\S+)\s*=\s*(\d+)",(folder/"mesh/mesh.names").read_text()))
    sif=common_header(folder/"mesh",2)
    sif+=block("Equation",1,["Active Solvers(2) = 1 2"])
    sif+=block("Solver",1,['Equation = "Heat"','Procedure = "HeatSolve" "HeatSolver"',
          'Variable = "Temperature"',"Variable DOFs = 1","Linear System Solver = Direct",
          "Linear System Direct Method = umfpack","Linear System Convergence Tolerance = 1e-11",
          "Steady State Convergence Tolerance = 1e-9","Nonlinear System Max Iterations = 2"])
    sif+=output_solver(2)
    for rid,k in [(1,resin_k),(2,390),(3,.15)]:
        sif+=block("Material",rid,["Heat Conductivity = %.16g"%k,"Density = 1","Heat Capacity = 1"])
        sif+=block("Body",rid,["Target Bodies(1) = %d"%rid,"Equation = 1","Material = %d"%rid])
    p=np.array(meta["profile_m"]);edge=np.roll(p,-1,axis=0)-p
    normals=np.c_[edge[:,1],-edge[:,0]]/np.linalg.norm(edge,axis=1)[:,None]
    for i in range(4):
        lines=["Target Boundaries(1) = %d"%names["Edge%d"%i]]
        if kind=="dirichlet":lines+=["Temperature = Variable Coordinate",'  Real MATC "1000*tx(%d)"'%direction]
        else:lines+=["Heat Flux = Real %.16g"%(1000*normals[i,direction])]
        sif+=block("Boundary Condition",i+1,lines)
    if kind!="dirichlet":
        if "Pin" not in names:raise RuntimeError("Neumann gauge pin lost in conversion")
        sif+=block("Boundary Condition",5,["Target Boundaries(1) = %d"%names["Pin"],"Temperature = Real 0"])
    data=solve(case,sif,check_nonlinear=False)
    top=data["topology"];selected=top["types"].astype(int)==5
    ends=top["offsets"].astype(int);starts=np.r_[0,ends[:-1]]
    conn=top["connectivity"].astype(int)
    t=np.array([conn[a:b] for a,b,keep in zip(starts,ends,selected) if keep])
    xy=data["points"][:,:2];v=xy[t]
    temp=data["point"][next(k for k in data["point"] if k.lower()=="temperature")]
    dxy=v[:,1:]-v[:,:1];dt=temp[t[:,1:]]-temp[t[:,:1]]
    gradient=np.linalg.solve(dxy,dt)
    area=np.abs(np.linalg.det(dxy))/2
    region=data["cell"]["GeometryIds"].astype(int)[selected]
    k=np.choose(region-1,[resin_k,390,.15])
    apparent=(area[:,None]*gradient*(k[:,None] if kind=="dirichlet" else 1)).sum(axis=0)/(area.sum()*1000)
    result=dict(kind=kind,direction=direction,resin_k_W_mK=resin_k,apparent_column=apparent.tolist(),
                area_mm2=float(area.sum()*1e6),T_min=float(temp.min()),T_max=float(temp.max()))
    dump(case/"summary.json",result)
    return apparent


def run(name="coarse",h=.00006):
    out=BASE/"winding_microstructure"/name
    if not (out/"mesh_summary.json").exists():prepare(out,h)
    cases=[]
    for resin in [.4,.2]:
        kd=np.column_stack([one_case(out,j,"dirichlet",resin) for j in range(2)])
        sn=np.column_stack([one_case(out,j,"neumann",resin) for j in range(2)])
        kn=np.linalg.inv(sn)
        if np.linalg.eigvalsh((kn+kn.T)/2).min()<=0:raise RuntimeError("Negative effective conductivity")
        cases.append(dict(resin_k_W_mK=resin,dirichlet_tensor_W_mK=kd.tolist(),
            neumann_tensor_W_mK=kn.tolist(),conservative_transverse_k_W_mK=float(np.linalg.eigvalsh((kn+kn.T)/2).min()),
            upper_eigenvalues_W_mK=np.linalg.eigvalsh((kd+kd.T)/2).tolist()))
    summary=dict(status="completed",engine="Gmsh exact 24 insulated wires + Elmer HeatSolver",
                 wire_count=24,enamel_k_W_mK=.15,copper_k_W_mK=390,cases=cases,
                 interpretation="Finite-section Dirichlet/Neumann apparent-conductivity bounds; prescribed material inputs")
    dump(out/"summary.json",summary);print(json.dumps(summary,indent=2),flush=True)
    return summary


if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("--name",default="coarse");p.add_argument("--h",type=float,default=.00006)
    a=p.parse_args();run(a.name,a.h)
