"""Exact Gmsh/OCC motor geometry and a declared, closed-coil 3D candidate.

Coordinates/meshes are SI. STEP conversion to millimetres is a separate checked
export. Closed bulk coils are stranded-current analysis regions, not shorted
individual wire rings or a fabrication routing of every turn.
"""
import argparse
import json
import math
from pathlib import Path
import gmsh
import numpy as np
from .machine import build_machine
from .run import dump

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT/"results/motor/gmsh_elmer"


def rotate(points, angle):
    c,s=np.cos(angle),np.sin(angle)
    return np.asarray(points)@np.array([[c,s],[-s,c]])


def polygon_properties(p):
    p=np.asarray(p);q=np.roll(p,-1,axis=0)
    cross=p[:,0]*q[:,1]-q[:,0]*p[:,1]
    signed=cross.sum()/2
    centroid=((p+q)*cross[:,None]).sum(axis=0)/(6*signed)
    return abs(signed),centroid


def winding_profile(machine, liner=.0002, separator=.0001):
    pts=machine.stator.slot._comp_point_coordinate()
    a=pts["Z4"].real;b=pts["Z5"].real
    slope=(abs(pts["Z5"].imag)-abs(pts["Z4"].imag))/(b-a)
    def bottom(x):
        return -abs(pts["Z4"].imag)-slope*(x-a)+liner*np.sqrt(1+slope*slope)
    return np.array([[a+liner,bottom(a+liner)],[b-liner,bottom(b-liner)],
                     [b-liner,-separator/2],[a+liner,-separator/2]])


def pack_wires(profile, diameter=.001, pitch=.00102, target=24):
    """Search hexagonal lattices inside the exact liner/partition envelope."""
    p=np.asarray(profile);area,center=polygon_properties(p)
    edges=np.roll(p,-1,axis=0)-p
    sign=np.sign(np.cross(edges[0],edges[1]))
    # Interior satisfies normals*x >= limit, including conductor radius.
    normals=sign*np.c_[-edges[:,1],edges[:,0]]
    normals/=np.linalg.norm(normals,axis=1)[:,None]
    limits=np.sum(normals*p,axis=1)+diameter/2
    best=np.empty((0,2))
    for angle in np.linspace(0,np.pi/3,13,endpoint=False):
        lattice=np.array([[i*pitch+j*pitch/2,j*pitch*np.sqrt(3)/2]
                          for i in range(-17,18) for j in range(-17,18)])
        lattice=rotate(lattice,angle)
        for dx in np.linspace(0,pitch,13,endpoint=False):
            for dy in np.linspace(0,pitch*np.sqrt(3)/2,13,endpoint=False):
                points=lattice+center+np.array([dx,dy])
                valid=np.all(points@normals.T>=limits[None,:]-1e-12,axis=1)
                candidate=points[valid]
                if len(candidate)>len(best):best=candidate
                if len(best)>=target:break
            if len(best)>=target:break
        if len(best)>=target:break
    if len(best)<target:
        raise RuntimeError("Insulated-wire packing failed: %d/%d"%(len(best),target))
    best=best[np.argsort(best[:,0])][:target]
    distances=np.linalg.norm(best[:,None,:]-best[None,:,:],axis=2)
    distances+=np.eye(target)*100
    clearance=np.min(best@normals.T-limits[None,:])
    return dict(centers_local_m=best.tolist(),wire_insulated_diameter_m=diameter,
                count=target,minimum_center_spacing_m=float(distances.min()),
                minimum_coating_to_envelope_clearance_m=float(clearance),
                liner_m=.0002,phase_separator_total_m=.0001,
                bare_copper_fraction_net=float(target*np.pi*(.00095/2)**2/area),
                coated_wire_area_fraction_net=float(target*np.pi*(diameter/2)**2/area),
                status="nominal_geometric_fit",production_tolerances_verified=False)


class Geometry:
    def __init__(self):
        gmsh.initialize()
        gmsh.option.setNumber("General.Terminal",0)
        gmsh.option.setNumber("General.NumThreads",4)
        gmsh.model.add("SpaceOctopus_motor")
        self.occ=gmsh.model.occ
        self.points={}
        self.parts=[]

    def close(self):gmsh.finalize()

    def point(self,z):
        z=complex(z);key=(round(z.real,12),round(z.imag,12))
        if key not in self.points:self.points[key]=self.occ.addPoint(key[0],key[1],0)
        return self.points[key]

    def native_loop(self,surface):
        lines=[]
        for line in surface.get_lines():
            if type(line).__name__=="Segment":
                lines.append(self.occ.addLine(self.point(line.get_begin()),self.point(line.get_end())))
            else:
                pp=line.discretize(2);center=self.point(line.get_center())
                for a,b in zip(pp[:-1],pp[1:]):
                    lines.append(self.occ.addCircleArc(self.point(a),center,self.point(b)))
        return self.occ.addCurveLoop(lines)

    def native_face(self,surface):
        if type(surface).__name__=="SurfRing":
            outer=self.occ.addPlaneSurface([self.native_loop(surface.out_surf)])
            inner=self.occ.addPlaneSurface([self.native_loop(surface.in_surf)])
            out,_=self.occ.cut([(2,outer)],[(2,inner)])
            self.points.clear()
            return out[0][1]
        return self.occ.addPlaneSurface([self.native_loop(surface)])

    def polygon_face(self,points,z=0):
        pp=[self.occ.addPoint(float(x),float(y),z) for x,y in points]
        lines=[self.occ.addLine(a,b) for a,b in zip(pp,pp[1:]+pp[:1])]
        return self.occ.addPlaneSurface([self.occ.addCurveLoop(lines)])

    def extrude(self,face,z0,length):
        self.occ.translate([(2,face)],0,0,z0)
        out=self.occ.extrude([(2,face)],0,0,length)
        return next(tag for dim,tag in out if dim==3)

    def ring(self,rin,rout,z0,length):
        outer=self.occ.addCylinder(0,0,z0,0,0,length,rout)
        inner=self.occ.addCylinder(0,0,z0,0,0,length,rin)
        out,_=self.occ.cut([(3,outer)],[(3,inner)])
        return out[0][1]

    def sector_face(self,rin,rout,start,end):
        a=np.linspace(start,end,3)
        inside=[rin*np.exp(1j*x) for x in a]
        outside=[rout*np.exp(1j*x) for x in a]
        center=self.occ.addPoint(0,0,0)
        pi=[self.occ.addPoint(z.real,z.imag,0) for z in inside]
        po=[self.occ.addPoint(z.real,z.imag,0) for z in outside]
        edges=[self.occ.addLine(pi[0],po[0]),
               self.occ.addCircleArc(po[0],center,po[-1]),
               self.occ.addLine(po[-1],pi[-1]),
               self.occ.addCircleArc(pi[-1],center,pi[0])]
        return self.occ.addPlaneSurface([self.occ.addCurveLoop(edges)])

    def add(self,name,tag,material,**metadata):
        self.parts.append(dict(name=name,tag=int(tag),material=material,**metadata))

    def fuse(self,tags):
        if len(tags)==1:return tags[0]
        out,_=self.occ.fuse([(3,tags[0])],[(3,x) for x in tags[1:]])
        if len(out)!=1:raise RuntimeError("Connected solid did not fuse: "+str(out))
        return out[0][1]

    def end_cap(self,side):
        if side=="left":
            plate=(-.020,-.014);boss=(-.020,-.009);seat=(-.019,-.009)
            wall=(-.020,0)
        else:
            plate=(.099,.105);boss=(.094,.105);seat=(.094,.104);wall=(.085,.105)
        tags=[self.ring(.048,.056,wall[0],wall[1]-wall[0]),
              self.ring(.014,.056,plate[0],plate[1]-plate[0]),
              self.ring(.014,.022,boss[0],boss[1]-boss[0])]
        whole=self.fuse(tags)
        seat_hole=self.occ.addCylinder(0,0,seat[0],0,0,seat[1]-seat[0],.016)
        out,_=self.occ.cut([(3,whole)],[(3,seat_hole)])
        whole=out[0][1]
        holes=[]
        for k in range(6):
            a=np.deg2rad(30+60*k)
            holes.append((3,self.occ.addCylinder(.052*np.cos(a),.052*np.sin(a),
                          wall[0]-.00001,0,0,wall[1]-wall[0]+.00002,.00225)))
        out,_=self.occ.cut([(3,whole)],holes)
        if len(out)!=1:raise RuntimeError("End cap topology")
        return out[0][1]

    def record(self):
        self.occ.synchronize()
        result=[]
        for i,part in enumerate(self.parts,1):
            p=dict(part)
            p["volume_m3"]=self.occ.getMass(3,p["tag"])
            p["center_m"]=list(self.occ.getCenterOfMass(3,p["tag"]))
            p["bounds_m"]=list(self.occ.getBoundingBox(3,p["tag"]))
            if p["volume_m3"]<=0:raise RuntimeError("Nonpositive CAD volume")
            gmsh.model.setEntityName(3,p["tag"],p["name"])
            result.append(p)
        return result


def assembly(export=True,output=None,lip_clearance=0.):
    c=json.loads((ROOT/"configs/motor_candidate.json").read_text());m=build_machine(c)
    out=Path(output) if output else BASE/"geometry";out.mkdir(parents=True,exist_ok=True)
    profile=winding_profile(m)
    area,centroid=polygon_properties(profile)
    packing=pack_wires(profile)
    g=Geometry()
    try:
        for surface in m.stator.build_geometry():
            if "_Winding" in surface.label:continue
            face=g.native_face(surface)
            tag=g.extrude(face,0,.085);g.add("StatorIron",tag,"steel")
        # Rotor outside diameter remains 46 mm. The new bond lies outside it.
        g.add("RotorIron",g.ring(.006,.023,0,.085),"steel")
        shaft=g.occ.addCylinder(0,0,-.035,0,0,.155,.006)
        g.add("Shaft",shaft,"steel",nominal_interface="12 mm rotor fit and bearing seats")
        conn=m.stator.winding.get_connection_mat(12)
        coil_data=[]
        for k in range(12):
            theta=np.deg2rad(15+30*k);axis=np.deg2rad(30*k)
            xy=rotate(profile,theta)
            face=g.polygon_face(xy)
            active_a=g.extrude(g.occ.copy([(2,face)])[0][1],0,.085)
            opposite=g.occ.copy([(2,face)])
            g.occ.mirror(opposite,-np.sin(axis),np.cos(axis),0,0)
            active_b=g.extrude(opposite[0][1],0,.085)
            bottom=g.occ.copy([(2,face)])
            bot=g.occ.revolve(bottom,0,0,0,np.cos(axis),np.sin(axis),0,-np.pi)
            top=g.occ.copy([(2,face)]);g.occ.translate(top,0,0,.085)
            top=g.occ.revolve(top,0,0,.085,np.cos(axis),np.sin(axis),0,np.pi)
            tags=[active_a,active_b]+[tag for dim,tag in bot+top if dim==3]
            solid=g.fuse(tags)
            phase=int(np.nonzero(conn[0,0,k])[0][0]);sign=int(np.sign(conn[0,0,k,phase]))
            rotated_center=rotate([centroid],theta-axis)[0]
            turn_length=.170+2*np.pi*rotated_center[1]
            coil_data.append(dict(coil=k+1,phase="ABC"[phase],signed_turns=12*sign,
                                  axis_angle_deg=30*k,net_cross_section_mm2=area*1e6,
                                  mean_turn_length_mm=float(turn_length*1000)))
            g.add("Coil%02d_%s"%(k+1,"ABC"[phase]),solid,"winding",phase=phase,
                  signed_turns=12*sign,axis_angle_rad=float(axis),cross_section_m2=float(area))
        # Physical slot liners and 0.1 mm phase/coil separator occupy real volume.
        p=m.stator.slot._comp_point_coordinate()
        active=np.array([[p[k].real,p[k].imag] for k in ["Z4","Z5","Z6","Z7"]])
        wedge=np.array([[p[k].real,p[k].imag] for k in ["Z2","Z3","Z8","Z9"]])
        for k in range(12):
            angle=np.deg2rad(15+30*k)
            full=g.polygon_face(rotate(active,angle))
            inner0=g.polygon_face(rotate(profile,angle))
            inner1=g.polygon_face(rotate(profile*np.array([1,-1]),angle))
            cut,_=g.occ.cut([(2,full)],[(2,inner0),(2,inner1)])
            if len(cut)!=1:raise RuntimeError("Liner topology")
            g.add("LinerSeparator%02d"%(k+1),g.extrude(cut[0][1],0,.085),"insulation")
            g.add("SlotWedge%02d"%(k+1),g.extrude(g.polygon_face(rotate(wedge,angle)),0,.085),"insulation")
        seg=(.085-3*.0001)/4
        for pole in range(10):
            a=np.deg2rad(3.6+36*pole);b=np.deg2rad(32.4+36*pole)
            for j in range(4):
                z=j*(seg+.0001)
                face=g.sector_face(.02305,.02605,a,b)
                g.add("Magnet%02d_Segment%d"%(pole+1,j+1),g.extrude(face,z,seg),"magnet",
                      pole=pole,segment=j,magnetization_sign=(-1)**pole)
                face=g.sector_face(.023,.02305,a,b)
                g.add("Bond%02d_Segment%d"%(pole+1,j+1),g.extrude(face,z,seg),"bond")
        g.add("RetainingWrap",g.ring(.02605,.02625,-lip_clearance,.085+2*lip_clearance),"wrap")
        for name,z in [("FrontRetentionLip",-.0005-lip_clearance),("RearRetentionLip",.085+lip_clearance)]:
            g.add(name,g.ring(.0225,.02625,z,.0005),"wrap")
        barrel=g.ring(.048,.056,0,.085)
        holes=[]
        for k in range(6):
            a=np.deg2rad(30+60*k);x=.052*np.cos(a);y=.052*np.sin(a)
            for z in [0,.075]:
                holes.append((3,g.occ.addCylinder(x,y,z,0,0,.010,.002)))
        cut,_=g.occ.cut([(3,barrel)],holes)
        g.add("HousingBarrel",cut[0][1],"aluminum")
        for side in ["left","right"]:
            g.add("EndCap_"+side,g.end_cap(side),"aluminum")
        for name,z in [("FrontBearing",-.019),("RearBearing",.094)]:
            g.add(name,g.ring(.006,.016,z,.010),"bearing_equivalent",
                  dimensional_envelope="6201 / 12 x 32 x 10; equivalent FE body")
        for name,z in [("FrontInnerCollar",-.009),("RearInnerCollar",.090)]:
            g.add(name,g.ring(.006,.009,z,.004),"steel",role="split collar envelope")
        for name,z in [("FrontLocknut",-.022),("RearLocknut",.104)]:
            g.add(name,g.ring(.006,.0095,z,.003),"steel",role="M12x1 equivalent locknut envelope")
        for k in range(6):
            a=np.deg2rad(30+60*k);x=.052*np.cos(a);y=.052*np.sin(a)
            for side,z,head in [("Front",-.020,-.024),("Rear",.075,.105)]:
                shaft=g.occ.addCylinder(x,y,z,0,0,.030,.002)
                cap=g.occ.addCylinder(x,y,head,0,0,.004,.0035)
                g.add("%sM4Bolt%d"%(side,k+1),g.fuse([shaft,cap]),"steel",
                      role="M4 x 30 nominal thread-equivalent envelope")
        parts=g.record()
        expected_end_volume=2*np.pi*area*rotate([centroid],np.deg2rad(15))[0][1]
        for part in parts:
            if part["material"]=="winding":
                expected=2*area*.085+expected_end_volume
                part["analytical_volume_m3"]=float(expected)
                part["raw_kernel_mass_quadrature_error"]=part["volume_m3"]/expected-1
        if export:
            gmsh.write(str(out/"motor_assembly_SI.brep"))
        metadata=dict(status="geometry_built",units="m",revision='B' if lip_clearance else 'A',parts=parts,coils=coil_data,
            winding_profile_local_m=profile.tolist(),wire_packing=packing,
            proposed_dimensions=dict(shaft_length_mm=155,shaft_z_mm=[-35,120],
                housing_ID_OD_mm=[96,112],barrel_z_mm=[0,85],endcap_z_mm=[[-20,0],[85,105]],
                bearing_centers_z_mm=[-14,99],bearing_dimensions_mm=[12,32,10],
                magnet_bond_mm=.05,magnet_radial_bounds_mm=[23.05,26.05],
                wrap_radial_bounds_mm=[26.05,26.25],free_cold_gap_mm=.25,
                retention_lip_axial_clearance_each_mm=lip_clearance*1000,
                sleeve_z_mm=[-lip_clearance*1000,85+lip_clearance*1000],
                magnet_axial_segments=4,magnet_seam_mm=.1,magnet_segment_length_mm=seg*1000,
                cap_bolt_count_each=6,cap_bolt_PCD_mm=104,cap_clearance_holes_mm=4.5,
                endcap_plate_mm=6,bearing_shoulder_opening_mm=28),
            status_note="New declared 3D analysis candidate. Bearing/fastener simplified envelopes, closed homogenized stranded coils; not a fabrication release.")
        dump(out/"assembly.json",metadata)
        return metadata
    finally:
        g.close()


if __name__=="__main__":
    result=assembly()
    print("Assembly solids:",len(result["parts"]),flush=True)
    print("Wire packing:",result["wire_packing"],flush=True)
    print("Geometric mean turn length mm:",result["coils"][0]["mean_turn_length_mm"],flush=True)
