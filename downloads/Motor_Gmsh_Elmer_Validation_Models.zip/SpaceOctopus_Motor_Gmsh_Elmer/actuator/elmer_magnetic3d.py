"""Three-dimensional Elmer edge-element magnetostatics and physical readback."""
import argparse
import json
import re
import shutil
import hashlib
from pathlib import Path
import numpy as np
from .elmer_motor import BASE,ROOT,MU0,block,common_header,output_solver,solve,read_vtu
from .run import dump
from .elmer_motor import bh_material

ANGLE_REFERENCE=.8901174250463588


def abc_currents(angle,Id=0,Iq=10.814):
    theta=5*(angle-ANGLE_REFERENCE)-np.arange(3)*2*np.pi/3
    return np.sqrt(2)*(Id*np.cos(theta)-Iq*np.sin(theta))


def loop_tangent(points,axis):
    eta=-np.sin(axis)*points[:,0]+np.cos(axis)*points[:,1]
    zz=np.maximum(points[:,2]-.085,0)+np.minimum(points[:,2],0)
    r=np.sqrt(eta**2+zz**2)
    return np.c_[np.sin(axis)*zz/r,-np.cos(axis)*zz/r,eta/r]


def phase_flux_quadrature(points,t,avec,bvec,region,groups,order=4):
    """Integrate closed stranded-coil flux using the actual affine Nedelec A.

    A(x)=A(centroid)+0.5*B cross (x-centroid) for the lowest-order
    tetrahedral first-kind basis. A centroid-times-tangent approximation loses
    their correlation in end turns and can introduce gauge-dependent errors.
    """
    q,w=np.polynomial.legendre.leggauss(order);q=(q+1)/2;w=w/2
    quadrature=[]
    for i,u in enumerate(q):
        for j,v in enumerate(q):
            for k,z in enumerate(q):
                L=np.array([(1-u)*(1-v)*(1-z),u,(1-u)*v,(1-u)*(1-v)*z])
                quadrature.append((L,6*w[i]*w[j]*w[k]*(1-u)**2*(1-v)))
    flux=np.zeros(3)
    for part in groups:
        if part['material']!='winding':continue
        mask=region==part['id'];vertices=points[t[mask]];center=vertices.mean(axis=1)
        volume=np.abs(np.linalg.det(vertices[:,1:]-vertices[:,:1]))/6
        total=0.
        for L,weight in quadrature:
            x=np.einsum('tij,i->tj',vertices,L)
            a=avec[mask]+.5*np.cross(bvec[mask],x-center)
            direction=loop_tangent(x,part['axis_angle_rad'])
            total+=weight*np.sum(volume*np.sum(a*direction,axis=1))
        flux[part['phase']]+=2*part['signed_turns']/part['cross_section_m2']*total
    return flux


def maxwell_enclosure(points,t,bvec,region,order=4,r1=.02610,r2=.02645,z1=.125,z2=.145):
    """Air-only weighted Maxwell stress enclosing every rotor body.

    w=f(r)g(z) is one on the rotor and zero before the stator/coils/far field.
    Its gradient lies exclusively in source-free, nonmagnetic air. Integrating
    -sigma.grad(w) avoids interpolating a discontinuous cell field onto a thin
    cylindrical contour and includes the axial end contribution.
    """
    vertices=points[t];center=vertices.mean(axis=1)
    rc=np.linalg.norm(center[:,:2],axis=1)
    margin=np.linalg.norm(vertices[:,:,:2]-center[:,None,:2],axis=2).max(axis=1)
    rlo=np.maximum(rc-margin,0);rhi=rc+margin;zlo=vertices[:,:,2].min(axis=1);zhi=vertices[:,:,2].max(axis=1)
    possible=(((rlo<r2)&(rhi>r1)&(zlo<z2))|((zhi>z1)&(zlo<z2)&(rlo<r2)))
    # The stated weight window must never pass through an active material.
    selected=possible&(region==1);v=vertices[selected];B=bvec[selected]
    volume=np.abs(np.linalg.det(v[:,1:]-v[:,:1]))/6
    q,w=np.polynomial.legendre.leggauss(order);q=(q+1)/2;w=w/2
    force=np.zeros(3);torque=0.;b2=np.sum(B*B,axis=1)
    def taper(x,a,b):
        u=np.clip((x-a)/(b-a),0,1)
        f=1-3*u*u+2*u*u*u
        df=(-6*u+6*u*u)/(b-a)
        return f,df
    for i,u in enumerate(q):
        for j,s in enumerate(q):
            for k,z in enumerate(q):
                L=np.array([(1-u)*(1-s)*(1-z),u,(1-u)*s,(1-u)*(1-s)*z])
                weight=6*w[i]*w[j]*w[k]*(1-u)**2*(1-s)
                x=np.einsum('tij,i->tj',v,L);r=np.linalg.norm(x[:,:2],axis=1)
                f,df=taper(r,r1,r2);g,dg=taper(x[:,2],z1,z2)
                gradw=np.c_[df*g*x[:,0]/np.maximum(r,1e-30),df*g*x[:,1]/np.maximum(r,1e-30),f*dg]
                bd=np.sum(B*gradw,axis=1)
                force-=weight*np.sum(volume[:,None]*(B*bd[:,None]-.5*b2[:,None]*gradw),axis=0)/MU0
                torque-=weight*np.sum(volume*(x[:,0]*B[:,1]-x[:,1]*B[:,0])*bd)/MU0
    return dict(torque_Nm=float(2*torque),force_xy_N=(2*force[:2]).tolist(),
                half_axial_force_N=float(force[2]),weight_radii_m=[r1,r2],weight_cap_z_m=[z1,z2],quadrature_order=order,
                method='Air-only closed weighted Maxwell stress, axial end cap included')


def material_linear_laminated(number):
    return block("Material",number,[
        "Reluctivity(3,3) = %.16g 0 0 0 %.16g 0 0 0 %.16g"%
        (1/(MU0*1500),1/(MU0*1500),1/(MU0*19.75)),
        "Electric Conductivity = 0",
    ])


def discrete_maxwell_enclosure(points,t,bvec,region,r1=.02610,r2=.02645,z1=.125,z2=.145):
    """Mesh-consistent Maxwell virtual work with a nodal rotation field.

    Interpolate v=w*(-y,x,0) on the same linear tetrahedra as the geometry.
    Its gradient is exact and constant per cell. A narrow continuous weight
    integrated independently can be outside the FE virtual-displacement space
    and give a misleading torque even with accurate numerical quadrature.
    """
    def taper(x,a,b):
        u=np.clip((x-a)/(b-a),0,1)
        return 1-3*u*u+2*u*u*u
    r=np.linalg.norm(points[:,:2],axis=1)
    weight=taper(r,r1,r2)*taper(points[:,2],z1,z2)
    velocity=weight[:,None]*np.c_[-points[:,1],points[:,0],np.zeros(len(points))]
    sel=region==1
    vertices=points[t[sel]];vel=velocity[t[sel]];B=bvec[sel]
    dx=vertices[:,1:]-vertices[:,:1]
    gradient=np.linalg.solve(dx,vel[:,1:]-vel[:,:1])
    stress=(B[:,:,None]*B[:,None,:]-.5*np.sum(B*B,axis=1)[:,None,None]*np.eye(3))/MU0
    volume=np.abs(np.linalg.det(dx))/6
    torque=-2*np.sum(volume*np.einsum('tij,tij->t',stress,gradient))
    return dict(torque_Nm=float(torque),method='Air-only Maxwell tensor with piecewise-linear nodal virtual rotation; axial end closure included',
                weight_radii_m=[r1,r2],weight_cap_z_m=[z1,z2])


def run(mesh_folder,name="linear",Id=0.,Iq=10.814,temp=80.,linear=True,iterations=1000,direct=False,hpc=True,reuse=False,regularization=0.,rooted_gauge=True,krylov=None,restart_case=None):
    mesh_folder=Path(mesh_folder)
    metadata=json.loads((mesh_folder/"mesh_summary.json").read_text())
    case=mesh_folder/name;case.mkdir(exist_ok=True)
    local_mesh=case/'mesh'
    if not local_mesh.exists():local_mesh.symlink_to((mesh_folder/'mesh').resolve(),target_is_directory=True)
    state_name='state_'+name+'.result'
    currents=abc_currents(metadata["rotor_angle_rad"],Id,Iq)
    sif=common_header(mesh_folder/"mesh",3).replace("Max Output Level = 4","Max Output Level = 6")
    sif=sif.replace('Output Intervals = 1','Output Intervals = 1\n  Output File = "'+state_name+'"')
    if restart_case:
        raise ValueError('Restart of the native Jfix/AV multi-solver state is not qualified; use a fresh solve (restart_case=None).')
    sif+=block("Equation",1,["Active Solvers(4) = 1 2 3 4"])
    sif+=block("Solver",1,[
        'Equation = "MotorMagnetic3D"','Procedure = "MagnetoDynamics" "WhitneyAVSolver"',
        'Variable = "AV"',"Fix Input Current Density = Logical False",
        "Use Tree Gauge = Logical True",
        "Nonlinear System Max Iterations = 60","Nonlinear System Convergence Tolerance = 1e-7",
        "Nonlinear System Relaxation Factor = 1","Newton-Raphson Iteration = Logical True",
        "Linear System Solver = Iterative","Linear System Iterative Method = BiCGStab",
        "Linear System Preconditioning = ILU0","Linear System Max Iterations = %d"%iterations,
        "Linear System Convergence Tolerance = 1e-8","Linear System Residual Output = 50",
        "Linear System Abort Not Converged = True",
        "Steady State Convergence Tolerance = 1e-7",
    ])
    if direct:
        method='cholmod' if direct=='cholmod' else 'umfpack'
        sif=sif.replace('Linear System Solver = Iterative','Linear System Solver = Direct\n  Linear System Direct Method = '+method+'\n  Linear System Symmetric = Logical True')
        sif=sif.replace('Fix Input Current Density = Logical False','Fix Input Current Density = Logical True')
        sif=sif.replace('Variable = "AV"','Variable = "AV"\n  Jfix: Linear System Solver = Direct\n  Jfix: Linear System Direct Method = '+method+'\n  Jfix: Linear System Symmetric = Logical True\n  Jfix: Linear System Refactorize = Logical False\n  Jfix: Linear System Free Factorization = Logical False')
    elif hpc:
        sif=sif.replace('Use Tree Gauge = Logical True','Use Tree Gauge = Logical False\n  Linear System Use Hypre = Logical True\n  Edge Basis = Logical True\n  Linear System Symmetric = Logical True')
        sif=sif.replace('Linear System Preconditioning = ILU0','Linear System Preconditioning = AMS')
        sif=sif.replace('Fix Input Current Density = Logical False','Fix Input Current Density = Logical True')
    if not linear:
        sif=sif.replace('Nonlinear System Max Iterations = 60','Nonlinear System Max Iterations = 60\n  Newton Epsilon = Real 1e-5')
    else:sif=sif.replace('Steady State Convergence Tolerance = 1e-7','Steady State Convergence Tolerance = 1e-7\n  Linear System Refactorize = Logical False\n  Linear System Free Factorization = Logical False')
    if krylov=='ilut':
        sif=sif.replace('Linear System Use Hypre = Logical True','Linear System Use Hypre = Logical False')
        sif=sif.replace('Linear System Preconditioning = AMS','Linear System Preconditioning = ILUT\n  Linear System ILUT Tolerance = 1e-4')
        sif=sif.replace('Linear System Preconditioning = ILU0','Linear System Preconditioning = ILUT\n  Linear System ILUT Tolerance = 1e-4')
        sif=sif.replace('Linear System Iterative Method = BiCGStab','Linear System Iterative Method = BiCGStabL\n  BiCGStabl Polynomial Degree = 2')
    if krylov=='ilu1':
        sif=sif.replace('Linear System Use Hypre = Logical True','Linear System Use Hypre = Logical False')
        sif=sif.replace('Linear System Preconditioning = AMS','Linear System Preconditioning = ILU1')
        sif=sif.replace('Linear System Preconditioning = ILU0','Linear System Preconditioning = ILU1')
        sif=sif.replace('Linear System Iterative Method = BiCGStab','Linear System Iterative Method = BiCGStabL\n  BiCGStabl Polynomial Degree = 2')
    if rooted_gauge:
        library=ROOT/('.local/elmer-user/MotorGaugeHPC' if hpc else '.local/elmer-user/MotorGauge')
        sif=sif.replace('Use Tree Gauge = Logical True','Use Tree Gauge = Logical False')
        sif=sif.replace('Variable = "AV"','Variable = "AV"\n  Before Linsolve = "'+str(library)+'" "MotorTreeGauge"')
        sif=sif.replace('Fix Input Current Density = Logical False','Fix Input Current Density = Logical True')
    if regularization:
        sif=sif.replace('Variable = "AV"','Variable = "AV"\n  Mass Regularize Epsilon = Real %.16g'%regularization)
    sif+=block("Solver",2,[
        'Equation = "MagneticFields"','Procedure = "MagnetoDynamics" "MagnetoDynamicsCalcFields"',
        'Potential Variable = "AV"',"Calculate Magnetic Flux Density = True",
        "Calculate Magnetic Field Strength = True","Calculate Magnetic Vector Potential = True",
        "Calculate Elemental Fields = True","Calculate Nodal Fields = False",
        "Calculate Nodal Forces = True",
    ])
    sif+=output_solver()
    sif+=block("Solver",4,[
        'Equation = "Scalars"','Procedure = "SaveData" "SaveScalars"',
        "Exec Solver = After Simulation",'Filename = "scalars.dat"',"Show Norm Index = 1",
    ])
    sif+=block("Material",1,["Relative Permeability = 1","Electric Conductivity = 0"])
    if linear:sif+=material_linear_laminated(2)
    else:
        table=bh_material(2,True).split('H-B Curve = Variable coupled iter',1)[1].rsplit('End',1)[0]
        library=ROOT/('.local/elmer-user/MotorMaterialsHPC' if hpc else '.local/elmer-user/MotorMaterials')
        sif+=block('Material',2,['Electric Conductivity = 0','Motor Steel Fill = Real .95',
             'Reluctivity Function(3,3) = Variable B1_dummy, B2_dummy, B3_dummy',
             '  Real Procedure "'+str(library)+'" "MotorLamination"',
             'Motor H-B Curve = Variable "Babs_dummy"'+table])
    sif+=block("Material",3,["Relative Permeability = 1500","Electric Conductivity = 0"])
    br=1.05*(1-.0003*(temp-20))
    for pole in range(10):
        strength=((-1)**pole)*br/(MU0*1.05)
        sif+=block("Material",4+pole,[
            "Relative Permeability = 1.05","Electric Conductivity = 0",
            "Magnetization 1 = Variable Coordinate",
            '  Real MATC "%.16g*tx(0)/sqrt(tx(0)^2+tx(1)^2)"'%strength,
            "Magnetization 2 = Variable Coordinate",
            '  Real MATC "%.16g*tx(1)/sqrt(tx(0)^2+tx(1)^2)"'%strength,
            "Magnetization 3 = Real 0",
        ])
    rotor=[]
    force_number=0
    for part in metadata["groups"]:
        rid=part["id"];material=1;extra=[]
        if part["name"] in ["RotorIron","StatorIron"]:material=2
        elif part["name"]=="Shaft":material=3
        elif part["material"]=="magnet":material=4+part["pole"]
        if part["name"] in ["RotorIron","Shaft"] or part["material"]=="magnet":
            rotor.append(rid);extra.append("Torque Groups = Integer 1")
        if part["material"]=="winding":
            force_number+=1
            amplitude=part["signed_turns"]*currents[part["phase"]]/part["cross_section_m2"]
            angle=part["axis_angle_rad"]
            variables="eta=%.16g*tx(0)+%.16g*tx(1);zz=(tx(2)-.085)*(tx(2)>.085);r=sqrt(eta^2+zz^2+1e-30);"%(-np.sin(angle),np.cos(angle))
            force_lines=[]
            for component,expression in enumerate([
                "%.16g*zz/r"%np.sin(angle),"%.16g*zz/r"%(-np.cos(angle)),"eta/r"
            ],1):
                force_lines+=["Current Density %d = Variable Coordinate"%component,
                              '  Real MATC "'+variables+"%.16g*(%s)"%(amplitude,expression)+'"']
            sif+=block("Body Force",force_number,force_lines)
            extra.append("Body Force = %d"%force_number)
        sif+=block("Body",rid,["Target Bodies(1) = %d"%rid,'Name = "'+part["name"]+'"',
                              "Equation = 1","Material = %d"%material]+extra)
    sif+=block("Component",1,['Name = "Rotor"',"Master Bodies(%d) = "%len(rotor)+" ".join(map(str,rotor)),
                             "Calculate Magnetic Torque = True","Calculate Magnetic Force = True"])
    mesh_names=(mesh_folder/"mesh/mesh.names").read_text()
    ids=[int(re.search(r"\$\s+"+name+r"\s*=\s*(\d+)",mesh_names).group(1))
         for name in ["SymmetryMidplane","FarField"]]
    sif+=block("Boundary Condition",1,["Target Boundaries(2) = %d %d"%tuple(ids),"AV {e} = Real 0"])
    (case/"case_parameters.json").write_text(json.dumps(dict(Id_Arms=Id,Iq_Arms=Iq,magnet_C=temp,
                 currents_ABC_A=currents.tolist(),laminated=True,linear=linear),indent=2)+"\n")
    expected_sif=sif.replace('Output File Name = "field"','Output File Name = "field"\n  Output Directory = "'+str(case.resolve())+'"')
    cache=case/'solver_status.json'
    goodcache=cache.exists() and json.loads(cache.read_text()).get('status')=='field_output_verified'
    if reuse and goodcache and json.loads(cache.read_text()).get('sif_sha256')==hashlib.sha256(expected_sif.encode()).hexdigest():
        data=read_vtu(sorted(case.glob('field*.vtu'))[-1])
    else:data=solve(case,sif,timeout=3600,hpc=hpc)
    saved_state=mesh_folder/'mesh'/state_name
    if saved_state.exists():shutil.copy2(saved_state,case/'state.result')
    log=(case/"solver.log").read_text()
    match=re.findall(r"Torque Group 1 torque:\s*([0-9.eE+-]+)",log)
    if not match:raise RuntimeError("No rotor torque returned")
    legacy_torque=2*float(match[-1])
    component=re.findall(r'Magnetic torque reduced: >\s*rotor\s*<\s*:\s*([0-9.eE+-]+)',log,re.I)
    if not component:raise RuntimeError('No variational component torque returned')
    torque=2*float(component[-1])
    topo=data["topology"]
    types=topo["types"].astype(int);offsets=topo["offsets"].astype(int)
    selected=types==10
    if np.any(~np.isin(types,[5,10])):raise RuntimeError("Unexpected VTU cells")
    starts=np.r_[0,offsets[:-1]];conn=topo['connectivity'].astype(int)
    t=np.array([conn[a:b] for a,b,s in zip(starts,offsets,selected) if s])
    points=data["points"];v=points[t]
    volume=np.abs(np.linalg.det(v[:,1:]-v[:,:1]))/6
    centers=v.mean(axis=1)
    region=data["cell"]["GeometryIds"].astype(int)[selected]
    akey=next(k for k in data["cell"] if k.lower()=="magnetic vector potential e")
    bkey=next(k for k in data["cell"] if k.lower()=="magnetic flux density e")
    avec=data["cell"][akey][selected];bvec=data["cell"][bkey][selected]
    if not (.05<np.linalg.norm(bvec,axis=1).max()<50):raise RuntimeError('Magnetic field magnitude gate failed')
    flux=phase_flux_quadrature(points,t,avec,bvec,region,metadata['groups'])
    flux3=phase_flux_quadrature(points,t,avec,bvec,region,metadata['groups'],order=3)
    reverse=[];reverse_volume=[]
    for part in metadata['groups']:
        if part['material']!='magnet':continue
        mask=region==part['id'];xy=centers[mask,:2]
        mdir=np.c_[xy/np.linalg.norm(xy,axis=1)[:,None],np.zeros(len(xy))]*((-1)**part['pole'])
        hp=(np.sum(bvec[mask]*mdir,axis=1)-br)/(MU0*1.05)
        reverse.extend(np.maximum(-hp,0));reverse_volume.extend(volume[mask])
    reverse=np.array(reverse);reverse_volume=np.array(reverse_volume)
    ind=np.argsort(reverse);cum=np.cumsum(reverse_volume[ind])/reverse_volume.sum()
    h99=float(np.interp(.99,cum,reverse[ind]))
    enclosure=maxwell_enclosure(points,t,bvec,region)
    enclosure3=maxwell_enclosure(points,t,bvec,region,order=3)
    discrete_enclosure=discrete_maxwell_enclosure(points,t,bvec,region)
    theta=5*(metadata["rotor_angle_rad"]-ANGLE_REFERENCE)-np.arange(3)*2*np.pi/3
    pd=np.sqrt(2)/3*flux@np.cos(theta)
    pq=-np.sqrt(2)/3*flux@np.sin(theta)
    result=dict(status="completed",engine="Elmer 26.2 3D Whitney edge elements",linear_steel=linear,
         laminated_steel=True,symmetry_factor=2,torque_Nm=torque,
         torque_method='Elmer component variational force; validated against fixed-current coenergy derivative',
         legacy_torque_group_Nm=legacy_torque,phase_flux_Wb=flux.tolist(),
         Phid_rms_Wb=float(pd),Phiq_rms_Wb=float(pq),dq_torque_Nm=float(15*(pd*Iq-pq*Id)),
         max_B_T=float(np.linalg.norm(bvec,axis=1).max()),
         nodes=metadata["nodes"],tetrahedra=metadata["tetrahedra"],source_current_ABC_A=currents.tolist(),
         Id_Arms=Id,Iq_Arms=Iq,magnet_C=temp,rotor_angle_rad=metadata["rotor_angle_rad"],
         mass_regularization=regularization,
         gauge='Dirichlet-rooted spanning tree' if rooted_gauge else 'solver native',
         phase_flux_integration='64-point Duffy quadrature, affine Nedelec potential reconstructed from A and curl A',
         phase_flux_27_vs_64_point_relative_change=float(np.linalg.norm(flux-flux3)/np.linalg.norm(flux)),
         magnet_reverse_H_max_A_m=float(reverse.max()),magnet_reverse_H_volume_p99_A_m=h99,
         nonlinear_method='consistent full-tensor Newton, recorded Elmer 26.2 correction' if not linear else 'linear check',
         air_maxwell_enclosure=enclosure,air_maxwell_27_vs_64_point_relative_change=float(abs(enclosure['torque_Nm']/enclosure3['torque_Nm']-1)),
         discrete_maxwell_enclosure=discrete_enclosure,
         torque_component_vs_discrete_maxwell_relative_error=float(abs(torque-discrete_enclosure['torque_Nm'])/max(abs(torque),1e-12)),
         limitations=["Generic material inputs and homogenized closed stranded coils",
                      "Constant steel tensor check" if linear else "Generic nonlinear BH curve, high-field extrapolation unqualified"])
    dump(case/"summary.json",result)
    np.savez_compressed(case/"fields.npz",p=points,t=t,B=bvec,A=avec,region=region,volume=volume)
    print(json.dumps(result,indent=2),flush=True)
    return result


if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("--mesh",default="coarse");p.add_argument("--name",default="linear")
    p.add_argument("--Iq",type=float,default=10.814);p.add_argument("--Id",type=float,default=0.)
    a=p.parse_args();run(BASE/"magnetic3d"/a.mesh,a.name,Id=a.Id,Iq=a.Iq)
