REAL(KIND=dp) FUNCTION MotorEddyFlux(Model,n,X) RESULT(Flux)
  USE DefUtils
  IMPLICIT NONE
  TYPE(Model_t) :: Model
  INTEGER :: n
  REAL(KIND=dp) :: X(*)
  TYPE(Element_t),POINTER :: El,Parent
  TYPE(Mesh_t),POINTER :: Mesh
  TYPE(ValueList_t),POINTER :: BC
  REAL(KIND=dp) :: xyz(3,4),a(3),b(3),normal(3),pc(3),fc(3),ef(3),sigma,omega,B0
  INTEGER :: i,j,axis
  LOGICAL :: Found
  El=>Model%CurrentElement;Mesh=>GetMesh();BC=>GetBC()
  Parent=>El%BoundaryInfo%Left
  IF(.NOT.ASSOCIATED(Parent)) Parent=>El%BoundaryInfo%Right
  IF(.NOT.ASSOCIATED(Parent)) CALL Fatal('MotorEddyFlux','Boundary has no bulk parent')
  DO i=1,3
    j=El%NodeIndexes(i)
    xyz(:,i)=[Mesh%Nodes%x(j),Mesh%Nodes%y(j),Mesh%Nodes%z(j)]
  END DO
  a=xyz(:,2)-xyz(:,1);b=xyz(:,3)-xyz(:,1)
  normal=[a(2)*b(3)-a(3)*b(2),a(3)*b(1)-a(1)*b(3),a(1)*b(2)-a(2)*b(1)]
  normal=normal/SQRT(SUM(normal**2));fc=SUM(xyz(:,1:3),DIM=2)/3._dp
  pc=0._dp
  DO i=1,4
    j=Parent%NodeIndexes(i)
    pc=pc+[Mesh%Nodes%x(j),Mesh%Nodes%y(j),Mesh%Nodes%z(j)]/4._dp
  END DO
  IF(SUM(normal*(fc-pc))<0._dp) normal=-normal
  sigma=ListGetConstReal(BC,'Motor Eddy Sigma',Found)
  omega=ListGetConstReal(BC,'Motor Eddy Omega',Found)
  B0=ListGetConstReal(BC,'Motor Eddy Bpeak',Found)
  axis=ListGetInteger(BC,'Motor Eddy Axis',Found)
  IF(axis==0) THEN
    ef=[0._dp,.5_dp*omega*B0*(X(3)-.0425_dp),-.5_dp*omega*B0*X(2)]
  ELSE
    ef=[-.5_dp*omega*B0*(X(3)-.0425_dp),0._dp,.5_dp*omega*B0*X(1)]
  END IF
  Flux=sigma*SUM(normal*ef)
END FUNCTION MotorEddyFlux
