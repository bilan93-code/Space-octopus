"""Gmsh quadratic full rotor, orthotropic wrap and CalculiX structural solves."""
import argparse,json,subprocess,os,re,resource,shutil
from pathlib import Path
import gmsh
import numpy as np
from .gmsh_elmer_geometry import Geometry
from .elmer_mesh3d import import_assembly
from .elmer_motor import ROOT,BASE
from .run import dump


def prepare(folder,h=.003,geometry_folder=None):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True);g=Geometry()
    try:
        parts,geometry_meta=import_assembly(g,geometry_folder);keep=[]
        for p in parts:
            if p['name'] in ['RotorIron','Shaft'] or p['material'] in ['magnet','bond','wrap']:keep.append(p)
            else:g.occ.remove([(3,p['tag'])],recursive=True)
        _,maps=g.occ.fragment([(3,keep[0]['tag'])],[(3,p['tag']) for p in keep[1:]])
        g.occ.synchronize();used=set()
        for rid,(p,mapped) in enumerate(zip(keep,maps),1):
            p['tags']=[tag for dim,tag in mapped if dim==3];p['id']=rid
            if not p['tags'] or used.intersection(p['tags']):raise RuntimeError('Rotor CAD overlap')
            used.update(p['tags']);gmsh.model.addPhysicalGroup(3,p['tags'],rid)
            gmsh.model.setPhysicalName(3,rid,p['name'])
        gmsh.option.setNumber('Mesh.MeshSizeMax',h);gmsh.option.setNumber('Mesh.MeshSizeMin',h*.4)
        gmsh.option.setNumber('Mesh.MinimumCircleNodes',128)
        gmsh.option.setNumber('Mesh.Algorithm3D',10)
        gmsh.option.setNumber('Mesh.SecondOrderLinear',1)
        gmsh.model.mesh.generate(3);gmsh.model.mesh.setOrder(2)
        gmsh.option.setNumber('Mesh.MshFileVersion',2.2);gmsh.write(str(folder/'rotor.msh'))
        nodeids,coords,_=gmsh.model.mesh.getNodes();order=np.argsort(nodeids)
        nodeids=np.array(nodeids)[order];coords=np.array(coords).reshape(-1,3)[order]
        all_t=[];region=[];eids=[];surface=[]
        for p in keep:
            for tag in p['tags']:
                et,ids,conn=gmsh.model.mesh.getElements(3,tag)
                for typ,elems,nodes in zip(et,ids,conn):
                    if typ!=11:raise RuntimeError('Expected quadratic tetrahedron')
                    t=np.searchsorted(nodeids,np.array(nodes).reshape(-1,10))
                    # Gmsh edge nodes 9/10 are the opposite order of Abaqus/CCX.
                    t[:,[8,9]]=t[:,[9,8]]
                    all_t.append(t);region.extend([p['id']]*len(t));eids.extend(elems)
                if p['material']=='magnet':
                    for d,face in gmsh.model.getBoundary([(3,tag)],oriented=False):
                        if gmsh.model.getType(d,face)!='Cylinder':continue
                        lo,hi=gmsh.model.getParametrizationBounds(d,face)
                        xyz=gmsh.model.getValue(d,face,((np.array(lo)+hi)/2).tolist())
                        if abs(np.linalg.norm(xyz[:2])-.02605)>1e-7:continue
                        ets,ids2,cn=gmsh.model.mesh.getElements(2,face)
                        for typ,cnodes in zip(ets,cn):
                            if typ!=9:raise RuntimeError('Expected quadratic traction triangle')
                            surface.append(np.searchsorted(nodeids,np.array(cnodes).reshape(-1,6)))
        t=np.vstack(all_t);region=np.array(region);surf=np.vstack(surface)
        np.savez_compressed(folder/'mesh_arrays.npz',p=coords,t=t,region=region,surface=surf)
        meta=dict(status='meshed',h_m=h,nodes=len(coords),quadratic_tetrahedra=len(t),groups=keep,
                  units='SI m N Pa kg s',traction_faces=len(surf),full_axial_model=True,geometry_revision=geometry_meta.get('revision','A'))
        dump(folder/'mesh_summary.json',meta)
    finally:g.close()
    print('Rotor structural mesh',len(coords),len(t),flush=True)
    return meta


def traction_forces(p,surf,pressure,torque):
    # 7-point degree-5 quadrature over curved quadratic triangular magnet faces.
    q=[([1/3]*3,.225)]
    for a,b,w in [(.05971587178977,.470142064105115,.132394152788506),(.797426985353087,.101286507323456,.125939180544827)]:
        q.extend([([a,b,b],w),([b,a,b],w),([b,b,a],w)])
    fp=np.zeros_like(p);ft=np.zeros_like(p);area=0.
    for L,w in q:
        a,b,c=L
        N=np.array([a*(2*a-1),b*(2*b-1),c*(2*c-1),4*a*b,4*b*c,4*c*a])
        # coordinates use b=u,c=v,a=1-u-v
        du=np.array([1-4*a,4*b-1,0,4*(a-b),4*c,-4*c])
        dv=np.array([1-4*a,0,4*c-1,-4*b,4*b,4*(a-c)])
        xyz=np.einsum('fij,i->fj',p[surf],N)
        jac=np.linalg.norm(np.cross(np.einsum('fij,i->fj',p[surf],du),np.einsum('fij,i->fj',p[surf],dv)),axis=1)
        da=w*.5*jac;rad=xyz.copy();rad[:,2]=0;rad/=np.linalg.norm(rad,axis=1)[:,None]
        tan=np.c_[-rad[:,1],rad[:,0],rad[:,2]];area+=da.sum()
        for k in range(6):
            np.add.at(fp,surf[:,k],N[k]*da[:,None]*rad)
            np.add.at(ft,surf[:,k],N[k]*da[:,None]*tan)
    surface_nodes=np.unique(surf)
    raw_force=pressure*fp.sum(axis=0)
    fp[surface_nodes]-=fp.sum(axis=0)/len(surface_nodes)
    ft[surface_nodes]-=ft.sum(axis=0)/len(surface_nodes)
    moment=np.sum(p[:,0]*ft[:,1]-p[:,1]*ft[:,0])
    moment_p=pressure*np.sum(p[:,0]*fp[:,1]-p[:,1]*fp[:,0])
    loads=pressure*fp+(torque-moment_p)*ft/moment
    check=dict(surface_area_m2=float(area),force_resultant_N=loads.sum(axis=0).tolist(),
               applied_torque_Nm=float(np.sum(p[:,0]*loads[:,1]-p[:,1]*loads[:,0])),
               raw_faceted_pressure_resultant_N=raw_force.tolist(),
               balancing_force_per_surface_node_N=float(np.linalg.norm(raw_force)/len(surface_nodes)))
    if abs(check['applied_torque_Nm']-torque)>1e-7 or np.linalg.norm(loads.sum(axis=0))>1e-4:raise RuntimeError('Mechanical load transfer gate failed')
    return loads,check


def listing(values,perline=12):
    return '\n'.join(', '.join(str(v) for v in values[i:i+perline]) for i in range(0,len(values),perline))+'\n'


def rotation_terms(p,nodes,sign=1.):
    xy=p[nodes,:2]-p[nodes,:2].mean(axis=0)
    den=np.sum(xy*xy)
    if den<=1e-20:raise RuntimeError('Degenerate mean rotation interface')
    terms=[]
    for n,(x,y) in zip(nodes,xy):
        if abs(y)>1e-14:terms.append((n+1,1,-sign*y/den))
        if abs(x)>1e-14:terms.append((n+1,2,sign*x/den))
    return terms


def translation_weights(p,nodes,center):
    A=np.vstack([np.ones(len(nodes)),((p[nodes]-center)/.01).T])
    weights=A.T@np.linalg.solve(A@A.T,np.array([1.,0,0,0]))
    if np.linalg.norm(A@weights-np.array([1.,0,0,0]))>1e-10:
        raise RuntimeError('Bearing rigid-rotation invariance failed')
    return weights


def run(folder,name='fault_hot',rpm=1890,torque=13.416,pressure=.591525e6,temperature=150.,radial_N=0.,order=2,contact=False,contact_penalty=5e13,preheat=False,contact_mode='face',timeout=5400,rotation_reference='weak',rotation_stiffness=.01,pressure_mode='follower'):
    folder=Path(folder);meta=json.loads((folder/'mesh_summary.json').read_text())
    m=np.load(folder/'mesh_arrays.npz');p=m['p'];t=m['t'];region=m['region'];surf=m['surface']
    # Straight-sided quadratic elements retain the positive linear tetrahedron
    # geometry across 50 um bond layers; curved mid-edge projection can invert
    # elements in such thin layers. The displacement basis remains quadratic.
    if meta.get('geometry_order')!='straight-sided quadratic':
        for k,(a,b) in enumerate([(0,1),(1,2),(2,0),(0,3),(1,3),(2,3)],4):
            p[t[:,k]]=(p[t[:,a]]+p[t[:,b]])/2
        np.savez_compressed(folder/'mesh_arrays.npz',p=p,t=t,region=region,surface=surf)
        meta['geometry_order']='straight-sided quadratic';dump(folder/'mesh_summary.json',meta)
    face_nodes=[(0,1,2),(0,3,1),(1,3,2),(2,3,0)]
    pressure_keys={tuple(sorted(row[:3])) for row in surf}
    kinds0={g['id']:g['material'] for g in meta['groups']}
    pressure_faces=[]
    for eid in np.where(np.array([kinds0[r]=='magnet' for r in region]))[0]:
        for faceid,indices in enumerate(face_nodes,1):
            if tuple(sorted(t[eid,list(indices)])) in pressure_keys:pressure_faces.append((eid,faceid))
    if len(pressure_faces)!=len(surf):raise RuntimeError('Magnet follower-pressure face mapping failed')
    loads,balance=traction_forces(p,surf,0. if pressure_mode=='follower' else pressure,torque)
    if order==1:
        edge=np.vstack([np.c_[t[:,a],t[:,b],t[:,k]] for k,(a,b) in
             enumerate([(0,1),(1,2),(2,0),(0,3),(1,3),(2,3)],4)])
        mids,first=np.unique(edge[:,2],return_index=True);edge=edge[first]
        force=loads[mids].copy()
        np.add.at(loads,edge[:,0],force/2);np.add.at(loads,edge[:,1],force/2);loads[mids]=0
        nodes=np.unique(t[:,:4]);t=np.searchsorted(nodes,t[:,:4]);p=p[nodes];loads=loads[nodes]
    contact_surfaces=None;wrap_gauge=None
    if contact:
        if order!=1:raise ValueError('Contact sensitivity uses verified linear tetrahedron mesh')
        kindmap={g['id']:g['material'] for g in meta['groups']}
        wrapmask=np.array([kindmap[r]=='wrap' for r in region]);faces={};master=[];slave=[]
        for eid,nn in enumerate(t):
            for faceid,indices in enumerate([(0,1,2),(0,3,1),(1,3,2),(2,3,0)],1):
                key=tuple(sorted(nn[list(indices)]))
                if key in faces:
                    other,otherface=faces.pop(key)
                    if wrapmask[eid]!=wrapmask[other]:
                        if wrapmask[eid]:slave.append((eid+1,faceid));master.append((other+1,otherface))
                        else:slave.append((other+1,otherface));master.append((eid+1,faceid))
                else:faces[key]=(eid,faceid)
        wrapnodes=np.unique(t[wrapmask]);dup=np.arange(len(p),len(p)+len(wrapnodes))
        p=np.vstack([p,p[wrapnodes]]);loads=np.vstack([loads,np.zeros((len(wrapnodes),3))])
        remap=np.arange(len(p));remap[wrapnodes]=dup;t[wrapmask]=remap[t[wrapmask]]
        used=np.unique(t);p=p[used];loads=loads[used];t=np.searchsorted(used,t)
        contact_surfaces=(master,slave)
        wrap_gauge=np.unique(t[wrapmask])
    rotor=next(g for g in meta['groups'] if g['name']=='RotorIron')
    iron_nodes=np.unique(t[region==rotor['id']]);loads[iron_nodes,0]+=radial_N/len(iron_nodes)
    radius=np.linalg.norm(p[:,:2],axis=1)
    front=np.where((abs(radius-.006)<1e-7)&(p[:,2]>=-.019-1e-8)&(p[:,2]<=-.009+1e-8))[0]
    rear=np.where((abs(radius-.006)<1e-7)&(p[:,2]>=.094-1e-8)&(p[:,2]<=.104+1e-8))[0]
    tip=np.where(abs(p[:,2]-.120)<1e-8)[0]
    if min(len(front),len(rear),len(tip))<3:raise RuntimeError('Bearing/output interfaces missing')
    bearing=[]
    for label,nodes,z in [('FRONT',front,-.014),('REAR',rear,.099)]:
        center=np.array([0.,0.,z]);weights=translation_weights(p,nodes,center)
        bearing.append((label,nodes,len(p),weights))
        p=np.vstack([p,center]);loads=np.vstack([loads,np.zeros(3)])
    weak_reference=None
    if contact and rotation_reference=='weak':
        weak_reference=len(p)
        p=np.vstack([p,[0.,0.,.0425]]);loads=np.vstack([loads,np.zeros(3)])
    case=folder/name;case.mkdir(exist_ok=True)
    text='*HEADING\nSpaceOctopus declared full rotor structural model, SI units\n*NODE\n'
    text+=''.join('%d, %.12g, %.12g, %.12g\n'%(i+1,*xyz) for i,xyz in enumerate(p))
    text+='*ELEMENT, TYPE='+('C3D10' if order==2 else 'C3D4')+', ELSET=ROTOR\n'
    text+=''.join(str(i+1)+', '+', '.join(map(str,nn+1))+'\n' for i,nn in enumerate(t))
    kinds={g['id']:('steel' if g['name'] in ['RotorIron','Shaft'] else g['material']) for g in meta['groups']}
    for kind in ['steel','magnet','bond','wrap']:
        indices=np.where(np.array([kinds[r] for r in region])==kind)[0]+1
        text+='*ELSET, ELSET='+kind+'\n'+listing(indices.tolist())
    text+='*ORIENTATION, NAME=WRAP_CYL, SYSTEM=CYLINDRICAL\n0,0,0,0,0,1\n'
    props={'steel':(210e9,.3,7650,12e-6),'magnet':(150e9,.24,8300,6e-6),'bond':(2.6e6,.3,1200,80e-6)}
    for kind,(E,nu,rho,alpha) in props.items():
        text+='*MATERIAL, NAME='+kind+'\n*ELASTIC\n%.12g, %.12g\n*DENSITY\n%.12g\n*EXPANSION, ZERO=20\n%.12g\n'%(E,nu,rho,alpha)
    if contact:
        text=text.replace('*MATERIAL, NAME=bond\n*ELASTIC\n2600000, 0.3','*MATERIAL, NAME=bond\n*HYPERELASTIC, NEO HOOKE\n500000, 9.23076923077e-7')
    text+='*MATERIAL, NAME=wrap\n*ELASTIC, TYPE=ENGINEERING CONSTANTS\n1e10,1e11,1e10,.025,.25,.25,5e9,3e9\n5e9\n*DENSITY\n1600\n*EXPANSION, TYPE=ORTHO, ZERO=20\n25e-6,0,0\n'
    for kind in ['steel','magnet','bond','wrap']:
        text+='*SOLID SECTION, ELSET='+kind+', MATERIAL='+kind+(', ORIENTATION=WRAP_CYL' if kind=='wrap' else '')+'\n'
    if contact:
        master,slave=contact_surfaces
        text+='*SURFACE,NAME=CORE_MASTER,TYPE=ELEMENT\n'+''.join('%d,S%d\n'%s for s in master)
        text+='*SURFACE,NAME=WRAP_SLAVE,TYPE=ELEMENT\n'+''.join('%d,S%d\n'%s for s in slave)
        text+='*SURFACE INTERACTION,NAME=SLIDING_WRAP\n*SURFACE BEHAVIOR,PRESSURE-OVERCLOSURE=LINEAR\n%.16g\n'%contact_penalty
        ctype='NODE TO SURFACE,SMALL SLIDING' if contact_mode=='small_sliding' else 'SURFACE TO SURFACE'
        text+='*CONTACT PAIR,INTERACTION=SLIDING_WRAP,TYPE='+ctype+'\nWRAP_SLAVE,CORE_MASTER\n'
    # Bearings act on mean journal translations at the shaft axis. Grounding
    # every surface node in x/y would also resist shaft spin, which a rolling
    # bearing must not do. Affine averaging annihilates rigid rotation exactly.
    eid=len(t)+1
    for label,nodes,reference,weights in bearing:
        for dof in [1,2]:
            text+='*ELEMENT, TYPE=SPRING1, ELSET=K_'+label+str(dof)+'\n'
            text+='%d, %d\n'%(eid,reference+1);eid+=1
            text+='*SPRING, ELSET=K_'+label+str(dof)+'\n%d\n5.000000e6\n'%dof
            terms=[(reference+1,dof,1.)]+[(n+1,dof,-w) for n,w in zip(nodes,weights)]
            text+='*EQUATION\n%d\n'%len(terms)
            text+='\n'.join(', '.join('%d,%d,%.12g'%q for q in terms[i:i+3]) for i in range(0,len(terms),3))+'\n'
    text+='*BOUNDARY\n'+''.join('%d,3,3,0.\n'%(reference+1) for _,_,reference,_ in bearing)
    if weak_reference is not None:
        text+='*ELEMENT,TYPE=SPRING1,ELSET=WEAK_SLEEVE_ROTATION\n%d,%d\n'%(eid,weak_reference+1);eid+=1
        text+='*SPRING,ELSET=WEAK_SLEEVE_ROTATION\n1\n%.12e\n'%(rotation_stiffness/.02625**2)
        text+='*BOUNDARY\n%d,2,3,0.\n'%(weak_reference+1)
    # Only mean rotation at the output tip and mean axial motion at the front
    # bearing are constrained. Neither equation clamps radial bearing motion.
    terms=rotation_terms(p,tip)
    text+='*EQUATION\n%d\n'%len(terms)
    text+='\n'.join(', '.join('%d,%d,%.12g'%q for q in terms[i:i+3]) for i in range(0,len(terms),3))+'\n'
    text+='*EQUATION\n%d\n'%len(front)
    text+='\n'.join(', '.join('%d,3,%.12g'%(n+1,1/len(front)) for n in front[i:i+3]) for i in range(0,len(front),3))+'\n'
    if contact:
        # A frictionless circular sleeve has an arbitrary rigid rotation.
        # Remove that mode without constraining translation or expansion.
        nodes=wrap_gauge[np.argsort(abs(p[wrap_gauge,2]-.0425))[:80]]
        core=iron_nodes[np.argsort(abs(p[iron_nodes,2]-p[nodes,2].mean()))[:160]]
        # Select a relative floating rotation, rather than grounding the sleeve
        # and giving faceted contact an artificial external torque path.
        if weak_reference is not None:
            terms=[(weak_reference+1,1,1.)]+[(n,d,-.02625*w) for n,d,w in rotation_terms(p,nodes)]
        else:terms=rotation_terms(p,nodes)+rotation_terms(p,core,sign=-1.)
        text+='*EQUATION\n%d\n'%len(terms)
        text+='\n'.join(', '.join('%d,%d,%.12g'%q for q in terms[i:i+3]) for i in range(0,len(terms),3))+'\n'
        if meta.get('geometry_revision')=='B':
            # Select the centered representative of the floating sleeve's axial
            # mode. A zero absolute sleeve translation would hold it to ground
            # while the front-located core thermally translates, artificially
            # consuming the rear lip gap. Follow the core's mean midplane motion.
            A=np.vstack([np.ones(len(core)),p[core,0]/.023,p[core,1]/.023,
                         (p[core,2]-.0425)/.01])
            target=np.array([1.,p[nodes,0].mean()/.023,p[nodes,1].mean()/.023,
                             (p[nodes,2].mean()-.0425)/.01])
            weights=A.T@np.linalg.solve(A@A.T,target)
            terms=[(n+1,3,1/len(nodes)) for n in nodes]+[(n+1,3,-w) for n,w in zip(core,weights)]
            text+='*EQUATION\n%d\n'%len(terms)
            text+='\n'.join(', '.join('%d,%d,%.12g'%q for q in terms[i:i+3]) for i in range(0,len(terms),3))+'\n'
    text+='*INITIAL CONDITIONS, TYPE=TEMPERATURE\nNALL,20\n' if False else ''
    text+='*NSET, NSET=NALL, GENERATE\n1,%d,1\n'%len(p)
    text+='*INITIAL CONDITIONS, TYPE=TEMPERATURE\nNALL,20\n'
    if contact and preheat:
        text+='*STEP,NLGEOM,INC=100\n*STATIC\n.1,1,1e-6,.1\n*TEMPERATURE\nNALL,%.12g\n*END STEP\n'%temperature
    text+=('*STEP,NLGEOM,INC=100\n*STATIC\n.2,1,1e-6,.25\n' if contact else '*STEP\n*STATIC\n')
    text+='*DLOAD\nROTOR,CENTRIF,%.12g,0,0,0,0,0,1\n'%((rpm*2*np.pi/60)**2)
    if pressure_mode=='follower' and pressure:
        # Negative face pressure is outward suction. Native DLOAD updates the
        # normal and area under NLGEOM, avoiding a spurious drag moment from
        # fixed Cartesian radial nodal forces on a rotating/deforming rotor.
        text+=''.join('%d,P%d,%.12g\n'%(eid+1,faceid,-pressure) for eid,faceid in pressure_faces)
    text+='*CLOAD\n'
    for n in np.where(np.linalg.norm(loads,axis=1)>1e-14)[0]:
        for dof,value in enumerate(loads[n],1):
            if abs(value)>1e-14:text+='%d,%d,%.12g\n'%(n+1,dof,value)
    text+='*TEMPERATURE\nNALL,%.12g\n*NODE FILE\nU,RF\n*EL FILE\nS,E\n'%temperature
    if contact:text+='*CONTACT FILE\nCDIS,CSTR\n'
    for kind in ['wrap','bond','magnet','steel']:text+='*EL PRINT,ELSET='+kind+',GLOBAL=YES\nS\n'
    text+='*END STEP\n'
    (case/'rotor.inp').write_text(text)
    env=os.environ.copy();env.update(OMP_NUM_THREADS='2',CCX_NPROC_STIFFNESS='2',OPENBLAS_NUM_THREADS='1')
    def solver_stack():
        soft,hard=resource.getrlimit(resource.RLIMIT_STACK)
        resource.setrlimit(resource.RLIMIT_STACK,(hard,hard))
    with (case/'solver.log').open('w') as log:
        executable=str(ROOT/'.local/bin/ccx') if (ROOT/'.local/bin/ccx').exists() else shutil.which('ccx')
        if not executable:raise RuntimeError('CalculiX ccx is required for this optional structural solve')
        proc=subprocess.Popen([executable,'-i','rotor'],cwd=case,env=env,stdout=log,stderr=subprocess.STDOUT,preexec_fn=solver_stack)
        (case/'.solver.pid').write_text(str(proc.pid))
        try:proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            proc.terminate()
            try:proc.wait(timeout=10)
            except subprocess.TimeoutExpired:proc.kill();proc.wait()
            raise
        finally:(case/'.solver.pid').unlink(missing_ok=True)
    log=(case/'solver.log').read_text()
    dump(case/'solver_status.json',dict(exit_code=proc.returncode,finished='Job finished' in log))
    if proc.returncode or '*ERROR' in log or 'Job finished' not in log:raise RuntimeError('CalculiX rotor solve failed (exit '+str(proc.returncode)+'): '+log[-2500:])
    result=read_results(case,p,t,region,kinds,finite_geometry=contact)
    fields=np.load(case/'fields.npz');deformed=p+fields['displacement']
    applied=float(np.sum(deformed[:,0]*loads[:,1]-deformed[:,1]*loads[:,0]))
    pressure_moment=0.
    if pressure_mode=='follower' and pressure:
        for eid,faceid in pressure_faces:
            vertices=deformed[t[eid,list(face_nodes[faceid-1])]]
            center=vertices.mean(axis=0);normal=np.cross(vertices[1]-vertices[0],vertices[2]-vertices[0])/2
            if np.dot(normal,center-deformed[t[eid,:4]].mean(axis=0))<0:normal=-normal
            force=pressure*normal
            pressure_moment+=center[0]*force[1]-center[1]*force[0]
        applied+=pressure_moment
    result['applied_torque_current_geometry_Nm']=applied
    result['follower_pressure_torque_current_geometry_Nm']=float(pressure_moment)
    result['pressure_load_mode']=pressure_mode
    if not contact:result['output_reaction_torque_Nm']=result['output_reaction_torque_reference_geometry_Nm']
    if weak_reference is not None:
        displacement=np.load(case/'fields.npz')['displacement']
        # FRD omits isolated reference-point displacement. Recover its proxy
        # coordinate from the actual physical sleeve nodes in the MPC.
        angle=sum(w*displacement[n-1,d-1] for n,d,w in rotation_terms(p,nodes))
        rotation_factor=sum(w*(-deformed[n-1,1] if d==1 else deformed[n-1,0]) for n,d,w in rotation_terms(p,nodes))
        weak_torque=rotation_stiffness*angle*rotation_factor
        result['weak_sleeve_rotation_spring']=dict(stiffness_Nm_rad=rotation_stiffness,
             angle_rad=float(angle),torque_Nm=float(weak_torque))
        if abs(weak_torque)>.001:
            raise RuntimeError('Weak sleeve reference carries a material torque; reduce stiffness')
    result.update(status='completed',engine='Gmsh tetrahedra + CalculiX 2.20',nodes=len(p),elements=len(t),
         rpm=rpm,torque_Nm=torque,magnetic_pressure_Pa=pressure,uniform_rotor_C=temperature,radial_load_N=radial_N,element_order=order,
         pair_bearing_stiffness_N_m=1e7,load_transfer=balance,
         bearing_support='Mean journal translations through on-axis 5 MN/m reference springs; no torsional support',
         sleeve_rotation_reference=rotation_reference if contact else None,
         geometry_revision=meta.get('geometry_revision','A'),
         wrap_interface='frictionless unilateral normal contact' if contact else 'fully bonded',
         bond_law='compressible neo-Hookean, G=1 MPa, K=2.167 MPa' if contact else 'linear elastic, E=2.6 MPa, nu=0.3',
         contact_penalty_Pa_m=contact_penalty if contact else None,preheated_before_fault=preheat,
         contact_tracking=contact_mode if contact else None,
         assumptions=[('Magnet-to-sleeve unilateral frictionless contact; inner adhesive interfaces bonded' if contact else 'All material interfaces bonded; no separation, press-fit slip or progressive damage'),
          'Generic 100 GPa hoop-modulus wrap; radial 10 GPa, axial 10 GPa; orthotropic constitutive model',
          'Soft hot bond shear modulus 1 MPa; vendor temperature/creep/strength data absent',
          'Uniform temperature scenario, 20 C stress-free assembly, symmetric radial bearing springs',
          'Full peak magnetic pressure applied simultaneously to every pole is a conservative load envelope'])
    dump(case/'summary.json',result);print(name,json.dumps({k:v for k,v in result.items() if k.endswith('MPa') or k.endswith('um')}),flush=True)
    reaction=result.get('output_reaction_torque_Nm')
    target=applied if contact else torque
    weak_torque=result.get('weak_sleeve_rotation_spring',{}).get('torque_Nm',0.)
    residual=abs(reaction+target-weak_torque) if reaction is not None else float('inf')
    result['moment_balance_residual_Nm']=float(residual)
    if residual>max(.01,abs(torque)*.005):
        result['status']='rejected_torque_balance';dump(case/'summary.json',result)
        raise RuntimeError('Output reaction does not balance applied torque: '+str(reaction))
    dump(case/'summary.json',result)
    return result


def read_results(case,p,t,region,kinds,finite_geometry=False):
    # CalculiX ASCII FRD nodal vectors/tensors. Values in each 12-character field
    # may have no intervening space, so whitespace splitting is unsafe.
    arrays={};current=None;rows={}
    for line in (case/'rotor.frd').open():
        if line.startswith(' -4'):
            if current and rows:arrays[current]=rows
            current=line[5:17].strip().split()[0];rows={}
        elif line.startswith(' -1') and current:
            n=int(line[3:13]);values=[float(line[i:i+12]) for i in range(13,len(line),12) if line[i:i+12].strip()]
            rows[n]=values
        elif line.startswith(' -3') and current:
            arrays[current]=rows;current=None;rows={}
    if 'DISP' not in arrays or 'STRESS' not in arrays:raise RuntimeError('Missing structural fields '+str(arrays.keys()))
    u=np.zeros_like(p);stress=np.zeros((len(p),6))
    for n,v in arrays['DISP'].items():u[n-1]=v[:3]
    for n,v in arrays['STRESS'].items():stress[n-1]=v[:6]
    if not np.isfinite(u).all() or not np.isfinite(stress).all():raise RuntimeError('Non-finite structural result')
    current=p+u
    ur=(np.linalg.norm(current[:,:2],axis=1)-np.linalg.norm(p[:,:2],axis=1)) if finite_geometry else np.sum(u[:,:2]*p[:,:2],axis=1)/np.maximum(np.linalg.norm(p[:,:2],axis=1),1e-12)
    fields={};maxes={}
    for kind in ['steel','magnet','bond','wrap']:
        mask=np.array([kinds[r]==kind for r in region]);nodes=np.unique(t[mask])
        s=stress[nodes];sx,sy,sz,txy,tyz,tzx=s.T
        vm=np.sqrt(.5*((sx-sy)**2+(sy-sz)**2+(sz-sx)**2)+3*(txy*txy+tyz*tyz+tzx*tzx))
        geometry=current if finite_geometry else p
        phi=np.arctan2(geometry[nodes,1],geometry[nodes,0]);c=np.cos(phi);ss=np.sin(phi)
        hoop=sx*ss**2+sy*c**2-2*txy*ss*c
        fields[kind]=dict(von_mises_max_MPa=float(vm.max()/1e6),von_mises_p99_MPa=float(np.quantile(vm,.99)/1e6),
             hoop_max_MPa=float(hoop.max()/1e6),radial_displacement_max_um=float(ur[nodes].max()*1e6))
    outer=np.where(abs(np.linalg.norm(p[:,:2],axis=1)-.02625)<1e-7)[0]
    integration=read_integration_stress(case,p,t,displacement=u if finite_geometry else None)
    np.savez_compressed(case/'fields.npz',p=p,t=t,region=region,displacement=u,stress=stress,finite_geometry=finite_geometry)
    result=dict(material_results=integration,nodal_smoothed_stresses_for_plot_only=fields,
          wrap_hoop_max_MPa=integration['wrap']['hoop_max_MPa'],
          wrap_factor2_required_hot_hoop_strength_MPa=2*integration['wrap']['hoop_max_MPa'],
          rotor_outer_radial_displacement_um=float(ur[outer].max()*1e6),
          max_displacement_um=float(np.linalg.norm(u,axis=1).max()*1e6))
    result['radial_displacement_method']='Actual current radius minus reference radius' if finite_geometry else 'Infinitesimal radial projection'
    wrapnodes=np.unique(t[np.array([kinds[r]=='wrap' for r in region])])
    corenodes=np.unique(t[np.array([kinds[r]!='wrap' for r in region])])
    rr=np.linalg.norm(p[:,:2],axis=1);deformed=p[:,2]+u[:,2]
    gaps=[]
    for corez,lipz,frontside in [(0.,-.00015,True),(.085,.08515,False)]:
        cn=corenodes[(abs(p[corenodes,2]-corez)<1e-8)&(rr[corenodes]>.0225-1e-8)]
        wn=wrapnodes[abs(p[wrapnodes,2]-lipz)<1e-8]
        if len(cn) and len(wn):
            gap=(deformed[cn].min()-deformed[wn].max()) if frontside else (deformed[wn].min()-deformed[cn].max())
            gaps.append(float(gap*1e6))
    if len(gaps)==2:result['axial_capture_clearance_um']=dict(front=gaps[0],rear=gaps[1],minimum=min(gaps),method='Conservative extrema of deformed core end faces and opposing lip planes')
    if 'CONTACT' in arrays:
        contact=np.array(list(arrays['CONTACT'].values()))
        result['contact_results']=dict(source='Final CalculiX CONTACT: COPEN, CSLIP1, CSLIP2, CPRESS, CSHEAR1, CSHEAR2',
            slave_output_nodes=len(contact),max_penetration_um=float(np.maximum(-contact[:,0],0).max()*1e6),
            penetration_p99_um=float(np.quantile(np.maximum(-contact[:,0],0),.99)*1e6),
            max_pressure_MPa=float(contact[:,3].max()/1e6),
            pressure_p99_MPa=float(np.quantile(contact[:,3],.99)/1e6),
            friction='Frictionless; tangential slip output is not used as a physical result')
    if 'FORC' in arrays:
        force=np.zeros_like(p)
        for n,v in arrays['FORC'].items():force[n-1]=v[:3]
        tip=abs(p[:,2]-.120)<1e-8
        result['output_reaction_torque_reference_geometry_Nm']=float(np.sum(p[tip,0]*force[tip,1]-p[tip,1]*force[tip,0]))
        current=p+u
        result['output_reaction_torque_Nm']=float(np.sum(current[tip,0]*force[tip,1]-current[tip,1]*force[tip,0]))
    return result


def read_integration_stress(case,p,t,displacement=None):
    result={};rows=[];kind=None
    geometry=p+displacement if displacement is not None else p
    def finish(label,data):
        if not label or not data:return
        a=np.array(data);centers=geometry[t[a[:,0].astype(int)-1,:4]].mean(axis=1)
        # DAT order is sxx,syy,szz,sxy,sxz,syz, explicitly printed in its header.
        sx,sy,sz,txy,txz,tyz=a[:,2:].T
        vm=np.sqrt(.5*((sx-sy)**2+(sy-sz)**2+(sz-sx)**2)+3*(txy*txy+tyz*tyz+txz*txz))
        phi=np.arctan2(centers[:,1],centers[:,0]);c=np.cos(phi);s=np.sin(phi)
        hoop=sx*s*s+sy*c*c-2*txy*s*c
        tensor=np.zeros((len(a),3,3));tensor[:,0,0]=sx;tensor[:,1,1]=sy;tensor[:,2,2]=sz
        tensor[:,0,1]=tensor[:,1,0]=txy;tensor[:,0,2]=tensor[:,2,0]=txz;tensor[:,1,2]=tensor[:,2,1]=tyz
        principal=np.linalg.eigvalsh(tensor);tau=(principal[:,2]-principal[:,0])/2
        radial=sx*c*c+sy*s*s+2*txy*s*c
        rtheta=(sy-sx)*s*c+txy*(c*c-s*s)
        rz=txz*c+tyz*s;thetaz=-txz*s+tyz*c
        axis_stress=dict(radial_tension=float(max(radial.max(),0)/1e6),radial_compression=float(max(-radial.min(),0)/1e6),
            hoop_tension=float(max(hoop.max(),0)/1e6),hoop_compression=float(max(-hoop.min(),0)/1e6),
            axial_tension=float(max(sz.max(),0)/1e6),axial_compression=float(max(-sz.min(),0)/1e6),
            shear_radial_hoop=float(abs(rtheta).max()/1e6),shear_radial_axial=float(abs(rz).max()/1e6),
            shear_hoop_axial=float(abs(thetaz).max()/1e6))
        axis_arrays=[np.maximum(radial,0),np.maximum(-radial,0),np.maximum(hoop,0),np.maximum(-hoop,0),
            np.maximum(sz,0),np.maximum(-sz,0),abs(rtheta),abs(rz),abs(thetaz)]
        axis_p99={key:float(np.quantile(value,.99)/1e6) for key,value in zip(axis_stress,axis_arrays)}
        result[label]=dict(source='unaveraged element integration points; global stress rotated to hoop at element centroid',
             integration_points=len(a),von_mises_max_MPa=float(vm.max()/1e6),von_mises_p99_MPa=float(np.quantile(vm,.99)/1e6),
             hoop_max_MPa=float(hoop.max()/1e6),hoop_p99_MPa=float(np.quantile(hoop,.99)/1e6),
             tensile_principal_max_MPa=float(principal[:,2].max()/1e6),tensile_principal_p99_MPa=float(np.quantile(principal[:,2],.99)/1e6),
             max_shear_MPa=float(tau.max()/1e6),max_shear_p99_MPa=float(np.quantile(tau,.99)/1e6),
             cylindrical_axis_stress_MPa=axis_stress,cylindrical_axis_stress_p99_MPa=axis_p99)
    with (case/'rotor.dat').open() as f:
        for line in f:
            if 'stresses (' in line:
                finish(kind,rows);rows=[]
                kind=re.search(r'for set\s+(\S+)',line).group(1).lower()
            elif kind:
                values=line.split()
                if len(values)==8:
                    try:rows.append([float(v) for v in values])
                    except ValueError:pass
    finish(kind,rows)
    if set(result)!=set(['steel','magnet','bond','wrap']):raise RuntimeError('Missing integration-point stresses')
    return result


if __name__=='__main__':
    pa=argparse.ArgumentParser();pa.add_argument('--name',default='coarse');pa.add_argument('--h',type=float,default=.003)
    pa.add_argument('--revision',choices=['A','B'],default='A');pa.add_argument('--case',default='fault_hot')
    pa.add_argument('--contact',action='store_true');pa.add_argument('--preheat',action='store_true')
    pa.add_argument('--order',type=int,choices=[1,2],default=1);pa.add_argument('--pressure',type=float,default=.591525e6)
    pa.add_argument('--torque',type=float,default=13.416);pa.add_argument('--rpm',type=float,default=1890)
    pa.add_argument('--temperature',type=float,default=150);pa.add_argument('--penalty',type=float,default=1e12)
    a=pa.parse_args();folder=BASE/'structural3d'/a.name
    metadata=folder/'mesh_summary.json'
    if metadata.exists() and json.loads(metadata.read_text()).get('geometry_revision','A')!=a.revision:
        raise RuntimeError('Choose a distinct --name for a different geometry revision')
    if not metadata.exists() or not (folder/'mesh_arrays.npz').exists():
        prepare(folder,a.h,BASE/('geometry_B' if a.revision=='B' else 'geometry'))
    run(folder,a.case,order=a.order,pressure=a.pressure,torque=a.torque,rpm=a.rpm,temperature=a.temperature,
        contact=a.contact,preheat=a.preheat,contact_penalty=a.penalty,contact_mode='small_sliding')
