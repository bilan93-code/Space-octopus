! A spanning tree with the Dirichlet boundary contracted to a single root.
! An interior-only forest leaves a constant-potential gradient mode in each
! component. This project callback fixes those modes without modifying Elmer.
INTEGER FUNCTION MotorTreeGauge(Model,Solver,A,b,x,n,DOFs,Norm) RESULT(Status)
  USE DefUtils
  USE CRSMatrix, ONLY: CRS_SetSymmDirichlet
  IMPLICIT NONE
  TYPE(Model_t) :: Model
  TYPE(Solver_t) :: Solver
  TYPE(Matrix_t),POINTER :: A
  INTEGER :: n,DOFs
  REAL(KIND=dp) :: b(n),x(n),Norm
  TYPE(Mesh_t),POINTER :: Mesh
  TYPE(Element_t),POINTER :: El,OldEl,Edge
  TYPE(ValueList_t),POINTER :: BC
  INTEGER,ALLOCATABLE :: Parent(:),Rank(:)
  LOGICAL,ALLOCATABLE :: Boundary(:),Active(:)
  INTEGER :: i,j,k,nn,root,r1,r2,row,nd,gauged,unrooted
  LOGICAL :: IsDirichlet
  Mesh=>GetMesh(Solver);nn=Mesh%NumberOfNodes
  ALLOCATE(Parent(nn),Rank(nn),Boundary(nn),Active(nn))
  DO i=1,nn
    Parent(i)=i
  END DO
  Rank=0;Boundary=.FALSE.;Active=.FALSE.
  OldEl=>Model%CurrentElement
  DO i=1,Mesh%NumberOfBoundaryElements
    El=>GetBoundaryElement(i)
    Model%CurrentElement=>El;BC=>GetBC()
    IF(.NOT.ASSOCIATED(BC)) CYCLE
    IsDirichlet=ListCheckPrefix(BC,'AV {e}').OR.ListCheckPrefix(BC,'A re {e}').OR. &
                ListCheckPrefix(BC,'Magnetic Flux Density')
    IF(IsDirichlet) Boundary(El%NodeIndexes)=.TRUE.
  END DO
  Model%CurrentElement=>OldEl
  IF(COUNT(Boundary)==0) CALL Fatal('MotorTreeGauge','No magnetic Dirichlet boundary')
  root=FINDLOC(Boundary,.TRUE.,DIM=1)
  WHERE(Boundary) Parent=root
  gauged=0;nd=Solver%Variable%DOFs
  DO k=1,Mesh%NumberOfEdges
    row=Solver%Variable%Perm(k+nn)
    IF(row<=0) CYCLE
    Edge=>Mesh%Edges(k)
    i=Edge%NodeIndexes(1);j=Edge%NodeIndexes(2)
    Active(i)=.TRUE.;Active(j)=.TRUE.
    r1=FindRoot(i);r2=FindRoot(j)
    IF(r1==r2) CYCLE
    IF(Rank(r1)<Rank(r2)) THEN
      Parent(r1)=r2
    ELSE
      Parent(r2)=r1
      IF(Rank(r1)==Rank(r2)) Rank(r1)=Rank(r1)+1
    END IF
    DO i=1,nd
      CALL CRS_SetSymmDirichlet(A,A%RHS,nd*(row-1)+i,0._dp)
    END DO
    gauged=gauged+1
  END DO
  root=FindRoot(root);unrooted=0
  DO i=1,nn
    IF(Active(i)) THEN
      IF(FindRoot(i)/=root) unrooted=unrooted+1
    END IF
  END DO
  WRITE(*,*) 'MOTOR_TREE_GAUGE active,boundary,tree,unrooted:',COUNT(Active),COUNT(Boundary.AND.Active),gauged,unrooted
  IF(unrooted/=0) CALL Fatal('MotorTreeGauge','An active component has no boundary gauge root')
  IF(gauged/=COUNT(Active)-COUNT(Boundary.AND.Active)) CALL Fatal('MotorTreeGauge','Incorrect tree rank')
  DEALLOCATE(Parent,Rank,Boundary,Active)
  Status=0
CONTAINS
  INTEGER FUNCTION FindRoot(node) RESULT(r)
    INTEGER :: node,current,next
    r=node
    DO WHILE(Parent(r)/=r)
      r=Parent(r)
    END DO
    current=node
    DO WHILE(Parent(current)/=r)
      next=Parent(current);Parent(current)=r;current=next
    END DO
  END FUNCTION FindRoot
END FUNCTION MotorTreeGauge
