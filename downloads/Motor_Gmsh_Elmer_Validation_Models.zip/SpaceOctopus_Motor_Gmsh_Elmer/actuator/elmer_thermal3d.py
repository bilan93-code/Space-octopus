"""Executed full motor thermal FE campaign using the declared 3D assembly.

Axial symmetry represents the full motor. Vacuum-facing surfaces are adiabatic;
only the complete external barrel has the declared distributed heat sink.
"""
import argparse,json,re,subprocess
from pathlib import Path
import gmsh
import numpy as np
from .gmsh_elmer_geometry import Geometry
from .elmer_mesh3d import import_assembly
from .elmer_motor import ROOT,BASE,environment,block,common_header,output_solver,solve
from .run import dump


def prepare(folder,h=.0025,geometry_folder=None):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    g=Geometry()
    try:
        parts,data=import_assembly(g,geometry_folder)
        # Fasteners touch the inner cap cavity tangentially and their shank-to-
        # clearance-hole gas gap has no conduction in vacuum. The cap/barrel
        # annulus is modelled in ideal contact; bolt heat paths are omitted.
        for p in list(parts):
            if 'M4Bolt' in p['name']:
                g.occ.remove([(3,p['tag'])],recursive=True);parts.remove(p)
        # The 50 um equivalent interface displaces the outermost steel only in
        # this conduction model. k=thickness*contact conductance; CAD is unchanged.
        contact=g.ring(.04795,.048,0,.085)
        stator=next(p for p in parts if p['name']=='StatorIron')
        cut,_=g.occ.cut([(3,stator['tag'])],[(3,contact)],removeTool=False)
        stator['tag']=cut[0][1]
        parts.append(dict(name='StatorHousingContact',material='contact',tag=contact))
        box=g.occ.addBox(-.2,-.2,.0425,.4,.4,.3)
        half=[]
        for p in parts:
            out,_=g.occ.intersect([(3,p['tag'])],[(3,box)],removeTool=False)
            for dim,tag in out:
                if dim==3:half.append(dict(p,tag=tag))
        g.occ.remove([(3,box)],recursive=True)
        if not half:raise RuntimeError('Empty thermal assembly')
        _,maps=g.occ.fragment([(3,half[0]['tag'])],[(3,p['tag']) for p in half[1:]])
        g.occ.synchronize()
        groups=[];used=set()
        for p,mapped in zip(half,maps):
            tags=[t for d,t in mapped if d==3]
            if not tags:raise RuntimeError('Lost thermal part '+p['name'])
            if used.intersection(tags):raise RuntimeError('Overlapping thermal volumes '+p['name'])
            used.update(tags);groups.append(dict(p,tags=tags))
        for rid,p in enumerate(groups,1):
            p['id']=rid
            gmsh.model.addPhysicalGroup(3,p['tags'],rid);gmsh.model.setPhysicalName(3,rid,p['name'])
        # Sink only on actual outer cylindrical barrel, not end plates or holes.
        barrel=next(p for p in groups if p['name']=='HousingBarrel')
        sink=[]
        for dim,tag in gmsh.model.getBoundary([(3,t) for t in barrel['tags']],combined=True,oriented=False):
            if gmsh.model.getType(dim,tag)!='Cylinder':continue
            uv0,uv1=gmsh.model.getParametrizationBounds(dim,tag)
            xyz=gmsh.model.getValue(dim,tag,((np.array(uv0)+uv1)/2).tolist())
            if abs(np.linalg.norm(xyz[:2])-.056)<1e-6:sink.append(tag)
        if not sink:raise RuntimeError('No barrel heat sink')
        gmsh.model.addPhysicalGroup(2,sink,1000);gmsh.model.setPhysicalName(2,1000,'BarrelSink')
        thin=[]
        for p in groups:
            if p['material'] in ['insulation','bond','wrap','contact']:
                thin.extend(t for d,t in gmsh.model.getBoundary([(3,t) for t in p['tags']],combined=True,oriented=False))
        field=gmsh.model.mesh.field
        dist=field.add('Distance');field.setNumbers(dist,'FacesList',sorted(set(thin)));field.setNumber(dist,'Sampling',100)
        near=field.add('Threshold');field.setNumber(near,'InField',dist)
        field.setNumber(near,'SizeMin',h*.5);field.setNumber(near,'SizeMax',h)
        field.setNumber(near,'DistMin',.00015);field.setNumber(near,'DistMax',.003)
        field.setAsBackgroundMesh(near)
        gmsh.option.setNumber('Mesh.MeshSizeMin',h*.4);gmsh.option.setNumber('Mesh.MeshSizeMax',h)
        gmsh.option.setNumber('Mesh.MeshSizeFromPoints',0);gmsh.option.setNumber('Mesh.MeshSizeFromCurvature',0)
        gmsh.option.setNumber('Mesh.MeshSizeExtendFromBoundary',0)
        gmsh.option.setNumber('Mesh.MinimumCircleNodes',128)
        gmsh.option.setNumber('Mesh.Algorithm3D',10);gmsh.option.setNumber('Mesh.MshFileVersion',2.2)
        gmsh.model.mesh.generate(3)
        gmsh.write(str(folder/'thermal.msh'));gmsh.write(str(folder/'thermal.inp'))
        nodeids,coords,_=gmsh.model.mesh.getNodes();order=np.argsort(nodeids)
        nodeids=np.array(nodeids)[order];coords=np.array(coords).reshape(-1,3)[order]
        nn=len(nodeids);nt=0;quality=[]
        for p in groups:
            p['mesh_half_volume_m3']=0.
            for tag in p['tags']:
                et,ids,connect=gmsh.model.mesh.getElements(3,tag)
                for e,tags,conn in zip(et,ids,connect):
                    if e!=4:raise RuntimeError('Unexpected thermal tetrahedron')
                    nt+=len(tags);quality.extend(gmsh.model.mesh.getElementQualities(tags,'minSICN'))
                    tetra=coords[np.searchsorted(nodeids,np.array(conn).reshape(-1,4))]
                    p['mesh_half_volume_m3']+=float(np.abs(np.linalg.det(tetra[:,1:]-tetra[:,:1])).sum()/6)
        if min(quality)<=0:raise RuntimeError('Invalid thermal mesh')
        meta=dict(status='meshed',units='m',h_m=h,nodes=nn,tetrahedra=nt,
                  min_scaled_jacobian=float(min(quality)),groups=groups,
                  symmetry_factor=2,geometry_revision=data.get('revision','A'),contact_equivalent_thickness_m=.00005,
                  sink_area_full_m2=2*np.pi*.056*.085)
        dump(folder/'mesh_summary.json',meta)
    finally:g.close()
    with environment(),(folder/'grid.log').open('w') as log:
        subprocess.run([str(ROOT/'.local/bin/ElmerGrid'),'14','2','thermal.msh','-autoclean','-names','-out','mesh'],
                       cwd=folder,stdout=log,stderr=subprocess.STDOUT,check=True)
    print('Thermal mesh',nn,'nodes',nt,'tetrahedra',flush=True)
    return meta


def run(folder,name='nominal',sink_C=50.,Iq=10.834,holding=False,resin=.4,
        contact_h=5000.,other_W=18.,sink_R=.05,kw_override=None,initial_case=None,pulse_seconds=None,pulse_steps=100,fixed_copper_C=None,holding_angle_deg=0.):
    folder=Path(folder);meta=json.loads((folder/'mesh_summary.json').read_text())
    if any('mesh_half_volume_m3' not in p for p in meta['groups']):
        nodes=np.loadtxt(folder/'mesh/mesh.nodes');elements=np.loadtxt(folder/'mesh/mesh.elements',dtype=int)
        order=np.argsort(nodes[:,0]);nodeids=nodes[order,0].astype(int);coords=nodes[order,2:5]
        if not np.all(elements[:,2]==504):raise RuntimeError('Unexpected native thermal topology')
        tetra=coords[np.searchsorted(nodeids,elements[:,3:7])]
        vol=np.abs(np.linalg.det(tetra[:,1:]-tetra[:,:1]))/6
        for p in meta['groups']:p['mesh_half_volume_m3']=float(vol[elements[:,1]==p['id']].sum())
        dump(folder/'mesh_summary.json',meta)
    geometry=json.loads((BASE/'geometry/assembly.json').read_text())
    rve=json.loads((BASE/'winding_microstructure/fine/summary.json').read_text())
    rvecase=next(c for c in rve['cases'] if abs(c['resin_k_W_mK']-resin)<1e-10)
    kt=kw_override or rvecase['conservative_transverse_k_W_mK']
    fc=geometry['wire_packing']['bare_copper_fraction_net'];fe=geometry['wire_packing']['coated_wire_area_fraction_net']-fc
    ka=fc*390+fe*.15+(1-fc-fe)*resin
    cpv=fc*8960*385+fe*1200*1400+(1-fc-fe)*1200*1100
    rho=fc*8960+(1-fc)*1200
    r20=.1272529634*geometry['coils'][0]['mean_turn_length_mm']/218.
    case=folder/name;case.mkdir(exist_ok=True)
    sif=common_header(folder/'mesh',3).replace('Steady State Max Iterations = 1','Steady State Max Iterations = 1')
    if pulse_seconds is not None:
        if initial_case is None:raise ValueError('A converged steady thermal initial field is required')
        old=np.load(folder/initial_case/'fields.npz')
        nodes=np.loadtxt(folder/'mesh/mesh.nodes');order=np.argsort(nodes[:,0]);nodes=nodes[order]
        from scipy.spatial import cKDTree
        distance,index=cKDTree(old['p']).query(nodes[:,2:5])
        if distance.max()>2e-8 or len(np.unique(index))!=len(index):raise RuntimeError('Thermal restart coordinate mismatch')
        values=old['temperature_C'][index]
        with (case/'initial_temperature.dat').open('w') as f:
            f.write(str(len(values))+'\n')
            for i,value in enumerate(values,1):f.write('%d %.16g\n'%(i,value))
        sif=sif.replace('Simulation Type = Steady State','Simulation Type = Transient\n  Timestepping Method = BDF\n  BDF Order = 2\n  Timestep Intervals(1) = %d\n  Timestep Sizes(1) = %.16g'%(pulse_steps,pulse_seconds/pulse_steps))
        sif=sif.replace('Output Intervals = 1','Output Intervals = 10')
    sif+=block('Equation',1,['Active Solvers(2) = 1 2'])
    sif+=block('Solver',1,['Equation = "Heat"','Procedure = "HeatSolve" "HeatSolver"','Variable = "Temperature"',
          'Variable DOFs = 1','Linear System Solver = Iterative','Linear System Iterative Method = CG',
          'Linear System Symmetric = True','Linear System Preconditioning = ILU0','Linear System Max Iterations = 2000',
          'Linear System Convergence Tolerance = 1e-10','Linear System Abort Not Converged = True',
          'Nonlinear System Max Iterations = 30','Nonlinear System Convergence Tolerance = 1e-8',
          'Nonlinear System Relaxation Factor = 1','Steady State Convergence Tolerance = 1e-8'])
    sif+=output_solver(2)
    if pulse_seconds is not None and fixed_copper_C is not None:
        sif=sif.replace('Variable DOFs = 1','Variable DOFs = 1\n  Constant Bulk System = Logical True')
    # Each coil occupies the same physical bulk volume. Distribute the electrical
    # loss using actual current and its original/native cold phase resistance.
    # A scalar density is multiplied by local 1+alpha*(T-20), giving FE feedback.
    amp=-np.sqrt(2)*Iq*np.sin(np.deg2rad(holding_angle_deg)-np.arange(3)*2*np.pi/3) if holding else np.ones(3)*Iq
    total_half_coil_volume=sum(gmsh_volume(p) for p in meta['groups'] if p['material']=='winding')
    coil_full_volume=2*total_half_coil_volume/12
    stator_vol=next(gmsh_volume(p) for p in meta['groups'] if p['name']=='StatorIron')*2
    rotor_vol=sum(gmsh_volume(p)*2 for p in meta['groups'] if p['name']=='RotorIron' or p['material']=='magnet')
    for p in meta['groups']:
        rid=p['id'];kind=p['material'];namep=p['name'];force=[]
        k=20.;dens=7650.;cp=460.;special=[]
        if kind=='winding':
            dens=rho;cp=cpv/rho
            special=['Heat Conductivity(3,3) = Variable Coordinate',
                '  Real Procedure "'+str(ROOT/'.local/elmer-user/MotorMaterials')+'" "MotorWindingConductivity"',
                'Motor Coil Axis = Real %.16g'%p['axis_angle_rad'],
                'Motor Winding K Transverse = Real %.16g'%kt,'Motor Winding K Along = Real %.16g'%ka]
            q20=r20/4*amp[p['phase']]**2/coil_full_volume
            force=['Heat Source = Variable Temperature','  Real MATC "%.16g*(1+.00393*(tx-20))/%.16g"'%(q20,dens)]
            if fixed_copper_C is not None:force=['Heat Source = Real %.16g'%(q20*(1+.00393*(fixed_copper_C-20))/dens)]
        elif kind=='aluminum':k=167.;dens=2700.;cp=900.
        elif kind=='insulation':k=.2;dens=1200.;cp=1100.
        elif kind=='magnet':k=10.;dens=8300.;cp=350.
        elif kind=='bond':k=.2;dens=1200.;cp=1100.
        elif kind=='wrap':k=.3;dens=1600.;cp=1000.
        elif kind=='contact':k=contact_h*.00005;dens=1200.;cp=1000.
        elif kind=='bearing_equivalent':k=.5;dens=5000.;cp=460.
        elif namep in ['RotorIron','StatorIron']:
            special=['Heat Conductivity(3,3) = 20 0 0 0 20 0 0 0 1.5']
        else:k=45.
        if namep=='StatorIron':force=['Heat Source = Real %.16g'%(other_W*.8/stator_vol/dens)]
        elif namep=='RotorIron' or kind=='magnet':force=['Heat Source = Real %.16g'%(other_W*.2/rotor_vol/dens)]
        mat=(special or ['Heat Conductivity = Real %.16g'%k])+['Density = Real %.16g'%dens,'Heat Capacity = Real %.16g'%cp]
        sif+=block('Material',rid,mat)
        extra=[]
        if force:sif+=block('Body Force',rid,force);extra=['Body Force = %d'%rid]
        sif+=block('Body',rid,['Target Bodies(1) = %d'%rid,'Equation = 1','Material = %d'%rid,'Initial Condition = 1']+extra)
    names=(folder/'mesh/mesh.names').read_text();bid=int(re.search(r'\$\s+BarrelSink\s*=\s*(\d+)',names).group(1))
    sif+=block('Boundary Condition',1,['Target Boundaries(1) = %d'%bid,
         'Heat Transfer Coefficient = Real %.16g'%(1/(sink_R*meta['sink_area_full_m2'])),
         'External Temperature = Real %.16g'%sink_C])
    if pulse_seconds is None:sif+=block('Initial Condition',1,['Temperature = Real %.16g'%sink_C])
    else:sif+=block('Initial Condition',1,['Temperature = Variable Coordinate',
        '  Real Procedure "'+str(ROOT/'.local/elmer-user/MotorMaterials')+'" "MotorInitialTemperature"'])
    data=solve(case,sif,timeout=1800)
    T=data['point'][next(k for k in data['point'] if k.lower()=='temperature')]
    top=data['topology'];ends=top['offsets'].astype(int);starts=np.r_[0,ends[:-1]]
    sel=top['types'].astype(int)==10;conn=top['connectivity'].astype(int)
    t=np.array([conn[a:b] for a,b,s in zip(starts,ends,sel) if s])
    points=data['points'];v=points[t];vol=np.abs(np.linalg.det(v[:,1:]-v[:,:1]))/6
    region=data['cell']['GeometryIds'].astype(int)[sel];tm=T[t].mean(axis=1)
    stats={};power=0.;power_at_temperature=0.;windingmask=np.zeros(len(t),bool)
    for p in meta['groups']:
        mask=region==p['id'];vm=vol[mask];tn=T[np.unique(t[mask])]
        stats[p['name']]=dict(max_C=float(tn.max()),min_C=float(tn.min()),mean_C=float(tm[mask]@vm/vm.sum()),volume_m3=float(vm.sum()*2))
        if p['material']=='winding':
            windingmask|=mask
            q20=r20/4*amp[p['phase']]**2/coil_full_volume
            local_power=2*q20*np.sum(vm*(1+.00393*(tm[mask]-20)))
            power_at_temperature+=local_power
            power+=local_power if fixed_copper_C is None else 2*q20*np.sum(vm)*(1+.00393*(fixed_copper_C-20))
    windingnodes=np.unique(t[windingmask]);active=windingnodes[points[windingnodes,2]<=.085+1e-9]
    ends=windingnodes[points[windingnodes,2]>.085+1e-9]
    result=dict(status='completed',engine='Elmer 26.2 full 3D HeatSolver',nodes=meta['nodes'],tetrahedra=meta['tetrahedra'],
        symmetry_factor=2,sink_C=sink_C,sink_R_K_W=sink_R,contact_h_W_m2K=contact_h,
        Iq_Arms=Iq,holding=holding,holding_angle_deg=holding_angle_deg,phase_effective_currents_A=amp.tolist(),resin_k_W_mK=resin,
        pulse_duration_s=pulse_seconds,initial_case=initial_case,pulse_time_steps=pulse_steps,fixed_copper_C=fixed_copper_C,
        winding_k_transverse_W_mK=kt,winding_k_along_W_mK=ka,R20_phase_Ohm=r20,
        copper_loss_W=float(power),copper_loss_at_actual_temperature_W=float(power_at_temperature),other_motor_loss_W=other_W,
        winding_hotspot_C=float(T[windingnodes].max()),active_winding_hotspot_C=float(T[active].max()),
        end_turn_hotspot_C=float(T[ends].max()),magnet_hotspot_C=max(v['max_C'] for k,v in stats.items() if k.startswith('Magnet')),
        regions=stats,limits_C=dict(winding=130),
        assumptions=['Barrel sink distributed over entire cylindrical surface','Internal vacuum: no gas convection or radiation',
          'Equivalent bearing conductivity 0.5 W/mK; no measured bearing resistance',
          'Stranded coil tensor from 24-wire FE bounds; local temperature-dependent copper loss',
          'Nominal interface conductance scenario; external sink and material values need validation'])
    result['winding_130C_pass']=result['winding_hotspot_C']<=130
    if not (sink_C-1e-5<=T.min() and T.max()<1000):raise RuntimeError('Nonphysical thermal result')
    np.savez_compressed(case/'fields.npz',p=points,t=t,temperature_C=T,region=region,volume=vol)
    dump(case/'summary.json',result)
    print(name,'winding',result['winding_hotspot_C'],'endturn',result['end_turn_hotspot_C'],'Cu W',power,flush=True)
    return result


def gmsh_volume(p):
    # Half-model bounds and source CAD values give exact full/half volume for all
    # paired regions. Actual FE source integrations are checked after solving.
    if 'mesh_half_volume_m3' in p:return p['mesh_half_volume_m3']
    full=p.get('analytical_volume_m3',p.get('volume_m3'))
    if full is None: # equivalent annular stator-to-housing interface
        return np.pi*(.048**2-.04795**2)*.0425
    lo,hi=p.get('bounds_m',[0,0,0,0,0,.085])[2::3]
    if lo>=.0425-1e-7:return full
    return full*.5


if __name__=='__main__':
    pa=argparse.ArgumentParser();pa.add_argument('--name',default='coarse');pa.add_argument('--h',type=float,default=.003)
    a=pa.parse_args();folder=BASE/'thermal3d'/a.name
    if not (folder/'mesh_summary.json').exists():prepare(folder,a.h)
    run(folder)
