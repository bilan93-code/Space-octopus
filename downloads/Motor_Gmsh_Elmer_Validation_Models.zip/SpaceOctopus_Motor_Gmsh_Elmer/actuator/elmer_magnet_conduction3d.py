"""Verified Elmer/scikit-fem 3D magnet eddy-current geometry response.

Solves insulating conduction with imposed dB/dt. This is the low-frequency,
negligible magnetic-reaction limit; frequency extrapolation is labelled.
"""
import json,re,shutil
from pathlib import Path
import numpy as np
from scipy.sparse.linalg import spsolve
from scipy.spatial import cKDTree
from skfem import MeshTet,Basis,ElementTetP1,BilinearForm,LinearForm,asm,condense,solve as fe_solve
from skfem.helpers import dot,grad
from .elmer_motor import ROOT,BASE,block,common_header,output_solver,solve
from .elmer_magnet_eddy3d import prepare
from .run import dump


def field(x,omega=2*np.pi*126,B0=.01,axis=0):
    if axis==0:return np.array([x[0]*0,.5*omega*B0*(x[2]-.0425),-.5*omega*B0*x[1]])
    return np.array([-.5*omega*B0*(x[2]-.0425),x[0]*0,.5*omega*B0*x[0]])


def run(folder,axis=0,freq=126.,B0=.01,T=80.):
    folder=Path(folder);meta=json.loads((folder/'mesh_summary.json').read_text())
    case=folder/('conduction_%s_%gHz'%('xy'[axis],freq));case.mkdir(exist_ok=True)
    sigma=1/(.9e-6*(1+.0003*(T-20)))
    sif=common_header(folder/'mesh',3)
    sif+=block('Equation',1,['Active Solvers(2) = 1 2'])
    sif+=block('Solver',1,['Equation = "MagnetConduction3D"','Procedure = "StatCurrentSolve" "StatCurrentSolver"',
         'Variable = "Potential"','Variable DOFs = 1','Linear System Solver = Direct','Linear System Direct Method = umfpack',
         'Linear System Convergence Tolerance = 1e-11','Steady State Convergence Tolerance = 1e-9'])
    sif+=output_solver(2)
    sif+=block('Material',1,['Electric Conductivity = Real %.16g'%sigma])
    for j in range(1,meta['segments']+1):sif+=block('Body',j,['Target Bodies(1) = %d'%j,'Equation = 1','Material = 1'])
    names=(folder/'mesh/mesh.names').read_text();bid=int(re.search(r'\$\s+ImposedField\s*=\s*(\d+)',names).group(1))
    sif+=block('Boundary Condition',1,['Target Boundaries(1) = %d'%bid,'Current Density = Variable Coordinate',
       '  Real Procedure "'+str(ROOT/'.local/elmer-user/MotorEddy')+'" "MotorEddyFlux"',
       'Motor Eddy Sigma = Real %.16g'%sigma,'Motor Eddy Omega = Real %.16g'%(2*np.pi*freq),
       'Motor Eddy Bpeak = Real %.16g'%B0,'Motor Eddy Axis = Integer %d'%axis])
    elements=np.loadtxt(folder/'mesh/mesh.elements',dtype=int);native=np.loadtxt(folder/'mesh/mesh.nodes')
    pins=[]
    for j in range(1,meta['segments']+1):
        node=int(elements[elements[:,1]==j,3][0]);pins.append(node-1)
        sif+=block('Boundary Condition',j+1,['Target Nodes(1) = %d'%node,'Potential = Real 0'])
    data=solve(case,sif,timeout=300,check_nonlinear=False)
    points=data['points'];phi=data['point']['potential']
    top=data['topology'];ends=top['offsets'].astype(int);starts=np.r_[0,ends[:-1]];conn=top['connectivity'].astype(int)
    selected=top['types']==10;t=np.array([conn[a:b] for a,b,s in zip(starts,ends,selected) if s])
    v=points[t];dxy=v[:,1:]-v[:,:1];dphi=phi[t[:,1:]]-phi[t[:,:1]]
    gradient=np.linalg.solve(dxy,dphi);vol=np.abs(np.linalg.det(dxy))/6
    ec=field(v.mean(axis=1).T,2*np.pi*freq,B0,axis).T
    ev=field(np.moveaxis(v,-1,0),2*np.pi*freq,B0,axis).transpose(1,2,0)
    # Exact integration of a squared affine electric field over each tetrahedron.
    variance=np.sum((ev-ec[:,None,:])**2,axis=(1,2))/20
    q=.5*sigma*(np.sum((ec-gradient)**2,axis=1)+variance)
    power=float(vol@q)
    mesh=MeshTet(points.T,t.T,sort_t=False);basis=Basis(mesh,ElementTetP1())
    @BilinearForm
    def laplace(u,v,w):return sigma*dot(grad(u),grad(v))
    @LinearForm
    def rhs(v,w):return sigma*dot(field(w.x,2*np.pi*freq,B0,axis),grad(v))
    K=asm(laplace,basis);F=asm(rhs,basis)
    native=native[np.argsort(native[:,0])]
    distance,mapidx=cKDTree(points).query(native[:,2:5])
    if distance.max()>2e-8:raise RuntimeError('Independent conductor node mapping mismatch')
    pinidx=mapidx[pins]
    independent=fe_solve(*condense(K,F,D=pinidx))
    error=np.linalg.norm(phi-independent)/np.linalg.norm(independent)
    residual=K@phi-F;free=np.setdiff1d(np.arange(len(phi)),pinidx)
    relative=float(np.linalg.norm(residual[free])/np.linalg.norm(F[free]))
    if error>2e-5 or relative>2e-5:raise RuntimeError('Elmer/scikit-fem conductor verification failed '+str((error,relative)))
    totalcurrent=float(np.abs(residual[pinidx]).max())
    result=dict(status='completed',engine='Elmer 26.2 StatCurrentSolver with prescribed Faraday excitation; independent scikit-fem solve',
       segments=meta['segments'],h_m=meta['h_m'],nodes=len(points),tetrahedra=len(t),T_C=T,
       frequency_Hz=freq,B_peak_T=B0,axis='xy'[axis],pole_loss_W=power,
       loss_over_f2_Bpeak2_W_Hz2_T2=power/(freq**2*B0**2),
       potential_relative_error_vs_independent=float(error),linear_residual_relative=relative,
       pin_spurious_current_A=totalcurrent,skin_depth_m=float(np.sqrt(2/(4e-7*np.pi*1.05*sigma*2*np.pi*freq))),
       notes=['Three-dimensional electrically isolated segments and closed return currents',
              'Imposed uniform induction derivative: magnetic conductive reaction is omitted',
              'Frequency-squared scaling is a low-frequency approximation, not a validated PWM loss prediction'])
    dump(case/'summary.json',result)
    np.savez_compressed(case/'fields.npz',p=points,t=t,potential=phi,current_peak_A_m2=sigma*(ec-gradient),joule_W_m3=q,volume=vol)
    print(meta['segments'],'xy'[axis],power,'crosscheck',error,'pin current',totalcurrent,flush=True)
    return result


def campaign():
    rows=[]
    for name,h in [('coarse',.001),('fine',.00065)]:
        for n in [1,4]:
            folder=BASE/'magnet_conduction3d'/name/str(n)
            if not (folder/'mesh_summary.json').exists():prepare(folder,n,h)
            for axis in [0,1]:rows.append(run(folder,axis))
    summary=dict(status='completed',rows=rows)
    dump(BASE/'magnet_conduction3d/summary.json',summary)
    return summary


if __name__=='__main__':campaign()
