"""Native Simu1/OutMag/ForceMT integration with real Elmer field extraction."""
import json
from pathlib import Path
import numpy as np
from scipy.spatial import cKDTree
from pyleecan.Classes.MagElmer import MagElmer
from pyleecan.Classes.OutMagElmer import OutMagElmer
from pyleecan.Classes.Simu1 import Simu1
from pyleecan.Classes.InputCurrent import InputCurrent
from pyleecan.Classes.OPdq import OPdq
from pyleecan.Classes.Output import Output
from pyleecan.Classes.ForceMT import ForceMT
from pyleecan.Classes.LUTdq import LUTdq
from .elmer_motor import ROOT,BASE,magnetostatic_2d
from .magnetics import MagneticModel
from .machine import build_machine
from .run import dump


class MotorMagElmer(MagElmer):
    """Project extension of the official class; upstream files remain unchanged."""
    def comp_flux_airgap(self,output,axes_dict,Is_val=None,Ir_val=None):
        cfg=json.loads((ROOT/"configs/motor_candidate.json").read_text())
        machine=output.simu.machine
        if output.mag.internal is None:output.mag.internal=OutMagElmer()
        angle_axis=axes_dict["angle"];time_axis=axes_dict["time"]
        _,anti_a=angle_axis.get_periodicity();_,anti_t=time_axis.get_periodicity()
        angle=angle_axis.get_values(is_oneperiod=self.is_periodicity_a,
                                  is_antiperiod=anti_a and self.is_periodicity_a)
        time=time_axis.get_values(is_oneperiod=self.is_periodicity_t,
                                 is_antiperiod=anti_t and self.is_periodicity_t)
        rotor=np.asarray(output.get_angle_rotor())[:len(time)]
        currents=np.asarray(Is_val)
        if currents.shape==(3,len(time)):currents=currents.T
        if currents.shape!=(len(time),3):raise ValueError("Native Elmer current-axis mismatch "+str(currents.shape))
        br=[];bt=[];torque=[];flux=[];rows=[]
        sample_angle=np.arange(2048)*2*np.pi/2048
        for i,(a,current) in enumerate(zip(rotor,currents)):
            folder=Path(output.get_path_result())/("pose_%02d"%i)
            folder.mkdir(parents=True,exist_ok=True)
            fe=MagneticModel(machine,cfg,h=.002,angle=float(a))
            summary_path=folder/"summary.json";field_path=folder/"field.npz"
            reuse=False
            if summary_path.exists() and field_path.exists():
                saved=json.loads(summary_path.read_text());cached=np.load(field_path)
                if saved["temperature_C"]==80 and np.allclose(saved["currents_ABC_A"],current,rtol=0,atol=1e-12):
                    distances,index=cKDTree(cached["p"].T).query(fe.mesh.p.T)
                    if distances.max()<1e-12 and len(np.unique(index))==fe.mesh.nvertices:
                        aa=cached["A"][index];gg=fe.basis.interpolate(aa).grad.mean(axis=2)
                        field=dict(a=aa,B=np.array([gg[1],-gg[0]]),phase_flux_Wb=fe.machine.stator.L1*(fe.phase_rhs@aa))
                        result=saved;reuse=True
            if not reuse:field,result=magnetostatic_2d(fe,folder,current,temp=80,nonlinear=True)
            radial,tangent=fe.airgap_fields(field,.02625)
            br.append(np.interp(angle%(2*np.pi),sample_angle,radial,period=2*np.pi))
            bt.append(np.interp(angle%(2*np.pi),sample_angle,tangent,period=2*np.pi))
            # Native Magnetics.run integrates these per-unit-length quantities
            # over the axial slice model. B itself is a local field, unchanged.
            torque.append(result["torque_Nm"]/machine.stator.L1)
            flux.append(np.asarray(result["phase_flux_Wb"])/machine.stator.L1)
            rows.append(dict(rotor_angle_rad=float(a),**result))
            dump(Path(output.get_path_result())/"progress.json",rows)
            print("Native MagElmer pose",i+1,"/",len(time),"torque",result["torque_Nm"],flush=True)
        return {
            "B_{rad}":np.asarray(br),"B_{circ}":np.asarray(bt),
            "B_{ax}":np.zeros_like(br),"Tem":np.asarray(torque),
            "Phi_wind":{machine.stator.get_label():np.asarray(flux)}
        }


def run_native():
    cfg=json.loads((ROOT/"configs/motor_candidate.json").read_text())
    out=BASE/"native_api_2d_24";out.mkdir(parents=True,exist_ok=True)
    magnetic=MotorMagElmer(is_periodicity_a=True,is_periodicity_t=True,is_get_mesh=False,T_mag=80)
    simu=Simu1(name="SpaceOctopus_MotorMagElmer",machine=build_machine(cfg),
               input=InputCurrent(OP=OPdq(N0=630.,Id_ref=0.,Iq_ref=10.814),
                                  Nt_tot=240,Na_tot=128,Nrev=1),
               mag=magnetic,force=ForceMT(),elec=None,struct=None,loss=None)
    output=Output(simu=simu,path_result=str(out.resolve()))
    result=simu.run()
    dq=LUTdq(simu=result.simu.copy(),output_list=[result]).get_Phi_dqh_mean()[0]
    torque=np.asarray(result.mag.Tem.values).ravel()
    reference=json.loads((ROOT/"results/motor/full_period/288/status.json").read_text())
    summary=dict(status="completed",pipeline="Native Simu1 -> MotorMagElmer subclass -> official MagElmer mesh converter -> Elmer -> real VTU readback -> native OutMag, LUTdq and ForceMT",
                 poses=len(torque),mean_torque_Nm=float(torque.mean()),torque_pp_Nm=float(np.ptp(torque)),
                 Phid_rms_Wb=float(dq[0]),Phiq_rms_Wb=float(dq[1]),
                 native_FEMM_reference_mean_torque_Nm=reference["torque_Nm"],
                 relative_mean_torque_difference=abs(float(torque.mean())/reference["torque_Nm"]-1),
                 installed_Pyleecan_sources_modified=False,upstream_zero_flux_extraction_replaced_in_project_adapter=True)
    dump(out/"summary.json",summary)
    print(json.dumps(summary,indent=2),flush=True)
    return result


if __name__=="__main__":run_native()
