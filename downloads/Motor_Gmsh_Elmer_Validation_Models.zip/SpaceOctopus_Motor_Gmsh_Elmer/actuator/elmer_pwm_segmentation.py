"""Transfer measured-in-model 3D segmentation factors to recorded PWM spectra.

This is an explicitly limited sensitivity model, not a complete motor AC solve:
the FEMM response includes the motor but continuous axial magnets; Elmer supplies
isolated-pole directional 3D segmentation factors under clamped uniform fields.
"""
import hashlib
import json
import numpy as np
from .elmer_motor import ROOT,BASE
from .run import dump


def run():
    out=BASE/'pwm_segmentation';out.mkdir(exist_ok=True)
    factors=[]
    for f in [20000,40000,80000]:
        directional={}
        for axis in ['x','y']:
            power=[]
            for n in [1,4]:
                p=BASE/('magnet_eddy3d/rooted_fine/%d/%gHz_%s_80C/summary.json'%(n,f,axis))
                d=json.loads(p.read_text());assert d['status']=='completed'
                power.append(d['pole_loss_W'])
            directional[axis]=dict(unsegmented_pole_W=power[0],four_segment_pole_W=power[1],ratio=power[1]/power[0])
        factors.append(dict(frequency_Hz=f,directional=directional,
            minimum_ratio=min(d['ratio'] for d in directional.values()),maximum_ratio=max(d['ratio'] for d in directional.values())))
    response=json.loads((ROOT/'results/motor/extensions/harmonics/magnet_summary.json').read_text())
    rows=sorted([r for r in response['rows'] if r['magnet_C']==80 and r['magnet_mesh_m']==.0003],key=lambda r:r['frequency_Hz'])
    axis=np.array([r['frequency_Hz'] for r in rows]);results=[]
    sources=sorted([*ROOT.glob('results/motor/candidate_drive/PWM_*.npz'),*ROOT.glob('results/motor/extensions/nonlinear_drive/PWM_*.npz')])
    spectra=[]
    for source in sources:
        values=np.load(source)['data'];values=values[values[:,0]>.075];t=values[:,0]
        i=values[:,1:3]-values[:,1:3].mean(axis=0);w=np.hanning(len(t))
        Z=np.sqrt(2)*np.fft.rfft(i*w[:,None],axis=0)/(len(t)*np.sqrt(np.mean(w*w)))
        f=np.fft.rfftfreq(len(t),np.median(np.diff(t)));pick=f>=1000;f=f[pick];Z=Z[pick]
        cached=out/('spectrum_'+source.parent.name+'_'+source.stem+'.npz')
        np.savez_compressed(cached,frequency_Hz=f,dq_rms_complex_A=Z,source=str(source.relative_to(ROOT)),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest())
        spectra.append(cached)
    if not spectra:spectra=sorted(out.glob('spectrum_*.npz'))
    if not spectra:raise RuntimeError('Recorded current spectra are missing')
    for cached in spectra:
        data=np.load(cached);f=data['frequency_Hz'];Z=data['dq_rms_complex_A']
        dd=np.interp(f,axis,[r['unit_basis_losses_W']['d'] for r in rows])
        qq=np.interp(f,axis,[r['unit_basis_losses_W']['q'] for r in rows])
        cross=[]
        for r in rows:
            p=r['unit_basis_losses_W'];cross.append((p['d_plus_q']-p['d']-p['q'])/2-1j*(p['d_plus_jq']-p['d']-p['q'])/2)
        re=np.interp(f,axis,np.real(cross));im=np.interp(f,axis,np.imag(cross))
        power=(dd*abs(Z[:,0])**2+qq*abs(Z[:,1])**2+2*np.real(np.conj(Z[:,0])*(re+1j*im)*Z[:,1]))*np.maximum(1.,(f/80000)**2)
        if power.min()<-1e-10:raise RuntimeError('Nonpositive response energy')
        lower=np.interp(f,axis,[r['minimum_ratio'] for r in factors]);upper=np.interp(f,axis,[r['maximum_ratio'] for r in factors])
        variance=np.sum(abs(Z)**2,axis=1);outside=(f<20000)|(f>80000)
        results.append(dict(current_waveform=str(data['source']),source_sha256=str(data['source_sha256']),
            continuous_2D_reference_loss_W=float(power.sum()),
            segmented_3D_shape_sensitivity_low_W=float(np.sum(power*lower)),
            segmented_3D_shape_sensitivity_high_W=float(np.sum(power*upper)),
            current_variance_outside20to80kHz_fraction=float(variance[outside].sum()/variance.sum())))
    result=dict(status='completed',magnet_response_temperature_C=80,segmentation_factors=factors,rows=results,
        engine='Recorded dq PWM spectra + Hermitian full-motor FEMM response + directional Elmer 3D segmentation sensitivity',
        limitations=['Directional shape-factor transfer is not a rigorous full-motor loss bound; actual fields are nonuniform',
           'Old drive waveforms and DC bias are retained, not re-solved for the new 13 A controller profile',
           'Frequency response below 20 kHz clamps to 20 kHz; above 80 kHz uses f-squared continuation with endpoint shape factors',
           '80°C conductor response differs from the 120°C design temperature; no supplier loss calibration',
           'Steel PWM loss, winding proximity and inverter loss remain separate and are not proven by this magnet sensitivity'])
    dump(out/'summary.json',result);print(json.dumps(result,indent=2),flush=True);return result


if __name__=='__main__':run()
