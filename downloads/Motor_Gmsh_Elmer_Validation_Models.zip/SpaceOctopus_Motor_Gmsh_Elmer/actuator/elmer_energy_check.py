"""Independent rotational coenergy derivative and mesh-motion consistency."""
import json,shutil
from pathlib import Path
import numpy as np
from .elmer_motor import BASE,MU0
from .elmer_magnetic3d import run,abc_currents,ANGLE_REFERENCE
from .run import dump


def taper(x,a,b):
    u=np.clip((x-a)/(b-a),0,1)
    return 1-3*u*u+2*u*u*u


def prepare(source,folder,delta):
    source=Path(source);folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    if (folder/'mesh').exists():shutil.rmtree(folder/'mesh')
    shutil.copytree(source/'mesh',folder/'mesh')
    meta=json.loads((source/'mesh_summary.json').read_text())
    nodes=np.loadtxt(folder/'mesh/mesh.nodes');p=nodes[:,2:5];r=np.linalg.norm(p[:,:2],axis=1)
    weight=taper(r,.02610,.02645)*taper(p[:,2],.125,.145)
    a=delta*weight;c=np.cos(a);s=np.sin(a);q=p.copy();q[:,0]=c*p[:,0]-s*p[:,1];q[:,1]=s*p[:,0]+c*p[:,1]
    elements=np.loadtxt(folder/'mesh/mesh.elements',dtype=int)
    order=np.argsort(nodes[:,0]);ids=nodes[order,0].astype(int);v=p[order][np.searchsorted(ids,elements[:,3:7])]
    vnew=q[order][np.searchsorted(ids,elements[:,3:7])]
    jac=np.linalg.det(v[:,1:]-v[:,:1]);jacnew=np.linalg.det(vnew[:,1:]-vnew[:,:1]);ratio=jacnew/jac
    if ratio.min()<.15:raise RuntimeError('Rotated mesh determinant gate failed '+str(ratio.min()))
    with (folder/'mesh/mesh.nodes').open('w') as f:
        for row,xyz in zip(nodes,q):f.write('%d %d %.17g %.17g %.17g\n'%(row[0],row[1],*xyz))
    meta.update(rotor_angle_rad=meta['rotor_angle_rad']+delta,coordinate_deformation_rad=delta,
       minimum_Jacobian_ratio=float(ratio.min()),deformation='Smooth air-only r/z rotation window; magnetic bodies rigidly rotated, stator/coils fixed')
    dump(folder/'mesh_summary.json',meta)
    return meta


def linear_coenergy(folder):
    folder=Path(folder);x=np.load(folder/'linear/fields.npz');meta=json.load(open(folder/'mesh_summary.json'))
    B=x['B'];volume=x['volume'];region=x['region'];energy=0.
    for part in meta['groups']:
        sel=region==part['id']
        if part['name'] in ['StatorIron','RotorIron']:nu=np.array([1/1500,1/1500,1/19.75])/MU0
        elif part['name']=='Shaft':nu=np.ones(3)/(1500*MU0)
        elif part['material']=='magnet':nu=np.ones(3)/(1.05*MU0)
        else:nu=np.ones(3)/MU0
        energy+=float(np.sum(volume[sel]*.5*np.sum(B[sel]**2*nu,axis=1)))
    return 2*energy


def campaign():
    source=BASE/'magnetic3d/coarse';out=BASE/'energy_rotation';out.mkdir(exist_ok=True)
    rows=[]
    for angle in [-.5,-.25,.25,.5]:
        delta=np.deg2rad(angle);name=str(angle).replace('-','minus').replace('.','p')
        folder=out/name;prepare(source,folder,delta)
        Id=10.814*np.sin(5*delta);Iq=10.814*np.cos(5*delta)
        assert np.max(abs(abc_currents(ANGLE_REFERENCE+delta,Id,Iq)-abc_currents(ANGLE_REFERENCE)))<1e-10
        result=run(folder,'linear',Id=Id,Iq=Iq,linear=True,direct='cholmod')
        row=dict(angle_offset_deg=angle,coenergy_J=linear_coenergy(folder),case=name,torque_legacy_Nm=result['torque_Nm'],air_maxwell_Nm=result['air_maxwell_enclosure']['torque_Nm'])
        rows.append(row);dump(out/'progress.json',rows);print(row,flush=True)
    lookup={r['angle_offset_deg']:r for r in rows};derivatives=[]
    for delta in [.25,.5]:
        derivatives.append(dict(delta_deg=delta,coenergy_derivative_torque_Nm=(lookup[delta]['coenergy_J']-lookup[-delta]['coenergy_J'])/(2*np.deg2rad(delta))))
    result=dict(status='completed',method='Fixed ABC current, symmetric finite rotation of material geometry; derivative of total linear coenergy',rows=rows,derivatives=derivatives)
    dump(out/'summary.json',result);return result


if __name__=='__main__':campaign()
