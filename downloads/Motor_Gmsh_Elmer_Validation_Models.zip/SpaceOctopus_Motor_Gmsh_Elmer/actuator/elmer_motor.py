"""Working motor-specific MagElmer extension; installed Pyleecan is unchanged.

The official MagElmer mesh-conversion method is used for 2D. The project supplies
explicit source normalization, solver files, VTU readback and checked quantities
in place of the upstream unfinished zero-valued flux extraction.
"""
import json
import fcntl
import hashlib
import logging
import os
import re
import subprocess
import resource
import xml.etree.ElementTree as ET
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace

import numpy as np
from scipy.spatial import cKDTree
from pyleecan.Classes.MagElmer import MagElmer
from pyleecan.Functions.labels import decode_label
from pyleecan.Functions.load import load
from pyleecan.definitions import DATA_DIR
from .machine import build_machine
from .magnetics import MagneticModel, MU0
from .run import dump, phase_q

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "results/motor/gmsh_elmer"


@contextmanager
def environment(threads=2):
    values = {
        "PATH": str(ROOT / ".local/bin") + ":" + os.environ["PATH"],
        "ELMER_HOME": str(ROOT / ".local/elmer"),
        "OMP_NUM_THREADS": str(threads),
        "OPENBLAS_NUM_THREADS": "1",
        "GFORTRAN_UNBUFFERED_ALL": "1",
    }
    old = {k: os.environ.get(k) for k in values}
    os.environ.update(values)
    try:
        yield
    finally:
        for k, v in old.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v


def block(kind, number, lines):
    return kind + (" " + str(number) if number is not None else "") + "\n  " + "\n  ".join(lines) + "\nEnd\n\n"


def read_vtu(path):
    """Read ASCII VTU output, refusing binary rather than interpreting garbage."""
    tree = ET.parse(path)
    piece = tree.find(".//Piece")
    def arrays(section):
        result = {}
        for a in piece.findall(section + "/DataArray"):
            if a.get("format", "ascii").lower() != "ascii":
                raise ValueError("ASCII VTU output required")
            data = np.fromstring(a.text or "", sep=" ")
            n = int(a.get("NumberOfComponents", 1))
            if n > 1:
                data = data.reshape(-1, n)
            result[a.get("Name", "points")] = data
        return result
    return dict(points=next(iter(arrays("Points").values())),
                point=arrays("PointData"), cell=arrays("CellData"), topology=arrays("Cells"))


def solve(case, sif, timeout=1800, check_nonlinear=True, hpc=False):
    case=Path(case);case.mkdir(parents=True,exist_ok=True)
    with (case/".solve.lock").open("w") as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise RuntimeError("This Elmer case is already running: "+str(case))
        try:return _solve_locked(case,sif,timeout,check_nonlinear,hpc)
        except Exception as exc:
            dump(case/'solver_status.json',dict(status='failed',sif_sha256=hashlib.sha256(sif.encode()).hexdigest(),error=str(exc)[:1500]))
            raise


def _solve_locked(case,sif,timeout,check_nonlinear,hpc=False):
    case = Path(case); case.mkdir(parents=True, exist_ok=True)
    sif=sif.replace('Output File Name = "field"',
        'Output File Name = "field"\n  Output Directory = "'+str(case.resolve())+'"')
    (case / "case.sif").write_text(sif)
    dump(case/"solver_status.json",dict(status="running",sif_sha256=hashlib.sha256(sif.encode()).hexdigest()))
    with environment(), (case / "solver.log").open("w") as log:
        def stack_limit():
            soft,hard=resource.getrlimit(resource.RLIMIT_STACK)
            resource.setrlimit(resource.RLIMIT_STACK,(hard,hard))
        executable=ROOT / ('.local/bin/ElmerSolverHPC' if hpc else '.local/bin/ElmerSolver')
        p = subprocess.Popen([str(executable), "case.sif"],
                           cwd=case, stdout=log, stderr=subprocess.STDOUT,preexec_fn=stack_limit)
        (case/".solver.pid").write_text(str(p.pid))
        try:
            p.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            p.terminate()
            try:p.wait(timeout=10)
            except subprocess.TimeoutExpired:p.kill();p.wait()
            raise
        finally:
            (case/".solver.pid").unlink(missing_ok=True)
    log = (case / "solver.log").read_text()
    if p.returncode or "ELMER SOLVER FINISHED" not in log or "FATAL" in log:
        raise RuntimeError("Elmer failed with exit "+str(p.returncode)+": " + str(case) + "\n" + log[-2400:])
    if "not converged" in log.lower() or "failed convergence" in log.lower():
        raise RuntimeError("Elmer convergence not accepted: " + str(case))
    hypre=re.findall(r'Required iterations\s+\d+.*?to norm\s+([0-9.eE+-]+)',log)
    if hypre and max(map(float,hypre))>1.1e-8:
        raise RuntimeError('HYPRE linear residual gate failed: '+str(max(map(float,hypre))))
    changes=re.findall(r"ComputeChange: NS.*?\(\s*([0-9.eE+-]+)\s+([0-9.eE+-]+)\s*\)\s*::\s*(\S+)",log)
    if check_nonlinear and changes and float(changes[-1][1])>1e-7:
        raise RuntimeError("Nonlinear relative-change gate failed: "+str(changes[-1]))
    files = sorted(case.glob("**/field*.vtu"))
    if not files:
        raise RuntimeError("No Elmer field output in " + str(case))
    data = read_vtu(files[-1])
    if not all(np.all(np.isfinite(a)) for a in data["point"].values()):
        raise RuntimeError("Non-finite Elmer output")
    if not all(np.all(np.isfinite(a)) for a in data["cell"].values()):
        raise RuntimeError("Non-finite Elmer element output")
    dump(case/"solver_status.json",dict(status="field_output_verified",sif_sha256=hashlib.sha256(sif.encode()).hexdigest(),exit_code=p.returncode))
    return data


def output_solver(number=3):
    return block("Solver", number, [
        'Equation = "ResultOutput"', 'Procedure = "ResultOutputSolve" "ResultOutputSolver"',
        "Exec Solver = After Simulation", 'Output File Name = "field"',
        "Vtu Format = Logical True", "Ascii Output = Logical True",
        "Single Precision = Logical False", "Save Geometry Ids = Logical True",
    ])


def common_header(mesh, dim):
    mesh = Path(mesh)
    directory = str(mesh.parent) if mesh.is_absolute() else "."
    return ('Check Keywords Warn\n\n' +
            block("Header", None, ['Mesh DB "' + directory + '" "' + mesh.name + '"']) +
            block("Simulation", None, [
                'Coordinate System = "' + ("Cartesian 2D" if dim == 2 else "Cartesian") + '"',
                "Simulation Type = Steady State", "Steady State Max Iterations = 1",
                "Max Output Level = 4", "Output Intervals = 1",
            ]) +
            block("Constants", None, ["Permeability Of Vacuum = Real %.16g" % MU0]))


def bh_material(number=2, nonlinear=True):
    if not nonlinear:
        return block("Material", number, ["Relative Permeability = 1500", "Electric Conductivity = 0"])
    curve = np.asarray(load(DATA_DIR + "/Material/M270-35A.json").mag.BH_curve.get_data())
    h, b = curve[:, 0], curve[:, 1]
    slope = (h[-1] - h[-2]) / (b[-1] - b[-2])
    b2 = np.r_[b, 2.0, 2.5, 3.0, 4.0]
    h2 = np.r_[h, h[-1] + (b2[len(b):] - b[-1]) * slope]
    lines = ["Electric Conductivity = 0", "H-B Curve = Variable coupled iter", "  Real"]
    lines += ["    %.14g %.14g" % pair for pair in zip(b2, h2)]
    lines += ["  End"]
    return block("Material", number, lines)


def mesh_2d(fe, path):
    """Export the Gmsh mesh with explicit physical regions and outside boundary."""
    path = Path(path)
    mesh = fe.mesh
    regions = sorted(fe.labels)
    names = {rid + 1: label.replace(" ", "_") for rid, label in fe.labels.items()}
    boundary = mesh.facets[:, mesh.boundary_facets()].T
    with path.open("w") as f:
        f.write("$MeshFormat\n2.2 0 8\n$EndMeshFormat\n$PhysicalNames\n%d\n" % (len(names)+1))
        for rid, name in names.items():
            f.write('2 %d "%s"\n' % (rid, name))
        f.write('1 1000 "VP0_BOUNDARY"\n$EndPhysicalNames\n$Nodes\n%d\n' % mesh.nvertices)
        for i, (x, y) in enumerate(mesh.p.T, 1):
            f.write("%d %.16g %.16g 0\n" % (i, x, y))
        f.write("$EndNodes\n$Elements\n%d\n" % (len(boundary) + mesh.nelements))
        idx = 0
        for edge in boundary:
            idx += 1
            f.write("%d 1 2 1000 1000 %d %d\n" % (idx, edge[0]+1, edge[1]+1))
        for tri, rid in zip(mesh.t.T, fe.region):
            idx += 1
            f.write("%d 2 2 %d %d %d %d %d\n" % (idx, rid+1, rid+1, tri[0]+1, tri[1]+1, tri[2]+1))
        f.write("$EndElements\n")
    return names


def convert_2d(fe, folder):
    folder = Path(folder)
    magnetic = MagElmer()
    output = SimpleNamespace(get_path_result=lambda: str(folder.resolve()))
    project = Path(magnetic.get_path_save_fea(output))
    names = mesh_2d(fe, str(project) + ".msh")
    with environment():
        if not magnetic.gen_elmer_mesh(output):
            raise RuntimeError("Official MagElmer.gen_elmer_mesh failed")
    return project, names


def magnetostatic_2d(fe, case, currents, temp=80, nonlinear=True, prepared=None):
    case = Path(case); case.mkdir(parents=True, exist_ok=True)
    project, names = convert_2d(fe, case) if prepared is None else prepared
    c = fe.config["motor"]
    br = c["magnet_Br20_T"] * (1 + c["magnet_alpha_per_K"] * (temp-20))
    sif = common_header(project, 2)
    sif += block("Equation", 1, ["Active Solvers(3) = 1 2 3"])
    sif += block("Solver", 1, [
        'Equation = "Magnetostatics"', 'Procedure = "MagnetoDynamics2D" "MagnetoDynamics2D"',
        'Variable = "Potential"', "Variable DOFs = 1",
        "Nonlinear System Max Iterations = 100", "Nonlinear System Convergence Tolerance = 1e-8",
        "Nonlinear System Newton After Iterations = 5", "Nonlinear System Newton After Tolerance = 1e-3",
        "Nonlinear System Relaxation Factor = 1",
        "Linear System Solver = Direct", 'Linear System Direct Method = "umfpack"',
        "Linear System Convergence Tolerance = 1e-10", "Steady State Convergence Tolerance = 1e-8",
    ])
    sif += block("Solver", 2, [
        'Equation = "Fields"', 'Procedure = "MagnetoDynamics" "MagnetoDynamicsCalcFields"',
        'Potential Variable = "Potential"', "Calculate Magnetic Flux Density = True",
        "Calculate Magnetic Field Strength = True", "Calculate Elemental Fields = True",
        "Calculate Nodal Fields = False",
    ])
    sif += output_solver()
    sif += block("Material", 1, ["Relative Permeability = 1", "Electric Conductivity = 0"])
    sif += bh_material(nonlinear=nonlinear)
    conn = fe.machine.stator.winding.get_connection_mat(12)
    force_number = 0
    for rid, name in names.items():
        label = fe.labels[rid-1]
        mat = 2 if "_Lam" in label else 1
        force = []
        if "_Magnet" in label:
            pole = decode_label(label)["S_id"]
            mat = 3 + pole
            sign = (-1)**pole
            strength = sign * br / (MU0*c["magnet_mu_r"])
            sif += block("Material", mat, [
                "Relative Permeability = %.16g" % c["magnet_mu_r"], "Electric Conductivity = 0",
                "Magnetization 1 = Variable Coordinate",
                '  Real MATC "%.16g*tx(0)/sqrt(tx(0)^2+tx(1)^2)"' % strength,
                "Magnetization 2 = Variable Coordinate",
                '  Real MATC "%.16g*tx(1)/sqrt(tx(0)^2+tx(1)^2)"' % strength,
            ])
        if "_Winding" in label:
            ids = decode_label(label)
            mask = fe.region == rid-1
            density = conn[ids["R_id"],ids["T_id"],ids["S_id"]] @ currents / fe.areas[mask].sum()
            force_number += 1
            force = ["Body Force = %d" % force_number]
            sif += block("Body Force", force_number, ["Current Density = Real %.16g" % density])
        sif += block("Body", rid, ["Target Bodies(1) = %d" % rid, 'Name = "'+name+'"',
                                  "Equation = 1", "Material = %d" % mat] + force)
    names_text=(project/"mesh.names").read_text()
    boundary_id=int(re.search(r"\$\s+VP0_BOUNDARY\s*=\s*(\d+)",names_text).group(1))
    sif += block("Boundary Condition", 1, ["Target Boundaries(1) = %d"%boundary_id, "Potential = Real 0"])
    data = solve(case, sif)
    key = next(k for k in data["point"] if k.lower() == "potential")
    dist, index = cKDTree(data["points"][:,:2]).query(fe.mesh.p.T)
    if dist.max() > 2e-9 or len(np.unique(index)) != fe.mesh.nvertices:
        raise RuntimeError("Elmer/Gmsh coordinate mapping failed")
    a = data["point"][key][index]
    g = fe.basis.interpolate(a).grad.mean(axis=2)
    solution = dict(a=a, B=np.array([g[1],-g[0]]),
                    phase_flux_Wb=fe.machine.stator.L1*(fe.phase_rhs@a), currents=np.asarray(currents))
    metrics = fe.metrics(solution)
    metrics.update(temperature_C=temp, currents_ABC_A=np.asarray(currents).tolist(),
                   nonlinear=nonlinear, nodes=fe.mesh.nvertices, elements=fe.mesh.nelements,
                   official_MagElmer_mesh_conversion=True, nonzero_field_readback=True,
                   coordinate_readback_error_m=float(dist.max()))
    dump(case/"summary.json", metrics)
    np.savez_compressed(case/"field.npz",p=fe.mesh.p,t=fe.mesh.t,A=a,B=solution["B"])
    return solution, metrics


def crosscheck():
    c = json.loads((ROOT/"configs/motor_candidate.json").read_text())
    m = build_machine(c)
    folder = BASE/"crosscheck_2d"; folder.mkdir(parents=True,exist_ok=True)
    dump(folder/"summary.json",dict(status="running"))
    fe = MagneticModel(m,c,h=.002)
    no = fe.solve(temperature_C=80)
    currents = phase_q(no["phase_flux_Wb"])*10.814
    ref = fe.solve(currents=currents,temperature_C=80)
    solution, linear = magnetostatic_2d(fe,folder/"linear",currents,nonlinear=False)
    linear["relative_A_error_against_same_mesh_independent_solve"] = float(np.linalg.norm(solution["a"]-ref["a"])/np.linalg.norm(ref["a"]))
    nonlinear_ref = fe.nonlinear(ref)
    solution, nonlinear = magnetostatic_2d(fe,folder/"nonlinear",currents,nonlinear=True)
    nonlinear["relative_A_error_against_same_mesh_independent_solve"] = float(np.linalg.norm(solution["a"]-nonlinear_ref["a"])/np.linalg.norm(nonlinear_ref["a"]))
    nonlinear["independent_reference_torque_Nm"] = fe.metrics(nonlinear_ref)["torque_Nm"]
    result = dict(status="completed",linear=linear,nonlinear=nonlinear,
                  source_normalization="M=Br/(mu0*mur); slot NI preserved with actual region area",
                  implementation="Official MagElmer mesh conversion with project solver/readback extension")
    dump(folder/"summary.json",result)
    if linear["relative_A_error_against_same_mesh_independent_solve"]>.001:
        raise RuntimeError("Linear independent-solver agreement failed")
    if nonlinear["relative_A_error_against_same_mesh_independent_solve"]>.005:
        raise RuntimeError("Nonlinear independent-solver agreement failed")
    print((folder/"summary.json").read_text(),flush=True)
    return result


if __name__ == "__main__":
    crosscheck()
