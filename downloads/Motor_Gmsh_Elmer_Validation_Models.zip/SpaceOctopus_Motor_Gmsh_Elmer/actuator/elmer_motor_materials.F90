MODULE MotorBHTable
  USE Types, ONLY: dp
  IMPLICIT NONE
  INTEGER,PARAMETER :: nBH=23
  REAL(KIND=dp),PARAMETER :: BTable(nBH)=[ &
    0.0_dp, 0.10000000000000001_dp, 0.20000000000000001_dp, 0.29999999999999999_dp, &
    0.40000000000000002_dp, 0.5_dp, 0.59999999999999998_dp, 0.69999999999999996_dp, &
    0.80000000000000004_dp, 0.90000000000000002_dp, 1.0_dp, 1.1000000000000001_dp, &
    1.2_dp, 1.3_dp, 1.3999999999999999_dp, 1.5_dp, &
    1.6000000000000001_dp, 1.7_dp, 1.8_dp, 2.0_dp, &
    2.5_dp, 3.0_dp, 4.0_dp]
  REAL(KIND=dp),PARAMETER :: HTable(nBH)=[ &
    0.0_dp, 30.0_dp, 39.600000000000001_dp, 46.0_dp, &
    52.0_dp, 58.200000000000003_dp, 65.200000000000003_dp, 73.299999999999997_dp, &
    83.099999999999994_dp, 95.5_dp, 112.0_dp, 136.0_dp, &
    178.0_dp, 272.0_dp, 596.0_dp, 1700.0_dp, &
    3880.0_dp, 7160.0_dp, 11600.0_dp, 20479.999999999993_dp, &
    42679.999999999971_dp, 64879.999999999956_dp, 109279.99999999993_dp]
CONTAINS
  REAL(KIND=dp) FUNCTION MotorSteelH(B) RESULT(H)
    REAL(KIND=dp),INTENT(IN) :: B
    INTEGER :: lo,hi,mid
    lo=1;hi=nBH
    DO WHILE(hi-lo>1)
      mid=(lo+hi)/2
      IF(B>BTable(mid)) THEN
        lo=mid
      ELSE
        hi=mid
      END IF
    END DO
    H=HTable(lo)+(B-BTable(lo))*(HTable(hi)-HTable(lo))/(BTable(hi)-BTable(lo))
  END FUNCTION MotorSteelH
END MODULE MotorBHTable

! Project material laws and finite-system checks. The upstream solver is unchanged.
INTEGER FUNCTION MotorMatrixCheck(Model,Solver,A,b,x,n,DOFs,Norm)
  USE DefUtils
  USE, INTRINSIC :: IEEE_ARITHMETIC
  IMPLICIT NONE
  TYPE(Model_t) :: Model
  TYPE(Solver_t) :: Solver
  INTEGER :: n,DOFs
  REAL(KIND=dp) :: b(n),x(n),Norm
  TYPE(Matrix_t), POINTER :: A
  INTEGER :: i,badm,badr,zero_diag,u
  LOGICAL :: Found
  badm=COUNT(.NOT.IEEE_IS_FINITE(A%Values))
  badr=COUNT(.NOT.IEEE_IS_FINITE(A%RHS))
  zero_diag=0
  DO i=1,A%NumberOfRows
    IF(A%Diag(i)>0) THEN
      IF(A%Values(A%Diag(i))==0._dp) zero_diag=zero_diag+1
    ELSE
      zero_diag=zero_diag+1
    END IF
  END DO
  WRITE(*,*) 'MOTOR_MATRIX_CHECK rows,nan_matrix,nan_rhs,zero_diag:',A%NumberOfRows,badm,badr,zero_diag
  WRITE(*,*) 'MOTOR_MATRIX_CHECK rhs_max,matrix_max:',MAXVAL(ABS(A%RHS)),MAXVAL(ABS(A%Values))
  IF(badm+badr>0) CALL Fatal('MotorMatrixCheck','Non-finite assembled system')
  IF(ListGetLogical(Solver%Values,'Motor Export Matrix',Found)) THEN
    OPEN(NEWUNIT=u,FILE='matrix.bin',STATUS='replace',ACCESS='stream',FORM='unformatted')
    WRITE(u) A%NumberOfRows,SIZE(A%Values)
    WRITE(u) A%Rows,A%Cols,A%Values,A%RHS
    CLOSE(u)
    CALL Fatal('MotorMatrixCheck','Diagnostic matrix exported; no physical solution accepted')
  END IF
  MotorMatrixCheck=0
END FUNCTION MotorMatrixCheck

SUBROUTINE MotorLamination(Model,n,X,Y)
  USE DefUtils
  USE MotorBHTable
  IMPLICIT NONE
  TYPE(Model_t) :: Model
  INTEGER :: n
  REAL(KIND=dp) :: X(*)
  REAL(KIND=dp), POINTER :: Y(:,:)
  TYPE(ValueList_t), POINTER :: Material
  REAL(KIND=dp) :: mu0,kf,bpar2,bz,lo,hi,nu,bfe,hfe,test
  INTEGER :: i
  LOGICAL :: Found
  mu0=4e-7_dp*ACOS(-1._dp)
  Material=>GetMaterial()
  kf=ListGetConstReal(Material,'Motor Steel Fill',Found)
  IF(.NOT.Found) kf=.95_dp
  bpar2=X(1)**2+X(2)**2
  bz=X(3)
  lo=1._dp
  hi=1._dp/mu0
  DO i=1,45
    nu=(lo+hi)/2._dp
    bfe=MAX(SQRT(bpar2/(kf+(1._dp-kf)*mu0*nu)**2+bz*bz),1e-10_dp)
    hfe=MotorSteelH(bfe)
    test=hfe/bfe-nu
    IF(test>0._dp) THEN
      lo=nu
    ELSE
      hi=nu
    END IF
  END DO
  nu=(lo+hi)/2._dp
  Y=0._dp
  Y(1,1)=nu/(kf+(1._dp-kf)*mu0*nu)
  Y(2,2)=Y(1,1)
  Y(3,3)=kf*nu+(1._dp-kf)/mu0
END SUBROUTINE MotorLamination

SUBROUTINE MotorWindingConductivity(Model,n,X,Y)
  USE DefUtils
  IMPLICIT NONE
  TYPE(Model_t) :: Model
  INTEGER :: n
  REAL(KIND=dp) :: X(*)
  REAL(KIND=dp), POINTER :: Y(:,:)
  TYPE(ValueList_t), POINTER :: Material
  REAL(KIND=dp) :: angle,kt,ka,eta,zz,r,t(3)
  INTEGER :: i,j
  LOGICAL :: Found
  Material=>GetMaterial()
  angle=ListGetConstReal(Material,'Motor Coil Axis',Found)
  IF(.NOT.Found) CALL Fatal('MotorWindingConductivity','Coil axis missing')
  kt=ListGetConstReal(Material,'Motor Winding K Transverse',Found)
  IF(.NOT.Found) CALL Fatal('MotorWindingConductivity','Transverse conductivity missing')
  ka=ListGetConstReal(Material,'Motor Winding K Along',Found)
  IF(.NOT.Found) CALL Fatal('MotorWindingConductivity','Along-wire conductivity missing')
  eta=-SIN(angle)*X(1)+COS(angle)*X(2)
  zz=MAX(X(3)-.085_dp,0._dp)+MIN(X(3),0._dp)
  r=SQRT(eta*eta+zz*zz+1e-30_dp)
  t=[SIN(angle)*zz/r,-COS(angle)*zz/r,eta/r]
  Y=0._dp
  DO i=1,3
    DO j=1,3
      Y(i,j)=(ka-kt)*t(i)*t(j)
    END DO
    Y(i,i)=Y(i,i)+kt
  END DO
END SUBROUTINE MotorWindingConductivity

REAL(KIND=dp) FUNCTION MotorInitialTemperature(Model,n,X) RESULT(T)
  USE DefUtils
  IMPLICIT NONE
  TYPE(Model_t) :: Model
  INTEGER :: n
  REAL(KIND=dp) :: X(*)
  REAL(KIND=dp), ALLOCATABLE,SAVE :: Values(:)
  INTEGER :: unit,k,i,count
  IF(.NOT.ALLOCATED(Values)) THEN
    OPEN(NEWUNIT=unit,FILE='initial_temperature.dat',STATUS='old',ACTION='read')
    READ(unit,*) count
    ALLOCATE(Values(count))
    DO k=1,count
      READ(unit,*) i,Values(k)
      IF(i/=k) CALL Fatal('MotorInitialTemperature','Native node ordering changed')
    END DO
    CLOSE(unit)
  END IF
  IF(n<1.OR.n>SIZE(Values)) CALL Fatal('MotorInitialTemperature','Node outside restart array')
  T=Values(n)
END FUNCTION MotorInitialTemperature
