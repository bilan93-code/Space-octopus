"""Unprestressed rotor modes with the verified torsion-free bearing supports."""
import json
import os
import resource
import subprocess
from .elmer_motor import ROOT,BASE
from .run import dump


def run():
    source=BASE/'structural3d/coarse/fault_hot_point_supports'
    check=json.loads((source/'summary.json').read_text())
    assert abs(check['output_reaction_torque_Nm']+check['torque_Nm'])<.01
    out=BASE/'structural3d/coarse/modal_point_supports';out.mkdir(exist_ok=True)
    text=(source/'rotor.inp').read_text().split('\n*STEP',1)[0]
    text+='\n*STEP\n*FREQUENCY\n12\n*NODE FILE\nU\n*END STEP\n'
    (out/'modal.inp').write_text(text)
    env=os.environ.copy();env.update(OMP_NUM_THREADS='2',CCX_NPROC_STIFFNESS='2',OPENBLAS_NUM_THREADS='1')
    def stack():
        _,hard=resource.getrlimit(resource.RLIMIT_STACK);resource.setrlimit(resource.RLIMIT_STACK,(hard,hard))
    with (out/'solver.log').open('w') as log:
        p=subprocess.run([str(ROOT/'.local/bin/ccx'),'-i','modal'],cwd=out,env=env,
            stdout=log,stderr=subprocess.STDOUT,preexec_fn=stack,timeout=900)
    if p.returncode or 'Job finished' not in (out/'solver.log').read_text():raise RuntimeError('Modal solve failed')
    text=(out/'modal.dat').read_text().split('P A R T I C I P A T I O N')[0];rows=[]
    for line in text.splitlines():
        a=line.split()
        if len(a)==5 and a[0].isdigit():rows.append(dict(mode=int(a[0]),frequency_Hz=float(a[3])))
    if len(rows)!=12 or min(r['frequency_Hz'] for r in rows)<=0:raise RuntimeError('Invalid mode extraction')
    result=dict(status='completed',modes=rows,first_frequency_Hz=rows[0]['frequency_Hz'],
        pair_bearing_stiffness_N_m=1e7,bearing_support=check['bearing_support'],
        prestressed=False,gyroscopic=False,geometry_revision='A',element_order=1,
        limitation='Bonded reference rotor, output mean rotation constrained; not final B prestressed contact or installed actuator dynamics')
    dump(out/'summary.json',result);print(json.dumps(result,indent=2),flush=True);return result


if __name__=='__main__':run()
