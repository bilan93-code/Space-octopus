"""3D conductive-magnet transfer functions for declared axial segmentation.

Each conducting sector is isolated electrically. Prescribed harmonic boundary
induction is a local excitation experiment, not a rotating full-motor PWM solve.
"""
import json,re,subprocess,argparse
from pathlib import Path
import gmsh
import numpy as np
from .gmsh_elmer_geometry import Geometry
from .elmer_motor import ROOT,BASE,environment,block,common_header,output_solver,solve
from .run import dump


def prepare(folder,segments=4,h=.001):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True);g=Geometry();parts=[]
    try:
        seam=.0001 if segments>1 else 0.;length=(.085-(segments-1)*seam)/segments
        # Rotate a pole to lie symmetrically about +x: radial/tangential test
        # fields are then the Cartesian x/y components.
        for j in range(segments):
            face=g.sector_face(.02305,.02605,np.deg2rad(-14.4),np.deg2rad(14.4))
            tag=g.extrude(face,j*(length+seam),length);parts.append(tag)
        g.occ.synchronize()
        for j,tag in enumerate(parts,1):
            gmsh.model.addPhysicalGroup(3,[tag],j);gmsh.model.setPhysicalName(3,j,'Segment%d'%j)
        faces=gmsh.model.getBoundary([(3,t) for t in parts],combined=True,oriented=False)
        gmsh.model.addPhysicalGroup(2,[t for d,t in faces],1000);gmsh.model.setPhysicalName(2,1000,'ImposedField')
        gmsh.option.setNumber('Mesh.MeshSizeMax',h);gmsh.option.setNumber('Mesh.MeshSizeMin',h*.7)
        gmsh.option.setNumber('Mesh.Algorithm3D',10);gmsh.option.setNumber('Mesh.MshFileVersion',2.2)
        gmsh.model.mesh.generate(3);gmsh.write(str(folder/'magnet.msh'))
        result=dict(status='meshed',segments=segments,h_m=h,segment_length_m=length,seam_m=seam,
                    nodes=len(gmsh.model.mesh.getNodes()[0]),tetrahedra=sum(len(a) for t in parts for a in gmsh.model.mesh.getElements(3,t)[1]))
        dump(folder/'mesh_summary.json',result)
    finally:g.close()
    with environment(),(folder/'grid.log').open('w') as log:
        subprocess.run([str(ROOT/'.local/bin/ElmerGrid'),'14','2','magnet.msh','-autoclean','-names','-out','mesh'],
                       cwd=folder,stdout=log,stderr=subprocess.STDOUT,check=True)
    return result


def run(folder,frequency=630.,axis=0,amplitude=.01,temp=80.):
    folder=Path(folder);meta=json.loads((folder/'mesh_summary.json').read_text())
    case=folder/('%gHz_%s_%gC'%(frequency,'xyz'[axis],temp));case.mkdir(exist_ok=True)
    sigma=1/(.9e-6*(1+.0003*(temp-20)))
    sif=common_header(folder/'mesh',3)
    sif+=block('Equation',1,['Active Solvers(3) = 1 2 3'])
    sif+=block('Solver',1,['Equation = "MagnetEddy3D"',
         'Procedure = "MagnetoDynamics" "WhitneyAVHarmonicSolver"','Variable = "A[A re:1 A im:1]"',
         'Angular Frequency = Real %.16g'%(2*np.pi*frequency),'Use Tree Gauge = Logical False',
         'Before Linsolve = "'+str(ROOT/'.local/elmer-user/MotorGauge')+'" "MotorTreeGauge"',
         'Linear System Solver = Direct','Linear System Direct Method = umfpack',
         'Linear System Convergence Tolerance = 1e-10','Steady State Convergence Tolerance = 1e-8'])
    sif+=block('Solver',2,['Equation = "MagneticFields"','Procedure = "MagnetoDynamics" "MagnetoDynamicsCalcFields"',
         'Potential Variable = "A"','Calculate Magnetic Flux Density = True','Calculate Current Density = True',
         'Calculate Electric Field = True','Calculate Joule Heating = True',
         'Calculate Elemental Fields = True','Calculate Nodal Fields = False'])
    sif+=output_solver(3)
    sif+=block('Material',1,['Relative Permeability = 1.05','Electric Conductivity = Real %.16g'%sigma])
    for j in range(1,meta['segments']+1):sif+=block('Body',j,['Target Bodies(1) = %d'%j,'Equation = 1','Material = 1'])
    names=(folder/'mesh/mesh.names').read_text();bid=int(re.search(r'\$\s+ImposedField\s*=\s*(\d+)',names).group(1))
    b=np.eye(3)[axis]*amplitude
    # A = 0.5 B x (r-rcentre). Subtracting a constant origin is a gauge choice.
    A=['%.16g*(tx(2)-.0425)+%.16g*tx(1)'%(.5*b[1],-.5*b[2]),
       '%.16g*tx(0)+%.16g*(tx(2)-.0425)'%(.5*b[2],-.5*b[0]),
       '%.16g*tx(1)+%.16g*tx(0)'%(.5*b[0],-.5*b[1])]
    bc=['Target Boundaries(1) = %d'%bid,'A re {e} = Real 0','A im {e} = Real 0']
    for j,expression in enumerate(A,1):bc+=['A re {e} %d = Variable Coordinate'%j,'  Real MATC "'+expression+'"']
    sif+=block('Boundary Condition',1,bc)
    nodes=np.loadtxt(folder/'mesh/mesh.nodes');elements=np.loadtxt(folder/'mesh/mesh.elements',dtype=int)
    for j in range(1,meta['segments']+1):
        node=int(elements[elements[:,1]==j,3][0])
        sif+=block('Boundary Condition',j+1,['Target Nodes(1) = %d'%node,'A re = Real 0','A im = Real 0'])
    data=solve(case,sif,timeout=600,check_nonlinear=False)
    top=data['topology'];sel=top['types'].astype(int)==10;ends=top['offsets'].astype(int);starts=np.r_[0,ends[:-1]]
    conn=top['connectivity'].astype(int);t=np.array([conn[a:z] for a,z,s in zip(starts,ends,sel) if s])
    v=data['points'][t];volume=np.abs(np.linalg.det(v[:,1:]-v[:,:1]))/6
    fields={k.lower():v[sel] for k,v in data['cell'].items()}
    peakB=float(np.linalg.norm(fields['magnetic flux density re e'],axis=1).max())
    if peakB>3*amplitude:raise RuntimeError('Harmonic induction magnitude gate failed '+str(peakB))
    key=next(k for k in fields if k=='joule heating e');q=fields[key]
    power=float(volume@q)
    er=fields['electric field re e'];ei=fields['electric field im e']
    direct=float(np.sum(volume*.5*sigma*np.sum(er*er+ei*ei,axis=1)))
    if power<=0 or not (0<direct/power<=1.02):raise RuntimeError('Harmonic peak/RMS power consistency gate failed')
    result=dict(status='completed',engine='Elmer 26.2 harmonic 3D A-V conductor solve',segments=meta['segments'],
       nodes=meta['nodes'],tetrahedra=meta['tetrahedra'],h_m=meta['h_m'],temperature_C=temp,
       frequency_Hz=frequency,excitation_axis='xyz'[axis],boundary_B_peak_T=amplitude,
       sigma_S_m=sigma,pole_loss_W=power,independent_sigma_E2_loss_W=direct,element_mean_E_power_ratio=direct/power,max_B_T=peakB,
       loss_per_Tpeak2_W=power/amplitude**2,material_volume_m3=float(volume.sum()),
       limitations=['Uniform prescribed boundary induction on one pole; surrounding steel/air and rotor motion are absent',
        'Conductive reaction and 3D closed eddy-current loops included within each isolated magnet',
        'Frequency/axis transfer function; cannot be called the complete motor PWM loss without the boundary spectrum',
        'Generic conductivity and linear recoil permeability; same declared four axial segments and seams'])
    np.savez_compressed(case/'fields.npz',p=data['points'],t=t,joule_W_m3=q,volume=volume)
    dump(case/'summary.json',result);print(meta['segments'],frequency,'xyz'[axis],power,flush=True)
    return result


if __name__=='__main__':
    pa=argparse.ArgumentParser();pa.add_argument('--h',type=float,default=.001);pa.add_argument('--name',default='coarse')
    a=pa.parse_args()
    for n in [1,4]:
        folder=BASE/'magnet_eddy3d'/a.name/str(n)
        if not (folder/'mesh_summary.json').exists():prepare(folder,n,a.h)
        for f in [126.,630.,20000.]:
            for axis in [0,1]:run(folder,f,axis)
