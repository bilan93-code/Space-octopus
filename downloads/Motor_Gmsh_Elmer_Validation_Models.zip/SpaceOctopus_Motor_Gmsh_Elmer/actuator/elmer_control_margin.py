"""Verify higher current at the sampled torque trough and bound its heating."""
import json
import numpy as np
from .elmer_motor import BASE
from .elmer_magnetic3d import run
from .elmer_angle_sweep import collect
from .run import dump


def main():
    sweep=collect()
    if sweep.get('status')!='completed':raise RuntimeError('Complete the angular sweep first')
    row=min(sweep['rows'],key=lambda d:d['torque_Nm'])
    folder=(BASE/row['case']).parent
    path=folder/'control13A_120C/summary.json'
    result=json.loads(path.read_text()) if path.exists() else run(folder,'control13A_120C',Iq=13,temp=120,linear=False,direct='cholmod')
    hotpath=folder/'control13A_150C/summary.json'
    hot=json.loads(hotpath.read_text()) if hotpath.exists() else run(folder,'control13A_150C',Iq=13,temp=150,linear=False,direct='cholmod')
    out=BASE/'control_margin';out.mkdir(exist_ok=True)
    speed=630*2*np.pi/60;required=220/(63*.8);drag=18/speed
    cases=[json.loads((BASE/r['case']/'summary.json').read_text()) for r in sweep['rows']]
    k=np.fft.fftfreq(8,d=1/8);phi=np.linspace(0,2*np.pi,4096,endpoint=False)
    basis=np.exp(1j*phi[:,None]*k)
    def curve(values):
        c=np.fft.fft(values)/8
        return (basis@c).real,(basis@(c*1j*k*(-10))).real
    torque,dtorque=curve([d['torque_Nm'] for d in cases])
    iq=12.2*(required+drag)/torque
    diq=-iq*dtorque/torque
    pd,dpd=curve([d['Phid_rms_Wb'] for d in cases]);pq,dpq=curve([d['Phiq_rms_Wb'] for d in cases])
    # Linearized incremental q-flux response. The actual trough point is solved
    # independently at 13 A; this profile remains a controller feasibility model.
    dpq_profile=dpq*iq/12.2+pq*diq/12.2;pq_profile=pq*iq/12.2
    moving=json.loads((BASE/'thermal3d/revisionB_fine/moving13_hot70/summary.json').read_text())
    R=.12852235140466137*(1+.00393*(moving['winding_hotspot_C']-20))
    vd=speed*(dpd-5*pq_profile);vq=R*iq+speed*(dpq_profile+5*pd)
    voltage=float(np.sqrt(2*(vd*vd+vq*vq)).max())
    holding=json.loads((BASE/'thermal3d/revisionB_fine/hold13_angle30/summary.json').read_text())
    pulse_path=BASE/'thermal3d/revisionB_fine/pulse22A_from13_hold100/summary.json'
    pulse=json.loads(pulse_path.read_text()) if pulse_path.exists() else None
    summary=dict(status='completed',selected_sample_index=row['index'],rotor_angle_deg=row['rotor_angle_deg'],
        verified_case=str(path.parent.relative_to(BASE)),
        baseline12p2_EM_torque_Nm=row['torque_Nm'],baseline12p2_shaft_torque_Nm=row['torque_Nm']-drag,
        tested_current_Arms=13.,tested_EM_torque_Nm=result['torque_Nm'],
        tested_shaft_torque_Nm=result['torque_Nm']-drag,required_shaft_torque_Nm=required,
        shaft_torque_margin_fraction=(result['torque_Nm']-drag)/required-1,
        sampled_trough_pass=bool(result['torque_Nm']-drag>required),
        hotter_magnet_test_150C=dict(case=str(hotpath.parent.relative_to(BASE)),
            torque_EM_Nm=hot['torque_Nm'],estimated_shaft_torque_Nm=hot['torque_Nm']-drag,
            shaft_margin_fraction=(hot['torque_Nm']-drag)/required-1,
            sampled_trough_pass=bool(hot['torque_Nm']-drag>required)),
        holding13_hotspot_C=holding['winding_hotspot_C'],moving13_hotspot_C=moving['winding_hotspot_C'],
        moving13_magnet_C=moving['magnet_hotspot_C'],
        pulse22_from13_hotspot_C=pulse['winding_hotspot_C'] if pulse else None,
        linearized_profile=dict(current_min_Arms=float(iq.min()),current_max_Arms=float(iq.max()),
            current_rms_Arms=float(np.sqrt(np.mean(iq*iq))),
            maximum_phase_voltage_circle_peak_V=voltage,reserved_ceiling_V=42*.9/np.sqrt(3),
            phase_resistance_upper_bound_Ohm=R,resistance_temperature_C=moving['winding_hotspot_C'],
            estimated_current_profile_fits_13A_cap=bool(iq.max()<=13),
            caveat='Interpolated torque and linearized current-to-q-flux scaling; no closed-loop inverter/controller simulation is claimed'),
        limitations=['13 A is tested at the minimum of eight sampled positions; exact continuum minimum is not proven',
           'Current lookup assumes locally near-linear torque/current; cogging and cross-saturation need controller calibration',
           'Strength, demagnetization and installed vibration remain separate qualification inputs'])
    dump(out/'summary.json',summary)
    np.savetxt(out/'linearized_current_profile.csv',np.c_[-phi/10*180/np.pi,iq,vd,vq],delimiter=',',
        header='mechanical_angle_offset_deg,Iq_Arms_estimate,Vd_rms_estimate,Vq_rms_estimate',comments='')
    print(json.dumps(summary,indent=2),flush=True);return summary


if __name__=='__main__':main()
