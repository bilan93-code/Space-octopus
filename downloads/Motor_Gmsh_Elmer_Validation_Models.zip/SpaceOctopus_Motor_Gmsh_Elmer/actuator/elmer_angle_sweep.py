"""Executed 3D sampling over the native 36-degree torque repeat interval."""
import argparse
import json
import numpy as np
from .elmer_motor import BASE
from .elmer_mesh3d import magnetic_mesh
from .elmer_magnetic3d import run, ANGLE_REFERENCE
from .run import dump


def campaign(lane=0):
    base=BASE/'magnetic3d/angle_sweep_120C';base.mkdir(exist_ok=True)
    for i in range(1,8):
        if i%2!=lane:continue
        folder=base/('pose_%02d'%i)
        if (folder/'run/summary.json').exists():continue
        if not (folder/'mesh_summary.json').exists():
            magnetic_mesh(folder,h=.003,gap_h=.0012,
                          angle=ANGLE_REFERENCE-np.deg2rad(4.5*i),segmented=True)
        run(folder,'run',Iq=12.2,temp=120,linear=False,direct='cholmod')
    return collect()


def collect():
    base=BASE/'magnetic3d/angle_sweep_120C'
    paths=[BASE/'magnetic3d/segmented/design12p2_120C/summary.json']
    paths.extend(base/('pose_%02d/run/summary.json'%i) for i in range(1,8))
    if not all(p.exists() for p in paths):return {'status':'running'}
    cases=[json.loads(p.read_text()) for p in paths]
    if not all(d.get('status')=='completed' for d in cases):raise RuntimeError('Incomplete angular case')
    torques=np.array([d['torque_Nm'] for d in cases]);mean=float(torques.mean())
    speed=630*2*np.pi/60;loss=18.
    native=json.loads((BASE/'native_api_2d_24/progress.json').read_text())
    native_t=np.array([d['torque_Nm'] for d in native])
    thermal=json.loads((BASE/'thermal3d/coarse/design12p2_moving70/summary.json').read_text())
    Rphase=.12852235140466137*(1+.00393*(thermal['winding_hotspot_C']-20))
    # dq flux repeats every 36 mechanical degrees. Reconstruct its sampled
    # harmonics and derivatives; the sign follows the descending rotor angles.
    phi=np.linspace(0,2*np.pi,4096,endpoint=False)
    k=np.fft.fftfreq(8,d=1/8)
    basis=np.exp(1j*phi[:,None]*k)
    dq=[];derivative=[]
    for key in ['Phid_rms_Wb','Phiq_rms_Wb']:
        coef=np.fft.fft([d[key] for d in cases])/8
        dq.append((basis@coef).real)
        derivative.append((basis@(coef*1j*k*(-10))).real)
    vd=speed*(derivative[0]-5*dq[1])
    vq=Rphase*12.2+speed*(derivative[1]+5*dq[0])
    theta=-phi[:,None]/2-np.arange(3)*2*np.pi/3
    vabc=np.sqrt(2)*(vd[:,None]*np.cos(theta)-vq[:,None]*np.sin(theta))
    vmax=float(np.max(np.sqrt(2*(vd*vd+vq*vq))))
    span=float(np.max(np.ptp(vabc,axis=1)))
    cu=thermal['copper_loss_W'];shaftpower=mean*speed-loss
    electrical=dict(method='Eight-sample dq-flux Fourier interpolation including angular flux derivatives; actual harmonics beyond sampling remain unresolved',
        resistance_temperature_upper_bound_C=thermal['winding_hotspot_C'],Rphase_upper_bound_Ohm=Rphase,
        max_dq_voltage_circle_phase_peak_V=vmax,max_phase_voltage_span_V=span,
        minimum_bus_V=42.,reserved_phase_peak_limit_V=42*.9/np.sqrt(3),reserved_voltage_span_limit_V=42*.9,
        sampled_harmonic_voltage_gate_pass=bool(vmax<=42*.9/np.sqrt(3)),
        moving_copper_loss_W=cu,noncopper_loss_W=loss,estimated_shaft_power_W=shaftpower,
        estimated_motor_input_W=mean*speed+cu,
        estimated_motor_efficiency=shaftpower/(mean*speed+cu),
        estimated_48V_DC_current_A=(mean*speed+cu)/48,
        excludes='Inverter power loss, unresolved switching spectrum and supplier-based material loss calibration')
    result=dict(status='completed',Iq_Arms=12.2,magnet_C=120,
        period_mechanical_deg=36,samples=8,spacing_mechanical_deg=4.5,
        torque_mean_Nm=mean,torque_min_sampled_Nm=float(torques.min()),
        torque_max_sampled_Nm=float(torques.max()),torque_pp_sampled_Nm=float(np.ptp(torques)),
        four_vs_eight_mean_relative_change=float(abs(torques[::2].mean()/mean-1)),
        native24_vs_native8_mean_relative_difference=float(abs(native_t[::3].mean()/native_t.mean()-1)),
        noncopper_loss_allowance_W=loss,speed_rpm=630,
        estimated_shaft_torque_mean_Nm=mean-loss/speed,
        estimated_actuator_torque_mean_Nm=(mean-loss/speed)*63*.8,
        required_motor_shaft_torque_Nm=220/(63*.8),
        mean_shaft_torque_margin_fraction=(mean-loss/speed)/(220/(63*.8))-1,
        requirement_sensitivity=dict(maximum_total_noncopper_loss_W=float(speed*(mean-220/(63*.8))),
            additional_loss_budget_beyond18W=float(speed*(mean-220/(63*.8))-loss),
            minimum_gearbox_efficiency_for220Nm=float(220/(63*(mean-loss/speed))),
            minimum_EM_torque_scale_factor=float((220/(63*.8)+loss/speed)/mean),
            approximate_minimum_Br20_T=float(1.05*(220/(63*.8)+loss/speed)/mean),
            Br_sensitivity_caveat='First-order torque proportional to remanence; saturation, reluctance and cogging changes are not re-solved'),
        electrical_estimate=electrical,
        rows=[dict(index=i,rotor_angle_deg=float(np.rad2deg(d['rotor_angle_rad'])),
                   torque_Nm=d['torque_Nm'],Phid_rms_Wb=d['Phid_rms_Wb'],
                   Phiq_rms_Wb=d['Phiq_rms_Wb'],case=str(p.parent.relative_to(BASE)))
              for i,(d,p) in enumerate(zip(cases,paths))],
        limitations=['Eight-point 3D mean; sampled extrema are not a ripple convergence proof',
                     'Generic steel and SmCo curves, no supplier demagnetization qualification',
                     '18 W non-copper allowance deducted as shaft drag at 630 rpm; must verify actual loss',
                     'Actuator torque uses assumed 63:1 ratio and 80% gearbox efficiency'])
    dump(base/'summary.json',result);print(json.dumps(result,indent=2),flush=True)
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--lane',type=int,choices=[0,1],default=0)
    p.add_argument('--collect',action='store_true');args=p.parse_args()
    collect() if args.collect else campaign(args.lane)
