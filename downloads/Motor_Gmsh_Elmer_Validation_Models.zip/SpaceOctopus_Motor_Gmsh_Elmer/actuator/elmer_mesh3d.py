"""Conformal 3D magnetic mesh from the declared motor CAD, with SI exports."""
import argparse
import json
import math
import subprocess
from pathlib import Path
import gmsh
import numpy as np
from scipy.optimize import linear_sum_assignment
from scipy.spatial.distance import cdist
from .gmsh_elmer_geometry import Geometry
from .elmer_motor import environment, BASE
from .run import dump

ROOT=Path(__file__).resolve().parents[1]


def import_assembly(g,geometry_folder=None):
    geometry_folder=Path(geometry_folder) if geometry_folder else BASE/'geometry'
    data=json.loads((geometry_folder/"assembly.json").read_text())
    tags=g.occ.importShapes(str(geometry_folder/"motor_assembly_SI.brep"),highestDimOnly=True)
    tags=[t for d,t in tags if d==3]
    if len(tags)!=len(data["parts"]):raise RuntimeError("BREP solid count changed")
    source=np.array([p["center_m"] for p in data["parts"]])
    target=np.array([g.occ.getCenterOfMass(3,t) for t in tags])
    sv=np.array([p["volume_m3"] for p in data["parts"]])
    tv=np.array([g.occ.getMass(3,t) for t in tags])
    cost=cdist(source,target)/.01+abs(np.log(sv[:,None]/tv[None,:]))
    i,j=linear_sum_assignment(cost)
    if cost[i,j].max()>1e-5:raise RuntimeError("BREP part identity mapping changed")
    parts=[]
    for a,b in zip(i,j):
        p=dict(data["parts"][a]);p["tag"]=tags[b];parts.append(p)
    return parts,data


def magnetic_mesh(folder, h=.0025, gap_h=.001, angle=.8901174250463588,
                  segmented=False, outer_radius=.09, far_z=.155):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    g=Geometry()
    try:
        parts,data=import_assembly(g)
        keep=[]
        for p in parts:
            if p["material"]=="winding" or p["material"]=="steel":
                # Exterior fastener permeability is a separate material scenario;
                # canonical electromagnetic comparison keeps the motor iron/shaft.
                if p["material"]=="steel" and p["name"] not in ["StatorIron","RotorIron","Shaft"]:
                    g.occ.remove([(3,p["tag"])],recursive=True)
                else:keep.append(p)
            elif segmented and p["material"]=="magnet":
                keep.append(p)
            else:
                g.occ.remove([(3,p["tag"])],recursive=True)
        if not segmented:
            for k in range(10):
                face=g.sector_face(.02305,.02605,np.deg2rad(3.6+36*k),np.deg2rad(32.4+36*k))
                keep.append(dict(name="Magnet%02d"%(k+1),tag=g.extrude(face,0,.085),
                                 material="magnet",pole=k,magnetization_sign=(-1)**k))
        for p in keep:
            if p["name"] in ["RotorIron","Shaft"] or p["material"]=="magnet":
                g.occ.rotate([(3,p["tag"])],0,0,0,0,0,1,float(angle))
        # Axial symmetry is valid for the declared centered 155 mm shaft,
        # symmetric end turns and axial segmentation; Bz=0 at the midplane.
        half_box=g.occ.addBox(-.2,-.2,.0425,.4,.4,.3)
        half=[]
        for p in keep:
            out,_=g.occ.intersect([(3,p["tag"])],[(3,half_box)],removeObject=True,removeTool=False)
            for dim,tag in out:
                if dim==3:
                    q=dict(p);q["tag"]=tag;half.append(q)
        g.occ.remove([(3,half_box)],recursive=True)
        domain=g.occ.addCylinder(0,0,.0425,0,0,far_z-.0425,outer_radius)
        _,mapping=g.occ.fragment([(3,domain)],[(3,p["tag"]) for p in half])
        g.occ.synchronize()
        label_by_tag={}
        groups=[]
        for p,mapped in zip(half,mapping[1:]):
            tags=[tag for dim,tag in mapped if dim==3]
            if not tags:raise RuntimeError("Lost magnetic region")
            for tag in tags:
                if tag in label_by_tag:raise RuntimeError("Overlapping magnetic volumes")
                label_by_tag[tag]=p["name"]
            groups.append(dict(p,tags=tags))
        air=[tag for dim,tag in gmsh.model.getEntities(3) if tag not in label_by_tag]
        if not air:raise RuntimeError("No surrounding air")
        groups=[dict(name="Air",material="air",tags=air)]+groups
        for rid,p in enumerate(groups,1):
            p["id"]=rid
            gmsh.model.addPhysicalGroup(3,p["tags"],rid)
            gmsh.model.setPhysicalName(3,rid,p["name"])
        # Select only true external boundaries of the conformal union.
        boundary=gmsh.model.getBoundary(gmsh.model.getEntities(3),combined=True,oriented=False)
        mid=[];far=[]
        for dim,tag in boundary:
            box=g.occ.getBoundingBox(dim,tag)
            if abs(box[2]-.0425)<2e-6 and abs(box[5]-.0425)<2e-6:mid.append(tag)
            else:far.append(tag)
        if not mid or not far:raise RuntimeError("Missing magnetic boundary")
        for rid,name,tags in [(1000,"SymmetryMidplane",mid),(1001,"FarField",far)]:
            gmsh.model.addPhysicalGroup(2,tags,rid);gmsh.model.setPhysicalName(2,rid,name)
        # Surface-distance refinement near the actual cylindrical magnetic gap.
        gap_faces=[]
        for dim,tag in gmsh.model.getEntities(2):
            if gmsh.model.getType(dim,tag)!="Cylinder":continue
            uv0,uv1=gmsh.model.getParametrizationBounds(dim,tag)
            xyz=gmsh.model.getValue(dim,tag,((np.asarray(uv0)+uv1)/2).tolist())
            r=np.linalg.norm(xyz[:2])
            if min(abs(r-radius) for radius in [.023,.02305,.02605,.0265])<1e-6:gap_faces.append(tag)
        field=gmsh.model.mesh.field
        near=field.add("Distance");field.setNumbers(near,"FacesList",gap_faces)
        field.setNumber(near,"Sampling",200)
        threshold=field.add("Threshold")
        field.setNumber(threshold,"InField",near)
        field.setNumber(threshold,"SizeMin",gap_h);field.setNumber(threshold,"SizeMax",max(h,.008))
        field.setNumber(threshold,"DistMin",.0002);field.setNumber(threshold,"DistMax",.003)
        farfield=field.add("MathEval")
        field.setString(farfield,"F","%.16g + .12*Max(0,Sqrt(x*x+y*y)-.058) + .10*Max(0,z-.105)"%h)
        overall=field.add("Min");field.setNumbers(overall,"FieldsList",[threshold,farfield])
        field.setAsBackgroundMesh(overall)
        gmsh.option.setNumber("Mesh.MeshSizeMin",gap_h*.7)
        gmsh.option.setNumber("Mesh.MeshSizeMax",max(h,.008))
        gmsh.option.setNumber("Mesh.MeshSizeFromPoints",0)
        gmsh.option.setNumber("Mesh.MeshSizeFromCurvature",0)
        gmsh.option.setNumber("Mesh.MeshSizeExtendFromBoundary",0)
        gmsh.option.setNumber("Mesh.MinimumCircleNodes",128)
        gmsh.option.setNumber("Mesh.Algorithm3D",10)
        gmsh.option.setNumber("Mesh.MshFileVersion",2.2)
        gmsh.model.mesh.generate(3)
        gmsh.write(str(folder/"motor.msh"))
        gmsh.write(str(folder/"motor.inp"))
        node_tags,xyz,_=gmsh.model.mesh.getNodes()
        order=np.argsort(node_tags);node_tags=np.asarray(node_tags)[order]
        xyz=np.asarray(xyz).reshape(-1,3)[order]
        all_t=[];all_r=[];all_q=[]
        for p in groups:
            for tag in p["tags"]:
                types,ids,connect=gmsh.model.mesh.getElements(3,tag)
                for et,tags,nn in zip(types,ids,connect):
                    if et!=4:raise RuntimeError("Only 4-node tetrahedra supported")
                    all_t.append(np.searchsorted(node_tags,np.asarray(nn).reshape(-1,4)))
                    all_r.extend([p["id"]]*len(tags))
                    all_q.extend(gmsh.model.mesh.getElementQualities(tags,"minSICN"))
        t=np.vstack(all_t);q=np.asarray(all_q)
        vertices=xyz[t];vol=np.abs(np.linalg.det(vertices[:,1:]-vertices[:,:1]))/6
        if np.any(vol<=0) or q.min()<=0:raise RuntimeError("Invalid tetrahedron")
        np.savez_compressed(folder/"mesh_arrays.npz",p=xyz,t=t,region=all_r,volumes=vol)
        result=dict(status="meshed",units="m",symmetry="axial half, multiply integral torque/flux by 2",
                    rotor_angle_rad=float(angle),segmented_magnets=segmented,
                    nodes=len(xyz),tetrahedra=len(t),min_scaled_jacobian=float(q.min()),
                    median_scaled_jacobian=float(np.median(q)),h_m=h,gap_h_m=gap_h,
                    outer_radius_m=outer_radius,far_z_m=far_z,groups=groups,
                    active_coil_source="closed divergence-free stranded-current loop",
                    nonmagnetic_parts_replaced_by_air_for_static_magnetics=True)
        dump(folder/"mesh_summary.json",result)
    finally:g.close()
    with environment(),(folder/"grid.log").open("w") as log:
        command=[str(ROOT/".local/bin/ElmerGrid"),"14","2","motor.msh","-autoclean","-names","-out","mesh"]
        subprocess.run(command,cwd=folder,stdout=log,stderr=subprocess.STDOUT,check=True)
    result["status"]="ready_for_solver";dump(folder/"mesh_summary.json",result)
    print("3D magnetic mesh:",len(xyz),"nodes",len(t),"tetrahedra",flush=True)
    return result


if __name__=="__main__":
    parser=argparse.ArgumentParser();parser.add_argument("--h",type=float,default=.003)
    parser.add_argument("--gap-h",type=float,default=.0012);parser.add_argument("--name",default="coarse")
    args=parser.parse_args()
    magnetic_mesh(BASE/"magnetic3d"/args.name,h=args.h,gap_h=args.gap_h)
