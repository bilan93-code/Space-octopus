"""Checked millimetre STEP/FreeCAD export of the Gmsh SI BREP assembly."""
import sys,json,hashlib
from pathlib import Path
sys.path.insert(0,'/usr/lib/freecad-python3/lib')
import FreeCAD as App
import Part
import numpy as np
from scipy.optimize import linear_sum_assignment

ROOT=Path(__file__).resolve().parents[1]
folder=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT/'results/motor/gmsh_elmer/geometry'
meta=json.loads((folder/'assembly.json').read_text())
shape=Part.Shape();shape.read(str(folder/'motor_assembly_SI.brep'))
solids=shape.Solids
assert len(solids)==len(meta['parts'])==143
source=np.array([p['center_m'] for p in meta['parts']])
target=np.array([[s.CenterOfMass.x,s.CenterOfMass.y,s.CenterOfMass.z] for s in solids])
# Geometric bounds, not default quadrature, identify the symmetric parts.
bounds=np.array([[s.BoundBox.XMin,s.BoundBox.YMin,s.BoundBox.ZMin,
                  s.BoundBox.XMax,s.BoundBox.YMax,s.BoundBox.ZMax] for s in solids])
expected=np.array([p['bounds_m'] for p in meta['parts']])
cost=np.linalg.norm(expected[:,None,:]-bounds[None,:,:],axis=2)
ii,jj=linear_sum_assignment(cost)
assert cost[ii,jj].max()<.0001
doc=App.newDocument('SpaceOctopus_motor_candidate')
parts=[]
for i,j in zip(ii,jj):
    name=meta['parts'][i]['name'];s=solids[j].copy();s.scale(1000.)
    assert s.isValid()
    obj=doc.addObject('Part::Feature',name);obj.Label=name;obj.Shape=s
    obj.addProperty('App::PropertyString','AnalysisMaterial');obj.AnalysisMaterial=meta['parts'][i]['material']
    parts.append(obj)
doc.recompute()
fc=folder/'Motor_Gmsh_Elmer_Candidate.FCStd';doc.saveAs(str(fc))
step=folder/'Motor_Gmsh_Elmer_Candidate_mm.step';Part.export(parts,str(step))
check=Part.read(str(step));bb=check.BoundBox
assert len(check.Solids)==143 and check.isValid()
assert abs(bb.XLength-112)<.02 and abs(bb.ZMin+35)<.01 and abs(bb.ZMax-120)<.01
result=dict(status='roundtrip_verified',units='mm',solids=143,
  overall_bounds_mm=[bb.XMin,bb.YMin,bb.ZMin,bb.XMax,bb.YMax,bb.ZMax],
  per_part_valid=True,step_sha256=hashlib.sha256(step.read_bytes()).hexdigest(),
  note='Nominal declared analysis candidate; homogenized coil and bearing envelopes; thread engagement is cylindrical.')
(folder/'cad_export_check.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
