"""Compile the recorded material, gauge and eddy callbacks with an Elmer ABI."""
import argparse
import os
import subprocess
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def compile_callbacks(hpc=False,check_only=False):
    suffix='HPC' if hpc else ''
    compiler=ROOT/'.local/bin'/('elmerf90'+suffix)
    destination=ROOT/'.local/elmer-user'
    build=destination/('build_hpc' if hpc else 'build_serial')
    build.mkdir(parents=True,exist_ok=True)
    for source,name in [('elmer_motor_materials.F90','MotorMaterials'),
                        ('elmer_tree_gauge.F90','MotorGauge'),
                        ('elmer_eddy_boundary.F90','MotorEddy')]:
        temporary=build/(name+suffix+'.so')
        subprocess.run([str(compiler),'-O3','-ffree-line-length-none','-o',str(temporary),
                        str(ROOT/'actuator'/source)],cwd=build,check=True)
        # Atomic replacement leaves an already running solver's mapped inode
        # intact; never truncate a shared library that might be in use.
        if not check_only:os.replace(temporary,destination/(name+suffix+'.so'))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--hpc',action='store_true');p.add_argument('--check-only',action='store_true');a=p.parse_args()
    compile_callbacks(a.hpc,a.check_only)
