"""Audit executed cases, record provenance and form explicit design gates."""
import base64
import hashlib
import importlib.metadata
import json
import os
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
import numpy as np
from actuator.elmer_motor import BASE
from actuator.elmer_magnetic3d import discrete_maxwell_enclosure
from actuator.elmer_angle_sweep import collect
from actuator.run import dump


def read(relative):
    return json.loads((BASE/relative).read_text())


def distribution_integrity(name):
    dist=importlib.metadata.distribution(name);checked=0;changed=[]
    for file in dist.files or []:
        if file.suffix!='.py' or not file.hash or file.hash.mode!='sha256':continue
        path=dist.locate_file(file)
        digest=base64.urlsafe_b64encode(hashlib.sha256(path.read_bytes()).digest()).decode().rstrip('=')
        checked+=1
        if digest!=file.hash.value:changed.append(str(file))
    if not checked or changed:raise RuntimeError('Installed source integrity failed: '+str(changed))
    return dict(version=dist.version,python_source_files_checked=checked,modified_files=changed)


def magnetic_audit(folder):
    p=folder/'summary.json';d=json.loads(p.read_text())
    if d.get('status')!='completed':raise RuntimeError('Incomplete magnetic case '+str(folder))
    if 'ELMER SOLVER FINISHED' not in (folder/'solver.log').read_text():raise RuntimeError('Missing completed log')
    if 'discrete_maxwell_enclosure' not in d:
        x=np.load(folder/'fields.npz')
        d['discrete_maxwell_enclosure']=discrete_maxwell_enclosure(x['p'],x['t'],x['B'],x['region'])
        d['torque_component_vs_discrete_maxwell_relative_error']=abs(d['torque_Nm']-d['discrete_maxwell_enclosure']['torque_Nm'])/max(abs(d['torque_Nm']),1e-12)
    x=np.load(folder/'fields.npz');meta=json.loads((folder.parent/'mesh_summary.json').read_text())
    steel=[p['id'] for p in meta['groups'] if p['name'] in ['StatorIron','RotorIron']]
    selected=np.isin(x['region'],steel);b=np.linalg.norm(x['B'][selected],axis=1);v=x['volume'][selected]
    order=np.argsort(b);c=np.cumsum(v[order])/v.sum()
    d['steel_B_volume_p99_T']=float(np.interp(.99,c,b[order]))
    d['steel_B_max_T']=float(b.max());d['steel_volume_fraction_above_1p8T']=float(v[b>1.8].sum()/v.sum())
    d['steel_field_quantity']='Homogenized bulk induction; intrinsic lamination BFe follows the recorded fill law and can be higher'
    dump(p,d);return d


def main():
    sweep=collect()
    if sweep.get('status')!='completed':raise RuntimeError('Angular sweep not complete')
    paths=[BASE/'magnetic3d'/s for s in ['coarse/linear_rooted_cholmod','coarse/nonlinear_tensor_newton',
        'fine/linear_bicg','fine/nonlinear_tensor_newton','segmented/design12p2_80C',
        'segmented/design12p2_120C','segmented/peak22_150C','segmented/fault_minus55d_150C']]
    paths.extend(BASE/row['case'] for row in sweep['rows'][1:])
    control=read('control_margin/summary.json')
    paths.append(BASE/control['verified_case'])
    paths.append(BASE/control['hotter_magnet_test_150C']['case'])
    magnetic=[magnetic_audit(p) for p in paths]
    native=read('native_api_2d_24/summary.json')
    fine=read('magnetic3d/fine/nonlinear_tensor_newton/summary.json')
    coarse=read('magnetic3d/coarse/nonlinear_tensor_newton/summary.json')
    hold=read('thermal3d/revisionB_fine/hold12p2_angle30/summary.json')
    limit=read('thermal3d/revisionB_fine/hold18p5_angle30/summary.json')
    failed22=read('thermal3d/revisionB/hold22_angle30/summary.json')
    pulse=read('thermal3d/revisionB_fine/pulse22A_worst_hotR_100/summary.json')
    control=read('control_margin/summary.json')
    structure=read('structural3d/revisionB/fault_hot_follower_weak01/summary.json')
    if structure.get('status')!='completed':raise RuntimeError('Contact analysis not complete')
    # Re-read finite-geometry derived quantities from the immutable native
    # fields. A running driver may have imported an earlier linear projection.
    from actuator.rotor_structural3d import read_results
    case=BASE/'structural3d/revisionB/fault_hot_follower_weak01'
    fields=np.load(case/'fields.npz');p=fields['p'];u=fields['displacement'];t=fields['t']
    meta=read('structural3d/revisionB/mesh_summary.json')
    kinds={g['id']:('steel' if g['name'] in ['RotorIron','Shaft'] else g['material']) for g in meta['groups']}
    structure.update(read_results(case,p,t,fields['region'],kinds,finite_geometry=True))
    sta=BASE/'structural3d/revisionB/fault_hot_follower_weak01/rotor.sta'
    rows=[l.split() for l in sta.read_text().splitlines() if l.split() and l.split()[0].isdigit()]
    if not rows or int(rows[-1][0])!=2 or abs(float(rows[-1][-2])-1)>1e-8:
        raise RuntimeError('Final structural fault load step is incomplete')
    structure['final_load_step_verified']=True
    if structure.get('pressure_load_mode')!='follower':raise RuntimeError('Follower pressure was not used')
    if structure.get('moment_balance_residual_Nm',float('inf'))>.01:
        raise RuntimeError('Structural output reaction does not balance the fault torque')
    weak=structure.get('weak_sleeve_rotation_spring')
    if weak is None or abs(weak['torque_Nm'])>.001:raise RuntimeError('Sleeve rotational reference not qualified')
    dump(sta.parent/'summary.json',structure)
    if 'contact_results' not in structure:
        # A solver driver already running when the streaming readback was added
        # can finish with the older summary. Read its final CONTACT block only.
        case=BASE/'structural3d/revisionB/fault_hot_follower_weak01'
        rows=[];current=False;final=[]
        for line in (case/'rotor.frd').open():
            if line.startswith(' -4'):current=line[5:17].strip().split()[0]=='CONTACT';rows=[]
            elif current and line.startswith(' -1'):
                rows.append([float(line[i:i+12]) for i in range(13,len(line),12) if line[i:i+12].strip()])
            elif current and line.startswith(' -3'):final=rows;current=False
        a=np.array(final)
        if a.ndim!=2 or a.shape[1]!=6:raise RuntimeError('Final contact output missing')
        penetration=np.maximum(-a[:,0],0)*1e6
        structure['contact_results']=dict(source='Final CONTACT COPEN/CPRESS; frictionless tangential output unused',
            slave_output_nodes=len(a),max_penetration_um=float(penetration.max()),penetration_p99_um=float(np.quantile(penetration,.99)),
            max_pressure_MPa=float(a[:,3].max()/1e6),pressure_p99_MPa=float(np.quantile(a[:,3],.99)/1e6))
        dump(case/'summary.json',structure)
    gates=[]
    def gate(name,status,evidence):gates.append(dict(name=name,status=status,evidence=evidence))
    gate('Nominal CAD geometry','PASS','143 valid solids and STEP round trip; Ø112 housing, Ø12×155 shaft; revision B axial sleeve clearance 0.15 mm each end.')
    gate('Native Pyleecan/Elmer coupling','PASS','24 positions; mean torque differs from native FEMM by %.3f%%.'%(100*native['relative_mean_torque_difference']))
    change=abs(fine['torque_Nm']/coarse['torque_Nm']-1)
    gate('3D torque numerical checks','PASS' if change<.01 else 'REVIEW','Nonlinear coarse/fine torque change %.3f%%; component, discrete air Maxwell tensor and finite-rotation energy checked.'%(change*100))
    gate('220 N·m mean duty','CONDITIONAL PASS' if sweep['mean_shaft_torque_margin_fraction']>0 else 'FAIL',
         'At 12.2 A/120°C magnets, mean shaft %.4f N·m after 18 W allowance; actuator %.2f N·m with assumed 63:1/80%%; margin %.2f%%. Generic materials and loss allowance apply.'%(sweep['estimated_shaft_torque_mean_Nm'],sweep['estimated_actuator_torque_mean_Nm'],100*sweep['mean_shaft_torque_margin_fraction']))
    e=sweep['electrical_estimate']
    gate('42 V nominal-duty voltage','CONDITIONAL PASS' if e['sampled_harmonic_voltage_gate_pass'] else 'FAIL',
         'Flux-derived sampled-harmonic phase-voltage circle %.3f V peak versus 21.824 V reserved ceiling; switching and higher harmonics unresolved.'%e['max_dq_voltage_circle_phase_peak_V'])
    hotcontrol=control['hotter_magnet_test_150C']
    gate('Torque-trough control headroom','CONDITIONAL PASS' if hotcontrol['sampled_trough_pass'] else 'FAIL',
         'Constant 12.2 A sampled minimum misses the shaft target; 13 A/150°C magnets at the sampled trough gives %.4f N·m shaft versus 4.3651. Ripple compensation, tracking and continuum extrema remain to qualify.'%hotcontrol['estimated_shaft_torque_Nm'])
    gate('12.2 A hot holding','PASS' if hold['winding_hotspot_C']<130 else 'FAIL','Refined winding %.3f°C; 70°C sink, low resin conductivity, reduced interface conductance, 30° holding angle.'%hold['winding_hotspot_C'])
    gate('Thermal joint retention','UNQUALIFIED','The 1000–5000 W/m²K contact conductance must be maintained by an engineered fit or bond. With generic Al/steel CTE, common 50 K heating opens a nominally zero-clearance Ø96 interface by 26.4 µm radially unless retained.')
    gate('18.5 A continuous hot holding','CONDITIONAL PASS' if limit['winding_hotspot_C']<130 else 'FAIL','Refined winding %.3f°C, only %.3f°C below 130°C; requires the stated cooling and impregnation.'%(limit['winding_hotspot_C'],130-limit['winding_hotspot_C']))
    gate('22 A continuous hot holding','FAIL','Winding %.3f°C exceeds 130°C. Do not assign 22 A continuous holding.'%failed22['winding_hotspot_C'])
    gate('22 A for 5 seconds','CONDITIONAL PASS' if pulse['winding_hotspot_C']<130 else 'FAIL','Refined winding %.3f°C from the 12.2 A hot holding field; fixed 130°C-resistance source and stated heat capacities/cooling.'%pulse['winding_hotspot_C'])
    gate('Rotor contact calculation','NUMERICALLY COMPLETED','Thermal preheat then full 1890 rpm/13.416 N·m/2 MPa/150°C case; finite-strain bond, frictionless small sliding. Uniform pressure is a screening envelope, not mapped local traction.')
    gate('Structural torque load path','PASS','Current-geometry applied %.6f N·m, output reaction %.6f N·m, weak reference %.6f N·m; residual %.6f N·m. Independent shaft torsion error 0.184%%.'%(structure['applied_torque_current_geometry_Nm'],structure['output_reaction_torque_Nm'],weak['torque_Nm'],structure['moment_balance_residual_Nm']))
    gaps=structure.get('axial_capture_clearance_um',{})
    if 'minimum' not in gaps:raise RuntimeError('Deformed axial capture clearance was not checked')
    gate('Hot axial sleeve capture','NOMINAL PASS' if gaps['minimum']>0 else 'FAIL',
         'Deformed front/rear lip gaps %.1f/%.1f µm with the centered floating sleeve; manufacturing tolerances excluded.'%(gaps['front'],gaps['rear']))
    axis=structure['material_results']['wrap']['cylindrical_axis_stress_MPa']
    gate('Sleeve, bond and magnet strength','UNQUALIFIED','Sleeve factor-two peak requirements: hoop %.1f, radial tension %.1f, axial tension %.1f MPa. Transverse/shear peaks and sharp corners require checked layup, mesh/penalty sensitivity and actual hot allowables; adhesive creep and brittle-magnet data absent.'%(structure['wrap_factor2_required_hot_hoop_strength_MPa'],2*axis['radial_tension'],2*axis['axial_tension']))
    gate('Irreversible demagnetization','UNQUALIFIED','3D −55.27 A d-axis/150°C reverse H max 712 kA/m; inherited cold fault requirement 852 kA/m. Supplier intrinsic curves/knee are absent.')
    gate('Running gap and installed bearings','CONDITIONAL','Nominal residual gap %.1f µm in the B hot fault case, before tolerances/runout. Generic bearing stiffness/conductance; fits, preload and supplier ratings not assigned.'%(250-structure['rotor_outer_radial_displacement_um']))
    gate('Installed vibration / forced response','UNQUALIFIED','Corrected-support A bonded first mode 416.008 Hz; 40× shaft-order coincidence is 624.0 rpm, near 630 rpm duty. Actual excitation projection, damping and installed bearing/housing dynamics are required; coincidence alone is not amplitude.')
    gate('Optional 400 N·m drive point','FAIL','Inherited angle-resolved 42 V reserved-voltage check failed; no pass is asserted by the new 22 A thermal or torque cases.')
    result=dict(status='completed_simulation_candidate',conclusion='Motor mean-duty feasibility is conditional on the stated cooling, loss and material assumptions; continuous 22 A holding fails. Hardware strength, demagnetization and manufacturing qualification are not established.',gates=gates,
        angular_mean=sweep,structural_case='structural3d/revisionB/fault_hot_follower_weak01',
        required_hardware_inputs=['Temperature-dependent intrinsic SmCo magnet curve and coating/segment insulation',
          'Qualified sleeve laminate orientation, hot strengths and composite interaction criterion',
          'Adhesive hot shear/tensile strength, creep and fatigue law',
          'Measured cooling/interface resistances and impregnation quality',
          'Bearing preload/clearance/stiffness/conductance and shaft fits',
          'Allocated manufacturing tolerances, concentricity, balance, joint and output interface'])
    dump(BASE/'assessment.json',result)
    integrity={name:distribution_integrity(name) for name in ['pyleecan','pyfemm']}
    selected=[*ROOT.glob('actuator/*elmer*.py'),ROOT/'actuator/rotor_structural3d.py',
        ROOT/'actuator/rotor_modal_check.py',
        *ROOT.glob('actuator/elmer_*.F90'),ROOT/'configs/motor_candidate.json',
        *ROOT.glob('docs/elmer*.json'),*ROOT.glob('docs/elmer*.patch'),
        ROOT/'scripts/make_gmsh_elmer_report.py',ROOT/'scripts/finalize_gmsh_elmer_study.py',
        BASE/'geometry_B/Motor_Gmsh_Elmer_Candidate_mm.step',BASE/'geometry_B/cad_export_check.json',
        *[p/'case.sif' for p in paths],*[p/'summary.json' for p in paths]]
    selected.extend(BASE/p for p in ['structural3d/revisionB/fault_hot_follower_weak01/rotor.inp',
        'structural3d/revisionB/fault_hot_follower_weak01/summary.json',
        'structural3d/coarse/modal_point_supports/modal.inp','structural3d/coarse/modal_point_supports/summary.json',
        'geometry_B/mass_properties.json','validation/structural_torque_path.json','pwm_segmentation/summary.json'])
    for folder in ['thermal3d/revisionB_fine','thermal3d/revisionB']:
        for case in (BASE/folder).glob('*/summary.json'):
            d=json.loads(case.read_text())
            if d.get('status')=='completed':selected.extend([case,case.parent/'case.sif'])
    selected.extend(ROOT/'.local'/p for p in ['elmer-hpc/bin/ElmerSolver','elmer/bin/ElmerSolver',
        'elmer-hpc/lib/elmersolver/MagnetoDynamics.so','elmer-user/MotorMaterialsHPC.so','elmer-user/MotorGaugeHPC.so'])
    hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in selected if p.is_file()}
    dump(BASE/'provenance.json',dict(installed_source_integrity=integrity,file_sha256=hashes,
        source_archive_sha256='7addfb102d735929a40929be08be0c16703d734498d33bc70c96e7d526fe249c',
        upstream_tests=read('validation/elmer_upstream_tests.json'),
        notes=['Elmer HPC magnetodynamics uses recorded CHOLMOD-index and full-tensor Newton corrections',
               'Pyleecan and pyfemm distribution Python sources remain unchanged',
               'Accepted field/case checks recorded; failed and time-limited runs excluded',
               'Build recipes are included; restoration into a new empty host was not tested']))
    print(json.dumps(gates,indent=2),flush=True)


if __name__=='__main__':main()
