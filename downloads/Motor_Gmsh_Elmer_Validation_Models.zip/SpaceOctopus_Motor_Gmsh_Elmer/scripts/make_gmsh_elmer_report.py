"""Build the standalone numerical motor design report and dimension reference."""
import argparse,hashlib,json,os,sys
from pathlib import Path
from xml.sax.saxutils import escape
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'.local/matplotlib'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle,Polygon,Wedge,Rectangle
from matplotlib.collections import PolyCollection
import numpy as np
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,Image,PageBreak,KeepTogether
from actuator.machine import build_machine
from actuator.elmer_motor import BASE

OUT=BASE/'report';FIG=OUT/'figures';FIG.mkdir(parents=True,exist_ok=True)
NAVY='#19364a';TEAL='#207b78';RED='#a8444c';COPPER='#c77d38'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'text.color':NAVY,'axes.labelcolor':NAVY,'savefig.facecolor':'white'})


def read(path,default=None):
    path=Path(path)
    return json.loads(path.read_text()) if path.exists() else default


def fmt(value,d=3):
    if value is None:return '—'
    if isinstance(value,(str,bool)):return str(value)
    if isinstance(value,(list,tuple,np.ndarray)):return ', '.join(fmt(v,d) for v in value)
    return ('%.'+str(d)+'f')%float(value)


def save(fig,name):
    p=FIG/(name+'.png');fig.savefig(p,dpi=190,bbox_inches='tight');plt.close(fig);return p


def section_polygons(points,t,values,axis=2,at=.05,nodal=False):
    """Linear tetrahedron/plane intersection; no interpolation outside the mesh."""
    v=points[t];s=v[:,:,axis]-at
    hit=(s.min(axis=1)<0)&(s.max(axis=1)>0);ids=np.where(hit)[0]
    edges=[(0,1),(0,2),(0,3),(1,2),(1,3),(2,3)];polygons=[];scalars=[]
    keep=[i for i in range(3) if i!=axis]
    for i in ids:
        poly=[];vals=[]
        for a,b in edges:
            if s[i,a]*s[i,b]>=0:continue
            f=s[i,a]/(s[i,a]-s[i,b]);p=v[i,a]+f*(v[i,b]-v[i,a]);poly.append(p[keep])
            if nodal:vals.append(values[t[i,a]]+f*(values[t[i,b]]-values[t[i,a]]))
        if len(poly)<3:continue
        poly=np.array(poly);center=poly.mean(axis=0);order=np.argsort(np.arctan2(poly[:,1]-center[1],poly[:,0]-center[0]))
        polygons.append(poly[order]*1000);scalars.append(float(np.mean(vals)) if nodal else values[i])
    return polygons,np.array(scalars)


def field_figure(path,name,kind='temperature',axis=1,at=.000113):
    x=np.load(path);p=x['p'];t=x['t']
    if kind=='temperature':value=x['temperature_C'];label='Temperature [°C]';nodal=True;cmap='inferno'
    elif kind=='B':value=np.linalg.norm(x['B'],axis=1);label='|B| [T]';nodal=False;cmap='viridis'
    else:
        value=(np.linalg.norm((p+x['displacement'])[:,:2],axis=1)-np.linalg.norm(p[:,:2],axis=1))*1e6
        label='Radial displacement [µm]';nodal=True;cmap='viridis'
    if t.shape[1]>4:t=t[:,:4]
    poly,scalars=section_polygons(p,t,value,axis,at,nodal)
    fig,ax=plt.subplots(figsize=(8,4.4));pc=PolyCollection(poly,array=scalars,cmap=cmap,rasterized=True,edgecolors='none')
    ax.add_collection(pc);ax.autoscale();ax.set_aspect('equal');ax.set(xlabel=['x [mm]','y [mm]','z [mm]'][[i for i in range(3) if i!=axis][0]],
       ylabel=['x [mm]','y [mm]','z [mm]'][[i for i in range(3) if i!=axis][1]])
    fig.colorbar(pc,ax=ax,label=label);return save(fig,name)


def figures(geo):
    paths={};c=read(ROOT/'configs/motor_candidate.json');m=build_machine(c)
    local=m.stator.slot._comp_point_coordinate();slot=np.array([[local['Z%d'%i].real,local['Z%d'%i].imag] for i in range(1,11)])*1000
    profile=np.array(geo['winding_profile_local_m'])*1000
    def rot(a,theta):
        co,si=np.cos(theta),np.sin(theta);return a@np.array([[co,si],[-si,co]])
    fig,ax=plt.subplots(figsize=(7.4,6.5))
    for r,color in [(56,'#dce3e8'),(48,'#8998a4'),(26.5,'white'),(23,'#536f85'),(6,'white')]:ax.add_patch(Circle((0,0),r,facecolor=color,edgecolor=NAVY,lw=.7))
    for k in range(12):
        a=np.deg2rad(15+30*k);ax.add_patch(Polygon(rot(slot,a),color='white'))
        for sign in [-1,1]:ax.add_patch(Polygon(rot(profile*np.array([1,sign]),a),facecolor=COPPER,edgecolor='white',lw=.25))
    for k in range(10):ax.add_patch(Wedge((0,0),26.05,3.6+36*k,32.4+36*k,width=3,color=RED))
    ax.add_patch(Wedge((0,0),26.25,0,360,width=.2,color=TEAL))
    ax.set(xlim=(-59,59),ylim=(-59,59),xlabel='x [mm]',ylabel='y [mm]',title='Nominal radial layout: 12 slots, 10 poles, inner rotor')
    ax.set_aspect('equal');paths['radial']=save(fig,'radial_dimensions')
    fig,ax=plt.subplots(figsize=(8,3.9));p=profile;ax.add_patch(Polygon(p,facecolor='#edf1f3',edgecolor=NAVY))
    for x,y in np.array(geo['wire_packing']['centers_local_m'])*1000:
        ax.add_patch(Circle((x,y),.5,color='#57748a'));ax.add_patch(Circle((x,y),.475,color=COPPER))
    ax.set_aspect('equal');ax.set(xlabel='Native radial coordinate [mm]',ylabel='Tangential coordinate [mm]',title='One coil side: 24 insulated strands inside the lined half-slot')
    paths['packing']=save(fig,'wire_packing')
    thermal=[]
    for folder in ['thermal3d/coarse','thermal3d/fine','thermal3d/revisionB','thermal3d/revisionB_fine']:
        for case in sorted((BASE/folder).glob('*/summary.json')):
            d=read(case)
            if d.get('status')=='completed':thermal.append((folder.split('/')[-1],case.parent.name,d))
    chosen=[(n,d) for f,n,d in thermal if (f=='revisionB' and n in ['nominal','hold12p2_angle30','hold22_angle30']) or (f=='revisionB_fine' and n=='hold18p5_angle30')]
    if chosen:
        fig,ax=plt.subplots(figsize=(8,3.8));ax.bar(np.arange(len(chosen)),[d['winding_hotspot_C'] for n,d in chosen],color=TEAL)
        ax.axhline(130,color=RED,ls='--',label='Declared winding limit 130°C');ax.set_xticks(np.arange(len(chosen)))
        ax.set_xticklabels([n.replace('_','\n') for n,d in chosen],fontsize=7);ax.set(ylabel='Winding hotspot [°C]',ylim=(0,170));ax.legend(loc='upper left')
        paths['thermal_bars']=save(fig,'thermal_cases')
    for folder,label,kind,axis,at in [
       ('thermal3d/revisionB_fine/pulse22A_worst_hotR_100','pulse','temperature',1,.000113),
       ('thermal3d/revisionB_fine/hold12p2_angle30','thermal_B','temperature',1,.000113),
       ('thermal3d/fine/nominal','thermal','temperature',1,.000113),
       ('magnetic3d/coarse/nonlinear_tensor_newton','magnetic','B',2,.050113),
       ('structural3d/revisionB/fault_hot_follower_weak01','deformation','displacement',1,.000113)]:
        p=BASE/folder/'fields.npz'
        if p.exists():paths[label]=field_figure(p,label,kind,axis,at)
    sweep=read(BASE/'magnetic3d/angle_sweep_120C/summary.json',{})
    if sweep:
        x=[d['rotor_angle_deg'] for d in sweep['rows']];y=[d['torque_Nm'] for d in sweep['rows']]
        fig,ax=plt.subplots(figsize=(7.6,3.2));ax.plot(x,y,'o-',color=TEAL,label='12.2 A / 120°C; solved samples')
        floor=220/(63*.8)+18/(630*2*np.pi/60)
        ax.axhline(floor,color=RED,ls='--',label='Shaft requirement + 18 W drag')
        ax.axhline(sweep['torque_mean_Nm'],color=NAVY,ls=':',label='Eight-position mean')
        c=read(BASE/'control_margin/summary.json',{})
        if c:ax.scatter([c['rotor_angle_deg']],[c['tested_EM_torque_Nm']],marker='^',s=70,color=COPPER,label='Separate 13 A trough check')
        ax.set(xlabel='Rotor angle [mechanical degrees]',ylabel='Electromagnetic torque [N·m]');ax.legend(fontsize=7,loc='upper right')
        paths['torque_sweep']=save(fig,'torque_sweep')
    return paths,thermal


def make(draft=False):
    geo=read(BASE/'geometry_B/assembly.json') or read(BASE/'geometry/assembly.json')
    pics,thermal=figures(geo)
    report=read(BASE/'assessment.json',{})
    native=read(BASE/'native_api_2d_24/summary.json',{})
    cross=read(BASE/'crosscheck_2d/summary.json',{})
    coil=geo['coils'][0];pack=geo['wire_packing'];dims=geo['proposed_dimensions']
    rve=read(BASE/'winding_microstructure/fine/summary.json',{})
    mechanical=read(BASE/'structural3d/coarse/fault_hot_point_supports/summary.json',{})
    modal=read(BASE/'structural3d/coarse/modal_point_supports/summary.json',{})
    f0=modal.get('first_frequency_Hz',0.)
    mechcontact=read(BASE/'structural3d/revisionB/fault_hot_follower_weak01/summary.json',{})
    sweep=read(BASE/'magnetic3d/angle_sweep_120C/summary.json',{})
    control=read(BASE/'control_margin/summary.json',{})
    em=[]
    for folder in (BASE/'magnetic3d').glob('*'):
        for p in folder.glob('*/summary.json'):
            d=read(p)
            if d.get('status')=='completed' and (d.get('gauge')=='Dirichlet-rooted spanning tree' or folder.name=='fine'):
                em.append((folder.name,p.parent.name,d))
    required=[BASE/'magnetic3d/coarse/nonlinear_tensor_newton/summary.json',BASE/'thermal3d/revisionB_fine/pulse22A_worst_hotR_100/summary.json',
              BASE/'geometry_B/cad_export_check.json',BASE/'structural3d/revisionB/fault_hot_follower_weak01/summary.json',
              BASE/'magnetic3d/angle_sweep_120C/summary.json',BASE/'assessment.json',BASE/'control_margin/summary.json',
              BASE/'thermal3d/revisionB_fine/pulse22A_from13_hold100/summary.json',
              BASE/'structural3d/coarse/modal_point_supports/summary.json',BASE/'validation/structural_torque_path.json']
    if not draft and any(not p.exists() for p in required):raise RuntimeError('Required final result missing: '+str([str(p) for p in required if not p.exists()]))
    for name in ['DejaVuSans','DejaVuSans-Bold']:
        pdfmetrics.registerFont(TTFont(name,'/usr/share/fonts/truetype/dejavu/'+name+'.ttf'))
    styles=getSampleStyleSheet();styles.add(ParagraphStyle('BodyMotor',fontName='DejaVuSans',fontSize=9,leading=12.6,textColor=colors.HexColor(NAVY),spaceAfter=8))
    styles.add(ParagraphStyle('TitleMotor',fontName='DejaVuSans-Bold',fontSize=21,leading=27,textColor=colors.HexColor(NAVY),spaceAfter=16))
    styles.add(ParagraphStyle('HeadingMotor',fontName='DejaVuSans-Bold',fontSize=14,leading=18,textColor=colors.HexColor(TEAL),spaceAfter=12))
    styles.add(ParagraphStyle('SmallMotor',fontName='DejaVuSans',fontSize=7,leading=9,textColor=colors.HexColor(NAVY)))
    story=[]
    def para(s):story.append(Paragraph(s,styles['BodyMotor']))
    def heading(s):story.append(Paragraph(s,styles['HeadingMotor']))
    def page(title):
        if story:story.append(PageBreak())
        heading(title)
    def table(headers,rows,widths=None,padding=5):
        vals=[[Paragraph(escape(str(x)),styles['SmallMotor']) for x in row] for row in [headers]+rows]
        w=widths or [499/len(headers)]*len(headers)
        t=Table(vals,colWidths=w,repeatRows=1,hAlign='LEFT')
        t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e6edef')),('VALIGN',(0,0),(-1,-1),'TOP'),
          ('LINEBELOW',(0,0),(-1,0),.6,colors.HexColor(TEAL)),('BOTTOMPADDING',(0,0),(-1,-1),padding),('TOPPADDING',(0,0),(-1,-1),padding),
          ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#f5f7f8')])]))
        story.extend([t,Spacer(1,9)])
    def picture(key,maxh=290):
        if key in pics:
            from PIL import Image as PI
            with PI.open(pics[key]) as im:w,h=im.size
            scale=min(499/w,maxh/h);story.extend([Image(str(pics[key]),w*scale,h*scale),Spacer(1,10)])
    story.append(Paragraph('Motor design and<br/>Gmsh–Elmer analysis',styles['TitleMotor']))
    para('Space Octopus • 12-slot / 10-pole permanent-magnet motor • 6 November 2026')
    if draft:para('<b>IN-PROGRESS LAYOUT DRAFT — missing cases are not accepted results.</b>')
    picture('radial',230)
    para('This report extends the previous Pyleecan/FEMM dimension report with actual three-dimensional geometry, electromagnetic finite elements, insulated-wire thermal calculations, complete motor conduction, and rotor structural calculations. Gmsh prepares the geometry and meshes; Elmer performs the field solves. CalculiX supplies the orthotropic rotor and contact analyses.')
    para('The deliverable is a simulation design candidate for independent validation. Supplier magnetic curves, composite strength, adhesive temperature/creep properties, bearing data and manufacturing tolerances remain material design inputs. Numerical completion does not constitute a fabrication or hardware qualification.')
    if sweep:
        para('<b>Torque finding:</b> at 12.2 Arms and 120°C magnets, the eight-position 3D mean is '+fmt(sweep.get('torque_mean_Nm'),4)+' N·m. After the stated 18 W non-copper loss allowance, the estimated mean shaft torque is '+fmt(sweep.get('estimated_shaft_torque_mean_Nm'),4)+' N·m against the 4.3651 N·m requirement.')
    para('<b>Thermal limit:</b> continuous 22 A hot holding reaches 154.7°C and fails the declared 130°C limit. The refined 18.5 A case reaches 126.4°C. A five-second 22 A pulse from the 12.2 A hot holding field reaches 103.3°C under the stated cooling and material assumptions.')

    page('1. Requirement, operating point and interpretation')
    table(['Quantity','Value / meaning'],[
      ['Actuator torque reference','220 N·m; actuator mechanics are outside this report'],['Assumed reduction / efficiency','63:1 / 0.80'],
      ['Actuator / motor speed','10 rpm / 630 rpm'],['Required motor shaft torque','220/(63×0.80) = 4.365079 N·m'],
      ['Required motor shaft power','287.979 W at 630 rpm'],['DC supply','48 V nominal; 42 V minimum'],['Current ceiling','22 Arms; pulse/voltage/temperature limits apply'],
      ['Declared winding temperature limit','130°C'],['Cooling boundary','Distributed barrel-to-sink resistance 0.05 K/W'],
      ['Sink cases','50°C nominal; 70°C hot boundary'],['Mechanical screening speed / torque','1,890 rpm / 13.416 N·m; final B outward pressure 2 MPa']],[165,334])
    para('The original native model required approximately 10.834 Arms for the nominal target. The additional 12.2 Arms case is a design-margin scenario; its electromagnetic result must be read with the corresponding temperature, rotor position and steel model. A static torque point is not a full-period mean rating.')
    para('The 22 A steady thermal calculation tests thermal capacity. It does not establish that 22 A is electrically available at every speed on a 42 V bus. The earlier angle-resolved optional 400 N·m actuator point failed the reserved 42 V voltage criterion and is not reclassified as a pass here.')
    para('All dimensions in the sketches/tables are millimetres unless marked otherwise. The motor has an inner rotor: the shaft and magnet-bearing rotor turn inside the stator. The motor contains no second internal motor.')

    page('2. Changes from the preceding PDF')
    table(['Item','Earlier dimensional basis','Declared three-dimensional candidate'],[
      ['Shaft','Basic Ø12 × 130','Ø12 × 155; z = −35 to 120'],['Coil end geometry','12 mm electrical half-turn allowance; physical route unresolved','Closed stranded-coil envelope with 180° formed end turns'],
      ['Mean turn length','218 mm','%.6f mm'%coil['mean_turn_length_mm']],['Net coil-side envelope','35.75 mm² native half-slot','%.6f mm² after liner/separator'%coil['net_cross_section_mm2']],
      ['Magnet bond','Not a separate radial solid','0.05 mm outside rotor iron; magnet radii 23.05–26.05'],
      ['Outer magnet retention','Proposed 0.20 mm wrap','Wrap radii 26.05–26.25; cold free radial gap 0.25'],
      ['Magnet axial segmentation','Four segments proposed','Four × 21.175 mm, three × 0.10 mm insulating seams'],
      ['Housing / end support','Preliminary envelopes','Barrel, two end caps, bearings, collars, nuts and 12 bolts in CAD'],
      ['Sleeve capture revision B','Revision A lips touch the 0/85 mm core end faces','0.15 mm nominal axial clearance at each retention lip; sleeve z −0.15 to 85.15']],[105,175,219])
    para('Revision A was retained as an analysed comparison. Bonding its sleeve/lip interfaces imposes strong thermal constraints and produces high local stresses. Revision B introduces axial clearance and explicitly evaluates sliding sleeve contact. Its active magnetic solids are unchanged, so the magnetic geometry is shared. Revision B receives a separate thermal and structural check.')
    para('The former report remains a historical reference: Motor_Dimensions_and_Analysis.pdf, SHA-256 560495945e37bcd89a2af78bca3e1a77938f5467ca1e12a78cf3cccc54d999f3. This report identifies every new geometric proposal explicitly.')

    page('3. Radial dimensions and magnetic stack')
    picture('radial',310)
    table(['Feature','Radius / diameter','Axial extent'],[
      ['Stator outer surface','R48 / Ø96','z 0–85'],['Stator bore','R26.5 / Ø53','z 0–85'],['Rotor iron','R6–23 / Ø12–46','z 0–85'],
      ['Magnet adhesive','R23–23.05','Under each segment'],['Magnets','R23.05–26.05 / bare Ø52.10','Total magnetic length 84.70'],
      ['Retention sleeve','R26.05–26.25 / Ø52.50','Revision B z −0.15–85.15'],['Free radial mechanical gap','26.50−26.25 = 0.250','Excludes thermal growth/runout'],
      ['Housing barrel','R48–56 / Ø96–112','z 0–85']],[180,165,154])

    page('4. Stator tooth and slot sketch coordinates')
    m=build_machine(read(ROOT/'configs/motor_candidate.json'));points=m.stator.slot._comp_point_coordinate()
    table(['Native point','Radial x [mm]','Tangential y [mm]'],[['Z%d'%i,fmt(points['Z%d'%i].real*1000,6),fmt(points['Z%d'%i].imag*1000,6)] for i in range(1,11)])
    para('Use straight segments Z1→Z2→…→Z10 and close along the bore arc of radius 26.5 mm through (26.5, 0). Rotate this local slot by 15° for slot 1 and repeat at 30° pitch. This preserves the native SlotW10 tooth tips and slot neck; a rectangular replacement changes the electromagnetic geometry.')
    table(['Slot parameter','Dimension'],[['W0 / H0','2 / 1'],['W1 / H1','6 / 1'],['H2 / W2','13 / 9'],['Total native slot opening area','77.474832 mm²'],['Native active winding window','71.500 mm²; 35.750 per side before new insulation'],['Minimum nominal back iron','6.275502 mm'],['Outer slot liner / middle separator','0.20 / 0.10 total']],[250,249])
    para('The liner and central separator are physical CAD volumes. Their nominal dimensions reduce each active half-slot to the polygon on the next page. No insulation strength, partial-discharge limit or process tolerance is established by geometric fit.')

    page('5. Coil-side packing and insulation')
    picture('packing',235)
    table(['Quantity','Value'],[['Turns per coil / strands in hand','12 / 2'],['Bare conductor diameter','0.950 mm'],['Assumed radial enamel thickness','0.025 mm'],['Insulated diameter','1.000 mm'],
      ['Net half-slot area',fmt(coil['net_cross_section_mm2'],6)+' mm²'],['Bare copper fraction of net envelope',fmt(100*pack['bare_copper_fraction_net'],4)+'%'],
      ['Insulated-wire area fraction',fmt(100*pack['coated_wire_area_fraction_net'],4)+'%'],['Minimum wire centre separation',fmt(pack['minimum_center_spacing_m']*1000,5)+' mm'],
      ['Minimum coating-to-envelope clearance',fmt(pack['minimum_coating_to_envelope_clearance_m']*1e6,3)+' µm']],[270,229])
    para('Twenty-four coated circles fit at nominal dimensions. The small minimum residual clearance is not a manufacturing tolerance allowance. The selected wire must meet the stated maximum coated diameter, and the liner/separator process must preserve the net envelope.')
    table(['Net polygon vertex','x [mm]','y [mm]'],[[i+1,fmt(x*1000,6),fmt(y*1000,6)] for i,(x,y) in enumerate(geo['winding_profile_local_m'])])

    page('6. Wire centre coordinates for CAD')
    table(['Strand','Local x [mm]','Local y [mm]'],[[i+1,fmt(x*1000,6),fmt(y*1000,6)] for i,(x,y) in enumerate(pack['centers_local_m'])])
    para('These are nominal centres for one lined half-slot. Mirror the tangential coordinate for its opposite half, then rotate the slot coordinate frame to the required slot centre. They locate conductor cross-sections; they are not a fabrication routing of all end-turn strands or terminal leads.')

    page('7. Winding connections and physical end turns')
    table(['Coil','Phase','Signed turns','Tooth axis [deg]'],[[d['coil'],d['phase'],d['signed_turns'],d['axis_angle_deg']] for d in geo['coils']])
    para('The three phases are Y connected, with four series coils and 48 series turns per phase. Signed turns specify the current direction relative to the positive local coil direction. Coil side T0 in slot s returns through the mirrored T1 side in slot s−1. The table retains the native Pyleecan connection matrix.')
    table(['End-turn quantity','Value'],[['Closed mean turn length',fmt(coil['mean_turn_length_mm'],6)+' mm'],['Active straight-leg contribution','2 × 85 = 170 mm'],['Mean total end-turn contribution',fmt(coil['mean_turn_length_mm']-170,6)+' mm'],
      ['Nominal cold phase resistance','0.128522351 Ω at 20°C'],['Copper temperature coefficient','0.00393 K⁻¹'],['Physical axial end-turn overhang','Approximately 10.636 mm from the exact coil-side profile']],[270,229])
    para('The CAD coils are connected homogenized stranded-current solids. The end-turn geometry is a 180° revolution of the lined coil-side polygon about its tooth radial axis at each stack end. The electromagnetic source follows that closed loop; it is not a shorted solid copper ring.')
    para('An independent CAD volume check found about 0.123% difference between kernel quadrature and the analytical swept-volume value for each curved coil. Electrical resistance uses the conservative analytical 220.174618 mm turn length. This small geometry/integration difference is disclosed rather than hidden in an exact-volume claim.')
    area=2*np.pi*(.95/2)**2
    table(['Conductor loading','Value'],[['Two-strand copper area per turn',fmt(area,6)+' mm²'],['Copper current density at 12.2 / 13 / 22 Arms',fmt(12.2/area,3)+' / '+fmt(13/area,3)+' / '+fmt(22/area,3)+' A/mm²'],['Worst holding phase current density','√2 times the corresponding dq RMS value']],[280,219])

    page('8. Magnets, sleeve, adhesive and capture clearances')
    table(['Feature','Nominal definition'],[['Pole pitch / arc','36° / 28.8°'],['Pole 1 angular extent / centre','3.6°–32.4° / 18°'],['Magnetization','Alternating outward/inward radial direction'],['Segments per pole / total','4 / 40'],
      ['Segment axial length / seam','21.175 / 0.100'],['Segment z intervals','0–21.175; 21.275–42.450; 42.550–63.725; 63.825–85.000'],['Inner bond thickness','0.050 radial'],['Sleeve radial thickness','0.200'],
      ['Revision B sleeve z interval','−0.150 to 85.150'],['Revision B front / rear retention lips','−0.650 to −0.150 / 85.150 to 85.650'],['Lip radial interval','22.500 to 26.250'],['Cold axial core-to-lip clearance','0.150 each side']],[210,289])
    para('The radial sleeve consumes mechanical clearance but is treated as approximately nonmagnetic. The bond moves the magnet radially outward by 0.05 mm. The total nonmagnetic radial path from rotor iron to stator remains approximately 0.50 mm because the inner bond replaces an equal amount of external bare-magnet gap.')
    para('Revision B axial clearance is a proposed change derived from the hot restraint study. A stress-free 20°C steel stack growing to 150°C increases its 85 mm length by approximately 0.1326 mm, or 0.0663 mm per end about the midplane. The stated 0.15 mm nominal clearance leaves approximately 0.0837 mm per end before tolerances and differential sleeve effects.')

    page('9. Shaft, bearings and enclosure dimensions')
    table(['Part / feature','Basic dimensions and locations'],[['Shaft','Ø12 × 155; z −35 to 120'],['Equivalent 6201 bearings','Ø12 ID × Ø32 OD × 10; centres z −14 and 99'],['Bearing seat intervals','Front z −19…−9; rear z 94…104'],['Bearing support span','113'],
      ['Barrel','Ø96 ID / Ø112 OD × 85'],['End caps','Front z −20…0; rear z 85…105'],['End-cap plate thickness','6; plates z −20…−14 and 99…105'],['Bearing boss / shoulder opening','Basic Ø44 boss / Ø28 shoulder opening'],
      ['Inner collars','Ø12/18 × 4; z −9…−5 and 90…94'],['Locknut envelopes','M12×1 equivalent, Ø19 × 3; z −22…−19 and 104…107'],['Cap screws','Six M4×30 per end; PCD104; cap clearance Ø4.5'],['Barrel screw engagement','10 mm at each end; Ø4 thread-equivalent cylinders']],[195,304])
    para('Bearings, collars, nuts and fasteners are dimensional envelopes in CAD. Bearing internal geometry, preload, journal fits, screw thread helices, rotor-to-shaft joint capacity and output coupling interfaces are not selected by the electromagnetic solver. These must be assigned for a manufactured assembly and for a final bearing/contact model.')

    page('10. Verified Pyleecan–Elmer coupling')
    para('The installed Pyleecan source is kept unchanged. The stock MagElmer mesh-conversion method is used; this project supplies the missing physical field/flux extraction through a motor-specific adapter. That adapter runs inside native Simu1, integrates depth exactly once, returns actual B fields and phase fluxes, and feeds native ForceMT.')
    table(['Check','Executed result'],[['Native Pyleecan API angular positions',native.get('positions',native.get('poses','See saved native API result'))],['Elmer mean torque [N·m]',fmt(native.get('mean_torque_Nm',native.get('torque_mean_Nm')))],
      ['Reference FEMM mean torque [N·m]','4.427214318'],['Mean-torque difference','Approximately 0.290% for 24 samples'],['Same-mesh vector-potential comparison','Linear and nonlinear Elmer versus independent scikit-fem: about 0.0117% relative error'],
      ['Force coupling','Native Pyleecan ForceMT executed with returned magnetic field'],['Depth normalization','Project flux/torque divided by stack length before native integration']],[235,264])
    para('The earlier 12-position torque-ripple result aliased the waveform and was replaced by the 24-position run. The 24-position peak-to-peak torque ripple is about 0.654 N·m. Mean torque agreement alone does not establish ripple convergence or all high-frequency losses.')
    para('This is an explicit project repair of an incomplete upstream interface, not a claim that the unmodified stock MagElmer extractor supplies all of these quantities. The adapter and readback are included with the reproducible study.')

    page('11. Three-dimensional magnetic mesh and constitutive law')
    table(['Mesh','Nodes','Tetrahedra','Near-gap target [mm]'],[[name,read(BASE/'magnetic3d'/name/'mesh_summary.json',{}).get('nodes','—'),read(BASE/'magnetic3d'/name/'mesh_summary.json',{}).get('tetrahedra','—'),fmt(read(BASE/'magnetic3d'/name/'mesh_summary.json',{}).get('gap_h_m',0)*1000)] for name in ['coarse','fine','segmented']])
    para('The axial-half domain starts at the 42.5 mm midplane. Magnetic normal flux is zero on that symmetry plane; total torque and phase flux integrals are multiplied by two. The far cylinder radius is 90 mm and its outer axial plane is z = 155 mm. The complete closed coil end region is present. The nonmagnetic housing, liner, bond and wrap are replaced by air in static magnetics; exterior ferromagnetic fastener effects are a separate unresolved material scenario.')
    para('The STEP rotor is at the nominal CAD reference, with pole 1 centred at 18°. The first magnetic case adds 50.999972° mechanical rotation to that rotor while keeping stator/coils fixed. Its phase currents are [0, +√(3/2) Iq, −√(3/2) Iq]. Other sweep cases use electrical angle 5(θ−50.999972°). Preserve this reference when recreating the cases in Ansys; CAD zero and the first solved rotor position are different.')
    para('The linear check uses relative permeabilities 1500 in the lamination plane and 19.75 axially. The nonlinear model uses the bundled M270-35A B–H curve and 95% steel fill, mixing parallel permeability and series axial reluctivity. The supplied curve ends at 1.8 T; higher-field extrapolation remains an unqualified material assumption.')
    para('A boundary-rooted spanning-tree gauge removes every active gradient mode and is checked by graph rank. The native interior forest left one mode in this mesh. Failed/nonphysical configurations are excluded. Direct and iterative comparisons, mesh refinement, finite field checks and actual solver residuals are recorded; an Elmer process merely exiting successfully is insufficient.')
    picture('magnetic',260)

    page('12. Executed three-dimensional magnetic results')
    table(['Mesh / case','Iq [Arms]','Magnet [°C]','Torque [N·m]','ψd,rms [Wb]','Peak |B| [T]'],[
      [f+'/'+n,fmt(d.get('Iq_Arms')),fmt(d.get('magnet_C'),1),fmt(d.get('torque_Nm'),6),fmt(d.get('Phid_rms_Wb'),7),fmt(d.get('max_B_T'),4)] for f,n,d in em],[155,55,60,80,80,69])
    para('The accepted torque is Elmer’s Component variational torque, multiplied by two for axial symmetry. It is cross-checked by independently integrating the air Maxwell tensor against a piecewise-linear nodal virtual rotation. The legacy Torque Group readout and a separately integrated narrow continuous weighting function disagree with that mesh-consistent result and are excluded from rating conclusions.')
    audit=read(BASE/'validation/torque_readback.json',{})
    table(['Torque method / check','Linear coarse result [N·m]'],[['Component variational torque','4.411918'],['Independent discrete air Maxwell tensor','4.411387'],['Fixed-current energy derivative, ±0.25°','4.410494'],['Fixed-current energy derivative, ±0.50°','4.407909']],[310,189])
    para('For linear tetrahedral Nedelec elements, A inside a cell is reconstructed as A at the centroid plus ½ B×(r−rcentroid). Coil flux is then integrated with 64-point Duffy quadrature along the actual curved current direction. The 27-versus-64-point change is recorded to separate end-turn integration error from magnetic mesh error.')
    para('With the accepted component method, coarse-to-fine linear torque changes 0.672% (4.411918→4.382280 N·m); nonlinear torque changes 0.635% (4.472416→4.444000 N·m). The fine nonlinear ψd,rms is 0.02721123 Wb. The independent discrete Maxwell torque differs from the component result by less than 0.02% in the principal comparison cases. Local sharp-corner |B| maxima are less converged than integral torque, especially near the axial magnet seams.')
    para('The approximately 3 T global maxima in the segmented cases occur in tiny air regions near the inner bond/seam edges, not as a uniform steel induction. At the 12.2 A/120°C reference position, the maximum homogenized steel |B| is about 1.686 T and its volume-weighted p99 is 1.303 T. Intrinsic lamination BFe can exceed bulk B because of fill. The near-zero d-axis fault torque is not a useful relative-error benchmark; its extraction difference is about 0.0016 N·m in absolute terms.')

    page('12A. Angular mean, shaft torque and actuator requirement')
    picture('torque_sweep',155)
    if sweep:
        table(['Rotor angle [deg]','3D torque [N·m]','ψd,rms [Wb]'],[[fmt(d['rotor_angle_deg'],3),fmt(d['torque_Nm'],6),fmt(d['Phid_rms_Wb'],7)] for d in sweep['rows']],[160,170,169])
        table(['Quantity','Executed result'],[['Current / magnet temperature','12.2 Arms / 120°C'],['Repeat interval / samples','36° mechanical / eight positions at 4.5°'],['Mean electromagnetic torque',fmt(sweep['torque_mean_Nm'],6)+' N·m'],['Sampled torque extrema',fmt(sweep['torque_min_sampled_Nm'],6)+' to '+fmt(sweep['torque_max_sampled_Nm'],6)+' N·m'],['Four-versus-eight mean change',fmt(100*sweep['four_vs_eight_mean_relative_change'],3)+'%'],['Non-copper shaft-drag allowance','18 W / 65.97345 rad/s = 0.272837 N·m'],['Estimated mean shaft torque',fmt(sweep['estimated_shaft_torque_mean_Nm'],6)+' N·m'],['Required shaft torque','4.365079 N·m'],['Estimated mean actuator torque',fmt(sweep['estimated_actuator_torque_mean_Nm'],3)+' N·m at 63:1 and 80% efficiency'],['Mean shaft-torque margin',fmt(100*sweep['mean_shaft_torque_margin_fraction'],2)+'%']],[265,234])
    para('The eight-position sampling spans the native 36° repeat interval. Applied to the existing 24-position 2D data, the same eight positions change the mean by approximately 0.022%. That is a sampling check using the reference waveform; sampled 3D extrema still do not prove ripple convergence. The four-versus-eight 3D mean comparison is reported above.')
    para('Electromagnetic torque is converted to an estimated shaft value by deducting the entire stated 18 W non-copper loss envelope at 630 rpm. Copper loss affects voltage, efficiency and temperature but is not subtracted again as shaft drag. Replace the allowance with actual core, magnet, bearing and windage losses when supplier data and measurements are available. Mean torque does not ensure the minimum instantaneous torque without controller ripple compensation.')

    page('12B. Flux-derived voltage and hot-duty efficiency')
    if sweep:
        e=sweep['electrical_estimate']
        table(['Quantity','Calculated value'],[['Resistance temperature upper bound',fmt(e['resistance_temperature_upper_bound_C'],3)+'°C winding hotspot'],['Phase resistance upper bound',fmt(e['Rphase_upper_bound_Ohm'],8)+' Ω'],['Maximum sampled-harmonic dq voltage circle',fmt(e['max_dq_voltage_circle_phase_peak_V'],4)+' V phase peak'],['Maximum phase-voltage span',fmt(e['max_phase_voltage_span_V'],4)+' V'],['42 V bus reserved ceilings','21.824 V phase circle / 37.800 V span'],['Moving copper loss',fmt(e['moving_copper_loss_W'],3)+' W'],['Additional motor loss allowance','18.000 W'],['Estimated shaft power at 630 rpm',fmt(e['estimated_shaft_power_W'],3)+' W'],['Estimated motor electrical input',fmt(e['estimated_motor_input_W'],3)+' W'],['Estimated motor efficiency',fmt(100*e['estimated_motor_efficiency'],2)+'%'],['Estimated 48 V DC current',fmt(e['estimated_48V_DC_current_A'],3)+' A, before inverter loss']],[290,209])
    para('The voltage estimate interpolates the eight-position 3D dq flux waveform and differentiates it with rotor angle. With RMS dq quantities, Vd = R Id + ωm(dψd/dθ−5ψq), Vq = R Iq + ωm(dψq/dθ+5ψd). Three phase voltages are reconstructed and their span is compared with the reserved bus voltage. The resistance uses the full winding hotspot as a conservative phase-temperature bound.')
    para('Only harmonics resolved by the eight samples are represented; higher space harmonics and switching components remain outside this new estimate. The earlier full-period FEMM/drive work remains relevant. These values are a nominal-duty model check, not a controller or inverter qualification. The estimated efficiency includes the new hot copper loss and 18 W motor loss allowance; it excludes inverter power loss.')

    page('12C. Torque trough and current-control headroom')
    if control:
        c=control;p=c['linearized_profile'];hot=c.get('hotter_magnet_test_150C',{})
        table(['Check','Result'],[['Selected lowest-torque sampled rotor angle',fmt(c['rotor_angle_deg'],3)+'°'],['12.2 A electromagnetic / estimated shaft torque',fmt(c['baseline12p2_EM_torque_Nm'],6)+' / '+fmt(c['baseline12p2_shaft_torque_Nm'],6)+' N·m'],['13 A verified electromagnetic / estimated shaft torque',fmt(c['tested_EM_torque_Nm'],6)+' / '+fmt(c['tested_shaft_torque_Nm'],6)+' N·m'],['Required motor shaft torque','4.365079 N·m'],['13 A sampled-trough shaft margin',fmt(100*c['shaft_torque_margin_fraction'],2)+'%'],['13 A steady hot holding winding',fmt(c['holding13_hotspot_C'],3)+'°C; refined low-resin/poor-contact model'],['13 A moving winding / magnet maxima',fmt(c['moving13_hotspot_C'],3)+' / '+fmt(c['moving13_magnet_C'],3)+'°C'],['22 A, 5 s pulse from 13 A holding field',fmt(c['pulse22_from13_hotspot_C'],3)+'°C winding'],['Linearized compensation current range',fmt(p['current_min_Arms'],3)+' to '+fmt(p['current_max_Arms'],3)+' Arms'],['Linearized compensation voltage circle',fmt(p['maximum_phase_voltage_circle_peak_V'],3)+' V peak; reserved ceiling 21.824 V']],[290,209])
        if hot:para('An additional 13 A trough solve at 150°C magnets gives '+fmt(hot['torque_EM_Nm'],6)+' N·m electromagnetic and '+fmt(hot['estimated_shaft_torque_Nm'],6)+' N·m estimated shaft torque, a '+fmt(100*hot['shaft_margin_fraction'],2)+'% margin. This magnet temperature is above the 121.3°C moving thermal result and adds a temperature sensitivity check.')
    para('Constant 12.2 A meets the mean torque criterion under the stated assumptions, but the sampled trough after the 18 W drag allowance falls below the shaft requirement. A separate nonlinear 13 A solve at the lowest sampled position tests available headroom. A controller can use an angle/current lookup and feedback to compensate ripple; the table reports a linearized feasibility profile, not an implemented controller.')
    para('The profile estimates Iq(θ) by scaling the sampled torque curve, then includes the resulting q-flux derivative in voltage. Cogging is not strictly proportional to current, and current-dependent cross-saturation is only approximated. Exact continuum extrema, sensor/commutation errors, dynamic current tracking and inverter limits require controller calibration. The constant 13 A thermal cases conservatively bound the heating of a profile that remains below 13 A.')
    if sweep:
        s=sweep['requirement_sensitivity']
        table(['Mean-duty sensitivity at 12.2 A','Threshold / scope'],[['Maximum non-copper loss compatible with 220 N·m',fmt(s['maximum_total_noncopper_loss_W'],3)+' W at 630 rpm'],['Extra loss budget beyond the assumed 18 W',fmt(s['additional_loss_budget_beyond18W'],3)+' W'],['Minimum gearbox efficiency for this mean shaft torque',fmt(100*s['minimum_gearbox_efficiency_for220Nm'],2)+'% at 63:1'],['Approximate Br20 floor if torque scaled linearly',fmt(s['approximate_minimum_Br20_T'],4)+' T; first-order sensitivity only']],[300,199])
        para('The 6% mean torque margin is not a material or manufacturing safety factor. Supplier remanence variation, actual gap, loss and gearbox efficiency can consume it. The remanence threshold is an algebraic first-order sensitivity, not another finite-element validation.')

    page('13. Electrical use, demagnetization and losses')
    table(['Model input / inherited result','Value / scope'],[['Magnet Br at 20°C','1.05 T'],['Br temperature coefficient','−0.0003 K⁻¹'],['Magnet recoil μr','1.05'],['Magnet electrical resistivity','0.9 µΩ·m at 20°C; assumed +0.0003 K⁻¹'],
      ['Phase resistance at 20°C','0.128522351 Ω for new coil length'],['Phase resistance at 100 / 130°C',fmt(.1285223514*(1+.00393*80),8)+' / '+fmt(.1285223514*(1+.00393*110),8)+' Ω'],
      ['Native nominal phase voltage peak','15.734 V at the former nominal operating point'],['42 V reserved phase-voltage ceiling','21.824 V peak in the inherited drive criterion'],['Inherited nonlinear fault current / torque','55.27 Arms vector envelope / 13.416 N·m'],
      ['Inherited reverse-field knee requirement','About 852 kA/m for the prior cold 1,890 rpm nonlinear fault case']],[225,274])
    para('A linear recoil magnet model cannot prove irreversible demagnetization resistance. The negative field must be checked against the selected supplier’s temperature-dependent intrinsic curve and knee, including segment-edge fields and tolerances. Br alone does not specify coercivity.')
    table(['New segmented 3D case','Maximum reverse H [kA/m]','Volume-weighted p99 [kA/m]'],[[n,fmt(d.get('magnet_reverse_H_max_A_m',0)/1000),fmt(d.get('magnet_reverse_H_volume_p99_A_m',0)/1000)] for f,n,d in em if f=='segmented'],[245,127,127])
    para('The −55.27 A d-axis, 150°C magnet case requires approximately 712 kA/m at its largest sampled local reverse field. This is a directional fault scenario, not an exhaustive current-angle demagnetization envelope. The inherited cold maximum of approximately 852 kA/m remains a separate requirement; neither result supplies the missing intrinsic magnet curve.')
    para('The preceding study already ran native winding, core-loss, magnet-loss and force models, full-period FEMM field histories, direct AC wire impedance, DC-biased harmonic magnet response and ideal-switch drive spectra. Steel loss coefficients remain calibrated to a generic 3 W/kg point, not supplier data. The new thermal campaign deliberately uses a stated additional motor-loss envelope rather than claiming those generic coefficients are measured losses.')

    page('14. Three-dimensional magnet segmentation and AC response')
    eddy=[]
    for name in ['rooted_coarse','rooted_fine']:
        for p in sorted((BASE/'magnet_eddy3d'/name).glob('*/*/summary.json')):
            d=read(p)
            if d.get('status')=='completed':eddy.append((name,d))
    table(['Mesh','Segments','f [Hz]','Field axis','Pole loss [W] at 10 mT peak'],[[n,d['segments'],fmt(d['frequency_Hz'],0),d['excitation_axis'],fmt(d['pole_loss_W'],8)] for n,d in eddy],[87,62,80,75,195],padding=3.5)
    para('These are three-dimensional harmonic A–V conductor solves with electrical isolation of each segment, finite conductivity, closed return currents and internal conductive reaction. A uniform boundary induction is clamped on one pole; surrounding motor steel/air reaction and the actual rotating/PWM boundary spectrum are absent. Multiply by ten poles only for a genuinely identical excitation on every pole. Loss scales with the square of boundary amplitude in this linear test.')
    para('A separate low-frequency conduction formulation was solved with Elmer StatCurrentSolver and independently with scikit-fem on the same 3D mesh. Potential differences were below 0.00001% and spurious reference-node current was negligible. Four axial segments reduce the tested radial-field low-frequency loss by approximately 30%; tangential-field reduction is much smaller. A 1/N² segmentation rule is not valid for this magnet geometry.')

    page('14A. Recorded PWM spectra and segmentation sensitivity')
    pwm=read(BASE/'pwm_segmentation/summary.json',{})
    table(['f [kHz]','Four/one segment loss ratio, radial','Four/one segment loss ratio, tangential'],[[fmt(d['frequency_Hz']/1000,0),fmt(d['directional']['x']['ratio'],6),fmt(d['directional']['y']['ratio'],6)] for d in pwm.get('segmentation_factors',[])],[100,199,200])
    table(['Recorded current waveform','2D continuous reference [W]','3D shape sensitivity [W]'],[[Path(d['current_waveform']).stem,fmt(d['continuous_2D_reference_loss_W'],6),fmt(d['segmented_3D_shape_sensitivity_low_W'],6)+'–'+fmt(d['segmented_3D_shape_sensitivity_high_W'],6)] for d in pwm.get('rows',[])],[255,122,122])
    para('The recorded dq current spectra are applied to the earlier full-motor DC-biased Hermitian FEMM response at 20/40/80 kHz. The new Elmer isolated-pole four/one-segment ratios are then used as directional shape sensitivities at those frequencies. They predict roughly 0.06–0.10 W magnet PWM loss for those recorded waveforms, well below the stated 3.6 W rotor heat allocation in the 18 W moving-loss scenario.')
    para('This is a quantified transfer sensitivity, not a complete 3D motor PWM loss bound. The actual motor fields are nonuniform; the old drive waveforms/bias are retained; response temperature is 80°C. Approximately 25–41% of the current variance lies outside 20–80 kHz, where the original response uses a low-frequency clamp or high-frequency continuation. The new 13 A compensation controller is not re-simulated here. Winding proximity, steel PWM loss and inverter power remain separate uncertainties.')

    page('15. Thermal conductivity from 24 actual insulated strands')
    picture('packing',210)
    rows=[]
    for d in rve.get('cases',[]):
        rows.append([fmt(d['resin_k_W_mK']),fmt(d['conservative_transverse_k_W_mK'],6),fmt(d['upper_eigenvalues_W_mK'],6)])
    table(['Resin k [W/m·K]','Conservative transverse k','Dirichlet tensor eigenvalues'],rows)
    para('Copper is 390 W/m·K and enamel is 0.15 W/m·K. The actual 24-wire cross-section is meshed, including every enamel ring. Dirichlet and Neumann apparent-conductivity experiments are run in two directions. The minimum Neumann-tensor eigenvalue is used as a conservative transverse scalar in the motor. The along-wire conductivity is approximately 211.3 W/m·K from actual copper/enamel/resin fractions.')
    para('The winding conductivity tensor follows the curved end turn: K = kt I + (ka−kt) t⊗t. A fixed global axial conductivity would incorrectly conduct through the curved end region. These values remain conditional on impregnation quality and the assumed resin/enamel properties; they are not measurements of a manufactured winding.')

    page('16. Full-motor thermal model and cooling requirements')
    table(['Thermal feature','Declared value / treatment'],[['Domain','Axial half of complete declared motor solids'],['Vacuum-facing surfaces','Adiabatic; no internal gas convection or radiation'],['External sink','Full Ø112 × 85 barrel only; 0.05 K/W distributed Robin boundary'],['Equivalent barrel coefficient','668.718 W/m²·K = 1/(0.05 × 2π × 0.056 × 0.085); equivalent sink coupling'],
      ['Stator-to-housing interface','50 µm equivalent layer; k = thickness × contact conductance'],['Contact conductance cases','5,000 and 1,000 W/m²·K'],['Stator / rotor laminated k','20 in-plane / 1.5 axial W/m·K'],['Aluminium k','167 W/m·K'],['Liner / bond / wrap k','0.2 / 0.2 / 0.3 W/m·K'],['Equivalent bearing k','0.5 W/m·K; no measured bearing resistance'],['Copper source','Local temperature-dependent I²R, except explicitly fixed-hot pulse bound']],[210,289])
    para('All coil end-turn heat and heat capacity are present. Moving operation applies phase RMS heating. Holding uses instantaneous balanced phase currents. The initial angle-zero pattern [0, +√(3/2) Iq, −√(3/2) Iq] was extended by a 0°/15°/30°/45°/60° electrical-angle sweep. The hottest selected position is 30°, with [−Iq/√2, +√2 Iq, −Iq/√2], concentrating heat in one phase. Every pattern has the same total current square, 3 Iq².')
    para('Additional motor losses are distributed 80% into stator iron and 20% into rotor iron plus magnets, proportional to their volumes. The moving design cases use 18 W; the 22 A moving screening case uses 25 W; hot holding/pulse cases use 2 W. These are stated heat-load scenarios, not a measured or supplier-calibrated partition.')
    para('The 50 µm thermal contact layer replaces only the outermost stator steel in the FE conduction model. It is an equivalent resistance, not an extra mechanical CAD gap. Exterior bolts are omitted from thermal meshing; cap/barrel contact is idealized. Bearing and interface data must be replaced with measured or supplier values for a final thermal qualification.')
    para('The basic Ø96 stator/barrel dimensions do not define an interference fit. With generic aluminium/steel expansion coefficients 23/12 µm/m·K, common 50 K heating creates 26.4 µm radial differential expansion at R48. A selected fit, bond or retained interface must preserve the assumed conductance as temperature changes. Fit tolerances and retention are not supplied by thermal conductivity alone.')
    para('Thermal transient steel density is the full-material 7650 kg/m³; the nominal CAD mass table applies 95% fill to laminated steel. This small heat-capacity difference is an input uncertainty. Homogenized coil temperature does not resolve a defective impregnation void or an individual poorly cooled strand.')

    page('16A. Thermal material properties for independent recreation')
    table(['Material','Density [kg/m³]','Heat capacity [J/kg·K]','k [W/m·K]'],[
       ['Copper',8960,385,390],['Enamel',1200,1400,.15],['Resin',1200,1100,'0.4 or 0.2'],
       ['Laminated stator/rotor steel',7650,460,'20 x/y; 1.5 z'],['Shaft, collars, locknuts',7650,460,45],
       ['SmCo magnet',8300,350,10],['Aluminium housing/caps',2700,900,167],['Liner / wedge / bond',1200,1100,.2],
       ['Sleeve / lips',1600,1000,.3],['Equivalent bearing',5000,460,.5],['Equivalent stator contact',1200,1000,'0.25 or 0.05']],[175,103,120,101])
    fc=pack['bare_copper_fraction_net'];fe=pack['coated_wire_area_fraction_net']-fc
    density=fc*8960+(1-fc)*1200
    cp=(fc*8960*385+fe*1200*1400+(1-fc-fe)*1200*1100)/density
    table(['Impregnated winding property','Value'],[['Homogenized density',fmt(density,4)+' kg/m³'],['Homogenized heat capacity',fmt(cp,4)+' J/kg·K'],['Copper / enamel / resin volume fractions',fmt(fc,7)+' / '+fmt(fe,7)+' / '+fmt(1-fc-fe,7)],['Along-wire conductivity','211.31–211.39 W/m·K; constituent mixture'],['Conservative transverse conductivity','0.584125 (low resin) / 0.991185 (nominal resin) W/m·K']],[280,219])
    para('All values are declared generic inputs. Winding k follows the curved wire direction as described in section 15. The stator contact conductivity is conductance × 50 µm; its density and heat capacity are numerical equivalents. Replace these properties with selected-material data before using the model as a hardware qualification.')

    page('17. Steady temperatures and mesh sensitivity')
    picture('thermal_bars',230)
    table(['Mesh / case','Iq','Sink [°C]','Winding max [°C]','Magnet max [°C]','Cu loss [W]'],[[f+'/'+n,fmt(d['Iq_Arms'],3),fmt(d['sink_C'],0),fmt(d['winding_hotspot_C'],3),fmt(d['magnet_hotspot_C'],3),fmt(d['copper_loss_W'],3)] for f,n,d in thermal if d.get('pulse_duration_s') is None],[166,47,55,80,80,71])
    para('The original coarse and refined full-motor meshes contain 99,278 / 177,525 nodes and 459,445 / 870,663 tetrahedra. Refinement changes the nominal winding hotspot by about 0.04°C, the low-resin hot holding point by 0.09°C, and the 22 A steady thermal case by 0.17°C. These changes quantify numerical sensitivity for the declared material/contact/cooling assumptions.')
    para('<b>New holding limit:</b> with a 70°C sink, 0.2 W/m·K resin, 1000 W/m²·K interface conductance and the 30° holding phase pattern, 22 A reaches 154.732°C and fails the 130°C criterion. At 19.0 A the coarse result is 130.124°C. Select 18.5 A as a conservative analysed continuous holding point: 126.584°C coarse, 126.387°C refined. This is conditional on the specified sink and impregnation, not a universal motor current rating.')
    para('Revision B’s refined model contains 177,964 nodes and 869,688 tetrahedra. At 12.2 A in the same hot holding scenario, coarse/refined winding temperatures are 92.945/92.870°C, a change of 0.075°C. The 18.5 A change is 0.198°C.')

    page('18. End-turn temperature and five-second current pulse')
    picture('pulse',285)
    pulse=[]
    for steps in [20,100]:
        d=read(BASE/('thermal3d/fine/pulse22A_5s_hotR_%d/summary.json'%steps))
        if d:pulse.append([steps,fmt(5/steps,3),fmt(d['winding_hotspot_C'],6),fmt(d['end_turn_hotspot_C'],6),fmt(d['copper_loss_W'],3)])
    table(['Time steps','Δt [s]','Winding max [°C]','End-turn max [°C]','Imposed Cu [W]'],pulse)
    para('The table above is the temporal-refinement check for the earlier angle-zero holding case: 20 versus 100 BDF2 time steps change the winding result by 0.0045°C. It is retained as a numerical check, not the worst holding result.')
    worst=[]
    for mesh in ['revisionB','revisionB_fine']:
        d=read(BASE/('thermal3d/'+mesh+'/pulse22A_worst_hotR_100/summary.json'))
        if d:worst.append([mesh,fmt(d['winding_hotspot_C'],6),fmt(d['end_turn_hotspot_C'],6),fmt(d['copper_loss_W'],3)])
    table(['Final 30° holding pulse','Winding max [°C]','End-turn max [°C]','Imposed Cu [W]'],worst,[180,110,110,99])
    para('The final pulse starts from the converged 12.2 A, 70°C-sink, low-resin, poor-interface field at the hotter 30° holding position. Apply 22 A for 5 s with 0.05 s steps and heat based on 130°C copper resistance. The refined winding/end-turn maxima are 103.266/100.109°C; the coarse winding result is 103.427°C. The imposed refined copper heat is 267.289 W. This heat-input bound is conservative while the winding remains below 130°C; actual strand temperatures, heat capacities and cooling must still be qualified.')

    page('19. Rotor loading, material model and mesh')
    table(['Structural input','Value / scope'],[['Full rotor domain','Shaft, rotor iron, 40 magnets, 40 bond pads, sleeve and retention lips'],['Mesh baseline','228,336 tetrahedra; 364,694 nodes for the A quadratic model'],['Thermal state','Uniform 150°C rotor from stress-free 20°C assembly'],['Speed / torque','1,890 rpm / 13.416 N·m'],['A historical outward pressure','0.591525 MPa from earlier 2D fault screening'],['B final outward pressure','2.000 MPa, simultaneously on all magnet outer faces'],['B pressure selection','3D sampled outer-gap |B|max 1.817 T → |B|²/(2µ0) 1.314 MPa; round up to 2 MPa'],['Bearings','On-axis mean journal translation springs; 5 MN/m per bearing'],['Shaft / magnet E','210 / 150 GPa; generic input values'],['Sleeve E radial / hoop / axial','10 / 100 / 10 GPa; orthotropic cylindrical axes'],['Sleeve CTE radial / hoop / axial','25 / 0 / 0 µm/m·K'],['Bond reference law','E 2.6 MPa, ν 0.3; G 1 MPa'],['Contact sensitivity','Frictionless unilateral sleeve; compressible neo-Hookean bond']],[210,289])
    para('The final bearings act on mean journal translations through on-axis reference springs, with 5 MN/m per bearing in each radial direction. They exert no torsional restraint. The output constraint removes mean tip rotation only; the front journal fixes mean axial rigid motion. Magnet-face load integration preserves zero resultant force and exactly 13.416 N·m in the undeformed geometry. Final contact uses linear tetrahedra; the original quadratic geometry benchmark remains a separate reference.')
    para('The B sleeve’s floating axial reference follows the rotor core’s mean midplane translation. Holding the sleeve at zero absolute axial displacement while locating the shaft at the front bearing would create an artificial thermal offset and consume one lip gap. The selected centered representative is checked against both deformed core-to-lip clearances; it is not an assumed bonded axial interface.')
    para('All reported design stresses below are unaveraged element integration-point values. Smoothed nodal stresses mix material interfaces and are retained for visualization only. Composite von Mises stress is not a composite failure criterion, and magnet tensile strength cannot be assessed from steel yield stress.')
    para('The final 2 MPa scalar pressure is approximately 52% above the largest sampled outer-gap |B|²/(2µ0) value in the new d-axis fault case. It is a deliberately increased screening load, not a direct mapped Maxwell traction analysis or a mesh-converged local peak bound. Higher sharp-edge fields occur inside the inner bond/segment seam. Physical edge radii and a resolved local electromagnetic/contact submodel are required for local strength qualification.')
    para('Normal pressure uses native element-face follower loading, updating surface normals and area with deformation. Tangential nodal loads have 13.416 N·m nominal moment in the undeformed geometry; the actual applied and reaction moments are evaluated in the deformed geometry. Fixed global radial nodal forces were excluded because they introduce an artificial drag moment when the rotor turns.')

    page('19A. Structural constitutive inputs and constraints')
    table(['Isotropic material','E [Pa]','Poisson ν','Density [kg/m³]','CTE [µm/m·K]'],[
       ['Steel','2.10×10¹¹',.30,7650,12],['Magnet','1.50×10¹¹',.24,8300,6],['Linear comparison bond','2.60×10⁶',.30,1200,80]],[140,110,75,95,79])
    table(['Sleeve cylindrical material axis','Declared engineering constant'],[['Axis 1 / 2 / 3','Radial / hoop / axial'],['E1 / E2 / E3','10 / 100 / 10 GPa'],['ν12 / ν13 / ν23','0.025 / 0.25 / 0.25; reciprocal values follow elastic symmetry'],['G12 / G13 / G23','5 / 3 / 5 GPa'],['Thermal expansion α1 / α2 / α3','25 / 0 / 0 µm/m·K'],['Density','1600 kg/m³']],[270,229])
    table(['Nonlinear bond input','Value'],[['Compressible neo-Hookean C10','0.500 MPa'],['D1','9.230769×10⁻⁷ Pa⁻¹'],['Equivalent reference G / K','1.000 / 2.166667 MPa'],['Stress-free temperature','20°C'],['Bond CTE','80 µm/m·K']],[270,229])
    para('Each radial bearing contributes 5 MN/m through an on-axis reference point coupled to the affine mean journal translation. The averaging annihilates rigid shaft rotation. Mean output-tip rotation fixes phase; mean front-journal axial displacement fixes the axial reference. Sleeve rotation is stabilized by a weak 0.01 N·m/rad numerical spring; its actual torque must remain below 0.001 N·m. The centered axial sleeve reference follows the core midplane. Contact is frictionless with a 10¹² Pa/m normal penalty. No adhesive damage, creep, composite interaction failure, rolling bearing contact or fit interference is included.')
    para('Rotor laminations are represented mechanically by isotropic steel in this screening model. Interlaminar slip, stack preload, selected shaft fit/joint capacity and actual orthotropic stack mechanics remain to be assigned. The 1,890 rpm case is a mechanical stress screen; it does not assert available loaded torque at that speed on the 48 V inverter.')
    para('The corrected load path is verified independently. A pure 13.416 N·m torque solve gives an output reaction of −13.416000 N·m. Away from interfaces, the Ø12 shaft shear is 39.614 MPa versus the analytical 16T/(πd³) = 39.541 MPa, a 0.184% difference. The final hot-contact output reaction is also checked against the full applied torque before acceptance.')

    page('20. Stress, sleeve interface and the design revision')
    rows=[]
    for label,data in [('A bonded, corrected supports',mechanical),('B sliding, corrected supports',mechcontact)]:
        for kind,v in data.get('material_results',{}).items():rows.append([label,kind,fmt(v.get('hoop_max_MPa')),fmt(v.get('tensile_principal_max_MPa')),fmt(v.get('max_shear_MPa')),fmt(v.get('von_mises_p99_MPa'))])
    table(['Model','Material','Hoop max [MPa]','Tensile principal max','Shear max','VM p99 [MPa]'],rows,[128,56,80,85,72,78])
    para('With the corrected supports, the A bonded linear-tetrahedron comparison gives approximately 435.8 MPa peak sleeve hoop stress and 258.4 MPa peak magnet tensile principal stress. Its sleeve hoop requirement alone is approximately 871.5 MPa at factor two. These are comparison requirements, not strength passes. B introduces axial clearance and a sliding interface to release the original end-face restraint.')
    para('Earlier supports grounded the sleeve angle and distributed Cartesian bearing-node motions, allowing unintended external torque reactions. Tying sleeve rotation rigidly to the core also produced an artificial internal torque through faceted contact. Those results are excluded from final strength evidence. The final mean-bearing/free-sleeve model checks both output reaction and the weak numerical spring torque. Sharp interface peaks and contact penalty/mesh effects still require qualification; historical P1/P2 agreement under the earlier supports is not treated as convergence of this contact solution.')
    para('A and B are different screening scenarios: B changes the pressure, contact law, axial capture and displacement basis. Their stress difference cannot be attributed solely to the added lip clearance. The A comparison provides a restraint/mesh warning; the final B numbers apply to its explicitly stated 2 MPa centered sliding model.')
    if mechcontact:
        c=mechcontact.get('contact_results',{})
        table(['Revision B completed contact check','Result'],[['Interface','Frictionless node-to-surface, small sliding; thermal preheat then fault load'],['Applied final screening pressure','2.000 MPa; A comparison used 0.591525 MPa'],['Normal penalty','1×10¹² Pa/m'],['Peak / p99 penetration',fmt(c.get('max_penetration_um'))+' / '+fmt(c.get('penetration_p99_um'))+' µm'],['Peak / p99 contact pressure',fmt(c.get('max_pressure_MPa'))+' / '+fmt(c.get('pressure_p99_MPa'))+' MPa'],['Outer radial growth',fmt(mechcontact.get('rotor_outer_radial_displacement_um'))+' µm'],['Required sleeve hot hoop strength, factor two',fmt(mechcontact.get('wrap_factor2_required_hot_hoop_strength_MPa'))+' MPa']],[290,209])
        para('The final contact model uses linear tetrahedra and a finite-strain soft-bond law. The larger sliding surface formulation and earlier time-limited runs were excluded. A small-sliding contact model is appropriate only while relative motion remains small compared with its facets; penalty penetration and mesh/facet effects are numerical uncertainty. Composite interaction failure, adhesive creep/fatigue and brittle magnet strength still require selected material data.')
        weak=mechcontact.get('weak_sleeve_rotation_spring',{})
        para('The numerical rotational spring carries '+fmt(weak.get('torque_Nm'),7)+' N·m; output reaction is '+fmt(mechcontact.get('output_reaction_torque_Nm'),6)+' N·m against 13.416 N·m nominal tangential loading. The proxy coordinate is q = 0.02625 θs in metres, with translational spring stiffness 0.01/(0.02625²) = 14.51247 N/m. This removes the floating mode with negligible torque rather than rigidly holding the sleeve angle.')
        para('The actual current-geometry applied moment is '+fmt(mechcontact.get('applied_torque_current_geometry_Nm'),6)+' N·m, including the follower-pressure contribution '+fmt(mechcontact.get('follower_pressure_torque_current_geometry_Nm'),6)+' N·m. The complete deformed-geometry balance residual is '+fmt(mechcontact.get('moment_balance_residual_Nm'),6)+' N·m. Structural p99 values are percentiles by integration-point count; they are not volume-weighted percentiles.')
        axis_stress=mechcontact.get('material_results',{}).get('wrap',{}).get('cylindrical_axis_stress_MPa',{})
        axis_p99=mechcontact.get('material_results',{}).get('wrap',{}).get('cylindrical_axis_stress_p99_MPa',{})
        table(['Sleeve material-axis stress','Peak [MPa]','p99 [MPa]','Factor-two peak allowable [MPa]'],[[k.replace('_',' '),fmt(v),fmt(axis_p99.get(k)),fmt(2*v)] for k,v in axis_stress.items()],[210,80,80,129])
        para('Principal maximum shear is an invariant on rotated planes; it is not automatically the laminate interlaminar shear stress. The table above gives actual radial/hoop/axial normal and shear components for comparison to selected composite allowables. A combined failure criterion and qualified laminate layup are still required.')
        gaps=mechcontact.get('axial_capture_clearance_um',{})
        para('The conservative deformed front/rear axial capture clearances are '+fmt(gaps.get('front'))+' / '+fmt(gaps.get('rear'))+' µm. These use the extrema of the relevant end faces, so a positive value confirms that the assumed open axial lip interfaces remain open in the analysed centered hot load case. Manufacturing and assembly errors are not included.')
    picture('deformation',230)

    page('21. Air-gap budget, bearing support and rotor modes')
    table(['Clearance contribution','Value / calculation'],[['Cold radial free gap','250 µm'],['A corrected-support hot-fault outer growth',fmt(mechanical.get('rotor_outer_radial_displacement_um'))+' µm'],['A residual gap before tolerance/runout',fmt(250-mechanical.get('rotor_outer_radial_displacement_um',0))+' µm'],['Declared residual-gap target','100 µm'],['A combined tolerance/runout/deflection budget',fmt(150-mechanical.get('rotor_outer_radial_displacement_um',0))+' µm'],['Static radial support compliance','100 N / 10 MN/m = 10 µm, plus shaft bending'],['First corrected-support unprestressed mode',fmt(f0,4)+' Hz'],['Equivalent 1× mode speed',fmt(f0*60,1)+' rpm; not an installed critical-speed map']],[255,244])
    para('The modal comparison uses the A bonded rotor and the corrected mean-bearing springs; it is not a prestressed solution of the final B sliding contact state. The first two modes are 416.008/416.013 Hz and the next is 525.304 Hz. Shaft rotation at 1,890 rpm is 31.5 Hz, but electromagnetic harmonics can excite much higher frequencies. Comparing only 1× shaft frequency with the first mode would miss possible coincidences.')
    table(['Forcing order × shaft speed','Speed at first-mode coincidence','Interpretation'],[[str(order),fmt(f0*60/order,1)+' rpm',meaning] for order,meaning in [(1,'Unbalance crossing above speed range'),(10,'2× electrical-frequency order; above maximum'),(12,'Slot-passing crossing above screening maximum'),(20,'Harmonic crossing inside screening range'),(30,'Harmonic crossing inside screening range'),(40,'Possible crossing near the 630 rpm duty')]], [155,165,179])
    para('These are frequency coincidences, not predictions of vibration amplitude. Force spatial order, modal projection, damping, real bearing/housing compliance and the actual spectrum determine whether a mode is excited. Bearing speed dependence, preload, gyroscopic terms and installed support dynamics are absent. The results therefore identify a follow-up forced-response/installed-support requirement and do not establish a resonance-free operating range.')
    para('Minimum running clearance must be checked with the selected sleeve/interface result, actual measured runout, rotor/stator diameter tolerances, bearing clearance and magnetic pull. A nominal 0.25 mm gap is not a tolerance-qualified running gap. The CAD fit does not allocate these unknown errors automatically.')
    if mechcontact:
        remaining=250-mechcontact['rotor_outer_radial_displacement_um']
        para('For the completed revision B contact scenario, the calculated outer radial growth is '+fmt(mechcontact['rotor_outer_radial_displacement_um'])+' µm. The nominal residual gap is therefore '+fmt(remaining)+' µm; retaining a 100 µm residual target leaves '+fmt(remaining-100)+' µm for the combined unmodelled tolerance, runout and deflection budget. Stator thermal expansion is omitted from this conservative clearance subtraction.')

    page('21A. Nominal assembly mass and rotor inertia')
    mass=read(BASE/'geometry_B/mass_properties.json',{})
    table(['Material class','Nominal mass [kg]'],[[k,fmt(v,6)] for k,v in mass.get('material_masses_kg',{}).items()],[290,209])
    table(['Quantity','Value'],[['Nominal complete CAD assembly mass',fmt(mass.get('total_CAD_assembly_mass_kg'),6)+' kg'],['Active rotating FE body mass',fmt(mass.get('active_rotating_FE_body_mass_kg'),6)+' kg'],['Active rotating polar inertia',fmt(mass.get('active_rotating_polar_inertia_kg_m2'),10)+' kg·m²']],[290,209])
    para('The nominal assembly includes housing, end caps, fastener envelopes, equivalent bearings, insulation and impregnated winding. Laminated iron mass uses 95% steel fill. Winding density follows the actual copper/insulation/resin area fractions; bearing density is an equivalent 5000 kg/m³. Masses come from independent OpenCascade integration of the delivered revision B solids. The rotating inertia includes the shaft, rotor iron, magnets, bond and sleeve; it excludes the rotating fraction of bearings, the coupling and the actuator.')

    page('22. Design decision and remaining qualification inputs')
    gates=report.get('gates',[])
    para('The study supplies a concrete CAD/FEA candidate and executed numerical evidence. A hardware strength or irreversible-demagnetization pass requires the actual supplier curves and allowables. The sleeve attachment, axial capture clearance and adhesive law are design variables; treating them as arbitrary bonded interfaces changes the result materially.')
    if gates:
        table(['Gate','Status','Evidence / implication'],[[g['name'],g['status'],g['evidence']] for g in gates[:11]],[150,80,269])
        page('22A. Mechanical and material qualification')
        table(['Gate','Status','Evidence / implication'],[[g['name'],g['status'],g['evidence']] for g in gates[11:]],[150,80,269])
    else:para('Final acceptance matrix is generated after the required numerical cases finish. This draft does not declare the motor validated.')
    para('Retain the full-period native electromagnetic maps and controller voltage limit when comparing to the actuator. Gearbox efficiency, actuator shock loads and installed thermal boundaries are assumptions inherited from the requirement; the actuator itself is not analysed by the Pyleecan motor model.')

    page('23. CAD and Ansys transfer')
    table(['Artifact','Units / contents'],[['Motor_Gmsh_Elmer_Candidate_mm.step','Millimetres; named nominal 143-solid assembly, independent round-trip check'],['Motor_Gmsh_Elmer_Candidate.FCStd','FreeCAD document with per-part names and analysis material labels'],['Magnetic Gmsh .msh / Abaqus .inp','Metres; axial half-domain, labelled field regions and boundaries'],['Thermal Gmsh .msh / .inp','Metres; actual lined coil/end-turn geometry and declared equivalent contact region'],['Rotor CalculiX .inp','SI m, N, Pa, kg, s; explicit loads, materials, supports and contact definitions'],['Reproduction source / case records','Project adapters, F90 material/gauge callbacks, solver inputs and compact result tables']],[205,294])
    para('STEP imports in millimetres. Solver meshes/decks use metres: do not apply the STEP scale to an already-SI mesh. Check the imported shaft length 155 mm and housing diameter 112 mm. Bearings and fasteners remain explicit dimensional envelopes. Closed coil solids represent stranded winding regions; do not assign them solid-copper eddy-current conductivity in a magnetic solver.')
    para('When recreating the magnetic half-model, preserve Bnormal = 0 at the stack midplane, the stated far-domain planes, current directions, 12 turns per coil, magnet radial orientation, coil/end-turn geometry and lamination tensor. In a full model, remove the symmetry multiplier. For thermal analysis, preserve complete barrel cooling and resolve the physical liner or a documented equivalent resistance.')
    para('No Ansys solve is claimed. The open-source model inputs and results are provided so that the user can independently recreate the same physics, then refine contacts, materials, mesh and installed conditions in Ansys or another solver.')
    para('The optional model archive also contains moving13_hot70_temperature_full_SI.csv: a 349,587-point full-motor temperature cloud obtained by mirroring the executed axial-half 13 A moving solution. Coordinates are metres and temperature is °C. It supports independent interpolation/comparison; the structural screen in this report still uses uniform 150°C, not a claimed mapped-temperature structural run.')

    page('24. Numerical provenance and result boundaries')
    table(['Software / input','Recorded basis'],[['Pyleecan','1.5.2; installed Python source integrity checked against distribution RECORD'],['Gmsh','4.13; OpenCascade geometry, conformal meshes'],['Elmer','Official release 26.2 source; local serial and MPI/HYPRE builds'],['Elmer CHOLMOD integration','Recorded 64-bit-index type correction; reference scalar solve versus UMFPACK'],['Elmer nonlinear tensor Newton','Recorded differentiation of complete H(B) vector; used by the nonlinear 3D HPC cases'],['Project extensions','Boundary-rooted tree gauge; motor-specific Pyleecan adapter; lamination and curved-winding material callbacks'],['CalculiX','2.20; linear/quadratic tetrahedra, orthotropic sleeve and nonlinear contact'],['Independent checks','scikit-fem/SciPy magnetic and conducting-potential solves; FreeCAD/OpenCascade geometry readback'],['Elmer source archive SHA-256','7addfb102d735929a40929be08be0c16703d734498d33bc70c96e7d526fe249c']],[185,314])
    para('All six selected upstream reference tests passed after the nonlinear correction: HeatAniso, mgdyn_anisotropic_rel, mgdyn_anisotropic_rel2, mgdyn_bh_relfun, mgdyn_hypre_ams and mgdyn_steady_2ndorder. The CHOLMOD scalar comparison to UMFPACK gives a 2.52×10⁻¹⁰ relative field difference. The project also checks finite-rotation energy torque, discrete Maxwell torque, native API results, wire packing, mesh/time refinement and mechanical load balance. Rejected and time-limited runs are excluded from accepted-result tables.')
    para('The recorded Elmer source corrections and project callbacks are required to reproduce these particular nonlinear 3D runs; results are not presented as an unmodified stock MagElmer workflow. Build recipes and hashes are supplied, although installation into a fresh empty host has not been tested. There is no claim of an Ansys solve or hardware correlation.')
    para('This report does not claim that every analysis Elmer or Pyleecan can perform has been run. There is no finite exhaustive software checklist that proves a motor correct. Its conclusions apply to the declared geometry, loads, material assumptions and numerical checks. Supplier-based demagnetization, composite/adhesive failure, manufacturing fits and physical test correlation remain qualification inputs.')

    page('Appendix A. Complete solid inventory and CAD bounds')
    para('Nominal axis-aligned CAD bounds in millimetres. Kernel bounding boxes for curved coils include a small numerical tolerance; use the exact swept geometry when constructing end turns. All 143 solids passed independent BREP validity checking and STEP round-trip count checks for the delivered revision.')
    rows=[]
    for p in geo['parts']:
        b=np.array(p['bounds_m'])*1000
        rows.append([p['name'],p['material'],fmt(b[:3],3),fmt(b[3:],3)])
    table(['Part name','Material class','Minimum x,y,z [mm]','Maximum x,y,z [mm]'],rows,[160,90,124,125])

    page('Appendix B. Magnetic material curve and lamination law')
    from pyleecan.Functions.load import load
    from pyleecan.definitions import DATA_DIR
    bh=np.asarray(load(DATA_DIR+'/Material/M270-35A.json').mag.BH_curve.get_data())
    H,B=bh[:,0],bh[:,1];slope=(H[-1]-H[-2])/(B[-1]-B[-2])
    extra=np.array([2.,2.5,3.,4.]);allB=np.r_[B,extra];allH=np.r_[H,H[-1]+(extra-B[-1])*slope]
    table(['B in steel [T]','H [A/m]','Basis'],[[fmt(b,3),fmt(h,3),'Bundled M270-35A' if b<=1.8 else 'Linear high-field extrapolation'] for b,h in zip(allB,allH)],[145,145,209])
    para('The tabulated isotropic steel curve is interpolated linearly in H(B). For fill kf = 0.95, solve νFe = H(|BFe|)/|BFe| with BFe,parallel = Bparallel/[kf+(1−kf)µ0νFe] and BFe,z = Bz. The homogenized reluctivity is νparallel = νFe/[kf+(1−kf)µ0νFe] and νz = kfνFe+(1−kf)/µ0. This preserves a conservative nonlinear anisotropic laminate law, rather than simply multiplying a scalar permeability by fill.')
    para('The linear numerical check uses µr,parallel = 1500 and µr,z = 19.75. The PM recoil model uses Br20 = 1.05 T, αBr = −0.0003 K⁻¹ and µr = 1.05, with alternating radial magnetization. Its source magnetization is Br/(µ0µr). The magnet’s intrinsic demagnetization curve is not supplied by this recoil model.')
    filename='Motor_Gmsh_Elmer_Design_Study_DRAFT.pdf' if draft else 'Motor_Gmsh_Elmer_Design_Study.pdf'
    target=OUT/filename
    def footer(c,doc):
        c.saveState();c.setStrokeColor(colors.HexColor('#cad4da'));c.line(48,39,547,39)
        c.setFont('DejaVuSans',7);c.setFillColor(colors.HexColor(NAVY));c.drawString(48,27,'Space Octopus • Motor study • 06 Nov 2026 • Simulation candidate')
        c.drawRightString(547,27,str(doc.page));c.restoreState()
    doc=SimpleDocTemplate(str(target),pagesize=A4,leftMargin=48,rightMargin=48,topMargin=47,bottomMargin=54,
       title='Motor Gmsh Elmer Design Study',author='Space Octopus engineering study',pageCompression=1)
    doc.build(story,onFirstPage=footer,onLaterPages=footer)
    print(target,hashlib.sha256(target.read_bytes()).hexdigest(),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--draft',action='store_true');a=parser.parse_args();make(a.draft)
