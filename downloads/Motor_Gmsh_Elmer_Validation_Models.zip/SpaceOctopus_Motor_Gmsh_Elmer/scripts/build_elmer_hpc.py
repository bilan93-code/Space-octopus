"""Configure/build the recorded official Elmer source in the project workspace."""
import argparse
import json
import os
import subprocess
from pathlib import Path
from apply_elmer_corrections import apply

ROOT = Path(__file__).resolve().parents[1]
LOCAL = ROOT / ".local"
SYS = LOCAL / "sysroot"
BIN = LOCAL / "bin"
BIN.mkdir(exist_ok=True)
LIB = SYS / "usr/lib/x86_64-linux-gnu"
GCC = SYS / "usr/lib/gcc/x86_64-linux-gnu/14"
ENV = os.environ.copy()
ENV["LD_LIBRARY_PATH"] = str(LIB) + ':' + str(LOCAL/'elmer-hpc-sysroot/usr/lib/x86_64-linux-gnu') + (":" + ENV["LD_LIBRARY_PATH"] if ENV.get("LD_LIBRARY_PATH") else "")
ENV["PATH"] = str(BIN) + ":" + ENV["PATH"]
ENV["OPENBLAS_NUM_THREADS"] = "1"
ENV["OMP_NUM_THREADS"] = "4"

fc = BIN / "gfortran-elmer"
fc.write_text('#!/bin/sh\nexec "' + str(SYS / "usr/bin/x86_64-linux-gnu-gfortran-14") +
              '" -B"' + str(GCC) + '" -B/usr/lib/gcc/x86_64-linux-gnu/14 "$@"\n')
fc.chmod(0o755)
cmake = SYS / "usr/bin/cmake"
source = LOCAL / "elmer-src"
apply(source)
build = LOCAL / "elmer-hpc-build"
install = LOCAL / "elmer-hpc"
modules = [
    "MagnetoDynamics", "MagnetoDynamics2D", "StatMagSolve", "StatCurrentSolve",
    "HeatSolve", "ElasticSolve", "StressSolve", "ResultOutputSolve",
    "SaveData", "HelmholtzProjection", "FourierLoss", "FluxSolver",
]
hpc_args = ['-DWITH_Hypre=ON', '-DHypre_INCLUDE_DIR=/workspace/Space-octopus/.local/elmer-hpc-sysroot/usr/include/hypre', '-DHypre_LIBRARIES=/workspace/Space-octopus/.local/elmer-hpc-sysroot/usr/lib/x86_64-linux-gnu/libHYPRE.so', '-DMPI_C_HEADER_DIR=/workspace/Space-octopus/.local/elmer-hpc-sysroot/usr/lib/x86_64-linux-gnu/openmpi/include', '-DMPI_C_ADDITIONAL_INCLUDE_DIRS=/workspace/Space-octopus/.local/elmer-hpc-sysroot/usr/lib/x86_64-linux-gnu/openmpi/include/openmpi', '-DMPI_Fortran_F77_HEADER_DIR=/workspace/Space-octopus/.local/elmer-hpc-sysroot/usr/lib/x86_64-linux-gnu/fortran/gfortran-mod-15/openmpi', '-DMPI_Fortran_MODULE_DIR=/workspace/Space-octopus/.local/elmer-hpc-sysroot/usr/lib/x86_64-linux-gnu/fortran/gfortran-mod-15/openmpi', '-DMPI_C_LIB_NAMES=mpi', '-DMPI_Fortran_LIB_NAMES=mpi_usempif08;mpi_usempi_ignore_tkr;mpi_mpifh;mpi', '-DMPI_mpi_LIBRARY=/lib/x86_64-linux-gnu/libmpi.so.40', '-DMPI_mpi_usempif08_LIBRARY=/lib/x86_64-linux-gnu/libmpi_usempif08.so.40', '-DMPI_mpi_usempi_ignore_tkr_LIBRARY=/lib/x86_64-linux-gnu/libmpi_usempi_ignore_tkr.so.40', '-DMPI_mpi_mpifh_LIBRARY=/lib/x86_64-linux-gnu/libmpi_mpifh.so.40', '-DCMAKE_EXE_LINKER_FLAGS=-Wl,-rpath-link,/workspace/Space-octopus/.local/elmer-hpc-sysroot/usr/lib/x86_64-linux-gnu', '-DCMAKE_SHARED_LINKER_FLAGS=-Wl,-rpath-link,/workspace/Space-octopus/.local/elmer-hpc-sysroot/usr/lib/x86_64-linux-gnu']
args = [
    str(cmake), "-S", str(source), "-B", str(build),
    "-DCMAKE_BUILD_TYPE=Release", "-DCMAKE_INSTALL_PREFIX=" + str(install),
    "-DCMAKE_Fortran_COMPILER=" + str(fc),
    "-DCMAKE_C_COMPILER=/usr/bin/gcc", "-DCMAKE_CXX_COMPILER=/usr/bin/g++",
    "-DWITH_MPI=ON", "-DWITH_OpenMP=ON", "-DWITH_ELMERGUI=OFF",
    "-DWITH_ElmerIce=OFF", "-DWITH_UMFPACK=ON",
    "-DUMFPACK_INCLUDE_DIR=" + str(SYS / "usr/include/suitesparse"),
    "-DUMFPACK_LIBRARIES=/lib/x86_64-linux-gnu/libumfpack.so.6",
    "-DBLAS_LIBRARIES=/lib/x86_64-linux-gnu/libblas.so.3",
    "-DLAPACK_LIBRARIES=/lib/x86_64-linux-gnu/liblapack.so.3;/lib/x86_64-linux-gnu/libblas.so.3",
    "-DINCLUDE_ELMER_MODULES=" + ";".join(modules),
    "-DELMER_FEM_REVISION=release-26.2", "-DRESET_ELMER_REVISION=FALSE",
    "-DELMER_FEM_BRANCH=release-26.2", "-DRESET_ELMER_BRANCH=FALSE",
]
args += hpc_args + ['-DMPI_SKIP_COMPILER_WRAPPER=ON', '-DMPI_CXX_HEADER_DIR=/workspace/Space-octopus/.local/elmer-hpc-sysroot/usr/lib/x86_64-linux-gnu/openmpi/include', '-DMPI_CXX_ADDITIONAL_INCLUDE_DIRS=/workspace/Space-octopus/.local/elmer-hpc-sysroot/usr/lib/x86_64-linux-gnu/openmpi/include/openmpi', '-DMPI_CXX_LIB_NAMES=mpi']
args += ['-DMPI_C_COMPILER_INCLUDE_DIRS=/workspace/Space-octopus/.local/elmer-hpc-sysroot/usr/lib/x86_64-linux-gnu/openmpi/include;/workspace/Space-octopus/.local/elmer-hpc-sysroot/usr/lib/x86_64-linux-gnu/openmpi/include/openmpi', '-DMPI_CXX_COMPILER_INCLUDE_DIRS=/workspace/Space-octopus/.local/elmer-hpc-sysroot/usr/lib/x86_64-linux-gnu/openmpi/include;/workspace/Space-octopus/.local/elmer-hpc-sysroot/usr/lib/x86_64-linux-gnu/openmpi/include/openmpi', '-DMPI_Fortran_COMPILER_INCLUDE_DIRS=/workspace/Space-octopus/.local/elmer-hpc-sysroot/usr/lib/x86_64-linux-gnu/fortran/gfortran-mod-15/openmpi;/workspace/Space-octopus/.local/elmer-hpc-sysroot/usr/lib/x86_64-linux-gnu/openmpi/include']
args += ['-DWITH_CHOLMOD=ON','-DCHOLMOD_INCLUDE_DIR='+str(SYS/'usr/include/suitesparse'),'-DCHOLMOD_LIBRARIES=/lib/x86_64-linux-gnu/libcholmod.so.5']
args += ['-DSPQR_INCLUDE_DIR='+str(SYS/'usr/include/suitesparse'),'-DSPQR_LIBRARIES=/workspace/Space-octopus/.local/elmer-hpc-sysroot/usr/lib/x86_64-linux-gnu/libspqr.so.4']
# Retain the recorded Debian 13 dependency layout while allowing relocation of
# this checkout. System /lib paths are platform requirements, not vendored ABI.
args=[arg.replace('/workspace/Space-octopus',str(ROOT)) for arg in args]
parser = argparse.ArgumentParser()
parser.add_argument("--configure-only", action="store_true")
options = parser.parse_args()
subprocess.run(args, env=ENV, check=True)
manifest_path = ROOT / "docs/elmer-hpc-build.json"
manifest = json.loads(manifest_path.read_text())
manifest.update(cmake_arguments=args[1:], modules=modules, host_packages_modified=False)
manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
if options.configure_only:
    raise SystemExit(0)
subprocess.run([str(cmake), "--build", str(build), "--parallel", "4"], env=ENV, check=True)
subprocess.run([str(cmake), "--install", str(build)], env=ENV, check=True)
for name in ["ElmerSolver", "ElmerGrid", "ElmerSolver_mpi", "elmerf90"]:
    if not (install / "bin" / name).is_file():
        continue
    wrapper = BIN / (name+"HPC")
    wrapper.write_text("#!/usr/bin/env python3\nimport os,sys\n" +
        "os.environ['ELMER_HOME']=" + repr(str(install)) + "\n" +
        "os.environ['OPENBLAS_NUM_THREADS']='2'\n" +
        "os.environ['LD_LIBRARY_PATH']=" + repr(str(LOCAL / 'elmer-hpc-sysroot/usr/lib/x86_64-linux-gnu/openblas-pthread') + ':' + str(install / "lib/elmersolver") + ':' + str(LOCAL / 'elmer-hpc-sysroot/usr/lib/x86_64-linux-gnu')) +
        "+(':'+os.environ['LD_LIBRARY_PATH'] if os.environ.get('LD_LIBRARY_PATH') else '')\n" +
        "os.environ.setdefault('OMP_NUM_THREADS','4')\n" +
        "os.execv(" + repr(str(install / "bin" / name)) + ",[sys.argv[0]]+sys.argv[1:])\n")
    wrapper.chmod(0o755)
manifest["build_completed"] = True
manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
print("Local Elmer installation complete:", install, flush=True)
