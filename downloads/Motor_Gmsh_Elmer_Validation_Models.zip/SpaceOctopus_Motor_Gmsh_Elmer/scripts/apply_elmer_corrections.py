"""Apply only the two hash-checked, recorded Elmer 26.2 corrections."""
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def apply(source):
    source = Path(source)
    corrections = [
        ('elmer-cholmod-fix.json', 'elmer-cholmod.patch', 'fem/src/cholmod.c'),
        ('elmer-newton-tensor-fix.json', 'elmer-newton-tensor.patch',
         'fem/src/modules/MagnetoDynamics/WhitneyAVSolver.F90'),
    ]
    for manifest, patch, relative in corrections:
        record = json.loads((ROOT / 'docs' / manifest).read_text())
        target = source / relative
        digest = hashlib.sha256(target.read_bytes()).hexdigest()
        if digest == record['patched_sha256']:
            continue
        if digest != record['original_sha256']:
            raise RuntimeError('Unrecognized Elmer source; refusing patch: ' + relative)
        subprocess.run(['patch', '--batch', '-p1', '-i', str(ROOT / 'docs' / patch)],
                       cwd=source, check=True)
        if hashlib.sha256(target.read_bytes()).hexdigest() != record['patched_sha256']:
            raise RuntimeError('Patched-source hash mismatch: ' + relative)


if __name__ == '__main__':
    import sys
    apply(Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / '.local/elmer-src')
