"""Fetch exact recorded Elmer/dependency bytes into workspace-local prefixes.

The recorded platform is Debian 13 amd64. System compiler, SuiteSparse/OpenMPI
and BLAS/LAPACK ABI requirements remain those in the build manifests. This does
not install host packages and refuses to overwrite populated dependency trees.
"""
import argparse
import hashlib
import json
import subprocess
import urllib.request
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def main(verify=False):
    manifest=json.loads((ROOT/'docs/elmer-dependencies.json').read_text())
    source=json.loads((ROOT/'docs/elmer-build.json').read_text())
    cache=ROOT/'.local/downloads'
    records=manifest['packages']+[dict(file='elmerfem-release-26.2.tar.gz',
        url=source['source_url'],sha256=source['source_sha256'])]
    files={}
    for record in records:
        candidates=[cache/record['file'],ROOT/'.local/apt/archives'/record['file']]
        found=next((p for p in candidates if p.exists() and hashlib.sha256(p.read_bytes()).hexdigest()==record['sha256']),None)
        if found is None:
            if verify:raise RuntimeError('Missing or altered recorded dependency: '+record['file'])
            cache.mkdir(parents=True,exist_ok=True);found=cache/record['file']
            with urllib.request.urlopen(record['url'],timeout=60) as response:found.write_bytes(response.read())
            if hashlib.sha256(found.read_bytes()).hexdigest()!=record['sha256']:
                raise RuntimeError('Downloaded hash mismatch: '+record['file'])
        files[record['file']]=found
    if verify:
        print('Verified exact source archive and %d dependency packages'%len(manifest['packages']))
        return
    for destination in sorted(set(p['destination'] for p in manifest['packages'])):
        target=ROOT/destination
        if target.exists() and any(target.iterdir()):
            raise RuntimeError('Refusing to overwrite populated dependency prefix '+str(target)+'; use the existing installation or a fresh checkout')
    for record in manifest['packages']:
        subprocess.run(['dpkg-deb','-x',str(files[record['file']]),str(ROOT/record['destination'])],check=True)
    target=ROOT/'.local/elmer-src'
    if not target.exists():
        target.mkdir(parents=True)
        subprocess.run(['tar','-xzf',str(files['elmerfem-release-26.2.tar.gz']),
                        '--strip-components=1','-C',str(target)],check=True)
    print('Workspace-local source and packages prepared; run the recorded build recipes')


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--verify-only',action='store_true');a=p.parse_args()
    main(a.verify_only)
