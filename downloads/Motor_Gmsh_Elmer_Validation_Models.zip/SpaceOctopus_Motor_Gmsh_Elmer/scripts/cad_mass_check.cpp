// Independent adaptive OpenCascade BREP volume/validity readback.
#include <BRepTools.hxx>
#include <BRep_Builder.hxx>
#include <BRepGProp.hxx>
#include <BRepCheck_Analyzer.hxx>
#include <BRepBuilderAPI_Transform.hxx>
#include <GProp_GProps.hxx>
#include <TopExp_Explorer.hxx>
#include <TopoDS.hxx>
#include <TopoDS_Shape.hxx>
#include <gp_Trsf.hxx>
#include <gp_Pnt.hxx>
#include <iostream>
#include <iomanip>
int main(int argc,char** argv) {
  if(argc!=2) return 2;
  BRep_Builder builder; TopoDS_Shape shape;
  if(!BRepTools::Read(shape,argv[1],builder)) return 3;
  std::cout<<std::setprecision(17)<<"[";
  bool first=true;
  for(TopExp_Explorer it(shape,TopAbs_SOLID);it.More();it.Next()){
    const TopoDS_Shape& solid=it.Current();
    GProp_GProps props;
    double error=BRepGProp::VolumePropertiesGK(solid,props,1.0e-11,true,true,true,false,false);
    const gp_Pnt p=props.CentreOfMass();
    if(!first)std::cout<<","; first=false;
    std::cout<<"{\"volume\":"<<props.Mass()<<",\"center\":["<<p.X()<<","<<p.Y()<<","<<p.Z()
             <<"],\"adaptive_relative_error\":"<<error<<",\"valid\":"
             <<(BRepCheck_Analyzer(solid).IsValid()?"true":"false")<<"}";
  }
  std::cout<<"]\n";
}
