"""Motor-specific acceptance checks, numerical balances and known failure cases."""
import json
from pathlib import Path
import numpy as np
import pytest
R=Path(__file__).resolve().parents[1]/'results/motor'
def read(name):return json.loads((R/name).read_text())


def test_rotor_losses_use_full_period_and_converge():
    rows=read('full_period/summary.json')['cases']
    assert all(not r['time_periodicity'] and r['solved_time_steps']==r['requested_time_steps'] for r in rows)
    assert abs(rows[1]['torque_Nm']/rows[0]['torque_Nm']-1)<.005
    for key in ['stator_bertotti','rotor_bertotti','magnets']:
        assert abs(rows[1]['loss_W'][key]/rows[0]['loss_W'][key]-1)<.02


def test_full_period_spatial_loss_check():
    coarse=read('full_period/144/status.json');fine=read('full_period/144_mesh1p5/status.json')
    assert fine['Kmesh_fineness']>coarse['Kmesh_fineness']
    for key in ['stator_bertotti','rotor_bertotti','magnets']:
        assert abs(fine['loss_W'][key]/coarse['loss_W'][key]-1)<.05


def test_native_maps_include_correct_no_load_and_energy_consistency():
    rows=read('maps/summary.json')['rows'];assert len(rows)==27
    assert max(abs(v['FE_mean_torque_Nm']-v['dq_torque_Nm']) for v in rows)<.01
    no=[v for v in rows if v['Id_rms_A']==v['Iq_rms_A']==0]
    assert len(no)==3 and all(abs(v['FE_mean_torque_Nm'])<.01 for v in no)
    assert no[0]['Phid_rms_Wb']>no[-1]['Phid_rms_Wb']>0


def test_native_LUT_reconstructs_all_actual_FEMM_points():
    from pyleecan.Functions.load import load
    for T in [20,80,150]:
        lut=load(str(R/f'maps/{T}C/native_LUTdq.json'))
        rows=read(f'maps/{T}C/summary.json')['rows']
        for row in rows:
            phi=lut.interp_Phi_dqh(row['Id_rms_A'],row['Iq_rms_A'])
            assert phi[0,0]==pytest.approx(row['Phid_rms_Wb'],abs=1e-12)
            assert phi[1,0]==pytest.approx(row['Phiq_rms_Wb'],abs=1e-12)


def test_native_generated_setter_survives_cloud_checkpoint():
    import cloudpickle
    from pyleecan.Classes.ParamExplorerSet import ParamExplorerSet
    from pyleecan.Classes.Simu1 import Simu1
    from pyleecan.Classes.InputCurrent import InputCurrent
    from pyleecan.Classes.OPdq import OPdq
    param=ParamExplorerSet(setter='simu.input.OP.Iq_ref',value=[3.])
    restored=cloudpickle.loads(cloudpickle.dumps(param))
    simu=Simu1(input=InputCurrent(OP=OPdq()))
    restored.setter(simu,3.)
    assert simu.input.OP.Iq_ref==3.


def test_full_motor_thermal_assessment_rejects_original_holding_hotspots():
    rows=read('hotspot/summary.json')['scenarios']
    original=[v for v in rows if v['wire_mm']==.9 and v['case'].startswith('hold70')]
    assert len(original)==8
    assert max(v['winding_hotspot_C'] for v in original)>130
    candidate=read('hotspot_candidate_fine/summary.json')
    selected=[v for v in candidate['scenarios'] if v['wire_mm']==.95]
    assert not candidate['radiation_credit']
    assert candidate['calibrated_average_R_winding_case_K_W']==pytest.approx(.12,rel=1e-5)
    assert all(v['steady_hotspot_ok'] and v['transient']['buffered_hotspot_ok'] for v in selected)
    assert candidate['distributed_case_model'] and candidate['case_sink_K_W']==.05
    assert max(v['steady_heat_balance_residual_W'] for v in selected)<.001


def test_selected_hotspot_mesh_refinement():
    a=read('hotspot_candidate/summary.json')['scenarios'];b=read('hotspot_candidate_fine/summary.json')['scenarios']
    for row in a:
        if row['wire_mm']!=.95:continue
        match=next(v for v in b if v['wire_mm']==.95 and v['case']==row['case'])
        assert abs(match['transient']['buffered_hotspot_C']-row['transient']['buffered_hotspot_C'])<2


def test_candidate_switched_drive_and_faults():
    r=read('candidate_drive/summary.json')
    for case in r['switched_PWM']:
        assert case['steady_tracking_error_relative']<.01
        assert case['peak_tracking_error_relative']<.01
        assert case['maximum_current_vector_Arms']<22
        assert case['maximum_phase_instantaneous_A']<22*np.sqrt(2)
    for fault in r['short_circuit_transients']:
        assert fault['transient_to_native_steady_error_Arms']<.01
    assert max(v['peak_current_vector_Arms'] for v in r['short_circuit_transients'])>22


def test_magnet_fault_field_does_not_invent_demagnetization_pass():
    r=read('fault_fields_candidate/summary.json');assert len(r['cases'])==4
    for row in r['cases']:
        assert row['irreversible_demagnetization_pass'] is None
        assert row['H_parallel_min_kA_m']<row['H_parallel_percentile01_kA_m']<0
        assert row['required_negative_knee_magnitude_with_20pct_screen_kA_m']>abs(row['H_parallel_min_kA_m'])


def test_force_transfer_and_peak_stator_clearance():
    for filename in ['structure/summary.json','structure_peak/summary.json']:
        for row in read(filename)['cases']:
            assert row['force_transfer']['force_balance_residual_N']<1e-6
            assert row['force_transfer']['torque_balance_residual_Nm']<1e-6
            assert 0<row['max_snapshot_displacement_um']<50
            assert min(row['first_16_modes_Hz'])>0


def test_official_two_slice_skew_reduces_ripple_with_expected_mean_torque():
    a=read('full_period/288/status.json');b=read('skew/status.json')
    assert b['torque_Nm']/a['torque_Nm']==pytest.approx(np.cos(np.deg2rad(7.5)),abs=.002)
    assert (b['torque_max_Nm']-b['torque_min_Nm'])/(a['torque_max_Nm']-a['torque_min_Nm'])<.25


def test_thermal_equilibria_stable():
    rows=read('performance/summary.json')['thermal_stability_and_warmup']
    assert all(r['locally_stable'] and max(r['thermal_eigenvalues_real_per_s'])<0 for r in rows)
