"""Independent numerical/physical consistency checks for the added campaign."""
import json
from pathlib import Path
import numpy as np
import pytest

R=Path(__file__).resolve().parents[1]/'results/motor/extensions'
pytestmark=pytest.mark.skipif(not (R/'assessment.json').exists(),reason='Run the native extension campaign and assessment first')


def read(path):return json.loads((R/path).read_text())


def test_independent_normal_map_holdouts_and_corner_refinements():
    r=read('assessment.json');assert len(r['normal_map_holdouts'])==6
    assert max(v['relative_torque_error'] for v in r['normal_map_holdouts'])<.005
    assert max(v['relative_flux_vector_error'] for v in r['normal_map_holdouts'])<.005
    assert max(v['torque_relative_change'] for v in r['map_corner_refinements'])<.01


def test_saturated_fault_map_holdouts_and_passive_differential_response():
    a=read('assessment.json');r=read('nonlinear_drive/summary.json')
    assert len(a['fault_map_holdouts'])==12
    assert max(v['relative_flux_vector_error'] for v in a['fault_map_holdouts'])<.02
    assert r['minimum_sampled_incremental_inductance_H']>0
    assert r['maximum_sampled_reciprocity_error_H']<.00005
    # Every saved trajectory must remain in the characterized rectangle.
    for path in (R/'nonlinear_drive').glob('fault_*.npz'):
        i=np.load(path)['current'];assert -60<=i[:,0].min()<=i[:,0].max()<=6
        assert -36<=i[:,1].min()<=i[:,1].max()<=24


def test_nonlinear_faults_keep_protection_requirement_visible():
    rows=read('nonlinear_drive/summary.json')['faults'];fixed=[v for v in rows if v['mode']=='fixed speed']
    assert len(fixed)==6 and max(v['peak_current_vector_Arms'] for v in fixed)>22
    assert all(v['copper_energy_J']>0 and v['torque_min_Nm']<0 for v in fixed)
    coasts=[v for v in rows if v['mode']=='coast down'];assert len(coasts)==8
    assert all(v['final_motor_rpm']<630 and v['time_simulated_s']>0 for v in coasts)


def test_end_leakage_sensitivity_and_updated_magnet_snapshot_basis():
    a=read('nonlinear_drive/summary.json')['end_leakage_sensitivity'];assert len(a)==8
    for T in [20,150]:
        low=next(v for v in a if v['T_C']==T and v['motor_rpm']==1890 and v['end_leakage_H']==0)
        high=next(v for v in a if v['T_C']==T and v['motor_rpm']==1890 and v['end_leakage_H']==.00016)
        assert low['peak_current_vector_Arms']>high['peak_current_vector_Arms']
    rows=read('nonlinear_fault_fields/summary.json')['cases'];assert len(rows)==4
    assert all(v['irreversible_demagnetization_pass'] is None and v['end_leakage_H']==0 for v in rows)


def test_nonlinear_switched_drive_time_step_and_current_limits():
    rows=read('nonlinear_drive/summary.json')['switched_PWM'];assert len(rows)==4
    for T in [20,150]:
        a=next(v for v in rows if v['magnet_C']==T and v['substeps']==40)
        b=next(v for v in rows if v['magnet_C']==T and v['substeps']==80)
        assert abs(a['peak_mean_Iq_Arms']/b['peak_mean_Iq_Arms']-1)<.01
        assert b['maximum_current_vector_Arms']<22
        assert b['maximum_phase_instantaneous_A']<22*np.sqrt(2)
        assert b['steady_tracking_error_relative']<.01 and b['peak_tracking_error_relative']<.01


def test_peak_losses_use_full_period_and_refine():
    for n in [144,288]:
        r=read(f'peak_losses/{n}/status.json');assert not r['time_periodicity']
        assert r['solved_time_steps']==n and r['operating']['Iq_rms_A']==22
    assert max(read('assessment.json')['peak_loss_time_refinement_relative_change'].values())<.03


def test_eccentricity_rotation_and_mesh_consistency():
    rows=read('eccentricity/summary.json')['cases'];assert len(rows)==6
    for h in [.0018,.0012]:
        centered=next(v for v in rows if v['h_m']==h and v['eccentricity_m']==[0,0])
        x=next(v for v in rows if v['h_m']==h and v['eccentricity_m']==[.00005,0])
        y=next(v for v in rows if v['h_m']==h and v['eccentricity_m']==[0,.00005])
        assert centered['maximum_radial_force_N']<1
        assert x['mean_Fx_N']>0 and y['mean_Fy_N']>0
        assert x['mean_Fx_N']==pytest.approx(y['mean_Fy_N'],rel=.05)
    coarse=next(v for v in rows if v['h_m']==.0018 and v['eccentricity_m']==[.00005,0])
    fine=next(v for v in rows if v['h_m']==.0012 and v['eccentricity_m']==[.00005,0])
    assert coarse['mean_Fx_N']==pytest.approx(fine['mean_Fx_N'],rel=.05)


def test_FEMM_harmonic_wire_matches_exact_impedance():
    rows=read('harmonics/wire_summary.json')['rows'];assert len(rows)==16
    fine=[v for v in rows if v['wire_radius_mesh_divisor']==24]
    assert max(abs(v['relative_error']) for v in fine)<.01
    assert all(v['FEMM_Rac_Rdc']>=.999 for v in rows)


def test_incremental_magnet_loss_is_passive_and_mesh_checked():
    rows=read('harmonics/magnet_summary.json')['rows'];assert len(rows)==8
    for row in rows:
        assert row['maximum_response_eigenvalue_W_per_A2']>0
        assert row['minimum_response_eigenvalue_W_per_A2']>=-1e-6
    a=read('assessment.json')['AC_magnet_mesh_refinement']
    assert all(v['q_loss_relative_change']<.05 and v['d_loss_relative_change']<.05 for v in a)


def test_geometry_search_uses_nine_actual_nonlinear_FEMM_solutions():
    r=read('geometry_optimization/summary.json');assert r['unique_native_FE_geometries']==9
    assert len(r['grid'])==9 and r['native_optimization_evaluations']>=9
    for path in (R/'geometry').glob('*/status.json'):
        status=json.loads(path.read_text());assert status['native_MagFEMM_executed'] and status['torque_Nm']>0


def test_hot_tolerance_cases_reduce_torque_without_inventing_a_rating():
    rows=read('assessment.json')['tolerances'];assert len(rows)==5
    ref=next(v for v in rows if v['case']=='reference')
    for row in rows:
        if row['case']!='reference':assert row['torque_Nm']<ref['torque_Nm']
    combined=next(v for v in rows if v['case']=='combined_low_flux')
    assert combined['torque_Nm']==min(v['torque_Nm'] for v in rows)


def test_coated_wire_thermal_unit_cell_mesh_refinement():
    rows=read('thermal_materials/summary.json')['microstructure'];assert len(rows)==20
    for row in rows:
        if row['h_m']!=.000025:continue
        fine=next(v for v in rows if v['h_m']==.0000125 and v['resin_k_W_mK']==row['resin_k_W_mK'] and v['assumed_resin_void_fraction']==row['assumed_resin_void_fraction'])
        assert row['effective_transverse_k_W_mK']==pytest.approx(fine['effective_transverse_k_W_mK'],rel=.03)


def test_explicit_liner_increases_thermal_resistance_and_exposes_failures():
    rows=read('thermal_materials/summary.json')['assembly_scenarios'];assert len(rows)==30
    for resin in [.1,.2,.4,.6,1.]:
        for void in [0.,.2]:
            a=sorted([v for v in rows if v['resin_k_W_mK']==resin and v['assumed_resin_void_fraction']==void],key=lambda v:v['liner_mm'])
            assert a[0]['mean_R_winding_case_K_W']<a[1]['mean_R_winding_case_K_W']<a[2]['mean_R_winding_case_K_W']
    assert any(v['meets_declared_average_path'] for v in rows)
    assert any(not v['meets_declared_average_path'] for v in rows)


def test_angle_resolved_voltage_preserves_continuous_and_peak_distinction():
    rows=read('torque_feedforward/summary.json')['cases'];assert len(rows)==12
    continuous=[v for v in rows if v['output_torque_Nm']==220]
    peak=[v for v in rows if v['output_torque_Nm']==400]
    assert all(v['quasistatic_current_and_voltage_screen'] for v in continuous)
    assert all(not v['quasistatic_current_and_voltage_screen'] for v in peak)
    assert all(v['maximum_phase_voltage_peak_V']<v['full_linear_SVPWM_V'] for v in peak)


def test_retainer_refinement_preserves_the_failed_earlier_clearance_screen():
    r=json.loads((R.parent/'build_requirements.json').read_text())['retaining_wrap']
    assert not r['previous_50GPa_gap_screen_pass']
    assert r['previous_50GPa_remaining_gap_including_bending_and_support_mm']<.1
    assert r['required_hot_hoop_modulus_from_gap_GPa']>50
    assert r['assumed_hoop_modulus_GPa']>=r['required_hot_hoop_modulus_from_gap_GPa']
    assert r['conservative_remaining_gap_mm']>=.1


def test_construction_loads_include_fault_torque_and_magnetic_traction():
    dynamic=read('nonlinear_drive/summary.json');rows=[v for v in dynamic['faults'] if v['mode']=='fixed speed']+dynamic['end_leakage_sensitivity']
    peak=max(max(abs(v['torque_min_Nm']),abs(v['torque_max_Nm'])) for v in rows)
    r=json.loads((R.parent/'build_requirements.json').read_text())
    assert r['compliant_magnet_bond']['design_shaft_torque_including_fault_Nm']>=peak
    assert r['compliant_magnet_bond']['bond_interface_radius_mm']==23
    assert r['retaining_wrap']['maximum_magnetic_traction_MPa']>=max(v['sampled_peak_outward_magnetic_traction_MPa'] for v in read('nonlinear_fault_fields/summary.json')['cases'])
