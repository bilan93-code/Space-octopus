"""Independent invariants for geometry, electromechanics and heat balance."""
import copy
import json
from pathlib import Path
import numpy as np
import pytest
from actuator.machine import build_machine,winding_summary
from actuator.coupled import gear_geometry,gear_loads,electrical_point,steady_state,thermal_outflow

ROOT=Path(__file__).resolve().parents[1]

@pytest.fixture
def config():
    return json.loads((ROOT/'configs/baseline.json').read_text())


def test_reject_original_overlapping_planets():
    v=gear_geometry(dict(sun=12,planet=36,ring=84,planets=4,module_m=.00125,face_m=.018))
    assert v['assembly_ok']
    assert v['planet_tip_clearance_mm']==pytest.approx(-5.0735931288)


def test_latest_geometry_and_ratio(config):
    gs=[gear_geometry(s) for s in config['gearbox']['stages']]
    assert np.prod([g['ratio'] for g in gs])==63
    assert all(g['closure_ok'] and g['assembly_ok'] and g['planet_tip_clearance_mm']>0 for g in gs)
    assert [g['ring_pitch_mm'] for g in gs]==[108,108]


def test_native_winding_balance_and_resistance(config):
    m=build_machine(config);s=winding_summary(m)
    w=np.array(s['connection_matrix'])
    assert np.all(w.sum(axis=(0,1,2))==0)  # no net axial phase conductor count
    assert s['turns_per_phase']==[60,60,60]
    assert .4<s['bare_copper_fill']<.45
    assert s['airgap_mm']==pytest.approx(.5)
    assert s['winding_factors'][0]==pytest.approx((2+np.sqrt(3))/4)
    expected=1.724e-8*60*2*(.085+2*.012)/(2*np.pi*.0008**2/4)
    assert s['R20_ohm']==pytest.approx(expected)
    assert s['R100_ohm']/s['R20_ohm']==pytest.approx(1+.00393*80)


def test_eec_rms_conventions_and_power_conservation(config):
    m=build_machine(config)
    params=dict(psi_pm_rms_Wb=.035,Ld_H=.0003,Lq_H=.0004)
    e=electrical_point(m,config,params,4.5,630,100,80)
    assert e['electromagnetic_torque_Nm']==pytest.approx(4.5)
    electrical_power=3*e['Uq_rms_V']*e['Iq_rms_A']
    assert electrical_power==pytest.approx(4.5*2*np.pi*630/60+e['copper_loss_W'])
    holding=electrical_point(m,config,params,4.5,0,100,80)
    assert holding['copper_loss_W']>0
    assert holding['Ud_rms_V']==0


def test_thermal_network_internal_flows_cancel(config):
    temps=np.array([100,90,70,65])
    out,rad=thermal_outflow(config,temps)
    sink=config['thermal']['sink_C']
    expected=(temps[2]-sink)/.3+(temps[3]-sink)/.5+rad
    assert out.sum()==pytest.approx(expected)


def test_gear_loads_scale_with_torque(config):
    a=gear_loads(config,220);b=gear_loads(config,400)
    assert b[-1]['nominal_mesh_tangential_N']/a[-1]['nominal_mesh_tangential_N']==pytest.approx(400/220)


def test_magnetic_materials_sources_and_reciprocity(config):
    from actuator.magnetics import MagneticModel
    m=build_machine(config);f=MagneticModel(m,config,h=.002)
    assert set(f.kind)=={0,1,2}
    assert sum('_Magnet' in label for label in f.labels.values())==10
    assert sum('_Winding' in label for label in f.labels.values())==24
    # Independent analytic magnet volume cross-section checks label mapping.
    magnet_area=f.areas[f.kind==2].sum()
    expected=np.pi*(.026**2-.023**2)*.8
    # Linear triangular edges approximate OCC circles by chords. The coarse
    # 2-mm mesh bounds magnet cross-section error to 0.5%; exact CAD areas
    # are separately checked to 0.01% before triangulation.
    assert magnet_area==pytest.approx(expected,rel=.005)
    # Reciprocity for current-only linear problems (symmetric stiffness).
    a=f.solve([1,-1,0],pm_scale=0);b=f.solve([0,1,-1],pm_scale=0)
    assert np.dot([0,1,-1],a['phase_flux_Wb'])==pytest.approx(np.dot([1,-1,0],b['phase_flux_Wb']),rel=1e-9)
    assert np.max(np.abs(f.solve(pm_scale=0)['a']))==0
    no=f.nonlinear(f.solve())
    assert no['nonlinear_residual']<1e-7
    assert np.linalg.norm(no['phase_flux_Wb'])>.04


def test_saved_run_numerical_and_energy_checks():
    path=ROOT/'results/baseline/analysis.json'
    assert path.exists(),'Run the complete analysis before this check'
    r=json.loads(path.read_text());v=r['magnetic_checks']
    assert len(r['rotor_sweep'])==24
    assert len(r['torque_speed_screen'])==40
    assert v['mesh_torque_change_relative']<.05
    assert v['mesh_flux_change_relative']<.02
    assert v['FE_EEC_difference_relative']<.12
    assert v['virtual_work_vs_fine_FE_relative']<.12
    for op in r['operating_points'].values():
        assert op['conducted_to_sink_W']+op['radiated_heat_W']==pytest.approx(op['total_actuator_heat_W'],abs=1e-5)
        assert op['thermal_residual_W']<1e-5
    assert r['operating_points']['higher_speed']['electrical']['voltage_ok'] is False


def test_conditional_limits_and_short_pulse_voltage():
    r=json.loads((ROOT/'results/baseline/analysis.json').read_text())
    limits=r['conditional_limits']
    assert 10<limits['voltage_limited_output_rpm_at_required_torque']<12
    assert 220<limits['output_torque_limits_Nm_at_design_speed']['thermal']<302.4
    assert limits['peak_required_bus_V_with_modulation_margin']>42
    assert all(not e['voltage_ok'] for e in limits['peak_drive_start_end'])
