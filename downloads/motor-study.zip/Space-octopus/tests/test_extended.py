"""Independent checks of the extended executed study and its honest boundaries."""
import json
from pathlib import Path
import numpy as np
import pytest
R=Path(__file__).resolve().parents[1]/'results/extended'
def data(name):return json.loads((R/name).read_text())


def test_structural_mesh_convergence():
    r=data('structural/carrier_summary.json')
    assert r['displacement_change_relative']<.02
    assert r['stress_p99_change_relative']<.05
    assert all(0<v['max_displacement_mm']<.02 for v in r['mesh_convergence'])
    assert all(0<v['von_mises_p99_MPa']<v['von_mises_max_MPa'] for v in r['mesh_convergence'])
    assert len(r['clamped_plate_modes_Hz'])==8
    assert 3000<r['clamped_plate_modes_Hz'][0]<4000


def test_native_lut_reconstructs_all_grid_points():
    r=data('controls/controls_summary.json')
    assert {v['magnet_C'] for v in r['native_LUTdq_interpolation']}=={20,80,140}
    assert max(v['grid_reconstruction_max_error_Wb'] for v in r['native_LUTdq_interpolation'])<1e-12


def test_fault_domain_is_not_claimed_validated():
    r=data('controls/controls_summary.json')
    assert len(r['short_circuit_native_EEC'])==6
    assert all(v['outside_characterized_flux_map'] for v in r['short_circuit_native_EEC'])
    assert max(v['current_rms_A'] for v in r['short_circuit_native_EEC'])>22


def test_nonlinear_current_temperature_map():
    r=data('redesign/redesign_summary.json');rows=r['flux_map']
    assert len(rows)==27
    assert max(v['nonlinear_residual'] for v in rows)<1e-7
    for temp in [20,80,140]:
        q=sorted([v for v in rows if v['magnet_C']==temp and v['Id_rms_A']==0],key=lambda v:v['Iq_rms_A'])
        assert q[0]['torque_Nm']<q[1]['torque_Nm']<q[2]['torque_Nm']
    no=[v for v in rows if v['Id_rms_A']==v['Iq_rms_A']==0]
    assert no[0]['Phid_rms_Wb']>no[-1]['Phid_rms_Wb']


def test_revised_winding_solves_minimum_bus_peak_screen_conditionally():
    r=data('redesign/redesign_summary.json')
    assert r['conditional_limits']['peak_required_bus_V_with_modulation_margin']<42
    assert all(v['current_ok'] and v['voltage_ok'] for v in r['conditional_limits']['peak_drive_start_end'])
    assert r['conditional_limits']['voltage_limited_output_rpm_at_required_torque']>14


def test_thermal_fea_energy_balance_and_monotonicity():
    r=data('thermal/thermal_fea_summary.json');s=r['scenarios']
    assert max(v['power_residual_W'] for v in s)<1e-6
    assert s[0]['winding_average_C']>s[1]['winding_average_C']>s[2]['winding_average_C']
    assert all(v['winding_node_max_C']>v['winding_average_C']>r['imposed_outer_case_C'] for v in s)


def test_cad_scope_and_individual_solids():
    r=data('cad/cad_status.json')
    assert r['objects']>=50 and r['all_individual_shapes_valid']
    assert r['assembly_clearance_verified'] is False
    assert r['step_bytes']>1e6


def test_mechanical_required_allowables_and_friction_limit():
    r=data('mechanical_screens.json');g=r['gear_and_planet_bearing_screens']
    assert g[0]['input_rpm']==630 and g[1]['carrier_rpm']==10
    assert g[1]['required_contact_allowable_for_1p3_margin_GPa']>g[1]['factored_Hertz_sun_planet_pitch_GPa']
    assert r['output_interface_trade']['friction_torque_capacity_Nm_at_mu_0p08']<220
    assert not r['output_interface_trade']['peak_400Nm_friction_only_supported']


def test_native_loss_force_full_material_history():
    r=data('electromagnetics/native_models.json')
    assert r['samples']==144 and r['span']=='one full mechanical revolution'
    assert all(np.isfinite(v) and v>=0 for v in r['loss_W'].values())
    assert r['loss_W']['copper']>=3*.29483070089994606*81
    assert r['force_radial_min_Pa']<0 and r['force_tangential_peak_Pa']>0
    assert 'NOT a native MagFEMM' in r['magnetic_source']


def test_native_femm_status_is_evidence_based():
    r=data('native_femm/status.json')
    if r['status']=='blocked':assert r['native_MagFEMM_executed'] is False
    else:assert r['status']=='completed' and r['native_MagFEMM_executed'] is True


def test_official_magnetic_pipeline_and_independent_torque_agreement():
    native=data('native_femm/status.json')
    custom=json.loads((R.parent/'baseline/analysis.json').read_text())
    assert native['status']=='completed' and native['native_MagFEMM_executed']
    assert native['solved_time_steps']>=8
    assert abs(native['torque_Nm']/custom['magnetic_checks']['FE_mean_torque_9Arms_Nm']-1)<.02
    assert all(np.isfinite(v) and v>=0 for v in native['loss_W'].values())


def test_native_electrical_flux_linkage_coupling():
    native=data('native_electrical/status.json')
    assert native['status']=='completed' and native['native_Electrical_MagFEMM_executed']
    assert native['PM_flux_rms_Wb']>0
    assert 4<native['total_torque_Nm']<5
    assert native['voltage_ok_at_min_bus']
    from actuator.machine import build_machine
    config=json.loads((R.parents[1]/'configs/revised.json').read_text())
    resistance=build_machine(config).stator.comp_resistance_wind(100)
    assert native['resistance_ohm']==pytest.approx(resistance)


def test_official_femm_distribution_integrity_and_real_app_readiness():
    import hashlib
    root=R.parents[1]
    spec=json.loads((root/'docs/femm-distribution.json').read_text())
    artifact=root/'.local/downloads/femm42-cached.exe'
    assert hashlib.sha256(artifact.read_bytes()).hexdigest()==spec['upstream_installer_sha256']
    readiness=data('native_femm/wine_readiness.json')
    assert readiness['windows_command_verified']
    assert readiness['FEMM_GUI_or_Lua_verified'] and readiness['FEMM_initial_model_commands_returned']
