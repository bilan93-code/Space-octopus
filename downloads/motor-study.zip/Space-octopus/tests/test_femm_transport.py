"""Reproduce partial-file delivery rather than mocking a successful solver."""
import importlib,threading,time
from types import SimpleNamespace
import pytest
from actuator.femm_transport import file_call


def test_empty_response_during_write_does_not_become_empty_torque(tmp_path,monkeypatch):
    module=importlib.import_module('pyleecan.Classes._FEMMHandler')
    request=tmp_path/'ifile.txt';response=tmp_path/'ofile.txt'
    monkeypatch.setattr(module,'ifile',str(request),raising=False)
    monkeypatch.setattr(module,'ofile',str(response),raising=False)
    observed=[]
    def delayed_solver():
        deadline=time.monotonic()+2
        while not request.exists() and time.monotonic()<deadline:time.sleep(.001)
        observed.append(request.read_text())
        response.write_text('')
        time.sleep(.05)
        response.write_text('[ 4.6123 ]\n')
    worker=threading.Thread(target=delayed_solver);worker.start()
    try:torque=file_call(SimpleNamespace(),'mo_blockintegral(22)',timeout=2)
    finally:worker.join(timeout=2)
    assert observed==['flput(mo_blockintegral(22))']
    assert torque==pytest.approx(4.6123)
    assert not response.exists()


def test_stale_response_is_rejected_before_sending_a_new_command(tmp_path,monkeypatch):
    module=importlib.import_module('pyleecan.Classes._FEMMHandler')
    request=tmp_path/'ifile.txt';response=tmp_path/'ofile.txt';response.write_text('[ 1 ]')
    monkeypatch.setattr(module,'ifile',str(request),raising=False)
    monkeypatch.setattr(module,'ofile',str(response),raising=False)
    with pytest.raises(RuntimeError,match='stale FEMM response'):
        file_call(SimpleNamespace(),'mo_blockintegral(22)',timeout=.1)
    assert not request.exists()


def test_AC_circuit_complex_response_is_decoded_without_eval(tmp_path,monkeypatch):
    module=importlib.import_module('pyleecan.Classes._FEMMHandler')
    request=tmp_path/'ifile.txt';response=tmp_path/'ofile.txt'
    monkeypatch.setattr(module,'ifile',str(request),raising=False)
    monkeypatch.setattr(module,'ofile',str(response),raising=False)
    def solver():
        deadline=time.monotonic()+2
        while not request.exists() and time.monotonic()<deadline:time.sleep(.001)
        response.write_text('[ 1 0.03+I*0.4 0.005-I*0.1 ]')
    worker=threading.Thread(target=solver);worker.start()
    try:values=file_call(SimpleNamespace(),'mo_getcircuitproperties("wire")',timeout=2)
    finally:worker.join(timeout=2)
    assert values==pytest.approx([1,.03+.4j,.005-.1j])


def test_numeric_decoder_rejects_executable_expression():
    import ast
    from actuator.femm_transport import numeric_expression
    with pytest.raises(ValueError,match='Non-numeric'):
        numeric_expression(ast.parse('[1, dangerous()]',mode='eval'))
