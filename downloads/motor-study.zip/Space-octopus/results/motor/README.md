# Motor artifact index

Start with **report.pdf** or the standalone **report.html**. The corrective
configuration is `configs/motor_candidate.json`. Reports distinguish adopted
requirements, simulations, conditional construction requirements and hardware
acceptance still requiring actual parts/data.

The completed additional campaign is in `extensions/report.pdf` and
`extensions/assessment.json`. It adds nonlinear faults, AC loss checks,
geometry/tolerance trades, eccentricity/support, liner/material construction
and angle-resolved feedforward. It rejects the earlier 50 GPa wrap clearance
assumption and the optional 400 N m reserved-voltage trajectory. The revised
construction requirements retain the failures and proposed corrections.
Reproduce both campaigns with `python -m actuator.motor_comprehensive` in .venv.

Accepted current evidence:

- `maps`: official 27-point VarLoadCurrent/MagFEMM/LUTdq map; `rejected_no_load`
  retains the documented stale-current failure and is excluded from the map.
- `full_period`: accepted full-mechanical-revolution native losses, 144/288 time
  positions and 144 with mesh factor 1.5. Use these for reference rotor losses.
- `candidate`, `candidate_drive`, `fault_fields_candidate`: revised wire/cooling,
  switched-drive results and native fault-H requirements. Demagnetization pass
  remains unset without supplier knee curves.
- `hotspot_candidate`, `hotspot_candidate_fine`: current distributed case/sink
  model, Rwc=.12, Rcase=.05 K/W, no radiation credit; select the .95 mm rows.
- `structure`, `structure_peak`, `mechanics`: native force-coupled stator FE and
  explicit motor mechanical screens. `build_requirements.json` is conditional
  construction specification, not a qualified-parts list.
- `optimization`: native NSGA-II and complete winding grid; mean-model surrogate.
- `skew`: separate official two-slice refinement; not the baseline operating map.
- `official_couplings`: attempted StructElmer case generation and traceback.
- `coverage.json`, `reproduction_manifest.json`: execution scope and provenance.

Historical/diagnostic trials are retained for transparency: `convergence` uses
reduced stator time periodicity and is unsuitable for rotor-loss acceptance.
`performance`, `drive`, `fault_fields`, `hotspot` describe the earlier .90 mm
design; its average thermal pass was superseded by failed holding hot spots.
`hotspot_proposed*` directories record intermediate cooling trials and are not
the current candidate. Native raw checkpoints are trusted local generated data;
portable packages omit them and installed runtimes. The runner regenerates
required missing checkpoints rather than mistaking summaries for raw fields.
