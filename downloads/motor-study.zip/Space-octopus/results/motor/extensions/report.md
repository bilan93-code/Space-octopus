# Space-octopus: additional motor verification

## 1. Decision and purpose

This addendum records the additional analyses left outside the earlier preliminary
campaign. The earlier stop was a scope decision, not a permission or solver-access
limitation. This is a finite verification campaign with explicit acceptance limits;
it does not claim every Pyleecan class is applicable or product release is complete.

The six independent operating-map holdouts have maximum relative mean-torque error
0.0361 percent
and flux-vector error
0.0761 percent.
The earlier mean-field interpolation is supported in these tested cells.
The additional cold map-corner refinements and hot full-period loaded losses are
reported below instead of assuming reference convergence holds everywhere.

Across the declared hot material/geometry perturbations, the lowest mean-torque
screen at 22 Arms corresponds to 387.3
N m output after the explicit 33 W motor-drag allowance. The optional 400 N m
perturbation screen does not pass. The 220 N m mean-torque requirement remains a
separate gate from local heating, manufacture and fault protection. Br -5 percent
is below the earlier specified Br20 minimum of 1.05 T; it is a material shortfall
sensitivity, not an accepted supplier-lot tolerance. The minimum must actually be
guaranteed if the nominal prediction is used.

The earlier approximately 119 C buffered hot-spot result remains conditional on
its specified winding, distributed housing contact and loss assumptions. It is
not a measured temperature or a demonstrated tolerance-wide thermal rating.
New analyses do not turn absent material, mission or hardware data into evidence.

An additional angle-resolved feedforward check supports 220 N m within the
42 V / 10 percent voltage reserve. The optional 400 N m trajectory exceeds that
design voltage budget even when its mean-voltage calculation passes. Its peaks
remain below the ideal full linear SVPWM ceiling in these samples, with reduced
headroom; it must not inherit the earlier mean-only voltage acceptance.

## 2. Independent map and numerical checks

The holdouts are new official VarLoadCurrent -> nonlinear MagFEMM calculations.
They were not used to fit the existing 27-point map. The points include mid-cell
Id/Iq positions and intermediate magnet temperatures of 50 / 115 C.

| Magnet C, Id Arms, Iq Arms | Mean torque error % | Flux vector error % |
| --- | --- | --- |
| [115, -6.0, 10.814] | 0.0004 | 0.0006 |
| [50, -6.0, 10.814] | 0.0003 | 0.0005 |
| [80, -9.0, 5.407] | 0.0257 | 0.0355 |
| [80, -9.0, 16.407] | 0.0361 | 0.0761 |
| [80, -3.0, 5.407] | 0.0181 | 0.0311 |
| [80, -3.0, 16.407] | 0.0309 | 0.0708 |

The cold loaded corner Id=-12, Iq=22 Arms receives a doubled time resolution
and separate global mesh factor 1.5. It is a field-characterization point above
the 22 Arms vector circle, not an allowed drive command.

| Refinement | Mean torque change % | Flux-vector change % |
| --- | --- | --- |
| time | 0.0038 | 0.0001 |
| mesh | 0.0057 | 0.7840 |

The wide fault map has Id=-60/-30/0/+6 and Iq=-36/-24/0/+24 Arms at magnet
temperatures 20/150 C. The positive Id margin covers the initial fault excursion;
negative Iq coverage extends beyond the previous 24 Arms edge. Independent
mid-cell checks include lower-quadrant points. Their maximum normalized flux
error is 0.621
percent, normalized by the actual flux-vector magnitude with a 5 mWb floor near
flux cancellation. All trajectories reject extrapolation beyond the native box.

## 3. Nonlinear fault, inertia and switched-drive coupling

The differential equations use the actual interpolated flux vector and its
current Jacobian, rather than constant Ld/Lq:

dPsi_d/dt = Ud - R Id + omega_e Psi_q;
dPsi_q/dt = Uq - R Iq - omega_e Psi_d.

The Jacobian converts flux derivatives to current derivatives. Assumed isotropic
80 microhenry end leakage is included; it cancels from the torque cross product.
Minimum sampled symmetric differential inductance is
850.3 microhenry. Maximum sampled
cross-derivative reciprocity mismatch is
17.22 microhenry. Piecewise interpolation
and residual reciprocity error limit energy accuracy; this is not full transient
eddy-current FE or irreversible magnet-recoil simulation.

| Winding / magnet C | Motor rpm | Peak vector Arms | Minimum Id Arms | Minimum Iq Arms |
| --- | --- | --- | --- | --- |
| 20 / 20 | 630 | 37.08 | -33.10 | -25.38 |
| 20 / 20 | 945 | 43.16 | -40.67 | -27.58 |
| 20 / 20 | 1890 | 51.46 | -50.53 | -30.11 |
| 130 / 150 | 630 | 30.08 | -24.77 | -22.06 |
| 130 / 150 | 945 | 36.36 | -32.72 | -24.69 |
| 130 / 150 | 1890 | 45.74 | -44.22 | -27.90 |

Fault currents still require hardware protection beyond the proposed 22 Arms
normal drive limit. The hot case uses winding 130 C and magnets 150 C, correcting
the earlier equal-150-C approximation. The hot winding is no longer artificially
assigned resistance above its stated design limit.

The assumed end leakage is also varied from zero to 160 microhenry at 630/1890
rpm. The largest peak across those scenarios is
55.27 Arms.
This is a declared sensitivity, not a resolved three-dimensional end-winding
inductance. The subsequent H-field snapshots select the most negative Id among
the 0/80/160 microhenry cases, so the magnetic material requirement does not rely
solely on the original 80 microhenry assumption.

Coast-down cases couple the electromagnetic torque to native-geometry rotor
inertia and declared output inertia scenarios of 0/1/10/100 kg m2 reflected
through 63:1. They include a fixed 4.365 N m resisting shaft load and stop at
zero speed. Actual robot-arm inertia, load sign and impact cases remain unknown;
these are scenarios rather than a certified fault-current bound.

The 20 kHz three-phase switched-voltage PI controller was also integrated with
the nonlinear map at 40/80 substeps per switching period. Winding temperature
is 130 C; magnet temperature spans the two native endpoints. The run is 100 ms
with a 50 ms high-current command, distinct from the earlier five-second thermal
screen. Dead time remains an averaged 1 microsecond voltage-bias approximation.

| Magnet C | Substeps | Maximum vector Arms | Steady error % | Peak error % |
| --- | --- | --- | --- | --- |
| 20 | 40 | 21.557 | 0.274 | 0.031 |
| 20 | 80 | 21.440 | 0.192 | 0.028 |
| 150 | 40 | 21.532 | 0.228 | 0.073 |
| 150 | 80 | 21.445 | 0.189 | 0.043 |

Native H-field snapshots were recomputed at the nonlinear fixed-speed fault
extrema. The required supplier irreversible-knee magnitudes include the same
20 percent screening allowance used previously:

| Winding / magnet C | rpm | Minimum parallel H kA/m | Required knee magnitude kA/m |
| --- | --- | --- | --- |
| 20 / 20 | 630 | -565.0 | 678.0 |
| 20 / 20 | 1890 | -710.3 | 852.3 |
| 130 / 150 | 630 | -483.8 | 580.6 |
| 130 / 150 | 1890 | -647.2 | 776.7 |

Irreversible-demagnetization acceptance remains unset. Linear recoil coercivity
is not a supplier knee curve. These snapshots are not accepted rotor-loss histories.

## 4. Real FEMM geometry trade and hot perturbations

Nine exact geometries vary magnet arc fraction and bare radial gap. Every table
row is an actual nonlinear rotor-averaged FEMM solve at 10.814 Arms / 80 C magnets.
Pyleecan OptiGenAlgNsga2Deap then performs
94 evaluations against those cached exact FE
results, minimizing magnet mass, reference-derived copper proxy and torque ripple.
The complete finite grid is retained; 9 candidates are nondominated.

| Magnet arc fraction | Bare gap mm | Mean torque N m | Magnet mass kg | Ripple p-p N m |
| --- | --- | --- | --- | --- |
| 0.7 | 0.4 | 4.2822 | 0.2281 | 0.0810 |
| 0.7 | 0.5 | 4.1472 | 0.2281 | 0.0799 |
| 0.7 | 0.6 | 4.0232 | 0.2281 | 0.0682 |
| 0.8 | 0.4 | 4.5684 | 0.2606 | 0.7316 |
| 0.8 | 0.5 | 4.4272 | 0.2606 | 0.6006 |
| 0.8 | 0.6 | 4.2938 | 0.2606 | 0.4836 |
| 0.9 | 0.4 | 4.7412 | 0.2932 | 0.4203 |
| 0.9 | 0.5 | 4.5933 | 0.2932 | 0.3353 |
| 0.9 | 0.6 | 4.4539 | 0.2932 | 0.2426 |

The current/copper proxy uses the local solved torque constant and does not
replace a complete operating/loss map for each alternative. No new geometry is
silently substituted into the earlier candidate. The existing .8 arc / .5 mm bare
gap remains the assessed baseline.

The perturbation cases use hot 150 C magnets, 130 C winding and 22 Arms. Stack
-0.5 mm, bare gap +50 micrometers and Br -5 percent are declared sensitivities.
The output column subtracts 30 W non-copper plus 3 W friction at 630 rpm before
applying the fixed 63:1 / .8 gearbox boundary. It is a mean-torque screen, not a
local thermal or full transmission rating.

| Case | EM torque N m | Torque change % | Conditional output N m |
| --- | --- | --- | --- |
| Br_minus5pct | 8.3681 | -4.97 | 396.5 |
| combined_low_flux | 8.1845 | -7.06 | 387.3 |
| gap_plus50um | 8.6637 | -1.61 | 411.4 |
| reference | 8.8058 | 0.00 | 418.6 |
| stack_minus0p5mm | 8.7540 | -0.59 | 416.0 |

## 5. Angle-resolved constant-torque current and voltage

Native torque and instantaneous dq flux waveforms are interpolated in current
and angle, then inverted for constant actuator torque. The full flux derivatives
enter Ud = R Id + dPsi_d/dt - omega_e Psi_q and
Uq = R Iq + dPsi_q/dt + omega_e Psi_d. Thus both geometry-induced flux ripple
and the current modulation required to counter torque ripple contribute to the
voltage requirement. The motor runs at 630 rpm and winding resistance is at 130 C.

| Magnet C | Output N m | Drag W | Maximum Iq Arms | Maximum phase peak V | 42 V design screen |
| --- | --- | --- | --- | --- | --- |
| 20 | 220 | 6.5 | 11.461 | 19.628 | pass |
| 20 | 220 | 33.0 | 12.433 | 19.980 | pass |
| 20 | 400 | 6.5 | 20.106 | 23.033 | exceeds budget |
| 20 | 400 | 33.0 | 21.079 | 23.440 | exceeds budget |
| 80 | 220 | 6.5 | 11.646 | 19.415 | pass |
| 80 | 220 | 33.0 | 12.635 | 19.786 | pass |
| 80 | 400 | 6.5 | 20.447 | 22.918 | exceeds budget |
| 80 | 400 | 33.0 | 21.438 | 23.335 | exceeds budget |
| 150 | 220 | 6.5 | 11.871 | 19.182 | pass |
| 150 | 220 | 33.0 | 12.882 | 19.566 | pass |
| 150 | 400 | 6.5 | 20.862 | 22.794 | exceeds budget |
| 150 | 400 | 33.0 | 21.874 | 23.223 | exceeds budget |

The design ceiling is 21.824 V phase peak; ideal full linear SVPWM at 42 V gives
24.249 V. The continuous 220 N m cases fit the design budget. The optional
400 N m cases use substantially more headroom and do not pass the reserved
budget. This is a quasistatic requirement, not a proof of servo tracking:
encoder timing, waveform calibration, current-loop bandwidth and inverter
nonidealities still matter. The 24 native positions per 36 mechanical degrees
and piecewise current interpolation limit the resolved angle waveform. No
gearbox mechanical filtering or skewed operating map is silently assumed.

## 6. Static eccentricity, magnetic pull and bearing stiffness

The independent full-circle project FE model translates the entire rotor,
magnets and shaft. Radial magnetization is evaluated about the displaced rotor
center. Gmsh/scikit-fem solve the nonlinear fields at 36 positions across one
72-degree magnetic period, on two meshes. Closed Maxwell-stress contours give
net force and torque, with torque shifted to the actual rotor center. This is
explicitly a custom route, not a native MagFEMM eccentricity claim.

| Mesh mm | Offset x/y um | Mean Fx N | Mean Fy N | Maximum radial force N |
| --- | --- | --- | --- | --- |
| 1.8 | [0. 0.] | -0.01 | -0.01 | 0.14 |
| 1.8 | [50.  0.] | 50.60 | -0.41 | 53.15 |
| 1.8 | [ 0. 50.] | 0.38 | 50.60 | 53.25 |
| 1.2 | [0. 0.] | -0.03 | 0.01 | 0.15 |
| 1.2 | [50.  0.] | 50.06 | 0.01 | 53.39 |
| 1.2 | [ 0. 50.] | -0.03 | 50.06 | 53.48 |

The approximately 50 N mean pull at 50 micrometers displacement implies magnetic
negative stiffness of roughly 1 MN/m. The supported-shaft compliance and assumed
bearing-pair stiffness are combined in series. A local linear stability screen
requires combined mechanical stiffness above the magnetic force gradient.
The assessment JSON retains 1/10/100 MN/m bearing-pair scenarios and the resulting
eccentricity amplification. Soft support can fail this gate despite adequate
nominal air gap. Catalog preload/stiffness, the real shaft shoulders and housing
must be selected before converting the screen into an assembled stability claim.

These calculations omit dynamic whirl, contact, thermal fit/preload evolution,
axial modes and mission vibration. The existing proposed wrap/gap budget does
not automatically establish bearing stability.

The retention screen now includes the sampled fault traction, unsupported-span
bending deflection and the declared bearing/shaft compliance. The earlier
50 GPa / .20 mm wrap leaves only
0.079 mm
in that combined screen, below the .1 mm target. It is rejected by this check.
The proposed hot hoop modulus is raised to
100 GPa; the modeled minimum to preserve the
gap is 72.6 GPa. At the proposed
value the retained gap is 0.113 mm and the
required hot hoop strength, with the stated factor two, is
623.5 MPa. This is a revised
material/construction requirement, not a pass for a selected insulating composite.
The assumed bearing-pair radial stiffness is 10 MN/m, and magnetic stiffness
comes from the nominal-field eccentricity cases; full fault-UMP dynamics,
anisotropic laminate/contact/end retention and actual fits remain open.

Shaft and bond torque requirements are also updated from the nonlinear faults
and end-leakage scenarios. Bond shear uses the actual 23 mm core-interface radius
rather than the magnet mean radius. The construction JSON retains those loads.

## 7. Winding construction and liner thermal resistance

An independent coated-wire unit cell uses .95 mm copper, 25 micrometer radial
enamel, the native 47.6 percent bare slot fill and declared matrix conductivities.
Two meshes establish numerical sensitivity. Copper conductivity is 390 W/m/K,
enamel .2 W/m/K. Insulating porosity is represented by a Maxwell dilute-pore
approximation, not a measured connected-void network.

The resulting transverse conductivity is then supplied directly to the actual
slotted-stator FE model. Copper/steel interface nodes are separated and connected
by the stated liner conductance, allowing a temperature jump. Liner conductivity
is .12 W/m/K. The mean winding-to-case resistance comes from a steady 1 W solve;
it is not fitted to the desired .12 K/W target in this calculation.

| Resin k W/m/K | Assumed resin void % | Liner mm | Composite k W/m/K | Mean path K/W |
| --- | --- | --- | --- | --- |
| 0.1 | 0 | 0.1 | 0.309 | 0.1326 |
| 0.1 | 0 | 0.2 | 0.309 | 0.1575 |
| 0.1 | 20 | 0.1 | 0.229 | 0.1603 |
| 0.1 | 20 | 0.2 | 0.229 | 0.1854 |
| 0.2 | 0 | 0.1 | 0.574 | 0.0953 |
| 0.2 | 0 | 0.2 | 0.574 | 0.1197 |
| 0.2 | 20 | 0.1 | 0.434 | 0.1094 |
| 0.2 | 20 | 0.2 | 0.434 | 0.1340 |
| 0.4 | 0 | 0.1 | 1.010 | 0.0762 |
| 0.4 | 0 | 0.2 | 1.010 | 0.1001 |
| 0.4 | 20 | 0.1 | 0.785 | 0.0835 |
| 0.4 | 20 | 0.2 | 0.785 | 0.1076 |

For example, .1 W/m/K impregnation with a .2 mm liner exceeds the target, whereas
.4 W/m/K impregnation has margin in the tested liner/porosity scenarios. The
proposed construction screen therefore specifies at least .4 W/m/K hot potting,
at most .2 mm liner and at least .12 W/m/K liner conductivity, while retaining
assembled Rwc <= .12 K/W as the actual requirement. This is a material scenario,
not a procured-grade or manufactured-coil pass. Liner volume, insertion and real
packing need checking: the zero-thickness interface preserves the native slot
envelope and does not resolve the liner's displaced copper volume. End-turn
geometry and actual contact quality remain separate requirements.

## 8. Loaded full-period loss convergence and extra native models

At hot 150 C magnets / 130 C winding / 22 Arms / 630 rpm:

| Full positions | Mean torque N m | Stator core W | Rotor core W | Magnets W |
| --- | --- | --- | --- | --- |
| 144 | 8.80564 | 3.96520 | 0.021918 | 0.63176 |
| 288 | 8.80574 | 3.97951 | 0.021920 | 0.63118 |

The largest non-copper loss change with 144-to-288 refinement is
0.361 percent.
These histories span a full mechanical revolution, respecting per_t_R=1.
They improve loaded-point numerical evidence, not empirical coefficient accuracy
or convergence over every current/speed/temperature combination.

Additional official formulations executed on retained native fields give:
LossModelWinding 58.681 W with the
.95 mm winding at 100 C; stator Steinmetz
3.210 W; rotor Steinmetz
0.005046 W. Steinmetz and Bertotti
share an assumed 3 W/kg calibration point and are alternative formulations,
not independent material measurements.

Native WindagePyrhonen returns
0.000308 W at its hard-coded
atmospheric-air conditions and rotor-iron radius. It is a ground-test comparison,
not a space-vacuum windage prediction. Bearing/seal losses remain unmeasured.

## 9. Harmonic AC verification and conductive reaction

Direct FEMM AC solves benchmark a .95 mm isolated round wire at 1/20/40/80 kHz,
100/130 C and two meshes. The fine-mesh maximum resistance-ratio error against
the exact Bessel internal-impedance solution is
0.032 percent. This verifies the
isolated-wire calculation; it does not validate neighboring-wire proximity.
The simulated PWM spectra above 1 kHz are evaluated separately with isolated-wire impedance
and the native low-frequency Pyrhonen expansion, whose high-frequency extrapolation
is explicitly a sensitivity rather than an accepted bound.

The motor harmonic calculation uses FEMM incremental permeability about native
DC geometry/bias, finite assumed magnet conductivity, and a separate zero-net-
current circuit per magnet. The AC field therefore includes conductive reaction.
Unit d/q RMS perturbations plus their real/quadrature combinations identify a
Hermitian magnet-loss response. The native half-domain integral is multiplied by
two and physical stack depth is 85 mm.

| Magnet C | Frequency kHz | Magnet mesh mm | Unit d loss W/A2 | Unit q loss W/A2 |
| --- | --- | --- | --- | --- |
| 80 | 20 | 0.30 | 22.07239 | 18.78048 |
| 80 | 40 | 0.30 | 32.39434 | 41.51704 |
| 80 | 80 | 0.30 | 51.45869 | 76.89498 |
| 80 | 20 | 0.15 | 22.06948 | 18.78154 |
| 150 | 20 | 0.30 | 22.13961 | 18.15215 |
| 150 | 40 | 0.30 | 32.43905 | 40.26184 |
| 150 | 80 | 0.30 | 51.24762 | 74.70294 |
| 150 | 20 | 0.15 | 22.13639 | 18.15190 |

The finer 20 kHz magnet mesh provides a separate AC convergence check. Results
describe one frozen rotor position and continuous axial magnets. Actual PWM
sidebands, axial segmentation and three-dimensional current return/end effects
remain approximations; laminated-steel high-frequency loss still needs supplier
data. This new solve is not labelled a complete three-dimensional PWM-loss model.

Combining the simulated high-frequency dq-current spectra with the sampled
Hermitian response gives incremental magnet-loss sensitivities from
0.0832 to
0.1117 W.
The response is interpolated at 20/40/80 kHz, clamped below the lowest sampled
frequency and continued as f-squared above the highest. Both DC-bias endpoints
are applied as scenarios. These are model sensitivities rather than a validated
PWM-loss bound; the component JSON records the current-spectrum share outside
the sampled frequency range. They do not remove the supplier/3-D loss gate.

## 10. Reproduction and remaining acceptance gates

Run python -m actuator.motor_comprehensive with .venv and OPENBLAS_NUM_THREADS=1
after the documented setup. All Wine/FEMM stages are sequential. Per-point native
checkpoints recover interrupted work; completed summaries are not substituted for
missing raw data when a stage actually needs the latter. Verification results,
coverage and source/artifact hashes are regenerated before packaging.

The remaining gates are explicit: supplier magnet irreversible curves and
high-field/high-frequency steel data, demonstrated winding/contact paths and
actual end-turn construction, selected bearings/preload and detailed retention
geometry/materials, real mission duty/inertia/environmental/life loads, protected
drive hardware and prototype correlation. StructElmer's installed compatibility
failure is retained. Those gaps cannot be closed by running unrelated machine
types or alternate optimizers with the same physical assumptions.


![map_and_faults.png](map_and_faults.png)

![fault_trajectories.png](fault_trajectories.png)

![tolerances_and_geometry.png](tolerances_and_geometry.png)

![eccentricity_and_AC_wire.png](eccentricity_and_AC_wire.png)

![incremental_AC_and_PWM.png](incremental_AC_and_PWM.png)

![voltage_and_thermal_construction.png](voltage_and_thermal_construction.png)
