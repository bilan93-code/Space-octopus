# Space-octopus: extended analysis and design proposal

Motor rating update: this report records the earlier actuator/concept study.
The motor-first report at results/motor/report.pdf supersedes its motor thermal
conclusions. Native full-mechanical-period rotor losses and spatial stationary
holding checks found limits missed by average-temperature calculations. Use
configs/motor_candidate.json and the motor report for the corrective winding,
distributed cooling, drive/fault and construction requirements. The earlier
concept CAD and actuator screens remain preliminary.

## 1. What this study establishes

The original preliminary study has been extended with official Pyleecan MagFEMM,
electrical-to-FEMM flux linkage, loss, force, lookup-table interpolation and fault
electrical calculations; nonlinear
current/temperature field maps; CalculiX 3-D carrier strength and modes; 2-D stator
thermal finite elements; a winding/cooling trade study; and FreeCAD concept CAD.

A revised candidate uses 12 turns per coil instead of 15, two 0.9 mm copper strands
instead of 0.8 mm, a 96 mm stator OD, a 22 Arms phase-current inverter, and tighter
thermal-interface requirements. At 220 N m and 10 output rpm, its nominal scenario
calculates 10.81 Arms, 16.14 V phase peak,
and 75.3 deg C winding temperature at a 50 deg C sink.
The nominal model assumes 3 W core/rotor loss, with 10/30 W alternatives below.
These values depend on cooling targets, not demonstrated thermal hardware.

Both the custom magnetic solver and official Pyleecan MagFEMM now execute.
The native solver predicts 4.6123 N m at 9 Arms, within
0.25 percent of the independent custom FE mean. The revised
motor also executes Electrical(EEC_PMSM(fluxlink=MagFEMM)); its hot comparison
point requires 16.12 V phase peak and produces
4.424 N m. This verifies real solver couplings rather than
only creating runner files. The installed FEMM binary came from a public cache
and matches the official release checksum byte-for-byte.

This remains an engineering study and a concept design, not completion of all
Pyleecan capabilities or a product release. Loss convergence, supplier data,
complete mechanical interfaces and physical qualification remain open. No
standards compliance or flight qualification is inferred from numerical tests.

## 2. Exact capability coverage

| Capability | Actual execution | Boundary |
| --- | --- | --- |
| Machine, slots, winding, resistance, material masses | Official Pyleecan classes | Generic material data |
| Nonlinear magnetic FE | Official MagFEMM/FEMM and independent custom Gmsh/scikit-fem | Generic materials, 2-D model |
| Core losses | Official LossModelBertotti | Assumed coefficient split, actual FE time history |
| Copper/skin and proximity losses | Official LossModelJoule and LossModelProximity | Frequency-limited model, no switched inverter |
| Magnet eddy-current loss | Official LossModelMagnet | 2-D postprocessing, assumed resistivity and simplified arc dimensions |
| Air-gap force fields | Official ForceMT module | Not a complete vibroacoustic assembly model |
| Current/temperature flux maps | Nonlinear FE, 27 operating points | Static rotor position, not rotor-averaged maps |
| Lookup-table interpolation | Official LUTdq at three temperatures | Built from those static FE maps |
| dq electrical/fault calculations | Official EEC_PMSM, including MagFEMM flux linkage | Steady linear fault estimates, not fault transients |
| Current controller | SciPy averaged dq PI plant | No PWM, DSP firmware, timing or hardware validation |
| Carrier strength and eigenmodes | CalculiX 2.20, quadratic 3-D elements | Clamped single plate, assumed steel |
| Stator conduction | scikit-fem 2-D transverse FE | No axial/end-turn/contact-resolved thermal model |
| Gear/bearing/interface screens | Explicit analytical equations | Not ISO fatigue/contact or output-bearing certification |
| Concept CAD | FreeCAD 1.0.0, native file and STEP | Individual solids valid; full assembly clearance unverified |
| Official MagFEMM | Executed under Wine, with native ForceMT and loss models | Coarse time/mesh validation; not a converged full loss map |
| MagElmer/StructElmer | Not executed | This release contains unfinished extraction and skipped structural validation tests |
| Hardware and mission qualification | Not performed | Requires physical components and mission requirements |

The official Pyleecan Elmer source and tests were inspected. Unfinished flux
extraction is visible in MagElmer.solve_FEA, and StructElmer validation tests in
Tests/Simulation/test_StructElmer.py are skipped as needing correction. That is
why these interfaces are not claimed as validated alternatives here.

## 3. Full-revolution field history and official loss/force coupling

The baseline 15-turn motor was solved at 9 Arms and 630 rpm, with 80 deg C magnet
properties. The history contains 144 positions over one complete mechanical
revolution. A full revolution, rather than one electrical period, makes the
rotor-material sampling periodic as it passes the stator slots. Stator samples
remain fixed in space; rotor samples and vector components are transformed into
rotor material coordinates. The reference mesh has 52148 triangles.

For this 144-position history, the magnetic source is the custom nonlinear solver.
An independent official MagFEMM run is compared in section 11. Fields Bx, By and A_z
were packaged in official Pyleecan MeshMat/MeshSolution, SolutionVector and
SolutionData objects, then passed through native Loss and ForceMT run methods.
Native copper loss uses a 100 deg C winding resistance. The history is not the
same operating point as the redesigned candidate or a measured motor.

Bertotti model: p = k_h f B squared + k_e (f B) squared + k_ex (f B)^1.5.
Coefficients are {'k_hy': 0.016, 'k_ed': 0.0001866666666666667, 'k_ex': 0.00023094010767585029}, selected to reproduce a
generic 3 W/kg point at 50 Hz and 1.5 T, not fitted to a certified dataset.
Native magnet loss uses J = -sigma d(A_z - magnet-area-mean A_z)/dt, and integrates
J squared / sigma. Assumed magnet resistivity is 0.9 microohm m. Native SlotM11
geometry is reduced to equal-area square dimensions in its segmentation correction.
No conductive-field feedback or full 3-D eddy-current solution is implied.

| Native loss source | Computed W at this history point |
| --- | --- |
| stator_bertotti | 3.1598 |
| rotor_bertotti | 0.2880 |
| copper | 71.6448 |
| proximity | 0.0138 |
| magnets | 0.2103 |

The summed core-plus-magnet result is 3.6580 W. This replaces neither a
calibrated material loss map nor the redesigned machine's own full history.
The redesigned study deliberately includes 3/10/30 W loss sensitivities.

The Nyquist limit is 756.0 Hz; PWM switching losses above
that are absent. Mesh-to-mesh interpolation introduces additional uncertainty,
especially for high-frequency loss terms. Exterior probes are clipped 0.1 mm
inside the outer circle to avoid different mesh chord approximations. Loss
convergence with time step and mesh has NOT been established; a 144-sample run
must not be described as a converged PWM or eddy-current loss prediction.

Native ForceMT computes p_r = -(Br squared - Bt squared)/(2 mu0) and
p_t = -Br Bt/mu0 with its stator traction convention. Recorded radial extrema are
-469.1 to 32.5 kPa;
peak tangential traction magnitude is 348.4 kPa.
These are air-gap tractions, not external arm bearing forces. The pressure
spectrum is available for later structural transfer; it was not applied as a
load on the gearbox carrier, where gear-pin reactions are the physical loads.

## 4. Winding and stator design trade

| Trial stator OD mm | Iron + winding + magnet mass kg | Static torque constant N m/Arms | Loaded iron B p99 T |
| --- | --- | --- | --- |
| 100 | 4.490 | 0.4104 | 1.545 |
| 96 | 4.109 | 0.4103 | 1.545 |
| 92 | 3.745 | 0.4100 | 1.546 |

These trials use the same 52 mm magnet OD, 53 mm stator bore, 85 mm active stack,
12 slots, 10 poles and 63:1 gearbox. The selected 96 mm stator is a conservative
intermediate design retaining more yoke than the 92 mm candidate. It is not a
global optimum; no mission mass/size requirement or manufacturing cost model was
provided. These masses exclude shaft, frame, bearings and the complete gearbox.

For fixed slot copper fill, fewer turns lower voltage demand but raise phase
current. Approximately, psi is proportional to N, L to N squared, and R to N/A.
The two 0.9 mm strands maintain a similar copper-fill level while reducing
resistance. The inverter must support 22 Arms, or 31.1 A sinusoidal phase peak,
plus a separately designed fault-protection margin.

The revised model's conditional voltage-limited speed at 220 N m is
14.18 output rpm, compared
with 10.85
for the baseline. Its 400 N m, five-second thermal-load scenario requires about
19.48 Arms and
19.50 V phase peak at the
pulse endpoint. The minimum DC bus implied by the same modulation margin is
37.53 V. This passes the assumed
42 V bus/current screens, but does not establish gear, bearing or demagnetization
peak capability.

## 5. Nonlinear current/temperature maps and native LUTdq

Twenty-seven FE points cover Id = -12/-6/0 Arms, Iq = 0/9/18 Arms, and magnet
T = 20/80/140 deg C. Each point includes nonlinear residual, RMS dq flux,
torque/voltage, B-H extrapolated area, and the reverse magnetizing field.
The map uses a single rotor position. It therefore cannot claim rotor-averaged
MTPA, calibrated field weakening, full efficiency maps or torque-ripple optima.

Official LUTdq objects were created at each temperature and interp_Phi_dqh ran
both off-grid and at every original grid point. Maximum grid reconstruction
error is 0 Wb.
This verifies the interpolation pipeline, not the accuracy of sparse interpolation
between nonlinear operating points. The native objects are saved as JSON.

The magnet screen computes H_parallel = (B_parallel - Br)/(mu0 mu_r).
Worst sampled H_parallel is -380.1
kA/m; the most negative recorded first-percentile value is
-326.1 kA/m. Corner minima are
mesh-sensitive. Without grade-specific temperature-dependent recoil/knee curves,
these fields cannot prove irreversible-demagnetization safety. No arbitrary
coercivity number was substituted to manufacture a pass.

## 6. Drive, control and electrical faults

An idealized continuous dq PI model uses a 300 Hz target bandwidth, feed-forward
decoupling, vector voltage saturation and anti-windup at the 42 V minimum bus.
Current demand steps to the continuous point at 10 ms and includes a separate
5 ms exploratory current pulse at 100 ms. This is not the five-second thermal
pulse. The model reaches 90 percent of continuous current in approximately
2.70 ms. It is a fixed-speed, averaged
plant with known R and L, not switched PWM or sampled DSP firmware.

The native EEC also solved Ud=Uq=0 steady three-phase short-circuit conditions at
630 and 1890 rpm and three magnet temperatures. The largest estimated current is
29.65 Arms, or
41.93 A
sinusoidal phase peak. All those currents lie outside the characterized FE map
because negative Iq and more negative Id are involved. Consequently no fault
survival, transient current bound or demagnetization pass is claimed. A protection
and braking architecture must be designed from component limits and mission loads.

## 7. Three-dimensional carrier strength and modal model

The final-stage carrier uses two 8 mm steel plates, 104 mm OD, 24 mm hub bore,
and three 12 mm pin holes at 31.5 mm radius. One plate is solved with a fully
clamped hub and half the conservative pin reaction, multiplied by a 1.5 load
factor. Each pin bore receives 1952.1 N distributed
traction. Equal sharing, rigid hub support and E=210 GPa, nu=0.3 are assumptions.

Gmsh quadratic tetrahedra are explicitly reordered to CalculiX C3D10 conventions.
Two meshes contain 22125 and
46452 elements. Peak displacement is
7.584 micrometres; maximum integration-point
von Mises stress is 47.11 MPa, with p99
38.80 MPa. Displacement changes by
0.015 percent and stress p99 by
1.47 percent between meshes.

These results do not include pin/bearing contact compliance, output-bearing
preload, bolts, carrier assemblies, real fits, launch loads or fatigue allowables.
A low plate stress does not prove the gear teeth or complete actuator is safe.
The first clamped-plate eigenfrequency is 3518.3 Hz.
This is not the full-actuator resonance: bearing, arm and gear compliance can
introduce much lower modes. No acoustic or complete forced-vibration prediction
has been made.

## 8. Gear, pin, bearing-life and interface requirements

The gearbox remains 18/63/144 teeth at module 0.75 and 18/45/108 at module 1,
three planets each, ratios 9 and 7. Geometry closure and adjacent-planet clearance
pass their nominal screens. Manufactured tooth profiles, load sharing and ring
flexibility are not validated.

A 10000-hour constant-load scenario gives the following REQUIRED values. These
are not certified allowables or safety-factor claims:

| Stage | Factored pitch-point Hertz GPa | Required contact allowable for 1.3 margin GPa | Required bending allowable for 1.5 margin MPa | Required pin-bearing C kN |
| --- | --- | --- | --- | --- |
| 1 | 0.766 | 0.996 | 179.6 | 2.54 |
| 2 | 1.202 | 1.563 | 406.7 | 8.69 |

Pitch-point contact uses Fn = K Ft/cos(alpha), 1/R_eff = 1/(rs sin(alpha)) +
1/(rp sin(alpha)), and sigma_H = sqrt(Fn E_star/(pi b R_eff)). This smooth-cylinder
screen is not an ISO 6336 rating. Tooth-root Lewis Y and all factors remain
assumptions; certification needs actual geometry, material treatment, life and
lubrication data. Planet teeth can experience reversed bending, which a static
yield-strength ratio does not address.

Planet-bearing life uses C/P = L10_millions^(3/10) for a roller-bearing scenario,
with planet spin relative to its carrier, not motor speed. Output bearings remain
unselected because external radial/axial/overturning loads are unspecified. The
32 mm pin support-centre span implied by 8 mm plates is used in the revised pin
screen, yielding 184.1
MPa continuous and 334.8 MPa
peak bending screens before bearing/contact fatigue assessment.

A friction-only example with six M6 bolts, 8 kN preload each, and 55 mm effective
radius carries only 211.2
N m at mu=0.08, below continuous torque. At mu=0.12 it still cannot carry 400 N m.
This proposed preload circle requires a larger flange than the present CAD and
is an interface trade, not an installed detail. Positive torque features such as
three 5 mm dowels at 45 mm radius give a nominal
150.9 MPa shear screen at
400 N m; fits, edge distances, bearing stress and fatigue remain to design.

## 9. Thermal finite elements and coupled uncertainty

The revised thermal requirements are winding-to-case 0.25 K/W and case-to-sink
0.15 K/W. They are substantially tighter than the baseline. The CAD includes a
0.1 mm bond-layer envelope, but no measured bond conductivity, contact conductance
or complete end-turn heat path. No convection is used in vacuum.

A separate 2-D stator conduction solve uses the actual Pyleecan cross-section,
20 W/mK iron and three effective winding conductivities. All copper loss is
conservatively placed in active slots, including the end-turn loss allowance.
The exterior case is fixed at 60.21 deg C; source power
is 60.56 W. This calculation tests the transverse
path, not end-turn hot spots or mounting contacts.

| Effective winding k W/mK | Average winding C | Maximum node C | Effective transverse R K/W |
| --- | --- | --- | --- |
| 0.3 | 66.84 | 73.35 | 0.1095 |
| 0.6 | 64.35 | 67.60 | 0.0684 |
| 1.2 | 63.08 | 64.70 | 0.0475 |

All three cases close heat balance within
3.77e-13 W. Unresolved insulation,
liners, voids and interfaces are represented only through effective conductivity.
The lower effective transverse resistances do not verify the complete 0.25 K/W
winding-to-case requirement in actual hardware.

| Sink C | Assumed core/rotor loss W | Output torque N m | Lumped winding C | Thermal screen |
| --- | --- | --- | --- | --- |
| 50 | 3 | 220 | 75.3 | pass |
| 50 | 3 | 302.4 | 100.1 | pass |
| 50 | 10 | 220 | 77.7 | pass |
| 50 | 10 | 302.4 | 103.4 | pass |
| 50 | 30 | 220 | 84.8 | pass |
| 50 | 30 | 302.4 | 113.2 | pass |
| 70 | 3 | 220 | 96.7 | pass |
| 70 | 3 | 302.4 | 123.4 | pass |
| 70 | 10 | 220 | 99.1 | pass |
| 70 | 10 | 302.4 | 126.9 | pass |
| 70 | 30 | 220 | 106.5 | pass |
| 70 | 30 | 302.4 | 137.3 | exceeds limit |

The 302.4 N m row corresponds to a 6 N m motor-shaft target with 63:1 and 0.80
efficiency. The 70 deg C sink / 30 W loss case exceeds the winding limit at that
target. Therefore the revised design is NOT robustly established as a 6 N m
continuous motor across the tested uncertainty range, even though it improves the
nominal scenario and supports 220 N m in these scenarios.

## 10. CAD and integration status

FreeCAD produced 58 individually valid concept solids, a native
FCStd file and a 32.2 MB STEP assembly, plus individual
STEP components and a volume/material BOM. Coil solids are slot envelopes, not
solid copper: mass requires the actual fill factor and native winding model.
The BOM is not a manufacturing release. Motor surfaces originate from native
Pyleecan lines/arcs. Gear flanks use sampled involutes; root fillets are not
manufacturing trochoids. Modelled envelope is approximately 140 mm OD by 219 mm
axial, before unresolved connectors, supports and interface details.

This CAD is NOT a manufacturing release. Assembly clearance and tooth phasing
have not been verified, and the current model omits the detailed stage-1 carrier,
interstage supports, bearing seats/preloads, retaining sleeve, seals, vents,
encoder, launch restraint and fastener/dowel interfaces. Coupling and output
support remain concept envelopes. These omissions mean the current CAD does not
establish a complete load path or final overall length/mass. Individual-solid
validity is a geometry-kernel test, not assembly acceptance.

## 11. Executed official magnetic and electrical couplings

Native MagFEMM executed: **True**.
Native Electrical-to-MagFEMM coupling executed:
**True**.

The official FEMM download remains blocked directly by network policy, but a
cached installer on an accessible public GitHub course repository matched the
FEMM project's published SourceForge SHA-256 exactly:
17384e8990b6305ec8ffef1f75b6ef091a266b6e49b30c151cd1daca2e952043.
Its source, pinned commit, checksum and extraction method are recorded in
docs/femm-distribution.json. No network-policy bypass or verification disabling
was used; the same official bytes were obtained through an allowed host.

The x64 payload was extracted from its 32-bit installer wrapper with innoextract.
The bundled x64 VC++ runtime was installed through its MSI under Wine, and the
actual FEMM GUI/Lua file link was verified. An additive filesystem alias fixes a
mixed Windows/Linux separator in Pyleecan 1.5.2's Lua resource path; no solver or
Pyleecan implementation file was edited. These steps are reproducible in
scripts/setup_femm.py.

The first time-refined attempt failed when the Linux file-link handler returned
a list where the torque routine expected a scalar. The raw reply was not retained.
Inspection found that the handler can read an output file before a complete
response is written; the failure is consistent with this file-link race. The
project now scopes a transport
guard around native jobs: atomic request delivery, waiting for a complete numeric
reply, rejection of stale replies, and a bounded timeout. A regression check
reproduces an empty file followed by a delayed valid torque response. This guard
replaces only the in-process Linux communication method during the job; the
official geometry, field solver, torque and loss algorithms are unchanged.
The failed attempt contributes no accepted numerical result. Completed refinement
transport diagnostics are retained with the corresponding results.

The native magnetic model uses the same baseline geometry, 9 Arms, 630 rpm and
80 deg C magnet properties. A 0.125 mm gap mesh and space/time symmetry were used.
Pyleecan solved 12 time positions after reducing the requested
120 full-revolution sample grid. It ran magnetic analysis,
ForceMT and all five loss models as a native simulation pipeline.

Independent one-step refinements double the full-revolution time grid or reduce
the air-gap element target from 125 to 83.3 micrometres, keeping the other setting
fixed. Their absolute results and torque changes relative to the reference are:

| Native case | Full time grid | Gap mesh µm | Torque N m | Torque change percent | Stator W | Rotor W | Magnet W |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Reference | 120 | 125.0 | 4.61227 | 0 | 3.1832 | 0.0156 | 0.3075 |
| time refined | 240 | 125.0 | 4.60752 | 0.103 | 3.2014 | 0.0240 | 0.4240 |
| mesh refined | 120 | 83.3 | 4.60761 | 0.101 | 3.1929 | 0.0156 | 0.3068 |

The largest mean-torque change in these checks is
0.103 percent.
These are separate single-point checks, not an asymptotic convergence proof,
a full mesh refinement of every region, or a converged operating-domain loss map.
Loss changes are retained individually in native_femm/convergence.json, including
results that are less stable than the mean torque. Supplier loss data and
independent material-frame/harmonic validation are still needed.

The time refinement changes sampled torque peak-to-peak from
0.1394 to
0.6058 N m. The larger sampled ripple is
13.1 percent
of mean motor torque. Coarse sampling misses important ripple extrema even when
the mean is stable. Neither ripple value is a validated final specification;
additional time steps and mechanical torsional transfer are required.

| Quantity | Custom field history | Official MagFEMM pipeline |
| --- | --- | --- |
| Mean motor torque N m | 4.6237 | 4.6123 |
| Stator core loss W | 3.1598 | 3.1832 |
| Rotor core loss W | 0.2880 | 0.0156 |
| Magnet loss W | 0.2103 | 0.3075 |
| Copper/skin loss W | 71.6448 | 71.6448 |

Torque agreement is 0.25 percent. This supports implementation
consistency for a shared assumed geometry/material model, not measured accuracy.
The rotor and magnet loss differences are much larger proportionally; different
time reduction, material-frame sampling, meshing and numerical derivatives remain
unconverged. Neither rotor/magnet value is presented as a verified loss rating.
Their absolute difference is small relative to total copper/gear heat but still
requires time/mesh convergence and material correlation for detailed design.

For the revised motor, native Electrical(EEC_PMSM(fluxlink=MagFEMM)) performed
open-circuit and loaded FEMM calculations, extracted dq flux and solved the
voltage/torque/copper-loss equations. At 10.814 Arms, Id=0, 630 rpm,
100 deg C winding and 80 deg C magnets it gives:

| Native revised electrical quantity | Result |
| --- | --- |
| PM linkage RMS Wb turns | 0.027280 |
| Loaded Phid / Phiq RMS Wb turns | 0.027276 / 0.008884 |
| Phase resistance ohm | 0.18636 |
| Phase voltage peak V | 16.116 |
| Electromagnetic torque N m | 4.4244 |
| Copper loss W | 65.378 |

The native secant Ld is undefined at Id=0 and is retained as null, not invented.
These fixed hot temperatures differ from the nominal thermal equilibrium in the
redesign table. Coarse temporal coupling checks do not replace a rotor-averaged,
current/temperature map with demonstrated convergence. The coupled pipeline is
working; product qualification and the limitations elsewhere in this report
remain unchanged.

## 12. Product release gates

The engineering package is useful for refining and reviewing the concept. To
release a product requires mission loads and life/backlash/stiffness requirements,
supplier material curves and temperature-dependent magnet knee data, actual
thermal contacts, winding manufacture, catalog bearing/encoder/inverter selection,
complete toleranced CAD and contact analysis, full gear fatigue/contact ratings,
protection and control validation, and hardware correlation.

Tests to obtain that evidence include winding resistance/inductance/back-EMF,
dynamometer torque/loss maps, gearbox efficiency/backlash/load sharing, bearing
and lubricant life, thermal contact characterization and vacuum hot/cold torque
runs. Space environmental acceptance criteria depend on the actual mission;
launch vibration, outgassing/contamination, EMC and radiation requirements have
not been guessed from the word space. No numeric reliability or flight-readiness
score is assigned without evidence.

## 13. Reproduction and artifacts

Run from /workspace/Space-octopus:

    bash scripts/setup.sh
    python scripts/setup_extended.py
    python scripts/setup_femm.py
    OPENBLAS_NUM_THREADS=1 .venv/bin/python -m actuator.extended
    OPENBLAS_NUM_THREADS=1 .venv/bin/python -m pytest -q

The extended runner reuses retained validated results unless --refresh is passed.
Native magnetic field histories are large and ignored by Git, but remain in this
workspace/snapshot. Reproduction packages use pinned SHA-256 values from signed
Debian indexes without modifying host packages. The present state is prepared in
this instance; environment publication/fresh-instance restoration is not verified.

See configs/revised.json, component JSON data, CalculiX input decks, the native
LUTdq files, CAD/BOM, thermal plots and controller data. Native FEMM and electrical execution evidence have separate JSON records. Software tests verify numerical invariants and stated
coverage; their pass count is not a substitute for the product gates above.
