"""Run with scripts/freecad_python.sh scripts/build_cad.py.

Concept CAD, millimetres. Involute flanks are polygonal approximations; root
fillets, tolerances, bearing seats, lubrication/sealing and tooth phasing remain
for detailed mechanical design. Not a manufacturing release.
"""
import sys,json,math
from pathlib import Path
sys.path.insert(0,'/usr/lib/freecad-python3/lib')
import FreeCAD as App
import Part

ROOT=Path(__file__).resolve().parents[1]
out=ROOT/'results/extended/cad';out.mkdir(parents=True,exist_ok=True)
doc=App.newDocument('SpaceOctopusConcept')
parts=[];bom=[]

def add(name,shape,material,notes=''):
    if shape.isNull() or not shape.isValid():raise RuntimeError('Invalid solid '+name)
    o=doc.addObject('Part::Feature',name);o.Shape=shape
    o.addProperty('App::PropertyString','Material');o.Material=material
    o.addProperty('App::PropertyString','DesignStatus');o.DesignStatus='CONCEPT / NOT FOR MANUFACTURE: '+notes
    parts.append(o);bom.append(dict(part=name,volume_mm3=shape.Volume,material=material,notes=notes))
    shape.exportStep(str(out/(name+'.step')))
    return o


def ring(ro,ri,z,h):return Part.makeCylinder(ro,h,App.Vector(0,0,z)).cut(Part.makeCylinder(ri,h,App.Vector(0,0,z)))

def wire(points):
    vs=[App.Vector(x,y,0) for x,y in points];return Part.makePolygon(vs+[vs[0]])

def gear(z,m,b,internal=False,ro=70):
    r=m*z/2;rb=r*math.cos(math.radians(20));rf=r-1.25*m;ra=r+m
    invp=math.tan(math.radians(20))-math.radians(20)
    pts=[]
    if not internal:
        for j in range(z):
            center=2*math.pi*j/z
            def half(rad):
                a=math.acos(min(1,rb/max(rb,rad)));return math.pi/(2*z)+invp-(math.tan(a)-a)
            lo=max(rb,rf);halflo=half(lo);halftip=half(ra)
            # Below-base radial flank, then sampled true involute.
            pts.append((rf*math.cos(center-halflo),rf*math.sin(center-halflo)))
            for k in range(13):
                rad=lo+(ra-lo)*k/12;a=center-half(rad);pts.append((rad*math.cos(a),rad*math.sin(a)))
            for k in range(1,5):
                a=center-halftip+2*halftip*k/4;pts.append((ra*math.cos(a),ra*math.sin(a)))
            for k in range(1,13):
                rad=ra-(ra-lo)*k/12;a=center+half(rad);pts.append((rad*math.cos(a),rad*math.sin(a)))
            pts.append((rf*math.cos(center+halflo),rf*math.sin(center+halflo)))
            end=2*math.pi*(j+1)/z-halflo
            for k in range(1,4):
                a=center+halflo+(end-center-halflo)*k/3;pts.append((rf*math.cos(a),rf*math.sin(a)))
        # Consecutive points can coincide when root and base circles match.
        clean=[]
        for p in pts:
            if not clean or math.dist(p,clean[-1])>1e-8:clean.append(p)
        face=Part.Face(wire(clean))
    else:
        ri=r-m;rr=r+1.25*m
        def half(rad):
            a=math.acos(min(1,rb/rad));return math.pi/(2*z)+(math.tan(a)-a)-invp
        for j in range(z):
            center=2*math.pi*j/z
            for k in range(5):
                a=center-half(ri)+2*half(ri)*k/4;pts.append((ri*math.cos(a),ri*math.sin(a)))
            for k in range(1,13):
                rad=ri+(rr-ri)*k/12;a=center+half(rad);pts.append((rad*math.cos(a),rad*math.sin(a)))
            end=2*math.pi*(j+1)/z-half(rr)
            for k in range(1,4):
                a=center+half(rr)+(end-center-half(rr))*k/3;pts.append((rr*math.cos(a),rr*math.sin(a)))
            for k in range(1,13):
                rad=rr-(rr-ri)*k/12;a=2*math.pi*(j+1)/z-half(rad);pts.append((rad*math.cos(a),rad*math.sin(a)))
        face=Part.Face(Part.Wire(Part.makeCircle(ro))).cut(Part.Face(wire(pts)))
    return face.extrude(App.Vector(0,0,b))

# Exact native Pyleecan line/arc surfaces, exported into a neutral JSON bridge.
geo=json.loads((out/'motor_surfaces.json').read_text())
for s in geo:
    def loop(lines):
        edges=[]
        for l in lines:
            v=[App.Vector(p[0]*1000,p[1]*1000,0) for p in l['points']]
            if l['type']=='line':edges.append(Part.makeLine(v[0],v[-1]))
            else:
                edges.append(Part.Arc(v[0],v[1],v[2]).toShape());edges.append(Part.Arc(v[2],v[3],v[4]).toShape())
        return Part.Wire(edges)
    face=Part.Face(loop(s['loops'][0]))
    for hole in s['loops'][1:]:face=face.cut(Part.Face(loop(hole)))
    shape=face.extrude(App.Vector(0,0,85));shape.translate(App.Vector(0,0,15))
    add(s['name'].replace('-','_'),shape,s['material'],'Native Pyleecan cross-section; winding regions represent coil envelopes')
add('MotorShaft',Part.makeCylinder(6,137,App.Vector(0,0,0)),'Steel','12 mm shaft couples to stepped gearbox input, not bored through sun')
add('MotorFrame',ring(54,48.1,0,125),'Aluminium','96 mm stator trial; no detailed thermal interface or bearing seats')
add('StatorBondLayer',ring(48.1,48,15,85),'Thermally conductive adhesive, grade TBD','0.1 mm bond line; vacuum suitability and conductivity require verification')
add('MotorEndbellRear',ring(54,16,0,12),'Aluminium','Bearing-seat envelope; fasteners and preload TBD')
add('MotorEndbellFront',ring(54,16,113,12),'Aluminium','Bearing-seat envelope; fasteners and preload TBD')
add('CouplingEnvelope',Part.makeCylinder(12,15,App.Vector(0,0,125)),'Steel','Placeholder for removable precision coupling; alignment and sealing not designed')
for num,zsun,zp,zr,mod,face,zpos in [(1,18,63,144,.75,12,145),(2,18,45,108,1.,24,175)]:
    sun=gear(zsun,mod,face);sun.translate(App.Vector(0,0,zpos));add(f'Stage{num}Sun',sun,'Case-hardening steel','No tooth fillets or input stub details')
    rr=gear(zr,mod,face,True);rr.translate(App.Vector(0,0,zpos));add(f'Stage{num}Ring',rr,'Case-hardening steel','Ring and housing concept, 140 mm OD')
    a=mod*(zsun+zp)/2
    for j in range(3):
        alpha=j*120
        pl=gear(zp,mod,face).cut(Part.makeCylinder(6,face))
        pl.rotate(App.Vector(),App.Vector(0,0,1),(1+zsun/zp)*alpha+180-180/zp)
        pl.translate(App.Vector(a*math.cos(math.radians(alpha)),a*math.sin(math.radians(alpha)),zpos))
        add(f'Stage{num}Planet{j+1}',pl,'Case-hardening steel','Nominal involute geometry; loaded mesh, backlash and phasing not certified')
for name,z in [('Carrier2Front',167),('Carrier2Rear',199)]:
    plate=ring(52,12,z,8)
    for j in range(3):
        a=2*math.pi*j/3;plate=plate.cut(Part.makeCylinder(6,8,App.Vector(31.5*math.cos(a),31.5*math.sin(a),z)))
    add(name,plate,'Steel','Matches carrier structural screening geometry; bearing fits omitted')
for j in range(3):
    a=2*math.pi*j/3;add('Carrier2Pin'+str(j+1),Part.makeCylinder(6,40,App.Vector(31.5*math.cos(a),31.5*math.sin(a),167)),'Steel','12 mm pin; 32 mm support-centre span')
add('OutputFlange',ring(52,12,207,12),'Steel','Mounting holes, bearing preload and seal interfaces remain open')
doc.recompute();doc.saveAs(str(out/'SpaceOctopusConcept.FCStd'))
Part.export(parts,str(out/'SpaceOctopusConcept.step'))
(out/'bom.json').write_text(json.dumps(bom,indent=2)+'\n')
(out/'cad_status.json').write_text(json.dumps(dict(engine='FreeCAD 1.0.0',objects=len(parts),all_individual_shapes_valid=all(p.Shape.isValid() for p in parts),step_bytes=(out/'SpaceOctopusConcept.step').stat().st_size,assembly_clearance_verified=False,status='concept, not for manufacture'),indent=2)+'\n')
print('CAD parts',len(parts),'All solids individually valid; concept envelope approximately 140 mm OD x 219 mm axial')
