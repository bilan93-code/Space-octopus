"""Verify the actual FEMM application and native handler, not just Wine's version."""
import sys,os,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from actuator.runtime import headless_environment
from pyleecan.Classes._FEMMHandler import _FEMMHandler
with headless_environment(ROOT/'.local/femm-smoke-display.log') as env:
    subprocess.run([str(ROOT/'.local/sysroot/usr/lib/wine/wineserver64'),'-k'],env=env)
    for key in ['PATH','DISPLAY','WINEPREFIX','LD_LIBRARY_PATH','XDG_RUNTIME_DIR']:os.environ[key]=env[key]
    h=_FEMMHandler();h.openfemm(1,winepath=str(ROOT/'.local/bin'),femmpath=str(ROOT/'.local/wineprefix/drive_c/femm42/bin'))
    try:
        h.newdocument(0);h.mi_probdef(0,'meters','planar',1e-8,.085,30)
        h.mi_addnode(0,0);h.mi_addnode(.01,0)
    finally:h.closefemm()
    p=ROOT/'results/extended/native_femm/wine_readiness.json';r=json.loads(p.read_text())
    r.update(FEMM_GUI_or_Lua_verified=True,FEMM_initial_model_commands_returned=True)
    p.write_text(json.dumps(r,indent=2)+'\n')
print('FEMM magnetic-model Lua commands and clean close verified')
