#!/usr/bin/env bash
set -euo pipefail
repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$repo_root"
# Use the existing isolated task checkout; do not create a Git worktree.
command -v uv >/dev/null
export UV_CACHE_DIR="$repo_root/.local/uv-cache"
uv python install 3.8.20
if [[ ! -x .venv/bin/python ]]; then
  uv venv --python 3.8.20 .venv
fi
uv pip sync --python .venv/bin/python requirements.lock
mkdir -p .local/pyleecan .local/swat-em .local/matplotlib
# These releases hard-code user paths. Preserve any pre-existing configuration.
# On a managed sandbox, this filesystem setup may need escalated execution.
user_dir="$(.venv/bin/python -c 'from pathlib import Path; print(Path.home())')"
for mapping in '.local/share/pyleecan:pyleecan' '.config/swat-em:swat-em'; do
  user_path="${mapping%%:*}"
  local_path="${mapping##*:}"
  if [[ ! -e "$user_dir/$user_path" && ! -L "$user_dir/$user_path" ]]; then
    mkdir -p "$(dirname "$user_dir/$user_path")"
    ln -s "$repo_root/.local/$local_path" "$user_dir/$user_path"
  fi
done
export MPLBACKEND=Agg QT_QPA_PLATFORM=offscreen MPLCONFIGDIR="$repo_root/.local/matplotlib"
.venv/bin/python -c 'import pyleecan, swat_em, gmsh, skfem; print("Analysis imports OK; Pyleecan", pyleecan.__version__)'
