"""Install verified solver packages in the task checkout, without root access."""
import hashlib,json,os,shutil,subprocess,urllib.request
from pathlib import Path
root=Path(__file__).resolve().parents[1];local=root/'.local'
manifest=json.loads((root/'docs/solver-packages.json').read_text())
for package in manifest['packages']:
    dest=local/'downloads'/package['file'];dest.parent.mkdir(parents=True,exist_ok=True)
    if not dest.exists() or hashlib.sha256(dest.read_bytes()).hexdigest()!=package['sha256']:
        with urllib.request.urlopen(package['url'],timeout=120) as r:dest.write_bytes(r.read())
    if hashlib.sha256(dest.read_bytes()).hexdigest()!=package['sha256']:raise RuntimeError('Checksum mismatch '+package['file'])
    subprocess.run(['dpkg-deb','-x',str(dest),str(local/'sysroot')],check=True)
bin=local/'bin';bin.mkdir(parents=True,exist_ok=True)
(bin/'ccx').write_text('''#!/usr/bin/env bash
root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export LD_LIBRARY_PATH="$root/sysroot/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
exec "$root/sysroot/usr/bin/ccx" "$@"
''')
(bin/'ccx').chmod(0o755)
# A Wine version string is not an application readiness check; verify an actual
# Windows command below, separately from the still-unverified FEMM application.
env=os.environ.copy();env['LD_LIBRARY_PATH']=str(local/'sysroot/usr/lib/x86_64-linux-gnu')+(':'+env['LD_LIBRARY_PATH'] if env.get('LD_LIBRARY_PATH') else '')
version=subprocess.run([str(bin/'ccx'),'-v'],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
# CalculiX 2.20's version-only path exits 201; real analysis jobs must exit 0.
if version.returncode not in [0,201] or 'Version 2.20' not in version.stdout:
    raise RuntimeError('CalculiX version check failed: '+version.stdout)
print(version.stdout.strip())
subprocess.run([str(root/'scripts/freecad_python.sh'),'-c',"import sys;sys.path.insert(0,'/usr/lib/freecad-python3/lib');import FreeCAD,Part;print('FreeCAD',FreeCAD.Version()[:3])"],check=True)
# Reproduce package-install links locally; original binaries remain unchanged.
server=local/'sysroot/usr/lib/wine/wineserver'
if server.exists() or server.is_symlink():server.unlink()
server.symlink_to('wineserver64')
alias=local/'sysroot/usr/share/wine/wine'
if not alias.exists() and not alias.is_symlink():alias.symlink_to('.',target_is_directory=True)
runtime=local/'runtime';runtime.mkdir(exist_ok=True);runtime.chmod(0o700)
(bin/'wine').write_text('''#!/usr/bin/env bash
root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export LD_LIBRARY_PATH="$root/sysroot/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export WINEDLLPATH="$root/sysroot/usr/lib/x86_64-linux-gnu/wine"
export WINESERVER="$root/sysroot/usr/lib/wine/wineserver64"
export WINEPREFIX="${WINEPREFIX:-$root/wineprefix}"
export WINEDEBUG="${WINEDEBUG:--all}"
export WINEDLLOVERRIDES="mscoree,mshtml="
export XDG_RUNTIME_DIR="$root/runtime"
exec "$root/sysroot/usr/lib/wine/wine64" "$@"
''')
(bin/'wine').chmod(0o755)
system32=local/'wineprefix/drive_c/windows/system32';system32.mkdir(parents=True,exist_ok=True)
source=local/'sysroot/usr/x86_64-w64-mingw32/lib/zlib1.dll'
target=system32/'zlib1.dll'
if target.is_symlink():target.unlink()
shutil.copyfile(source,target)
wine=subprocess.run([str(bin/'wine'),'cmd','/c','ver'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=45)
if wine.returncode or 'Microsoft Windows' not in wine.stdout:raise RuntimeError('Wine command initialization failed: '+wine.stdout)
print(wine.stdout.strip())
status=root/'results/extended/native_femm/wine_readiness.json';status.parent.mkdir(parents=True,exist_ok=True)
status.write_text(json.dumps(dict(wine_version='10.0',windows_command_verified=True,command_exit_code=wine.returncode,observed_output=wine.stdout.strip(),FEMM_GUI_or_Lua_verified=False,fix='Verified packaged zlib1.dll in prefix system32 and relocated Wine data layout'),indent=2)+'\n')
print('Local CalculiX, FreeCAD and Wine Windows command verified; FEMM application remains a separate gate.')
