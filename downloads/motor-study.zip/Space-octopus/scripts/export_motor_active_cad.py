"""Convert the current Pyleecan surface bridge into FreeCAD/STEP millimetres.

Run with bash scripts/freecad_python.sh scripts/export_motor_active_cad.py.
This exports the analyzed active geometry and a basic shaft, not a new assembly.
"""
import json,sys
from pathlib import Path
sys.path.insert(0,'/usr/lib/freecad-python3/lib')
import FreeCAD as App
import Part
ROOT=Path(__file__).resolve().parents[1];out=ROOT/'results/motor/cad'
components=out/'components';components.mkdir(exist_ok=True)
data=json.loads((out/'motor_surfaces.json').read_text());c=json.loads((ROOT/'configs/motor_candidate.json').read_text())
doc=App.newDocument('SpaceOctopusMotorActive');parts=[];bom=[]


def add(name,shape,material,role):
    if shape.isNull() or not shape.isValid() or len(shape.Solids)!=1:raise RuntimeError('Invalid motor CAD solid '+name)
    obj=doc.addObject('Part::Feature',name);obj.Shape=shape
    obj.addProperty('App::PropertyString','MaterialBasis');obj.MaterialBasis=material
    obj.addProperty('App::PropertyString','GeometryRole');obj.GeometryRole=role
    parts.append(obj);shape.exportStep(str(components/(name+'.step')))
    bom.append(dict(name=name,volume_mm3=shape.Volume,role=role,material=material,
        bounds_mm=dict(xmin=shape.BoundBox.XMin,xmax=shape.BoundBox.XMax,ymin=shape.BoundBox.YMin,ymax=shape.BoundBox.YMax,zmin=shape.BoundBox.ZMin,zmax=shape.BoundBox.ZMax)))


def loop(lines):
    edges=[]
    for line in lines:
        p=[App.Vector(x*1000,y*1000,0) for x,y in line['points']]
        if line['type']=='line':edges.append(Part.makeLine(p[0],p[-1]))
        else:edges.extend([Part.Arc(p[0],p[1],p[2]).toShape(),Part.Arc(p[2],p[3],p[4]).toShape()])
    return Part.Wire(edges)


for surface in data:
    face=Part.Face(loop(surface['loops'][0]))
    for hole in surface['loops'][1:]:face=face.cut(Part.Face(loop(hole)))
    shape=face.extrude(App.Vector(0,0,c['motor']['stack_m']*1000))
    add(surface['name'],shape,surface['material'],'Current active coil envelope' if 'Winding' in surface['name'] else 'Current active electromagnetic geometry')
shaft_length=json.loads((out/'current_machine.json').read_text())['shaft']['Lshaft']*1000;stack=c['motor']['stack_m']*1000
add('BasicShaftReference',Part.makeCylinder(c['motor']['shaft_radius_m']*1000,shaft_length,App.Vector(0,0,(stack-shaft_length)/2)),
    'Assumed steel','Basic 12 x 130 mm shaft envelope; centered display placement; no final shoulders/bearing fits')
doc.recompute();native=out/'SpaceOctopusMotorActive.FCStd';step=out/'SpaceOctopusMotorActive.step'
doc.saveAs(str(native));Part.export(parts,str(step))
# Import the neutral file again to check for lost solids or unit scaling.
restored=Part.read(str(step));volume=sum(v.Shape.Volume for v in parts)
if len(restored.Solids)!=len(parts):raise RuntimeError('STEP solid count changed on import')
relative=abs(restored.Volume/volume-1)
if relative>1e-6:raise RuntimeError('STEP volume/units changed on import')
(out/'active_cad_parts.json').write_text(json.dumps(bom,indent=2)+'\n')
(out/'active_cad_status.json').write_text(json.dumps(dict(status='completed',engine='FreeCAD '+'.'.join(App.Version()[:3]),
    source='configs/motor_candidate.json',objects=len(parts),all_individual_solids_valid=True,
    STEP_round_trip_solid_count=len(restored.Solids),STEP_relative_volume_error=relative,
    units='mm',complete_mechanical_assembly=False,
    note='Current active motor geometry and basic shaft only. Earlier full concept CAD and proposed assembly requirements are separate.'),indent=2)+'\n')
App.closeDocument(doc.Name)
print('Current motor-only CAD exported:',len(parts),'valid solids; STEP import and units verified.')
