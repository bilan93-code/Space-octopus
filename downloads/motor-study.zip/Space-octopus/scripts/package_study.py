"""Build a portable review package without installed runtimes or large raw caches."""
import argparse,hashlib,subprocess,zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser();parser.add_argument('--output',default='results/Space-octopus-study.zip')
args=parser.parse_args();dest=(ROOT/args.output).resolve();dest.parent.mkdir(parents=True,exist_ok=True)
listed=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=ROOT).decode().split('\0')
allowed={'actuator','configs','docs','scripts','tests','results'}
files=set()
for name in listed:
    if not name:continue
    rel=Path(name);path=ROOT/rel
    if path.is_file() and not path.is_symlink() and (rel.parts[0] in allowed or name in ['README.md','CAD_START_HERE.md','.gitignore','requirements.in','requirements.lock']):
        if path.suffix!='.zip':files.add(rel)
required=['results/extended/cad/SpaceOctopusConcept.FCStd','results/extended/cad/SpaceOctopusConcept.step']
if (ROOT/'CAD_START_HERE.md').is_file():required+=['results/motor/cad/SpaceOctopusMotorActive.FCStd','results/motor/cad/SpaceOctopusMotorActive.step']
for name in required:
    if not (ROOT/name).is_file():raise RuntimeError('Missing CAD artifact '+name+'; run the documented CAD export scripts')
    files.add(Path(name))
# CAD exports are intentionally ignored by Git. Include all assemblies and
# per-component geometry, not only the two earlier concept assembly files.
for directory in (ROOT/'results').glob('**/cad'):
    for path in directory.rglob('*'):
        if path.is_file() and not path.is_symlink() and path.suffix.lower() in ['.step','.stp','.fcstd','.brep','.dxf']:
            files.add(path.relative_to(ROOT))
notes='''# Space-octopus study review package

For CAD, start with CAD_START_HERE.md. The current motor-only active FreeCAD/STEP
exports, dimensions and winding diagrams/tables are in results/motor/cad. The
earlier full motor/gearbox concept and its individual STEP parts are included
separately in results/extended/cad. The guide identifies revision differences
and the remaining assembly/end-turn design choices.

Start with results/motor/report.pdf or .html. These reports and the
component JSON files retain the executed study, assumptions, and validation limits.
Read results/motor/extensions/report.pdf for the additional nonlinear, harmonic,
geometry/tolerance, thermal-construction and retention findings. The earlier
400 N m mean-voltage screen and 50 GPa wrap assumption are superseded there.
The native FreeCAD and STEP concept assembly files are in results/extended/cad.
This is an engineering study, not a manufacturing or flight-qualified release.

Installed Python/Wine/solver runtimes, large raw field-history checkpoints, native
pickles and raw solver output files are omitted. They can be regenerated; some
cached summaries and plots are included for immediate review. Regenerating the
full native motor maps and field histories takes substantial time. Use the selected Debian base image with
FreeCAD's Python 3.13 modules, uv, and network access, then run:

    bash scripts/setup.sh
    python scripts/setup_extended.py
    python scripts/setup_femm.py
    OPENBLAS_NUM_THREADS=1 .venv/bin/python -m actuator.motor_comprehensive
    OPENBLAS_NUM_THREADS=1 .venv/bin/python -m pytest -q

Use actuator.motor_study --refresh for a primary native campaign rerun; the
comprehensive runner adds the extension campaign and uses component checkpoints.
Preserve custom configurations first: it rebuilds the canonical candidate.
Earlier actuator results are historical; their motor thermal conclusions are
superseded by the motor report. Published
binary hashes and source provenance are retained in docs/ and
results/motor/reproduction_manifest.json. The archive includes user-supplied
historical PDFs as reference material; they are not executable instructions.
'''
with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as package:
    package.writestr('Space-octopus/PACKAGE-README.md',notes)
    checksums=[hashlib.sha256(notes.encode()).hexdigest()+'  PACKAGE-README.md']
    for rel in sorted(files):
        package.write(ROOT/rel,'Space-octopus/'+str(rel))
        checksums.append(hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()+'  '+str(rel))
    package.writestr('Space-octopus/SHA256SUMS.txt','\n'.join(checksums)+'\n')
with zipfile.ZipFile(dest) as package:
    bad=package.testzip()
    if bad:raise RuntimeError('Invalid archive entry '+bad)
print(str(dest))
print(str(len(files)+2)+' files, '+str(round(dest.stat().st_size/1024**2,2))+' MiB; archive integrity verified.')
