"""Install the official byte-verified FEMM release using an accessible cache.

The cache is not trusted independently: the installer must match the SHA-256
published by the FEMM project's SourceForge release metadata. No proxy bypass,
verification disabling or changes to the installed solver code are used.
"""
import sys,hashlib,json,os,shutil,subprocess,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from actuator.runtime import headless_environment
local=ROOT/'.local';spec=json.loads((ROOT/'docs/femm-distribution.json').read_text())
installer=local/'downloads/femm42-cached.exe';installer.parent.mkdir(parents=True,exist_ok=True)
if not installer.exists() or hashlib.sha256(installer.read_bytes()).hexdigest()!=spec['upstream_installer_sha256']:
    with urllib.request.urlopen(spec['cache_url'],timeout=90) as source:installer.write_bytes(source.read())
if hashlib.sha256(installer.read_bytes()).hexdigest()!=spec['upstream_installer_sha256']:raise RuntimeError('FEMM checksum mismatch; artifact must not be used')
env=os.environ.copy();env['LD_LIBRARY_PATH']=str(local/'sysroot/usr/lib/x86_64-linux-gnu')+(':'+env['LD_LIBRARY_PATH'] if env.get('LD_LIBRARY_PATH') else '')
subprocess.run([str(local/'sysroot/usr/bin/innoextract'),'-d',str(local/'femm-payload'),str(installer)],env=env,check=True,stdout=subprocess.DEVNULL)
# Pyleecan 1.5.2 uses a Windows separator in its Lua resource path on Linux.
# An additive filesystem alias preserves all upstream implementation files.
compat=ROOT/'.venv/lib/python3.8/site-packages/pyleecan/Functions'/('FEMM'+chr(92))
if not compat.exists():compat.symlink_to('FEMM',target_is_directory=True)
exe=local/'wineprefix/drive_c/femm42'
shutil.copytree(local/'femm-payload/app',exe,dirs_exist_ok=True)
seven=local/'sysroot/usr/lib/7zip/7z'
subprocess.run([str(seven),'x','-y','-o'+str(local/'vcredist'),str(local/'femm-payload/tmp/vcredist_x64.exe')],env=env,check=True,stdout=subprocess.DEVNULL)
# The native Pyleecan handler discovers ~/.wine. Preserve any existing profile.
user_wine=Path.home()/'.wine'
if not user_wine.exists() and not user_wine.is_symlink():user_wine.symlink_to(local/'wineprefix',target_is_directory=True)
if user_wine.resolve()!=(local/'wineprefix').resolve():raise RuntimeError('Existing user Wine profile is preserved; configure its FEMM path before running the native adapter')
with headless_environment(local/'setup-femm-display.log') as wine_env:
    subprocess.run([str(local/'sysroot/usr/lib/wine/wineserver64'),'-k'],env=wine_env)
    msi='Z:'+str(local/'vcredist/vc_red.msi').replace('/',chr(92))
    proc=subprocess.run([str(local/'bin/wine'),'msiexec','/i',msi,'/qn','/norestart'],env=wine_env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=90)
    if proc.returncode:raise RuntimeError('Bundled x64 MSVC runtime install failed: '+proc.stdout)
subprocess.run([str(ROOT/'.venv/bin/python'),str(ROOT/'scripts/femm_smoke.py')],cwd=ROOT,check=True,timeout=60)
print('Official FEMM installer hash verified; application/Lua file link verified.')
