"""Record current executed-study provenance and verify installed upstream files."""
import base64,hashlib,json,re,subprocess
from datetime import datetime,timezone
from importlib import metadata
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def record():
    verification_log=(ROOT/'results/motor/verification.txt').read_text()
    match=re.search(r'(\d+) passed',verification_log)
    if match is None or re.search(r'\d+ failed',verification_log):
        raise RuntimeError('A successful recorded test run is required before recording provenance')
    tests_passed=int(match.group(1))
    integrity={}
    for name in ['pyleecan','pyfemm']:
        dist=metadata.distribution(name);count=0;mismatch=[]
        for file in dist.files:
            if file.suffix!='.py' or file.hash is None:continue
            count+=1;path=Path(dist.locate_file(file))
            actual=base64.urlsafe_b64encode(hashlib.new(file.hash.mode,path.read_bytes()).digest()).decode().rstrip('=')
            if actual!=file.hash.value:mismatch.append(str(file))
        integrity[name]=dict(version=dist.version,python_files_compared_to_distribution_RECORD=count,
            mismatches=mismatch,all_recorded_Python_implementation_files_unchanged=not mismatch)
        if mismatch or not count:raise RuntimeError('Installed source verification failed: '+name)
    (ROOT/'results/motor/upstream_integrity.json').write_text(json.dumps(integrity,indent=2)+'\n')
    # Preserve the former record's shape; the same distribution files remain unchanged.
    (ROOT/'results/extended/upstream_integrity.json').write_text(json.dumps(integrity,indent=2)+'\n')
    sources=[ROOT/name for name in ['README.md','.gitignore','requirements.in','requirements.lock','CAD_START_HERE.md'] if (ROOT/name).exists()]
    for directory in ['actuator','scripts','tests','configs','docs']:
        sources.extend(p for p in (ROOT/directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix in ['.py','.sh','.md','.json','.pdf'])
    source_hashes={str(p.relative_to(ROOT)):sha(p) for p in sorted(set(sources))}
    artifacts=[]
    for directory in ['results/motor','results/extended','results/baseline']:
        artifacts.extend(p for p in (ROOT/directory).rglob('*') if p.is_file()
            and 'Femm' not in p.parts and p.name!='reproduction_manifest.json'
            and p.suffix in ['.json','.pdf','.md','.html','.png','.svg','.csv','.npz','.FCStd','.step']
            and p.name!='history_checkpoint.npz')
    manifest=dict(recorded_utc=datetime.now(timezone.utc).isoformat(),
        local_HEAD=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        working_tree_changes_included=True,source_sha256=source_hashes,
        artifact_sha256={str(p.relative_to(ROOT)):sha(p) for p in sorted(set(artifacts))},
        verification=dict(tests_passed=tests_passed,test_command='OPENBLAS_NUM_THREADS=1 .venv/bin/python -m pytest -q',
            result_log='results/motor/verification.txt',native_map_points=27,
            native_reference_full_mechanical_samples=[144,288],native_spatial_refinement_factor=1.5,
            all_recorded_Pyleecan_Python_sources_unchanged=True,
            physical_validation_performed=False,construction_release=False,
            full_operating_domain_loss_convergence_established=False,fresh_environment_restoration_verified=False),
        report_sha256=sha(ROOT/'results/motor/report.pdf'))
    extension=ROOT/'results/motor/extensions/assessment.json'
    if extension.exists():
        a=json.loads(extension.read_text())
        manifest['verification']['additional_motor_campaign']=dict(
            normal_map_independent_holdouts=len(a['normal_map_holdouts']),
            nonlinear_fault_independent_holdouts=len(a['fault_map_holdouts']),
            hot_tolerance_cases=len(a['tolerances']),
            full_period_peak_loss_positions=[144,288],native_FE_geometry_grid=9,
            static_eccentricity_mesh_and_offset_cases=6,FEMM_AC_wire_cases=16,
            FEMM_incremental_AC_response_rows=8,thermal_material_and_liner_scenarios=len(a['thermal_material_scenarios']),
            optional_peak_perturbation_screen_pass=a['gates']['optional_peak_tolerance_robust'])
        manifest['extension_report_sha256']=sha(ROOT/'results/motor/extensions/report.pdf')
    cad=ROOT/'results/motor/cad/active_cad_status.json'
    if cad.exists():
        status=json.loads(cad.read_text())
        manifest['verification']['current_CAD_export']=dict(objects=status['objects'],
            individual_shapes_valid=status['all_individual_solids_valid'],
            STEP_round_trip_solid_count=status['STEP_round_trip_solid_count'],
            STEP_relative_volume_error=status['STEP_relative_volume_error'],complete_mechanical_assembly=False)
    (ROOT/'results/motor/reproduction_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    oldpath=ROOT/'results/extended/reproduction_manifest.json'
    if oldpath.exists():
        old=json.loads(oldpath.read_text());old.update(recorded_utc=manifest['recorded_utc'],source_sha256=source_hashes)
        old['artifact_sha256']={name:sha(ROOT/name) for name in old['artifact_sha256'] if (ROOT/name).exists()}
        old['report_sha256']=sha(ROOT/'results/extended/extended_report.pdf')
        old['verification']['tests_passed']=tests_passed
        old['motor_rating_superseded_by']='results/motor/report.pdf'
        oldpath.write_text(json.dumps(old,indent=2)+'\n')
    print('Verified upstream source integrity:',{k:v['python_files_compared_to_distribution_RECORD'] for k,v in integrity.items()})
    print('Recorded',len(source_hashes),'source and',len(manifest['artifact_sha256']),'artifact hashes.')


if __name__=='__main__':record()
