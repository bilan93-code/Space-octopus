"""Export existing model data for CAD use, without rerunning design simulations."""
import csv,json,sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from actuator.machine import build_machine,winding_summary
from actuator.extended import export_motor_surfaces
from actuator.run import dump
from pyleecan.Functions.labels import decode_label


def main():
    out=ROOT/'results/motor/cad';out.mkdir(parents=True,exist_ok=True)
    c=json.loads((ROOT/'configs/motor_candidate.json').read_text());m=build_machine(c);w=m.stator.winding
    matrix=w.get_connection_mat(m.stator.slot.Zs)
    reference=json.loads((ROOT/'results/motor/candidate/summary.json').read_text())['winding']['connection_matrix']
    if not np.array_equal(matrix,np.asarray(reference)):raise RuntimeError('Exported winding differs from analyzed candidate')
    export_motor_surfaces(c,out)
    m.save(str(out/'current_machine.json'));dump(out/'winding_definition.json',winding_summary(m))
    w.export_to_csv(file_path=str(out/'winding_native_0based.csv'),is_skip_empty=True)
    w.plot_linear(is_max_sym=False,is_show_fig=False,save_path=str(out/'winding_linear.png'))
    w.plot_linear(is_max_sym=False,is_show_fig=False,save_path=str(out/'winding_linear.svg'))
    m.stator.plot_winding(all_slot=True,is_show_fig=False,save_path=str(out/'winding_slot_layers.png'))
    m.plot(is_show_fig=False,save_path=str(out/'current_cross_section.png'))
    m.plot(is_show_fig=False,save_path=str(out/'current_cross_section.svg'))
    regions={}
    for surf in m.stator.build_geometry():
        if '_Winding' in surf.label:
            d=decode_label(surf.label);regions[d['R_id'],d['T_id'],d['S_id']]=(surf.label,surf.point_ref)
    with (out/'winding_sides_and_coordinates_mm.csv').open('w',newline='') as stream:
        writer=csv.writer(stream);writer.writerow(['native_slot_index_0based','human_slot_number_1based','radial_layer_index_0based','tangential_layer_index_0based','phase','signed_turns','region_label','reference_x_mm','reference_y_mm'])
        for r,t,s,p in np.argwhere(matrix!=0):
            name,z=regions[int(r),int(t),int(s)]
            writer.writerow([int(s),int(s)+1,int(r),int(t),'ABC'[p],int(matrix[r,t,s,p]),name,float(z.real*1000),float(z.imag*1000)])
    dimensions=[]
    def item(name,value,unit,basis):dimensions.append(dict(parameter=name,value=value,unit=unit,basis=basis))
    v=c['motor']
    for name,value in [('stator_outer_diameter',2*v['stator_outer_radius_m']),('stator_bore_diameter',2*v['stator_bore_radius_m']),
        ('rotor_iron_outer_diameter',2*v['rotor_iron_radius_m']),('bare_magnet_outer_diameter',2*(v['rotor_iron_radius_m']+v['magnet_thickness_m'])),
        ('active_stack_length',v['stack_m']),('shaft_diameter',2*v['shaft_radius_m']),('basic_shaft_length',m.shaft.Lshaft),
        ('magnet_radial_thickness',v['magnet_thickness_m']),('bare_radial_airgap',m.comp_width_airgap_mec()),
        ('bare_wire_diameter',v['wire_diameter_m']),('assumed_wire_enamel_radial_thickness',w.conductor.Wins_wire),
        ('half_turn_end_length_allowance',v['half_turn_end_length_m'])]:item(name,float(value*1000),'mm','Current Pyleecan model; end length is an electrical allowance, not a routed coil drawing')
    item('slots',v['slots'],'count','Current model');item('poles',2*v['pole_pairs'],'count','Current model')
    item('turns_per_coil',v['turns_per_coil'],'turns','Current model');item('strands_in_hand',v['strands'],'count','Current model')
    item('magnet_arc_fraction',v['magnet_arc_fraction'],'fraction of pole pitch','Current model')
    item('magnet_arc_angle',v['magnet_arc_fraction']*180/v['pole_pairs'],'deg','Current model')
    for name,value in v['slot'].items():item('SlotW10_'+name,value*1000,'mm','Native Pyleecan slot parameter; use the shape export rather than interpreting it as a drawing ordinate')
    req=json.loads((ROOT/'results/motor/build_requirements.json').read_text())
    for name,value in [('proposed_wrap_thickness',req['retaining_wrap']['thickness_mm']),('proposed_magnet_bond_thickness',req['compliant_magnet_bond']['bond_mm']),
        ('proposed_housing_wall',req['cooling_requirement']['housing_wall_mm']),('proposed_housing_outer_diameter',96+2*req['cooling_requirement']['housing_wall_mm']),
        ('assumed_bearing_center_span',113),('bearing_bore',12),('bearing_outer_diameter',32),('bearing_width',10)]:item(name,value,'mm','Proposed mechanical requirement/envelope, not included as a final assembly feature in current active CAD')
    with (out/'motor_dimensions_mm.csv').open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=['parameter','value','unit','basis']);writer.writeheader();writer.writerows(dimensions)
    dump(out/'export_metadata.json',dict(status='completed',source='configs/motor_candidate.json',
        winding_matches_analyzed_candidate=True,winding_connection='star / Y',matrix_shape=list(matrix.shape),
        native_surface_geometry_units='m',CAD_export_units='mm',active_z_range_mm=[0,85],
        intended_outputs=['motor-only active FreeCAD/STEP','per-component STEP','native winding CSV and diagrams','dimensions table'],
        notes=['Coil solids are active winding envelopes, not individual conductor routes',
            'The 130 mm basic shaft display placement is centered on the active stack; bearing/shoulder locations are not finalized',
            'Earlier full concept CAD uses a different axial datum and 137 mm shaft; see CAD_START_HERE.md']))
    print('Current geometry, dimensions and winding exports prepared:',out)


if __name__=='__main__':main()
