#!/usr/bin/env bash
set -euo pipefail
exec env -u PYTHONHOME -u PYTHONPATH /usr/bin/python3 "$@"
