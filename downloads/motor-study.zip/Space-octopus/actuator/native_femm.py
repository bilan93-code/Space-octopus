"""Official Pyleecan MagFEMM -> ForceMT/Loss pipeline under verified Wine."""
import os,json,subprocess,pickle
from pathlib import Path
import numpy as np
from .machine import build_machine
from .run import dump
from .runtime import headless_environment
from .femm_transport import reliable_femm_transport
from pyleecan.Classes.Simu1 import Simu1
from pyleecan.Classes.InputCurrent import InputCurrent
from pyleecan.Classes.OPdq import OPdq
from pyleecan.Classes.MagFEMM import MagFEMM
from pyleecan.Classes.ForceMT import ForceMT
from pyleecan.Classes.Output import Output
from pyleecan.Classes.Loss import Loss
from pyleecan.Classes.LossModelBertotti import LossModelBertotti
from pyleecan.Classes.LossModelJoule import LossModelJoule
from pyleecan.Classes.LossModelMagnet import LossModelMagnet
from pyleecan.Classes.LossModelProximity import LossModelProximity
ROOT=Path(__file__).resolve().parents[1]


def magnetic_module(gap_mesh=.000125,magnet_C=80,kmesh=1,time_periodicity=True):
    return MagFEMM(nb_worker=1,Kmesh_fineness=kmesh,is_periodicity_a=True,is_periodicity_t=time_periodicity,is_get_meshsolution=True,type_BH_stator=0,type_BH_rotor=0,T_mag=magnet_C,is_close_femm=True,is_calc_torque_energy=True,FEMM_dict_enforced={"mesh":{"meshsize_airgap":gap_mesh,"elementsize_airgap":gap_mesh}})


def native_loss(winding_C=100,magnet_C=80):
    kh=1.8/(50*1.5**2);ke=1.05/(50*1.5)**2;kex=.15/(50*1.5)**1.5
    return Loss(Tsta=winding_C,Trot=magnet_C,is_get_meshsolution=True,model_dict={
        'stator_bertotti':LossModelBertotti(group='stator core',k_hy=kh,k_ed=ke,k_ex=kex),
        'rotor_bertotti':LossModelBertotti(group='rotor core',k_hy=kh,k_ed=ke,k_ex=kex),
        'copper':LossModelJoule(group='stator winding',type_skin_effect=1),
        'proximity':LossModelProximity(group='stator winding'),
        'magnets':LossModelMagnet(group='rotor magnets')})


def run_native_femm(config,out,nt=120,gap_mesh=.000125,Id=0.,Iq=9.,rpm=630.,magnet_C=80.,winding_C=100.,kmesh=1,time_periodicity=True,na=256,full_fields=True):
    femm=ROOT/'.local/wineprefix/drive_c/femm42/bin/femm.exe';out.mkdir(parents=True,exist_ok=True)
    if not femm.is_file():
        dump(out/'status.json',dict(status='blocked',native_MagFEMM_executed=False,reason='Verified FEMM payload is not installed. Run scripts/setup_femm.py.',published_sha256='17384e8990b6305ec8ffef1f75b6ef091a266b6e49b30c151cd1daca2e952043'))
        return None
    m=build_machine(config)
    dump(out/'input_config.json',config)
    magnetic=magnetic_module(gap_mesh,magnet_C,kmesh,time_periodicity)
    magnetic.is_get_meshsolution=full_fields
    if config['motor'].get('step_skew_degrees'):magnetic.Nslices_enforced=2
    simu=Simu1(name='SpaceOctopus_official_MagFEMM',machine=m,elec=None,struct=None,loss=native_loss(winding_C,magnet_C) if full_fields else None,force=ForceMT() if full_fields else None,input=InputCurrent(OP=OPdq(N0=rpm,Id_ref=Id,Iq_ref=Iq),Nt_tot=int(nt),Na_tot=int(na),Nrev=1),mag=magnetic)
    output=Output(simu=simu,path_result=str(out.resolve()))
    dump(out/'status.json',dict(status='running',native_MagFEMM_executed=False,requested_time_steps=nt))
    with headless_environment(out/'display.log') as env, reliable_femm_transport() as transport:
        keys=['PATH','DISPLAY','WINEPREFIX','LD_LIBRARY_PATH','XDG_RUNTIME_DIR'];before={k:os.environ.get(k) for k in keys}
        try:
            # Clear only this project's Wine prefix to avoid an old X display.
            subprocess.run([str(ROOT/'.local/sysroot/usr/lib/wine/wineserver64'),'-k'],env=env)
            for k in keys:os.environ[k]=env[k]
            try:result=simu.run()
            except Exception as exc:
                dump(out/'status.json',dict(status='failed',native_MagFEMM_executed=False,reason=repr(exc),requested_time_steps=nt))
                raise
        finally:
            for k,v in before.items():
                if v is None:os.environ.pop(k,None)
                else:os.environ[k]=v
    with (out/'native_output.pkl').open('wb') as checkpoint:pickle.dump(result,checkpoint,protocol=4)
    torque=np.asarray(result.mag.Tem.values).ravel()
    if len(torque)==0 or not np.all(np.isfinite(torque)):raise RuntimeError('MagFEMM returned invalid torque')
    fields=result.mag.B.get_rphiz_along('time','angle','z=mean')
    np.savez_compressed(out/'native_fields.npz',torque_Nm=torque,Br_T=fields['radial'],Bt_T=fields['tangential'])
    losses={k:float(v.get_loss_scalar(config['motor']['pole_pairs']*rpm/60)) for k,v in result.loss.loss_dict.items()} if result.loss is not None else {}
    from pyleecan.Classes.LUTdq import LUTdq
    flux=LUTdq(simu=result.simu.copy(),output_list=[result]).get_Phi_dqh_mean()[0]
    summary=dict(status='completed',engine='Official Pyleecan 1.5.2 MagFEMM + FEMM 4.2 (21Apr2019), Wine 10',native_MagFEMM_executed=True,torque_Nm=float(result.mag.Tem_av),torque_min_Nm=float(torque.min()),torque_max_Nm=float(torque.max()),solved_time_steps=len(torque),requested_time_steps=nt,angular_samples=na,time_periodicity=time_periodicity,full_fields=full_fields,Phid_rms_Wb=float(flux[0]),Phiq_rms_Wb=float(flux[1]),gap_mesh_m=gap_mesh,Kmesh_fineness=kmesh,loss_W=losses,operating=dict(motor_rpm=rpm,Id_rms_A=Id,Iq_rms_A=Iq,magnet_C=magnet_C,winding_loss_C=winding_C),coefficient_provenance='Same uncalibrated 3 W/kg reference split as the custom-field history',limitations=['A single-point mesh/time check does not establish a converged full harmonic-loss map','Material, conductivity and end effects are still assumptions','No hardware correlation or complete product qualification implied'])
    dump(out/'status.json',summary)
    summary['rotor_loss_period_compatible']=bool(full_fields and not time_periodicity)
    if full_fields:
        ms=result.mag.meshsolution
        bx=ms.solution_dict['B'].field.components['comp_x'].values
        by=ms.solution_dict['B'].field.components['comp_y'].values
        field_stats={}
        for group in ['stator core','rotor core','rotor magnets']:
            b=np.hypot(bx[:,ms.group[group]],by[:,ms.group[group]])
            field_stats[group]=dict(B_max_T=float(b.max()),B_percentile99_T=float(np.quantile(b,.99)),fraction_samples_above_1p8T=float(np.mean(b>1.8)))
        summary['material_field_statistics']=field_stats
    dump(out/'status.json',summary)
    dump(out/'transport.json',transport)
    return result


if __name__=='__main__':
    run_native_femm(json.loads((ROOT/'configs/baseline.json').read_text()),ROOT/'results/extended/native_femm')
