"""Official Electrical/EEC_PMSM -> MagFEMM flux-linkage coupling."""
import json,os,subprocess,pickle
from pathlib import Path
import numpy as np
from pyleecan.Classes.EEC_PMSM import EEC_PMSM
from pyleecan.Classes.Electrical import Electrical
from pyleecan.Classes.Simu1 import Simu1
from pyleecan.Classes.InputCurrent import InputCurrent
from pyleecan.Classes.OPdq import OPdq
from pyleecan.Classes.Output import Output
from .machine import build_machine
from .runtime import ROOT,headless_environment
from .native_femm import magnetic_module
from .femm_transport import reliable_femm_transport
from .run import dump


def run_native_electrical(config,redesign,out):
    out.mkdir(parents=True,exist_ok=True)
    mag=magnetic_module();mag.is_get_meshsolution=False;mag.is_calc_torque_energy=False
    op=OPdq(Id_ref=0.,Iq_ref=float(redesign['continuous']['electrical']['Iq_rms_A']),N0=630.,felec=52.5)
    elec=Electrical(Tsta=100,Trot=80,eec=EEC_PMSM(fluxlink=mag,type_skin_effect=0))
    simu=Simu1(name='SpaceOctopus_native_EEC_FEMM',machine=build_machine(config),input=InputCurrent(OP=op,Nt_tot=40,Na_tot=128,Nrev=1),elec=elec,mag=None,force=None,struct=None,loss=None)
    output=Output(simu=simu,path_result=str(out.resolve()))
    dump(out/'status.json',dict(status='running',native_Electrical_MagFEMM_executed=False))
    with headless_environment(out/'display.log') as env, reliable_femm_transport() as transport:
        keys=['PATH','DISPLAY','WINEPREFIX','LD_LIBRARY_PATH','XDG_RUNTIME_DIR'];before={k:os.environ.get(k) for k in keys}
        try:
            subprocess.run([str(ROOT/'.local/sysroot/usr/lib/wine/wineserver64'),'-k'],env=env)
            for k in keys:os.environ[k]=env[k]
            result=simu.run()
        finally:
            for k,v in before.items():
                if v is None:os.environ.pop(k,None)
                else:os.environ[k]=v
    # Retain the actual native output before any report/export work. This is a
    # local artifact created by this trusted run, never a downloaded pickle.
    with (out/'native_output.pkl').open('wb') as checkpoint:pickle.dump(result,checkpoint,protocol=4)
    e=result.elec.eec
    # Electrical.run stores both currents and calculated voltage references in OP.
    # Calling solve() again would select voltage-driven mode and require Ld,
    # which the native secant method intentionally leaves None at Id=0.
    values=dict(e.OP.get_Ud_Uq(),**e.OP.get_Id_Iq());ts,tr=e.comp_torque_sync_rel()
    phase_peak=float(np.sqrt(2)*np.hypot(values['Ud'],values['Uq']))
    summary=dict(status='completed',native_Electrical_MagFEMM_executed=True,engine='Official Pyleecan Electrical(EEC_PMSM(fluxlink=MagFEMM))',machine_config='configs/revised.json',Id_rms_A=0.,Iq_rms_A=op.Iq_ref,motor_rpm=630,winding_C=100,magnet_C=80,PM_flux_rms_Wb=e.Phid_mag,Phid_rms_Wb=e.Phid,Phiq_rms_Wb=e.Phiq,Ld_H=e.Ld,Lq_H=e.Lq,resistance_ohm=e.R1,phase_voltage_peak_V=phase_peak,synchronous_torque_Nm=float(ts),reluctance_torque_Nm=float(tr),total_torque_Nm=float(ts+tr),copper_loss_W=float(e.comp_joule_losses(values,simu.machine)['Pj_losses']),voltage_ok_at_min_bus=bool(phase_peak<=config['drive']['bus_min_V']*config['drive']['modulation_margin']/np.sqrt(3)),limitations=['Coarse time discretization for native coupling verification, not a converged full flux map','Ld is undefined by the native secant method at Id=0 and is reported as null','Hot winding/magnet comparison point differs from the nominal lumped equilibrium','Generic materials and no hardware correlation'])
    if not np.isfinite(summary['total_torque_Nm']) or abs(summary['total_torque_Nm'])<.1:raise RuntimeError('Invalid native EEC torque')
    dump(out/'status.json',summary);dump(out/'transport.json',transport);return result


if __name__=='__main__':
    run_native_electrical(json.loads((ROOT/'configs/revised.json').read_text()),json.loads((ROOT/'results/extended/redesign/redesign_summary.json').read_text()),ROOT/'results/extended/native_electrical')
