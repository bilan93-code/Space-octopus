"""Official VarLoadCurrent -> MagFEMM -> LUTdq rotor-averaged motor maps."""
import json,os,subprocess
import cloudpickle as pickle
from functools import partial
from pathlib import Path
import numpy as np
from pyleecan.Classes.Simu1 import Simu1
from pyleecan.Classes.InputCurrent import InputCurrent
from pyleecan.Classes.OPdq import OPdq
from pyleecan.Classes.VarLoadCurrent import VarLoadCurrent
from pyleecan.Classes.XOutput import XOutput
from pyleecan.Classes.LUTdq import LUTdq
from pyleecan.Classes.PostFunction import PostFunction
from pyleecan.Classes.Electrical import Electrical
from pyleecan.Classes.EEC_PMSM import EEC_PMSM
from .machine import build_machine
from .native_femm import magnetic_module
from .runtime import headless_environment,ROOT
from .femm_transport import reliable_femm_transport
from .run import dump


def checkpoint_point(output,folder):
    point=output.simu.input.OP
    label='point_'+str(point.Id_ref)+'_'+str(point.Iq_ref)
    path=Path(folder)/(label+'.pkl');temporary=path.with_suffix('.tmp')
    with temporary.open('wb') as f:pickle.dump(output,f,protocol=4)
    temporary.replace(path)
    phi=LUTdq(simu=output.simu.copy(),output_list=[output]).get_Phi_dqh_mean()[0]
    dump(path.with_suffix('.json'),dict(Id_rms_A=point.Id_ref,Iq_rms_A=point.Iq_ref,magnet_C=output.simu.mag.T_mag,
        Phid_rms_Wb=float(phi[0]),Phiq_rms_Wb=float(phi[1]),FE_mean_torque_Nm=float(output.mag.Tem_av)))


def export_points(c,folder,temp,points,cached,transport):
    outputs=[cached[(float(p[1]),float(p[2]))] for p in points]
    flux=np.array([LUTdq(simu=r.simu.copy(),output_list=[r]).get_Phi_dqh_mean()[0] for r in outputs])
    fullvar=VarLoadCurrent();fullvar.set_OP_array(points,'N0','Id','Iq',is_update_input=False)
    zero=next(phi for p,phi in zip(points,flux) if p[1]==p[2]==0)
    stub=Simu1(machine=build_machine(c),var_simu=fullvar,elec=Electrical(eec=EEC_PMSM(Phid_mag=float(zero[0]),Phiq_mag=float(zero[1]))),mag=None,force=None,struct=None)
    lut=LUTdq(simu=stub,Phi_dqh_mean=flux);lut.save(str(folder/'native_LUTdq.json'))
    rows=[]
    for point,phi,r in zip(points,flux,outputs):
        rows.append(dict(magnet_C=temp,Id_rms_A=float(point[1]),Iq_rms_A=float(point[2]),Phid_rms_Wb=float(phi[0]),Phiq_rms_Wb=float(phi[1]),
            FE_mean_torque_Nm=float(r.mag.Tem_av),dq_torque_Nm=float(15*(phi[0]*point[2]-phi[1]*point[1])),
            torque_min_Nm=float(np.min(r.mag.Tem.values)),torque_max_Nm=float(np.max(r.mag.Tem.values)),
            solved_time_steps=len(r.mag.Tem.values),within_22Arms=bool(np.hypot(point[1],point[2])<=22)))
    error=max(np.max(np.abs(lut.interp_Phi_dqh(float(p[1]),float(p[2]))[:2,0]-phi[:2])) for p,phi in zip(points,flux))
    dump(folder/'summary.json',dict(status='completed',engine='Official VarLoadCurrent -> MagFEMM -> LUTdq',magnet_C=temp,rows=rows,transport=transport,grid_reconstruction_error_Wb=float(error)))
    return rows


def run():
    out=ROOT/'results/motor/maps';out.mkdir(parents=True,exist_ok=True)
    c=json.loads((ROOT/'configs/revised.json').read_text());all_rows=[]
    for temp in [20,80,150]:
        folder=out/(str(temp)+'C');status=folder/'summary.json'
        if status.exists() and json.loads(status.read_text()).get('status')=='completed':
            all_rows+=json.loads(status.read_text())['rows'];continue
        folder.mkdir(parents=True,exist_ok=True)
        full_points=np.array([[630,id,iq] for id in [-12.,-6.,0.] for iq in [0.,10.814,22.]])
        cached={}
        for path in folder.glob('point_*.pkl'):
            with path.open('rb') as f:point_output=pickle.load(f)
            op=point_output.simu.input.OP;key=(float(op.Id_ref),float(op.Iq_ref))
            if key==(0.,0.) and abs(point_output.mag.Tem_av)>.02:
                rejected=folder/'rejected_no_load';rejected.mkdir(exist_ok=True)
                path.replace(rejected/path.name)
                if path.with_suffix('.json').exists():path.with_suffix('.json').replace(rejected/path.with_suffix('.json').name)
                dump(rejected/'reason.json',dict(reason='Reused FEMM model retained nonzero circuit currents when zero-current input was represented by None',rejected_torque_Nm=point_output.mag.Tem_av))
                continue
            cached[key]=point_output
        points=np.array([p for p in full_points if (float(p[1]),float(p[2])) not in cached])
        # A fresh zero-current reference prevents stale source currents in the
        # official reused-file path, whose Is=None case does not reset circuits.
        points=np.array(sorted(points.tolist(),key=lambda p:(not(p[1]==p[2]==0),p[1],p[2]))) if len(points) else points
        if not len(points):
            all_rows+=export_points(c,folder,temp,full_points,cached,dict(recovered_from_native_point_checkpoints=True))
            continue
        var=VarLoadCurrent(is_keep_all_output=True,stop_if_error=True,is_reuse_femm_file=True,is_reuse_LUT=False,
            post_keeper_postproc_list=[PostFunction(run=partial(checkpoint_point,folder=str(folder)))])
        var.set_OP_array(points,'N0','Id','Iq',is_update_input=False)
        mag=magnetic_module(magnet_C=temp);mag.is_get_meshsolution=False
        s=Simu1(name='MotorNativeMap_'+str(temp)+'C',machine=build_machine(c),
            input=InputCurrent(OP=OPdq(Id_ref=0.,Iq_ref=0.,N0=630.),Nt_tot=240,Na_tot=32,Nrev=1),
            elec=None,mag=mag,force=None,loss=None,struct=None,var_simu=var)
        output=XOutput(simu=s,path_result=str(folder.resolve()))
        with headless_environment(folder/'display.log') as env,reliable_femm_transport() as transport:
            keys=['PATH','DISPLAY','WINEPREFIX','LD_LIBRARY_PATH','XDG_RUNTIME_DIR'];before={k:os.environ.get(k) for k in keys}
            try:
                subprocess.run([str(ROOT/'.local/sysroot/usr/lib/wine/wineserver64'),'-k'],env=env)
                for k in keys:os.environ[k]=env[k]
                result=s.run()
            finally:
                for k,v in before.items():
                    if v is None:os.environ.pop(k,None)
                    else:os.environ[k]=v
        with (folder/'native_batch.tmp').open('wb') as f:pickle.dump(result,f,protocol=4)
        (folder/'native_batch.tmp').replace(folder/'native_batch.pkl')
        for point_output in result.output_list:
            op=point_output.simu.input.OP;cached[(float(op.Id_ref),float(op.Iq_ref))]=point_output
        # Merge previously completed native points; serialize a data-only native
        # LUT, without the batch's executable checkpoint callback objects.
        outputs=[cached[(float(p[1]),float(p[2]))] for p in full_points]
        flux=LUTdq(simu=result.simu.copy(),output_list=outputs).get_Phi_dqh_mean()
        fullvar=VarLoadCurrent();fullvar.set_OP_array(full_points,'N0','Id','Iq',is_update_input=False)
        zero=next(phi for point,phi in zip(full_points,flux) if point[1]==point[2]==0)
        stub=Simu1(machine=build_machine(c),var_simu=fullvar,elec=Electrical(eec=EEC_PMSM(Phid_mag=float(zero[0]),Phiq_mag=float(zero[1]))),mag=None,force=None,struct=None)
        lut=LUTdq(simu=stub,Phi_dqh_mean=flux);lut.save(str(folder/'native_LUTdq.json'))
        rows=[]
        for point,phi,r in zip(full_points,flux,outputs):
            rows.append(dict(magnet_C=temp,Id_rms_A=float(point[1]),Iq_rms_A=float(point[2]),
                Phid_rms_Wb=float(phi[0]),Phiq_rms_Wb=float(phi[1]),
                FE_mean_torque_Nm=float(r.mag.Tem_av),dq_torque_Nm=float(15*(phi[0]*point[2]-phi[1]*point[1])),
                torque_min_Nm=float(np.min(r.mag.Tem.values)),torque_max_Nm=float(np.max(r.mag.Tem.values)),
                solved_time_steps=len(r.mag.Tem.values),within_22Arms=bool(np.hypot(point[1],point[2])<=22)))
        dump(status,dict(status='completed',engine='Official VarLoadCurrent -> MagFEMM -> LUTdq',magnet_C=temp,rows=rows,transport=transport))
        all_rows+=rows;dump(out/'progress.json',all_rows)
    dump(out/'summary.json',dict(status='completed',engine='Official VarLoadCurrent -> MagFEMM -> LUTdq',rows=all_rows,
        current_grid_rms_A=dict(Id=[-12,-6,0],Iq=[0,10.814,22]),magnet_temperatures_C=[20,80,150],
        limitations=['Rotor-averaged stator flux/torque maps; reduced stator-time domain is not used to qualify rotor losses',
            'DC magnetostatic fields reused over speed; PWM eddy-current feedback is not modelled',
            'Three q-axis and three d-axis levels; interpolation domain is limited and explicitly enforced']))


if __name__=='__main__':run()
