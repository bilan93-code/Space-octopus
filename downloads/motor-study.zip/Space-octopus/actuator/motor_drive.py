"""Switched SVPWM current control and native-EEC-checked short-circuit transients."""
import json
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp
from pyleecan.Classes.EEC_PMSM import EEC_PMSM
from pyleecan.Classes.OPdq import OPdq
from .machine import build_machine
from .run import dump
ROOT=Path(__file__).resolve().parents[1]


def switched(R,Ld,Lq,psi,bus,deadtime,iq_cont,iq_peak,substeps=80):
    fs=20000;dt=1/(fs*substeps);omega=2*np.pi*52.5;wc=2*np.pi*300
    current=np.zeros(2);integ=np.zeros(2);vcommand=np.zeros(2);records=[]
    for n in range(int(.1/dt)):
        t=n*dt;theta=omega*t;cs=np.cos(theta-np.arange(3)*2*np.pi/3);sn=np.sin(theta-np.arange(3)*2*np.pi/3)
        ref=0 if t<.002 else iq_peak if .020<=t<.070 else iq_cont
        if n%substeps==0:
            err=np.array([-current[0],ref-current[1]])
            ff=np.array([R*current[0]-omega*Lq*current[1],R*current[1]+omega*(Ld*current[0]+psi)])
            unsat=ff+wc*np.array([Ld,Lq])*err+integ
            # The .9 factor is a design operating budget. The controller may use
            # the full linear SVPWM range to compensate deadtime/transients.
            vcommand=unsat*min(1.,(bus/np.sqrt(6))/max(np.linalg.norm(unsat),1e-12))
            integ+=(R*wc*err+1000*(vcommand-unsat))/fs
        vref=np.sqrt(2)*(vcommand[0]*cs-vcommand[1]*sn);offset=(vref.max()+vref.min())/2
        duty=np.clip(.5+(vref-offset)/bus,0,1);phase=(n%substeps)/substeps
        carrier=abs(2*phase-1);switch=(duty>carrier).astype(float)
        iabc=np.sqrt(2)*(current[0]*cs-current[1]*sn)
        vabc=bus*(switch-switch.mean())-bus*deadtime*fs*np.sign(iabc);vabc-=vabc.mean()
        vd=2/(3*np.sqrt(2))*(vabc@cs);vq=-2/(3*np.sqrt(2))*(vabc@sn)
        current+=dt*np.array([(vd-R*current[0]+omega*Lq*current[1])/Ld,(vq-R*current[1]-omega*(Ld*current[0]+psi))/Lq])
        if n%4==0:records.append([t,current[0],current[1],*iabc,ref])
    a=np.asarray(records);steady=a[a[:,0]>.085];peak_window=a[(a[:,0]>.06)&(a[:,0]<.07)]
    rise=a[(a[:,0]>.02)&(a[:,0]<.07)&(a[:,2]>.95*iq_peak)]
    return a,dict(bus_V=bus,deadtime_bias_s=deadtime,PWM_Hz=fs,substeps=substeps,
        steady_Iq_mean_Arms=float(steady[:,2].mean()),steady_Iq_peak_to_peak_A=float(np.ptp(steady[:,2])),
        steady_tracking_error_relative=float(abs(steady[:,2].mean()/iq_cont-1)),
        peak_Iq_mean_Arms=float(peak_window[:,2].mean()),peak_tracking_error_relative=float(abs(peak_window[:,2].mean()/iq_peak-1)),
        peak_time_to_95pct_s=float(rise[0,0]-.02) if len(rise) else None,
        maximum_current_vector_Arms=float(np.hypot(a[:,1],a[:,2]).max()),maximum_phase_instantaneous_A=float(np.abs(a[:,3:6]).max()),
        steady_copper_W=float(3*R*np.mean(steady[:,1]**2+steady[:,2]**2)))


def run(out,config=None):
    out.mkdir(parents=True,exist_ok=True);c=json.loads((ROOT/'configs/revised.json').read_text()) if config is None else config;m=build_machine(c)
    p=json.loads((ROOT/'results/extended/redesign/redesign_summary.json').read_text())['parameters']
    native=json.loads((ROOT/'results/extended/native_electrical/status.json').read_text())
    psi=native['PM_flux_rms_Wb'];Ld=p['Ld_H'];Lq=native['Lq_H'];iq_cont=11.;iq_peak=21.
    calibrated=ROOT/'results/motor/performance_parameters.json'
    if calibrated.exists():
        q=json.loads(calibrated.read_text());psi=q['psi80_rms_Wb'];Ld=q['Ld_H'];Lq=q['Lq_H'];iq_cont=q['continuous_Iq_Arms'];iq_peak=q['peak_Iq_Arms']
    rows=[]
    for bus,deadtime,Tw,Tm in [(42,0,100,80),(42,1e-6,100,80),(48,1e-6,100,80),(42,1e-6,130,150)]:
        flux=psi*(1+c['motor']['magnet_alpha_per_K']*(Tm-20))/(1+c['motor']['magnet_alpha_per_K']*60)
        a,row=switched(m.stator.comp_resistance_wind(Tw),Ld,Lq,flux,bus,deadtime,iq_cont,iq_peak)
        row.update(winding_C=Tw,magnet_C=Tm)
        rows.append(row);np.savez_compressed(out/('PWM_'+str(bus)+'_'+str(deadtime)+'_'+str(Tw)+'C.npz'),data=a)
    _,fine=switched(m.stator.comp_resistance_wind(100),Ld,Lq,psi,42,0,iq_cont,iq_peak,substeps=160)
    faults=[]
    for T in [20,150]:
        R=m.stator.comp_resistance_wind(T);flux=psi*(1+c['motor']['magnet_alpha_per_K']*(T-20))/(1+c['motor']['magnet_alpha_per_K']*60)
        for rpm in [630,945,1890]:
            omega=2*np.pi*5*rpm/60
            def rhs(t,i):return [(-R*i[0]+omega*Lq*i[1])/Ld,(-R*i[1]-omega*(Ld*i[0]+flux))/Lq]
            sol=solve_ivp(rhs,[0,.1],[0,iq_cont],t_eval=np.linspace(0,.1,4001),rtol=1e-9,atol=1e-10,max_step=1e-4)
            if not sol.success:raise RuntimeError(sol.message)
            e=EEC_PMSM(OP=OPdq(Ud_ref=0.,Uq_ref=0.,N0=float(rpm),felec=5*rpm/60),R1=R,Ld=Ld,Lq=Lq,Phid_mag=flux,Phiq_mag=0.,type_skin_effect=0)
            steady=e.solve();peak=int(np.argmax(np.hypot(*sol.y)));demag=int(np.argmin(sol.y[0]))
            faults.append(dict(magnet_and_winding_C=T,motor_rpm=rpm,peak_current_vector_Arms=float(np.hypot(*sol.y).max()),
                minimum_Id_Arms=float(sol.y[0,demag]),Iq_at_minimum_Id_Arms=float(sol.y[1,demag]),
                native_EEC_steady_Id_Arms=float(steady['Id']),native_EEC_steady_Iq_Arms=float(steady['Iq']),
                transient_to_native_steady_error_Arms=float(np.linalg.norm(sol.y[:,-1]-[steady['Id'],steady['Iq']]))))
    summary=dict(status='completed',engine='Explicit three-phase SVPWM switched-voltage integration; native EEC checked dq short-circuit ODE',
        parameters=dict(psi80_rms_Wb=psi,Ld_H=Ld,Lq_H=Lq),switched_PWM=rows,time_step_refinement=fine,short_circuit_transients=faults,
        phase_instantaneous_limit_A=22*np.sqrt(2),current_vector_limit_Arms=22,
        limitations=['Ideal switch states; deadtime represented by averaged voltage bias, not device commutation physics',
            'Fixed mechanical speed during faults; arm inertia and deceleration are not characterized',
            'Ld/Lq are constant approximations; saturated fault trajectories require nonlinear map/hardware correlation',
            '50 ms electrical peak command settles current; the separate thermal model checks 5 s duty',
            'No implemented hardware protection, semiconductor/EMC validation or demagnetization pass'])
    dump(out/'summary.json',summary);return summary


if __name__=='__main__':run(ROOT/'results/motor/drive')
