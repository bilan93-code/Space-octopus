"""Readable addendum assembled from completed extension artifacts only."""
import base64,json
import numpy as np
import matplotlib.pyplot as plt
import markdown
from .runtime import ROOT
from .motor_extensions import OUT
from .report import make_pdf


def build():
    def read(name):return json.loads((OUT/name).read_text())
    a=read('assessment.json');n=read('nonlinear_drive/summary.json');g=read('geometry_optimization/summary.json')
    loss=read('loss_formulations/summary.json');wire=read('harmonics/wire_summary.json');mag=read('harmonics/magnet_summary.json')
    ecc=read('eccentricity/summary.json');h=read('nonlinear_fault_fields/summary.json')
    construction=json.loads((ROOT/'results/motor/build_requirements.json').read_text());wrap=construction['retaining_wrap']
    materials=read('thermal_materials/summary.json')
    material_table='\n'.join(f"| {v['resin_k_W_mK']:.1f} | {100*v['assumed_resin_void_fraction']:.0f} | {v['liner_mm']:.1f} | {v['effective_transverse_k_W_mK']:.3f} | {v['mean_R_winding_case_K_W']:.4f} |" for v in materials['assembly_scenarios'] if v['liner_mm'] in [.1,.2] and v['resin_k_W_mK'] in [.1,.2,.4])
    feedforward=read('torque_feedforward/summary.json')
    PWM_loss=read('harmonics/PWM_loss_coupling.json')
    ff_table='\n'.join(f"| {v['magnet_C']} | {v['output_torque_Nm']} | {v['motor_drag_allowance_W']:.1f} | {v['maximum_required_Iq_Arms']:.3f} | {v['maximum_phase_voltage_peak_V']:.3f} | {'pass' if v['quasistatic_current_and_voltage_screen'] else 'exceeds budget'} |" for v in feedforward['cases'])
    holds='\n'.join(f"| {v['point']} | {100*v['relative_torque_error']:.4f} | {100*v['relative_flux_vector_error']:.4f} |" for v in a['normal_map_holdouts'])
    refs='\n'.join(f"| {v['case']} | {100*v['torque_relative_change']:.4f} | {100*v['flux_vector_relative_change']:.4f} |" for v in a['map_corner_refinements'])
    tolerances='\n'.join(f"| {v['case']} | {v['torque_Nm']:.4f} | {100*v['relative_torque_change']:.2f} | {v['conditional_output_torque_at_22Arms_with_33W_drag_Nm']:.1f} |" for v in a['tolerances'])
    fixed=[v for v in n['faults'] if v['mode']=='fixed speed']
    faults='\n'.join(f"| {v['winding_C']} / {v['magnet_C']} | {v['motor_rpm']} | {v['peak_current_vector_Arms']:.2f} | {v['minimum_Id_Arms']:.2f} | {v['minimum_Iq_Arms']:.2f} |" for v in fixed)
    knees='\n'.join(f"| {v['winding_C']} / {v['magnet_C']} | {v['motor_rpm']} | {v['H_parallel_min_kA_m']:.1f} | {v['required_negative_knee_magnitude_with_20pct_screen_kA_m']:.1f} |" for v in h['cases'])
    geotable='\n'.join(f"| {v['arc_fraction']:.1f} | {v['gap_mm']:.1f} | {v['mean_torque_Nm']:.4f} | {v['magnet_mass_kg']:.4f} | {v['ripple_peak_to_peak_Nm']:.4f} |" for v in g['grid'])
    forces='\n'.join(f"| {v['h_m']*1000:.1f} | {np.asarray(v['eccentricity_m'])*1e6} | {v['mean_Fx_N']:.2f} | {v['mean_Fy_N']:.2f} | {v['maximum_radial_force_N']:.2f} |" for v in ecc['cases'])
    pwm='\n'.join(f"| {v['magnet_C']} | {v['substeps']} | {v['maximum_current_vector_Arms']:.3f} | {100*v['steady_tracking_error_relative']:.3f} | {100*v['peak_tracking_error_relative']:.3f} |" for v in n['switched_PWM'])
    ac='\n'.join(f"| {v['magnet_C']} | {v['frequency_Hz']/1000:.0f} | {v['magnet_mesh_m']*1000:.2f} | {v['unit_basis_losses_W']['d']:.5f} | {v['unit_basis_losses_W']['q']:.5f} |" for v in mag['rows'])
    peak=[read(f'peak_losses/{nt}/status.json') for nt in [144,288]]
    peaks='\n'.join(f"| {v['solved_time_steps']} | {v['torque_Nm']:.5f} | {v['loss_W']['stator_bertotti']:.5f} | {v['loss_W']['rotor_bertotti']:.6f} | {v['loss_W']['magnets']:.5f} |" for v in peak)
    worst=min(a['tolerances'],key=lambda v:v['conditional_output_torque_at_22Arms_with_33W_drag_Nm'])
    optional='passes' if a['gates']['optional_peak_tolerance_robust'] else 'does not pass'
    text=f'''# Space-octopus: additional motor verification

## 1. Decision and purpose

This addendum records the additional analyses left outside the earlier preliminary
campaign. The earlier stop was a scope decision, not a permission or solver-access
limitation. This is a finite verification campaign with explicit acceptance limits;
it does not claim every Pyleecan class is applicable or product release is complete.

The six independent operating-map holdouts have maximum relative mean-torque error
{100*max(v['relative_torque_error'] for v in a['normal_map_holdouts']):.4f} percent
and flux-vector error
{100*max(v['relative_flux_vector_error'] for v in a['normal_map_holdouts']):.4f} percent.
The earlier mean-field interpolation is supported in these tested cells.
The additional cold map-corner refinements and hot full-period loaded losses are
reported below instead of assuming reference convergence holds everywhere.

Across the declared hot material/geometry perturbations, the lowest mean-torque
screen at 22 Arms corresponds to {worst['conditional_output_torque_at_22Arms_with_33W_drag_Nm']:.1f}
N m output after the explicit 33 W motor-drag allowance. The optional 400 N m
perturbation screen {optional}. The 220 N m mean-torque requirement remains a
separate gate from local heating, manufacture and fault protection. Br -5 percent
is below the earlier specified Br20 minimum of 1.05 T; it is a material shortfall
sensitivity, not an accepted supplier-lot tolerance. The minimum must actually be
guaranteed if the nominal prediction is used.

The earlier approximately 119 C buffered hot-spot result remains conditional on
its specified winding, distributed housing contact and loss assumptions. It is
not a measured temperature or a demonstrated tolerance-wide thermal rating.
New analyses do not turn absent material, mission or hardware data into evidence.

An additional angle-resolved feedforward check supports 220 N m within the
42 V / 10 percent voltage reserve. The optional 400 N m trajectory exceeds that
design voltage budget even when its mean-voltage calculation passes. Its peaks
remain below the ideal full linear SVPWM ceiling in these samples, with reduced
headroom; it must not inherit the earlier mean-only voltage acceptance.

## 2. Independent map and numerical checks

The holdouts are new official VarLoadCurrent -> nonlinear MagFEMM calculations.
They were not used to fit the existing 27-point map. The points include mid-cell
Id/Iq positions and intermediate magnet temperatures of 50 / 115 C.

| Magnet C, Id Arms, Iq Arms | Mean torque error % | Flux vector error % |
| --- | --- | --- |
{holds}

The cold loaded corner Id=-12, Iq=22 Arms receives a doubled time resolution
and separate global mesh factor 1.5. It is a field-characterization point above
the 22 Arms vector circle, not an allowed drive command.

| Refinement | Mean torque change % | Flux-vector change % |
| --- | --- | --- |
{refs}

The wide fault map has Id=-60/-30/0/+6 and Iq=-36/-24/0/+24 Arms at magnet
temperatures 20/150 C. The positive Id margin covers the initial fault excursion;
negative Iq coverage extends beyond the previous 24 Arms edge. Independent
mid-cell checks include lower-quadrant points. Their maximum normalized flux
error is {100*max(v['relative_flux_vector_error'] for v in a['fault_map_holdouts']):.3f}
percent, normalized by the actual flux-vector magnitude with a 5 mWb floor near
flux cancellation. All trajectories reject extrapolation beyond the native box.

## 3. Nonlinear fault, inertia and switched-drive coupling

The differential equations use the actual interpolated flux vector and its
current Jacobian, rather than constant Ld/Lq:

dPsi_d/dt = Ud - R Id + omega_e Psi_q;
dPsi_q/dt = Uq - R Iq - omega_e Psi_d.

The Jacobian converts flux derivatives to current derivatives. Assumed isotropic
80 microhenry end leakage is included; it cancels from the torque cross product.
Minimum sampled symmetric differential inductance is
{n['minimum_sampled_incremental_inductance_H']*1e6:.1f} microhenry. Maximum sampled
cross-derivative reciprocity mismatch is
{n['maximum_sampled_reciprocity_error_H']*1e6:.2f} microhenry. Piecewise interpolation
and residual reciprocity error limit energy accuracy; this is not full transient
eddy-current FE or irreversible magnet-recoil simulation.

| Winding / magnet C | Motor rpm | Peak vector Arms | Minimum Id Arms | Minimum Iq Arms |
| --- | --- | --- | --- | --- |
{faults}

Fault currents still require hardware protection beyond the proposed 22 Arms
normal drive limit. The hot case uses winding 130 C and magnets 150 C, correcting
the earlier equal-150-C approximation. The hot winding is no longer artificially
assigned resistance above its stated design limit.

The assumed end leakage is also varied from zero to 160 microhenry at 630/1890
rpm. The largest peak across those scenarios is
{max(v['peak_current_vector_Arms'] for v in n['end_leakage_sensitivity']):.2f} Arms.
This is a declared sensitivity, not a resolved three-dimensional end-winding
inductance. The subsequent H-field snapshots select the most negative Id among
the 0/80/160 microhenry cases, so the magnetic material requirement does not rely
solely on the original 80 microhenry assumption.

Coast-down cases couple the electromagnetic torque to native-geometry rotor
inertia and declared output inertia scenarios of 0/1/10/100 kg m2 reflected
through 63:1. They include a fixed 4.365 N m resisting shaft load and stop at
zero speed. Actual robot-arm inertia, load sign and impact cases remain unknown;
these are scenarios rather than a certified fault-current bound.

The 20 kHz three-phase switched-voltage PI controller was also integrated with
the nonlinear map at 40/80 substeps per switching period. Winding temperature
is 130 C; magnet temperature spans the two native endpoints. The run is 100 ms
with a 50 ms high-current command, distinct from the earlier five-second thermal
screen. Dead time remains an averaged 1 microsecond voltage-bias approximation.

| Magnet C | Substeps | Maximum vector Arms | Steady error % | Peak error % |
| --- | --- | --- | --- | --- |
{pwm}

Native H-field snapshots were recomputed at the nonlinear fixed-speed fault
extrema. The required supplier irreversible-knee magnitudes include the same
20 percent screening allowance used previously:

| Winding / magnet C | rpm | Minimum parallel H kA/m | Required knee magnitude kA/m |
| --- | --- | --- | --- |
{knees}

Irreversible-demagnetization acceptance remains unset. Linear recoil coercivity
is not a supplier knee curve. These snapshots are not accepted rotor-loss histories.

## 4. Real FEMM geometry trade and hot perturbations

Nine exact geometries vary magnet arc fraction and bare radial gap. Every table
row is an actual nonlinear rotor-averaged FEMM solve at 10.814 Arms / 80 C magnets.
Pyleecan OptiGenAlgNsga2Deap then performs
{g['native_optimization_evaluations']} evaluations against those cached exact FE
results, minimizing magnet mass, reference-derived copper proxy and torque ripple.
The complete finite grid is retained; {len(g['pareto'])} candidates are nondominated.

| Magnet arc fraction | Bare gap mm | Mean torque N m | Magnet mass kg | Ripple p-p N m |
| --- | --- | --- | --- | --- |
{geotable}

The current/copper proxy uses the local solved torque constant and does not
replace a complete operating/loss map for each alternative. No new geometry is
silently substituted into the earlier candidate. The existing .8 arc / .5 mm bare
gap remains the assessed baseline.

The perturbation cases use hot 150 C magnets, 130 C winding and 22 Arms. Stack
-0.5 mm, bare gap +50 micrometers and Br -5 percent are declared sensitivities.
The output column subtracts 30 W non-copper plus 3 W friction at 630 rpm before
applying the fixed 63:1 / .8 gearbox boundary. It is a mean-torque screen, not a
local thermal or full transmission rating.

| Case | EM torque N m | Torque change % | Conditional output N m |
| --- | --- | --- | --- |
{tolerances}

## 5. Angle-resolved constant-torque current and voltage

Native torque and instantaneous dq flux waveforms are interpolated in current
and angle, then inverted for constant actuator torque. The full flux derivatives
enter Ud = R Id + dPsi_d/dt - omega_e Psi_q and
Uq = R Iq + dPsi_q/dt + omega_e Psi_d. Thus both geometry-induced flux ripple
and the current modulation required to counter torque ripple contribute to the
voltage requirement. The motor runs at 630 rpm and winding resistance is at 130 C.

| Magnet C | Output N m | Drag W | Maximum Iq Arms | Maximum phase peak V | 42 V design screen |
| --- | --- | --- | --- | --- | --- |
{ff_table}

The design ceiling is 21.824 V phase peak; ideal full linear SVPWM at 42 V gives
24.249 V. The continuous 220 N m cases fit the design budget. The optional
400 N m cases use substantially more headroom and do not pass the reserved
budget. This is a quasistatic requirement, not a proof of servo tracking:
encoder timing, waveform calibration, current-loop bandwidth and inverter
nonidealities still matter. The 24 native positions per 36 mechanical degrees
and piecewise current interpolation limit the resolved angle waveform. No
gearbox mechanical filtering or skewed operating map is silently assumed.

## 6. Static eccentricity, magnetic pull and bearing stiffness

The independent full-circle project FE model translates the entire rotor,
magnets and shaft. Radial magnetization is evaluated about the displaced rotor
center. Gmsh/scikit-fem solve the nonlinear fields at 36 positions across one
72-degree magnetic period, on two meshes. Closed Maxwell-stress contours give
net force and torque, with torque shifted to the actual rotor center. This is
explicitly a custom route, not a native MagFEMM eccentricity claim.

| Mesh mm | Offset x/y um | Mean Fx N | Mean Fy N | Maximum radial force N |
| --- | --- | --- | --- | --- |
{forces}

The approximately 50 N mean pull at 50 micrometers displacement implies magnetic
negative stiffness of roughly 1 MN/m. The supported-shaft compliance and assumed
bearing-pair stiffness are combined in series. A local linear stability screen
requires combined mechanical stiffness above the magnetic force gradient.
The assessment JSON retains 1/10/100 MN/m bearing-pair scenarios and the resulting
eccentricity amplification. Soft support can fail this gate despite adequate
nominal air gap. Catalog preload/stiffness, the real shaft shoulders and housing
must be selected before converting the screen into an assembled stability claim.

These calculations omit dynamic whirl, contact, thermal fit/preload evolution,
axial modes and mission vibration. The existing proposed wrap/gap budget does
not automatically establish bearing stability.

The retention screen now includes the sampled fault traction, unsupported-span
bending deflection and the declared bearing/shaft compliance. The earlier
50 GPa / .20 mm wrap leaves only
{wrap['previous_50GPa_remaining_gap_including_bending_and_support_mm']:.3f} mm
in that combined screen, below the .1 mm target. It is rejected by this check.
The proposed hot hoop modulus is raised to
{wrap['assumed_hoop_modulus_GPa']:.0f} GPa; the modeled minimum to preserve the
gap is {wrap['required_hot_hoop_modulus_from_gap_GPa']:.1f} GPa. At the proposed
value the retained gap is {wrap['conservative_remaining_gap_mm']:.3f} mm and the
required hot hoop strength, with the stated factor two, is
{wrap['required_hot_hoop_strength_with_factor2_MPa']:.1f} MPa. This is a revised
material/construction requirement, not a pass for a selected insulating composite.
The assumed bearing-pair radial stiffness is 10 MN/m, and magnetic stiffness
comes from the nominal-field eccentricity cases; full fault-UMP dynamics,
anisotropic laminate/contact/end retention and actual fits remain open.

Shaft and bond torque requirements are also updated from the nonlinear faults
and end-leakage scenarios. Bond shear uses the actual 23 mm core-interface radius
rather than the magnet mean radius. The construction JSON retains those loads.

## 7. Winding construction and liner thermal resistance

An independent coated-wire unit cell uses .95 mm copper, 25 micrometer radial
enamel, the native 47.6 percent bare slot fill and declared matrix conductivities.
Two meshes establish numerical sensitivity. Copper conductivity is 390 W/m/K,
enamel .2 W/m/K. Insulating porosity is represented by a Maxwell dilute-pore
approximation, not a measured connected-void network.

The resulting transverse conductivity is then supplied directly to the actual
slotted-stator FE model. Copper/steel interface nodes are separated and connected
by the stated liner conductance, allowing a temperature jump. Liner conductivity
is .12 W/m/K. The mean winding-to-case resistance comes from a steady 1 W solve;
it is not fitted to the desired .12 K/W target in this calculation.

| Resin k W/m/K | Assumed resin void % | Liner mm | Composite k W/m/K | Mean path K/W |
| --- | --- | --- | --- | --- |
{material_table}

For example, .1 W/m/K impregnation with a .2 mm liner exceeds the target, whereas
.4 W/m/K impregnation has margin in the tested liner/porosity scenarios. The
proposed construction screen therefore specifies at least .4 W/m/K hot potting,
at most .2 mm liner and at least .12 W/m/K liner conductivity, while retaining
assembled Rwc <= .12 K/W as the actual requirement. This is a material scenario,
not a procured-grade or manufactured-coil pass. Liner volume, insertion and real
packing need checking: the zero-thickness interface preserves the native slot
envelope and does not resolve the liner's displaced copper volume. End-turn
geometry and actual contact quality remain separate requirements.

## 8. Loaded full-period loss convergence and extra native models

At hot 150 C magnets / 130 C winding / 22 Arms / 630 rpm:

| Full positions | Mean torque N m | Stator core W | Rotor core W | Magnets W |
| --- | --- | --- | --- | --- |
{peaks}

The largest non-copper loss change with 144-to-288 refinement is
{100*max(a['peak_loss_time_refinement_relative_change'].values()):.3f} percent.
These histories span a full mechanical revolution, respecting per_t_R=1.
They improve loaded-point numerical evidence, not empirical coefficient accuracy
or convergence over every current/speed/temperature combination.

Additional official formulations executed on retained native fields give:
LossModelWinding {loss['official_models_executed']['winding']:.3f} W with the
.95 mm winding at 100 C; stator Steinmetz
{loss['official_models_executed']['stator_steinmetz']:.3f} W; rotor Steinmetz
{loss['official_models_executed']['rotor_steinmetz']:.6f} W. Steinmetz and Bertotti
share an assumed 3 W/kg calibration point and are alternative formulations,
not independent material measurements.

Native WindagePyrhonen returns
{loss['official_models_executed']['air_windage']:.6f} W at its hard-coded
atmospheric-air conditions and rotor-iron radius. It is a ground-test comparison,
not a space-vacuum windage prediction. Bearing/seal losses remain unmeasured.

## 9. Harmonic AC verification and conductive reaction

Direct FEMM AC solves benchmark a .95 mm isolated round wire at 1/20/40/80 kHz,
100/130 C and two meshes. The fine-mesh maximum resistance-ratio error against
the exact Bessel internal-impedance solution is
{100*a['AC_wire_maximum_fine_mesh_analytic_error']:.3f} percent. This verifies the
isolated-wire calculation; it does not validate neighboring-wire proximity.
The simulated PWM spectra above 1 kHz are evaluated separately with isolated-wire impedance
and the native low-frequency Pyrhonen expansion, whose high-frequency extrapolation
is explicitly a sensitivity rather than an accepted bound.

The motor harmonic calculation uses FEMM incremental permeability about native
DC geometry/bias, finite assumed magnet conductivity, and a separate zero-net-
current circuit per magnet. The AC field therefore includes conductive reaction.
Unit d/q RMS perturbations plus their real/quadrature combinations identify a
Hermitian magnet-loss response. The native half-domain integral is multiplied by
two and physical stack depth is 85 mm.

| Magnet C | Frequency kHz | Magnet mesh mm | Unit d loss W/A2 | Unit q loss W/A2 |
| --- | --- | --- | --- | --- |
{ac}

The finer 20 kHz magnet mesh provides a separate AC convergence check. Results
describe one frozen rotor position and continuous axial magnets. Actual PWM
sidebands, axial segmentation and three-dimensional current return/end effects
remain approximations; laminated-steel high-frequency loss still needs supplier
data. This new solve is not labelled a complete three-dimensional PWM-loss model.

Combining the simulated high-frequency dq-current spectra with the sampled
Hermitian response gives incremental magnet-loss sensitivities from
{min(v['incremental_magnet_loss_sensitivity_W'] for v in PWM_loss['rows']):.4f} to
{max(v['incremental_magnet_loss_sensitivity_W'] for v in PWM_loss['rows']):.4f} W.
The response is interpolated at 20/40/80 kHz, clamped below the lowest sampled
frequency and continued as f-squared above the highest. Both DC-bias endpoints
are applied as scenarios. These are model sensitivities rather than a validated
PWM-loss bound; the component JSON records the current-spectrum share outside
the sampled frequency range. They do not remove the supplier/3-D loss gate.

## 10. Reproduction and remaining acceptance gates

Run python -m actuator.motor_comprehensive with .venv and OPENBLAS_NUM_THREADS=1
after the documented setup. All Wine/FEMM stages are sequential. Per-point native
checkpoints recover interrupted work; completed summaries are not substituted for
missing raw data when a stage actually needs the latter. Verification results,
coverage and source/artifact hashes are regenerated before packaging.

The remaining gates are explicit: supplier magnet irreversible curves and
high-field/high-frequency steel data, demonstrated winding/contact paths and
actual end-turn construction, selected bearings/preload and detailed retention
geometry/materials, real mission duty/inertia/environmental/life loads, protected
drive hardware and prototype correlation. StructElmer's installed compatibility
failure is retained. Those gaps cannot be closed by running unrelated machine
types or alternate optimizers with the same physical assumptions.
'''
    figures=plots(a,n,g,wire,mag,ecc)
    (OUT/'report.md').write_text(text+'\n'+''.join(f'\n![{p}]({p})\n' for p in figures))
    html=markdown.markdown(text,extensions=['tables'])
    imgs=''.join('<figure><img style="max-width:100%" src="data:image/png;base64,'+base64.b64encode((OUT/f).read_bytes()).decode()+'"></figure>' for f in figures)
    (OUT/'report.html').write_text('<!doctype html><meta charset="utf-8"><title>Additional motor verification</title><style>body{font:16px/1.6 system-ui;max-width:1100px;margin:35px auto;padding:20px;color:#152537}table{border-collapse:collapse}td,th{border:1px solid #ccd5de;padding:6px}h1,h2{line-height:1.2}</style>'+html+imgs)
    make_pdf(OUT,text,figures)
    return text


def plots(a,n,g,wire,mag,ecc):
    files=[];plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    def save(fig,name):
        fig.tight_layout();fig.savefig(OUT/name,dpi=150,bbox_inches='tight');plt.close(fig);files.append(name)
    fig,axes=plt.subplots(1,2,figsize=(10,4.3));r=a['normal_map_holdouts'];x=np.arange(len(r))
    axes[0].bar(x,[100*v['relative_torque_error'] for v in r]);axes[0].set(xlabel='Independent native holdout',ylabel='Relative mean-torque error (%)',title='Existing map interpolation check')
    for T in [20,150]:
        rows=[v for v in n['faults'] if v['mode']=='fixed speed' and v['T_C']==T];axes[1].plot([v['motor_rpm'] for v in rows],[v['peak_current_vector_Arms'] for v in rows],'o-',label=f'Magnets {T} C')
    axes[1].axhline(22,c='r',ls='--',label='Normal current limit');axes[1].set(xlabel='Motor speed (rpm)',ylabel='Nonlinear fault peak (Arms)',title='Map-driven short-circuit transients');axes[1].legend();save(fig,'map_and_faults.png')
    fig,axes=plt.subplots(1,2,figsize=(10,4.3))
    for T in [20,150]:
        z=np.load(OUT/f'nonlinear_drive/fault_{T}C_1890rpm.npz');axes[0].plot(z['t']*1000,z['current'][:,0],label=f'Id, {T} C');axes[0].plot(z['t']*1000,z['current'][:,1],ls='--',label=f'Iq, {T} C')
    axes[0].set(xlabel='Time (ms)',ylabel='Current (Arms)',title='1890 rpm fixed-speed fault');axes[0].legend()
    for T in [20,150]:
        rows=[v for v in n['faults'] if v['mode']=='coast down' and v['T_C']==T];axes[1].plot([v['assumed_output_inertia_kg_m2'] for v in rows],[v['peak_current_vector_Arms'] for v in rows],'o-',label=f'{T} C')
    axes[1].set(xscale='symlog',xlabel='Assumed output inertia (kg m2)',ylabel='Peak current (Arms)',title='Mechanical coupling scenarios, 630 rpm');axes[1].legend();save(fig,'fault_trajectories.png')
    fig,axes=plt.subplots(1,2,figsize=(11,4.5));r=a['tolerances'];x=np.arange(len(r))
    axes[0].bar(x,[v['conditional_output_torque_at_22Arms_with_33W_drag_Nm'] for v in r],color='#267c90');axes[0].set(xticks=x,xticklabels=[v['case'] for v in r],ylabel='Conditional output torque (N m)',title='Hot 22 Arms / 33 W drag screen');axes[0].tick_params(axis='x',rotation=30)
    axes[0].axhline(400,c='r',ls='--',label='Optional peak');axes[0].axhline(220,c='gray',ls=':',label='Continuous demand');axes[0].legend()
    rows=g['grid'];sc=axes[1].scatter([v['magnet_mass_kg'] for v in rows],[v['ripple_peak_to_peak_Nm'] for v in rows],c=[v['gap_mm'] for v in rows],s=75)
    axes[1].set(xlabel='Magnet mass (kg)',ylabel='Sampled torque ripple p-p (N m)',title='Nine real nonlinear FEMM geometries');fig.colorbar(sc,ax=axes[1],label='Bare gap (mm)');save(fig,'tolerances_and_geometry.png')
    fig,axes=plt.subplots(1,2,figsize=(10,4.3))
    for h in [.0018,.0012]:
        rows=[v for v in ecc['cases'] if v['h_m']==h];axes[0].plot([0,50,50],[v['maximum_radial_force_N'] for v in rows],'o',label=f'{h*1000:.1f} mm mesh')
    axes[0].set(xlabel='Static rotor offset magnitude (um)',ylabel='Maximum sampled radial force (N)',title='Eccentric magnetic pull');axes[0].legend()
    for T in [100,130]:
        r=sorted([v for v in wire['rows'] if v['T_C']==T and v['wire_radius_mesh_divisor']==24],key=lambda v:v['frequency_Hz']);axes[1].semilogx([v['frequency_Hz'] for v in r],[v['FEMM_Rac_Rdc'] for v in r],'o-',label=f'FEMM {T} C');axes[1].semilogx([v['frequency_Hz'] for v in r],[v['Bessel_Rac_Rdc'] for v in r],'x--',label=f'Exact {T} C')
    axes[1].set(xlabel='Frequency (Hz)',ylabel='Rac / Rdc',title='Isolated .95 mm round wire');axes[1].legend();save(fig,'eccentricity_and_AC_wire.png')
    fig,axes=plt.subplots(1,2,figsize=(10,4.3))
    for T in [80,150]:
        r=sorted([v for v in mag['rows'] if v['magnet_C']==T and v['magnet_mesh_m']==.0003],key=lambda v:v['frequency_Hz']);axes[0].plot([v['frequency_Hz']/1000 for v in r],[v['unit_basis_losses_W']['q'] for v in r],'o-',label=f'{T} C bias')
    axes[0].set(xlabel='AC perturbation frequency (kHz)',ylabel='Magnet loss response (W / Arms2)',title='DC-biased incremental FEMM, q direction');axes[0].legend()
    z=np.load(OUT/'nonlinear_drive/PWM_150C_substeps80.npz')['data'];axes[1].plot(z[::10,0]*1000,z[::10,2],label='Iq');axes[1].plot(z[::10,0]*1000,z[::10,6],ls='--',label='Command');axes[1].set(xlabel='Time (ms)',ylabel='Iq (Arms)',title='Nonlinear-map switched controller, hot magnets');axes[1].legend();save(fig,'incremental_AC_and_PWM.png')
    fig,axes=plt.subplots(1,2,figsize=(10,4.5))
    for target in [220,400]:
        z=np.load(OUT/f'torque_feedforward/80C_{target}Nm_33.0W.npz');axes[0].plot(np.rad2deg(z['theta']),z['phase_voltage_peak'],label=f'{target} N m')
    axes[0].axhline(42*.9/np.sqrt(3),c='r',ls='--',label='42 V reserved budget');axes[0].set(xlabel='Mechanical angle (degrees)',ylabel='Required phase peak (V)',title='Angle-resolved constant-torque voltage');axes[0].legend()
    materials=json.loads((OUT/'thermal_materials/summary.json').read_text())['assembly_scenarios']
    for liner in [.1,.2]:
        r=sorted([v for v in materials if v['liner_mm']==liner and v['assumed_resin_void_fraction']==.2],key=lambda v:v['resin_k_W_mK'])
        axes[1].plot([v['resin_k_W_mK'] for v in r],[v['mean_R_winding_case_K_W'] for v in r],'o-',label=f'{liner} mm liner')
    axes[1].axhline(.12,c='r',ls='--',label='Required assembled path');axes[1].set(xlabel='Assumed resin conductivity (W/m/K)',ylabel='Mean winding-case path (K/W)',title='Explicit liner, 20% matrix-void scenario');axes[1].legend();save(fig,'voltage_and_thermal_construction.png')
    return files


if __name__=='__main__':build()
