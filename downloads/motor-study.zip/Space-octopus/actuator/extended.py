"""Reproduce/reuse the extended study: python -m actuator.extended [--refresh]."""
import argparse,json,subprocess
from pathlib import Path
from .machine import build_machine
from .native_models import run_native_history,reprocess_history
from .native_femm import run_native_femm
from .native_electrical import run_native_electrical
from .native_convergence import run_native_convergence
from .structural import run_carrier
from .redesign import run_redesign
from .controls import run_controls
from .thermal_fea import run_thermal_fea
from .mechanical import run_mechanical
from .extended_report import build_report
from .run import dump
ROOT=Path(__file__).resolve().parents[1]


def export_motor_surfaces(c,out):
    m=build_machine(c);surfs=[]
    for lam in [m.rotor,m.stator]:
        for surf in lam.build_geometry():
            loops=[surf.out_surf,surf.in_surf] if type(surf).__name__=='SurfRing' else [surf]
            lines=[]
            for loop in loops:
                items=[]
                for l in loop.get_lines():
                    segment=type(l).__name__=='Segment';points=[l.get_begin(),l.get_end()] if segment else l.discretize(3)
                    items.append(dict(type='line' if segment else 'arc',points=[[float(z.real),float(z.imag)] for z in points]))
                lines.append(items)
            material='Copper coil envelope' if '_Winding' in surf.label else 'SmCo-like assumed' if '_Magnet' in surf.label else 'Electrical steel'
            surfs.append(dict(name=surf.label.replace('_R','_Region').replace('-','_'),material=material,loops=lines))
    dump(out/'motor_surfaces.json',surfs)


def run(refresh=False):
    out=ROOT/'results/extended';out.mkdir(parents=True,exist_ok=True)
    baseline=json.loads((ROOT/'configs/baseline.json').read_text())
    if refresh or not (out/'redesign/redesign_summary.json').exists():run_redesign(baseline,out/'redesign')
    revised=json.loads((ROOT/'configs/revised.json').read_text());red=json.loads((out/'redesign/redesign_summary.json').read_text())
    if refresh or not (out/'structural/carrier_summary.json').exists():run_carrier(baseline,out/'structural')
    if refresh or not (out/'thermal/thermal_fea_summary.json').exists():run_thermal_fea(revised,red,out/'thermal')
    if refresh or not (out/'controls/controls_summary.json').exists():run_controls(revised,red,out/'controls')
    run_mechanical(baseline,out/'mechanical_screens.json')
    if refresh or not (out/'cad/cad_status.json').exists():
        (out/'cad').mkdir(parents=True,exist_ok=True);export_motor_surfaces(revised,out/'cad')
        subprocess.run(['bash','scripts/freecad_python.sh','scripts/build_cad.py'],cwd=ROOT,check=True,timeout=180)
    fieldout=out/'electromagnetics'
    if refresh:
        # Explicit refresh replaces generated field histories, not source/PDF data.
        (fieldout/'history_checkpoint.npz').unlink(missing_ok=True)
    history_files=['native_models.json','history_checkpoint.npz','reference_mesh.npz','reference_labels.json']
    if refresh or not all((fieldout/name).exists() for name in history_files):
        run_native_history(build_machine(baseline),baseline,fieldout,nt=144)
    # Rerun native postprocessing on retained fields so skin/proximity models and
    # the final capability report always reflect the current official pipeline.
    reprocess_history(build_machine(baseline),baseline,fieldout)
    native_status=out/'native_femm/status.json'
    if refresh or not native_status.exists() or json.loads(native_status.read_text()).get('status')!='completed':
        run_native_femm(baseline,out/'native_femm')
    run_native_convergence(baseline,out/'native_femm',refresh=refresh)
    electrical_status=out/'native_electrical/status.json'
    if refresh or not electrical_status.exists() or json.loads(electrical_status.read_text()).get('status')!='completed':
        run_native_electrical(revised,red,out/'native_electrical')
    build_report(out)
    print('Extended report:',out/'extended_report.pdf')
    print('Native magnetic/electrical execution evidence is retained in component status files.')


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--refresh',action='store_true');a=p.parse_args();run(a.refresh)
