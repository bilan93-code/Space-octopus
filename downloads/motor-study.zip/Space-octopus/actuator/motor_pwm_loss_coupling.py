"""Combine simulated dq ripple spectra with the sampled incremental FEMM response."""
import json
import numpy as np
from .runtime import ROOT
from .run import dump


def run():
    out=ROOT/'results/motor/extensions';path=out/'harmonics/magnet_summary.json';data=json.loads(path.read_text())
    # Derive the Hermitian off-diagonal sign directly from the four measured
    # basis powers; do not depend on an earlier serialization convention.
    for row in data['rows']:
        p=row['unit_basis_losses_W'];row['cross_real_W_A2']=(p['d_plus_q']-p['d']-p['q'])/2
        row['cross_imag_W_A2']=-(p['d_plus_jq']-p['d']-p['q'])/2
    dump(path,data);dump(out/'harmonics/magnet_progress.json',data['rows'])
    results=[]
    paths=list((ROOT/'results/motor/candidate_drive').glob('PWM_*.npz'))+list((out/'nonlinear_drive').glob('PWM_*.npz'))
    for source in sorted(paths):
        values=np.load(source)['data'];values=values[values[:,0]>.075];t=values[:,0];i=values[:,1:3]-values[:,1:3].mean(axis=0)
        window=np.hanning(len(t));Z=np.sqrt(2)*np.fft.rfft(i*window[:,None],axis=0)/(len(t)*np.sqrt(np.mean(window*window)))
        f=np.fft.rfftfreq(len(t),np.median(np.diff(t)));pick=f>=1000;f=f[pick];Z=Z[pick]
        for T in [80,150]:
            rows=sorted([v for v in data['rows'] if v['magnet_C']==T and v['magnet_mesh_m']==.0003],key=lambda v:v['frequency_Hz'])
            axis=[v['frequency_Hz'] for v in rows]
            dd=np.interp(f,axis,[v['unit_basis_losses_W']['d'] for v in rows]);qq=np.interp(f,axis,[v['unit_basis_losses_W']['q'] for v in rows])
            re=np.interp(f,axis,[v['cross_real_W_A2'] for v in rows]);im=np.interp(f,axis,[v['cross_imag_W_A2'] for v in rows])
            scale=np.maximum(1.,(f/80000)**2)
            power=(dd*np.abs(Z[:,0])**2+qq*np.abs(Z[:,1])**2+2*np.real(np.conj(Z[:,0])*(re+1j*im)*Z[:,1]))*scale
            total=float(power.sum());variance=np.sum(np.abs(Z)**2,axis=1);outside=(f<20000)|(f>80000)
            results.append(dict(current_waveform=str(source.relative_to(ROOT)),AC_bias_magnet_C=T,
                high_frequency_dq_variance_A2=float(variance.sum()),incremental_magnet_loss_sensitivity_W=total,
                current_variance_fraction_outside_sampled_frequency_range=float(variance[outside].sum()/variance.sum())))
    result=dict(status='completed',engine='Simulated dq-current RMS spectra -> Hermitian incremental FEMM magnet-loss response',rows=results,
        limitations=['Sensitivity, not a proven hardware loss bound: fixed-position DC bias and sampled AC frequencies',
            'Response interpolated at 20/40/80 kHz; lower frequencies clamp to 20 kHz and higher frequencies use an f-squared continuation',
            'Bias endpoints applied as scenarios, not an exact temperature/load match to every current waveform',
            'Only current components >=1 kHz included; winding proximity, laminated-steel PWM loss and 3-D segmentation/end returns remain separate'])
    dump(out/'harmonics/PWM_loss_coupling.json',result);return result


if __name__=='__main__':run()
