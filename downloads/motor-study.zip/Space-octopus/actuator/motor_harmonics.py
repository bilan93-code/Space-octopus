"""Direct FEMM harmonic solves: wire impedance and DC-biased magnet eddy loss.

These are explicit project pyfemm integrations. They retain conductive reaction
and FEMM incremental permeability, with 2-D/frozen-position limits stated.
"""
import json,os,subprocess,shlex,re
from pathlib import Path
import numpy as np
from pyleecan.Classes._FEMMHandler import _FEMMHandler
from .runtime import ROOT,headless_environment
from .femm_transport import reliable_femm_transport
from .motor_loss_extensions import wire_factor
from .run import dump

OUT=ROOT/'results/motor/extensions/harmonics'


def circle(h,r,group=0):
    h.mi_addnode(r,0);h.mi_addnode(-r,0)
    h.mi_addarc(r,0,-r,0,180,2);h.mi_addarc(-r,0,r,0,180,2)


def wire(h):
    rows=[];a=.00095/2
    for T in [100,130]:
        rho=1.724e-8*(1+.00393*(T-20));Rdc=rho/(np.pi*a*a)
        for divisor in [12,24]:
            for freq in [1000,20000,40000,80000]:
                h.newdocument(0);h.mi_probdef(freq,'meters','planar',1e-9,1.,20)
                h.mi_addmaterial('Air',1,1);h.mi_addmaterial('Wire',1,1,0,0,1/rho/1e6)
                h.mi_addcircprop('wire',1,1);h.mi_addboundprop('A0',0,0,0,0,0,0,0,0,0)
                circle(h,a);circle(h,5*a)
                for y in [5*a,-5*a]:
                    h.mi_selectarcsegment(0,y);h.mi_setarcsegmentprop(2,'A0',0,0);h.mi_clearselected()
                h.mi_addblocklabel(0,0);h.mi_selectlabel(0,0);h.mi_setblockprop('Wire',0,a/divisor,'wire',0,1,1);h.mi_clearselected()
                h.mi_addblocklabel(3*a,0);h.mi_selectlabel(3*a,0);h.mi_setblockprop('Air',0,a/3,'<None>',0,0,0);h.mi_clearselected()
                path=OUT/f'wire_{T}C_{freq}Hz_h{divisor}.fem';h.mi_saveas(str(path));h.mi_analyze(1);h.mi_loadsolution()
                resistance=float(complex(h.mo_getcircuitproperties('wire')[1]).real)
                reference=float(wire_factor(freq,T));rows.append(dict(T_C=T,frequency_Hz=freq,wire_radius_mesh_divisor=divisor,
                    FEMM_Rac_Rdc=resistance/Rdc,Bessel_Rac_Rdc=reference,relative_error=(resistance/Rdc/reference-1)))
                h.mo_close();h.mi_close()
                dump(OUT/'wire_progress.json',rows)
    dump(OUT/'wire_summary.json',dict(status='completed',engine='Direct FEMM AC conductive-wire solve versus exact Bessel internal impedance',rows=rows,
        limitations=['Single isolated round wire; adjacent-conductor proximity is excluded','Rac derived from complex voltage/current; impedance ratio is independent of RMS/peak convention']))


def parse_labels(text):
    lines=text.splitlines();start=next(i for i,s in enumerate(lines) if s.startswith('[NumBlockLabels]'))
    count=int(lines[start].split('=')[1]);names=[]
    for line in lines:
        if '<BlockName>' in line:names.append(line.split('=',1)[1].strip().strip('"'))
    magnet_index=names.index('Generic SmCo-like assumption')+1
    labels=[]
    for line in lines[start+1:start+1+count]:
        fields=shlex.split(line)
        if int(fields[2])==magnet_index:labels.append(fields)
    return labels


def biased_magnets(h):
    source=ROOT/'results/motor/full_period/288/Femm/SpaceOctopus_12s10p_v1_model.fem'
    text=source.read_text();labels=parse_labels(text)
    c=json.loads((ROOT/'configs/motor_candidate.json').read_text());rows=[]
    # Native file is a half-domain with magnetic anti-periodicity.
    dc_current=np.array([float(v) for v in re.findall(r'<TotalAmps_re>\s*=\s*([^\s]+)',text)]);qaxis=dc_current/10.814
    qaxis/=np.sqrt(np.mean(qaxis*qaxis));daxis=np.array([qaxis[1]-qaxis[2],qaxis[2]-qaxis[0],qaxis[0]-qaxis[1]])/np.sqrt(3)
    for T,Iq in [(80,10.814),(150,22.)]:
        for mesh in [.0003,.00015]:
            dc=OUT/f'bias_{T}C_I{Iq}_mesh{mesh}.fem'
            h.opendocument(str(source));h.mi_setprevious('',0)
            h.mi_probdef(0,'meters','planar',1e-8,.085,15)
            rho=.9e-6*(1+.0003*(T-20));h.mi_modifymaterial('Generic SmCo-like assumption',5,1/rho/1e6)
            Hc=1.05*(1-.0003*(T-20))/(4e-7*np.pi*1.05);h.mi_modifymaterial('Generic SmCo-like assumption',3,Hc)
            for index,f in enumerate(labels):
                x,y=float(f[0]),float(f[1])
                # Each magnet is electrically isolated: zero total axial
                # current, while allowing internal eddy-current circulation.
                name='isolated_mag_'+str(index);h.mi_addcircprop(name,0,0)
                h.mi_selectlabel(x,y)
                direction=f[9] if len(f)>9 and f[9] else float(f[5])
                h.mi_setblockprop('Generic SmCo-like assumption',0,mesh,name,direction,int(f[6]),1)
                h.mi_clearselected()
            for j in range(3):h.mi_modifycircprop('Circs'+str(j),1,float(qaxis[j]*Iq))
            h.mi_saveas(str(dc));h.mi_analyze(1);h.mi_loadsolution();h.mo_close();h.mi_close()
            dcans=dc.with_suffix('.ans')
            if not dcans.is_file():raise RuntimeError('DC bias solution was not produced')
            frequencies=[20000,40000,80000] if mesh==.0003 else [20000]
            for freq in frequencies:
                losses={}
                for label,vector in [('d',daxis),('q',qaxis),('d_plus_q',daxis+qaxis),('d_plus_jq',daxis+1j*qaxis)]:
                    h.opendocument(str(dc));h.mi_probdef(freq,'meters','planar',1e-8,.085,15)
                    h.mi_setprevious(str(dcans),1)
                    for j,value in enumerate(vector):
                        value=complex(np.sqrt(2)*value)
                        expression=f'({value.real:.17g}+({value.imag:.17g})*I)'
                        h.callfemm(f'mi_modifycircprop("Circs{j}",1,{expression})')
                    path=OUT/f'AC_{T}C_{freq}Hz_h{mesh}_{label}.fem';h.mi_saveas(str(path));h.mi_analyze(1);h.mi_loadsolution()
                    for f in labels:h.mo_selectblock(float(f[0]),float(f[1]))
                    # AC block loss is time-averaged; current phasors above are
                    # peak values for one RMS dq ampere. Multiply half domain.
                    power=complex(h.mo_blockintegral(4))
                    if abs(power.imag)>1e-6*max(abs(power.real),1e-12):
                        raise RuntimeError('Unexpected imaginary part in resistive AC power: '+str(power))
                    losses[label]=2*float(power.real);h.mo_clearblock();h.mo_close();h.mi_close()
                cross_re=(losses['d_plus_q']-losses['d']-losses['q'])/2
                cross_im=-(losses['d_plus_jq']-losses['d']-losses['q'])/2
                matrix=np.array([[losses['d'],complex(cross_re,cross_im)],[complex(cross_re,-cross_im),losses['q']]])
                eig=np.linalg.eigvalsh(matrix)
                rows.append(dict(magnet_C=T,bias_Iq_Arms=Iq,frequency_Hz=freq,magnet_mesh_m=mesh,unit_basis_losses_W=losses,
                    cross_real_W_A2=cross_re,cross_imag_W_A2=cross_im,
                    minimum_response_eigenvalue_W_per_A2=float(eig.min()),maximum_response_eigenvalue_W_per_A2=float(eig.max())))
                dump(OUT/'magnet_progress.json',rows)
    dump(OUT/'magnet_summary.json',dict(status='completed',engine='Direct FEMM DC-biased incremental-permeability AC solve with conductive magnet reaction',
        rows=rows,half_domain_scale=2,magnet_sigma_S_m='1/[0.9e-6*(1+0.0003*(T-20))]',
        conductor_constraint='Separate zero-net-current circuit for each magnet',
        limitations=['Frozen rotor position from the native reference file; rotational/PWM sidebands approximated locally',
            'Two-dimensional continuous axial magnet; segmentation and 3-D end effects unresolved',
            'Native uncalibrated B-H/recoil data and assumed conductivity retained',
            'Winding regions remain stranded current sources; conductor proximity is screened separately',
            'Laminated-steel PWM loss not established without supplier high-frequency data']))


def run():
    OUT.mkdir(parents=True,exist_ok=True)
    with headless_environment(OUT/'display.log') as env,reliable_femm_transport() as transport:
        keys=['PATH','DISPLAY','WINEPREFIX','LD_LIBRARY_PATH','XDG_RUNTIME_DIR'];before={k:os.environ.get(k) for k in keys}
        try:
            subprocess.run([str(ROOT/'.local/sysroot/usr/lib/wine/wineserver64'),'-k'],env=env)
            for k in keys:os.environ[k]=env[k]
            h=_FEMMHandler();h.openfemm(1)
            try:
                if not (OUT/'wire_summary.json').exists():wire(h)
                if not (OUT/'magnet_summary.json').exists():biased_magnets(h)
            finally:h.closefemm()
        finally:
            for k,v in before.items():
                if v is None:os.environ.pop(k,None)
                else:os.environ[k]=v
    dump(OUT/'transport.json',transport)


if __name__=='__main__':run()
