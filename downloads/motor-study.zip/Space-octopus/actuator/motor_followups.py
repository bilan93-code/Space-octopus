"""Sequential native full-period mesh, rotor-skew and fault-field checks."""
import copy,json,pickle
from pathlib import Path
import numpy as np
from .motor_campaign import ROOT,solve_case
from .machine import build_machine
from .run import dump


def run(candidate=False):
    config='configs/motor_candidate.json' if candidate else 'configs/revised.json'
    c=json.loads((ROOT/config).read_text());out=ROOT/'results/motor'
    if not candidate:
        solve_case(c,out/'full_period/144_mesh1p5',nt=144,na=32,kmesh=1.5,gap_mesh=.0000833333333333,Iq=10.814,time_periodicity=False)
        proposal=copy.deepcopy(c);proposal['motor']['step_skew_degrees']=3.
        proposal['provenance']='Proposed two-step rotor skew, two 42.5 mm axial sections separated by 3 mechanical degrees; construction and 3-D end effects not validated.'
        solve_case(proposal,out/'skew',nt=480,na=32,Iq=10.814,full_fields=False)
        build_machine(proposal).save(str(out/'skew/machine.json'));dump(out/'skew/proposed_config.json',proposal)
        solve_case(c,out/'peak_fields',nt=240,na=256,Iq=22.,magnet_C=20.)
        if not (out/'structure_peak/summary.json').exists():
            from .motor_structure import run as run_structure
            run_structure(out/'structure_peak',source=out/'peak_fields/native_output.pkl')
    with (out/'full_period/288/native_output.pkl').open('rb') as f:reference=pickle.load(f)
    ms=reference.mag.meshsolution;ctr=ms.mesh.node.coordinate[ms.mesh.element_dict['triangle'].connectivity.astype(int)].mean(axis=1)
    angle=np.arctan2(ctr[:,1],ctr[:,0]);bx=ms.solution_dict['B'].field.components['comp_x'].values;by=ms.solution_dict['B'].field.components['comp_y'].values
    polarities={}
    for name,ids in ms.group.items():
        if name.startswith('rotor magnets_'):
            ids=np.asarray(ids);polarities[name]=float(np.sign(np.median(bx[:,ids]*np.cos(angle[ids])+by[:,ids]*np.sin(angle[ids]))))
    faults=json.loads((out/('candidate_drive' if candidate else 'drive')/'summary.json').read_text())['short_circuit_transients'];results=[]
    faultout=out/('fault_fields_candidate' if candidate else 'fault_fields')
    for T,rpm in [(20,630),(150,630),(20,1890),(150,1890)]:
        fault=next(r for r in faults if r['magnet_and_winding_C']==T and r['motor_rpm']==rpm)
        folder=faultout/(str(T)+'C_'+str(rpm)+'rpm')
        solve_case(c,folder,require_output=True,nt=240,na=32,Id=fault['minimum_Id_Arms'],Iq=fault['Iq_at_minimum_Id_Arms'],magnet_C=T,winding_C=T,rpm=float(rpm))
        with (folder/'native_output.pkl').open('rb') as f:r=pickle.load(f)
        mesh=r.mag.meshsolution;xy=mesh.mesh.node.coordinate;tri=mesh.mesh.element_dict['triangle'].connectivity.astype(int);center=xy[tri].mean(axis=1);phi=np.arctan2(center[:,1],center[:,0])
        hx=mesh.solution_dict['H'].field.components['comp_x'].values;hy=mesh.solution_dict['H'].field.components['comp_y'].values
        values=[]
        for name,ids in mesh.group.items():
            if name.startswith('rotor magnets_'):
                ids=np.asarray(ids);values.append((polarities[name]*(hx[:,ids]*np.cos(phi[ids])+hy[:,ids]*np.sin(phi[ids]))).ravel())
        h=np.concatenate(values)
        results.append(dict(magnet_C=T,fault_reference_rpm=rpm,Id_Arms=fault['minimum_Id_Arms'],Iq_Arms=fault['Iq_at_minimum_Id_Arms'],
            H_parallel_min_kA_m=float(h.min()/1000),H_parallel_percentile01_kA_m=float(np.quantile(h,.01)/1000),
            required_negative_knee_magnitude_with_20pct_screen_kA_m=float(-1.2*h.min()/1000),irreversible_demagnetization_pass=None))
        dump(faultout/'progress.json',results)
    dump(faultout/'summary.json',dict(status='completed',engine='Native MagFEMM H field at dynamic-fault dq extrema',cases=results,
        limitations=['Linear-recoil magnet model cannot establish irreversible loss of magnetization',
            'Supplier temperature-dependent knee/coercivity curves and local mesh refinement are required for acceptance',
            'Fault operating points come from constant-inductance transients at fixed speed; field snapshots are not full transient FE co-simulation',
            'Reduced stator-time histories here sample spatial H extrema; their rotor loss outputs are not qualified']))


if __name__=='__main__':run()
