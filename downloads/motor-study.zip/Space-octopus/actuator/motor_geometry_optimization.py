"""Native NSGA-II over a grid evaluated with real nonlinear FEMM solutions."""
import json,random
import numpy as np
from pyleecan.Classes.OptiProblem import OptiProblem
from pyleecan.Classes.OptiObjective import OptiObjective
from pyleecan.Classes.OptiConstraint import OptiConstraint
from pyleecan.Classes.OptiDesignVarSet import OptiDesignVarSet
from pyleecan.Classes.OptiGenAlgNsga2Deap import OptiGenAlgNsga2Deap
from pyleecan.Classes.Simu1 import Simu1
from .machine import build_machine
from .motor_extensions import OUT
from .runtime import ROOT
from .run import dump


def arc_set(simu,value):
    simu.machine.rotor.slot.W0=simu.machine.rotor.slot.W1=float(value)*np.pi/5


def gap_set(simu,value):simu.machine.stator.Rint=.026+float(value)


def run():
    out=OUT/'geometry_optimization';out.mkdir(parents=True,exist_ok=True)
    c=json.loads((ROOT/'configs/motor_candidate.json').read_text());grid=[]
    for path in sorted((OUT/'geometry').glob('*/status.json')):
        r=json.loads(path.read_text());v=json.loads((path.parent/'input_config.json').read_text());m=build_machine(v)
        required=220/(63*.8)+(3.5+3)/(630*2*np.pi/60)
        current=required/(r['torque_Nm']/10.814)
        vp=np.sqrt(2)*np.hypot(2*np.pi*52.5*(r['Phiq_rms_Wb']+.00008*10.814),
            m.stator.comp_resistance_wind(130)*10.814+2*np.pi*52.5*r['Phid_rms_Wb'])
        grid.append(dict(arc_fraction=v['motor']['magnet_arc_fraction'],gap_mm=round((v['motor']['stator_bore_radius_m']-.026)*1000,5),
            magnet_mass_kg=m.rotor.comp_masses()['Mmag'],mean_torque_Nm=r['torque_Nm'],
            ripple_peak_to_peak_Nm=r['torque_max_Nm']-r['torque_min_Nm'],continuous_current_proxy_Arms=current,
            copper_proxy_W=3*m.stator.comp_resistance_wind(100)*current**2,reference_voltage_phase_peak_V=float(vp),
            feasible=bool(current<22 and vp<=42*.9/np.sqrt(3))))
    if len(grid)!=9:raise RuntimeError('All nine real FEMM geometry evaluations are required')
    def metric(output):
        m=output.simu.machine;arc=round(m.rotor.slot.W0/(np.pi/5),1);gap=round((m.stator.Rint-.026)*1000,1)
        return next(v for v in grid if v['arc_fraction']==arc and v['gap_mm']==gap)
    variables=[OptiDesignVarSet(name='Magnet arc fraction',symbol='arc',space=[.7,.8,.9],get_value=random.choice,setter=arc_set),
        OptiDesignVarSet(name='Bare radial gap',symbol='gap',unit='m',space=[.0004,.0005,.0006],get_value=random.choice,setter=gap_set)]
    objectives=[OptiObjective(name=k,symbol=k,keeper=lambda o,k=k:metric(o)[k])
        for k in ['magnet_mass_kg','copper_proxy_W','ripple_peak_to_peak_Nm']]
    constraints=[OptiConstraint(name='Current',symbol='I',type_const='<=',value=22.,keeper=lambda o:metric(o)['continuous_current_proxy_Arms']),
        OptiConstraint(name='Voltage',symbol='V',type_const='<=',value=float(42*.9/np.sqrt(3)),keeper=lambda o:metric(o)['reference_voltage_phase_peak_V'])]
    problem=OptiProblem(simu=Simu1(machine=build_machine(c),elec=None,mag=None,force=None,struct=None),
        design_var=variables,obj_func=objectives,constraint=constraints,eval_func=metric)
    random.seed(93);np.random.seed(93)
    result=OptiGenAlgNsga2Deap(problem=problem,size_pop=12,nb_gen=8,p_mutate=.5,is_keep_all_output=False).solve()
    keys=['magnet_mass_kg','copper_proxy_W','ripple_peak_to_peak_Nm']
    def dominates(a,b):return all(a[k]<=b[k] for k in keys) and any(a[k]<b[k] for k in keys)
    valid=[r for r in grid if r['feasible']];pareto=[r for r in valid if not any(dominates(v,r) for v in valid)]
    dump(out/'summary.json',dict(status='completed',engine='Official OptiGenAlgNsga2Deap with cached real nonlinear MagFEMM grid evaluations',
        unique_native_FE_geometries=9,native_optimization_evaluations=result.nb_simu,grid=grid,pareto=pareto,
        retained_design='Existing .8 arc / .5 mm bare gap; alternative geometries do not inherit its complete thermal/fault assessment',
        limitations=['Discrete 3x3 geometry trade; not a global topology optimization',
            'Current/copper proxy uses the solved reference torque constant; no full nonlinear operating/loss map per alternative',
            'Reference voltage is a local screening constraint, not a complete candidate speed rating']))


if __name__=='__main__':run()
