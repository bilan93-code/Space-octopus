"""Separate native FEMM time and air-gap-mesh refinements at one operating point."""
import json
from pathlib import Path
from .native_femm import run_native_femm
from .run import dump

ROOT=Path(__file__).resolve().parents[1]


def run_native_convergence(config,out,refresh=False):
    reference=json.loads((out/'status.json').read_text())
    cases=[]
    for name,nt,gap in [('time_refined',240,.000125),('mesh_refined',120,.0000833333333333)]:
        folder=out/name;status=folder/'status.json'
        if refresh or not status.exists() or json.loads(status.read_text()).get('status')!='completed':
            run_native_femm(config,folder,nt=nt,gap_mesh=gap)
        row=json.loads(status.read_text())
        if row.get('status')!='completed':raise RuntimeError('Native refinement incomplete: '+name)
        cases.append(dict(case=name,requested_time_steps=nt,solved_time_steps=row['solved_time_steps'],gap_mesh_m=gap,
            torque_Nm=row['torque_Nm'],torque_min_Nm=row['torque_min_Nm'],torque_max_Nm=row['torque_max_Nm'],
            torque_peak_to_peak_Nm=row['torque_max_Nm']-row['torque_min_Nm'],torque_change_relative=abs(row['torque_Nm']/reference['torque_Nm']-1),
            loss_W=row['loss_W'],loss_change_relative={k:abs(v/reference['loss_W'][k]-1) for k,v in row['loss_W'].items()}))
    summary=dict(status='completed',reference_requested_time_steps=reference['requested_time_steps'],reference_gap_mesh_m=.000125,
        cases=cases,scope='Two independent one-step refinements at baseline 9 Arms, 630 rpm; not a full-domain or asymptotic convergence proof',
        absolute_accuracy='Generic shared material data; no hardware validation')
    dump(out/'convergence.json',summary)
    return summary


if __name__=='__main__':
    run_native_convergence(json.loads((ROOT/'configs/baseline.json').read_text()),ROOT/'results/extended/native_femm')
