"""Corrective candidate voltage/current/mean-thermal exploration, not ratings."""
import json
from .motor_performance import MotorModel
from .machine import build_machine
from .runtime import ROOT
from .run import dump


def run():
    out=ROOT/'results/motor/extensions/candidate_envelope';out.mkdir(parents=True,exist_ok=True)
    model=MotorModel();c=json.loads((ROOT/'configs/motor_candidate.json').read_text());model.c=c;model.m=build_machine(c)
    rows=[]
    for sink in [50,70]:
        for speed in [0,5,10,12,14,15,17.5,20]:
            for torque in [110,220,302.4,400]:
                points=[dict(Id_command_Arms=d,**model.steady(torque,speed,sink=sink,Rwc=.12,Rcase=.05,Id=d)) for d in [0,-3,-6,-9,-12]]
                valid=[v for v in points if v['overall_conditional_pass']]
                best=min(valid,key=lambda v:v['electrical']['DC_input_W']) if valid else points[0]
                rows.append(dict(sink_C=sink,output_rpm=speed,output_torque_Nm=torque,
                    mean_model_feasible=bool(valid),best=best,all_Id_cases=points,
                    local_hotspot_rating_established=False))
    result=dict(status='completed',engine='Corrected candidate native FEMM map -> constrained dq voltage/current and coupled mean thermal roots',
        rows=rows,limitations=['This is an exploration, not a continuous-duty rating; local holding hot spots require the spatial FE assessment',
            'Only explicitly tested 0/10 rpm duty has the earlier spatial thermal evidence',
            '400 N m mean-thermal feasibility cannot override local hot-spot/current/fault/material acceptance',
            'Losses use native reference coefficients and approximate flux/load scaling; empirical coefficients remain uncalibrated'])
    dump(out/'summary.json',result);return result


if __name__=='__main__':run()
