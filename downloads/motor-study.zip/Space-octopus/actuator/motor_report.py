"""Motor suitability report assembled exclusively from executed study artifacts."""
import json,base64
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
import markdown
from .report import make_pdf
from .runtime import ROOT
from .run import dump


def build():
    out=ROOT/'results/motor'
    def read(name):return json.loads((out/name).read_text())
    p=read('performance/summary.json');c=read('candidate/summary.json');maps=read('maps/summary.json')
    full=read('full_period/summary.json')['cases'];fine=read('full_period/144_mesh1p5/status.json');skew=read('skew/status.json')
    h0=read('hotspot/summary.json');h1=read('hotspot_candidate/summary.json');h2=read('hotspot_candidate_fine/summary.json')
    drive=read('candidate_drive/summary.json');fault=read('fault_fields_candidate/summary.json');req=read('build_requirements.json')
    opt=read('optimization/summary.json');mech=read('mechanics/summary.json');structure=read('structure_peak/summary.json')
    selected=[v for h in [h1,h2] for v in h['scenarios'] if v['wire_mm']==.95]
    buffered=max(v['transient']['buffered_hotspot_C'] for v in selected)
    oldmax=max(v['transient']['maximum_winding_hotspot_C'] for v in h0['scenarios'] if v['wire_mm']==.9)
    ripple0=full[-1]['torque_max_Nm']-full[-1]['torque_min_Nm'];ripple1=skew['torque_max_Nm']-skew['torque_min_Nm']
    n=c['nominal'];stress=c['stress_scenario'];wrap=req['retaining_wrap'];bond=req['compliant_magnet_bond']
    lossrows='\n'.join(f"| {v['requested_time_steps']} | {v['Kmesh_fineness']} | {v['torque_Nm']:.5f} | {v['loss_W']['stator_bertotti']:.5f} | {v['loss_W']['rotor_bertotti']:.6f} | {v['loss_W']['magnets']:.5f} |" for v in full+[fine])
    text=f'''# Space-octopus motor suitability and corrective design

## 1. Decision

The 12-turn, two-0.9 mm-strand motor is electromagnetically capable of the
required mean torque, but its earlier cooling assumption does not satisfy the
full local-temperature duty screen. Stationary holding concentrates current in
particular phases; average winding temperature hid the resulting hot spots.
The original spatial model reaches {oldmax:.1f} deg C in the tested hot holding/
five-second-peak cases, above the assumed 130 deg C copper hot-spot limit.

The corrective candidate keeps the characterized magnetic geometry and 12 turns,
uses two 0.95 mm strands, and requires an assembled average winding-to-case path
of at most 0.12 K/W and distributed case-to-sink path of at most 0.05 K/W. It takes no credit
for radiation. Across the tested holding positions, running conditions and
five-second pulses, its conservative buffered maximum is {buffered:.1f} deg C.
Both spatial meshes pass the 130 deg C screen. This is a conditional design
result: the thermal paths are construction requirements to demonstrate.

At 220 N m output and 10 rpm through the assumed 63:1, 80-percent-efficient
gearbox, the candidate's nominal model gives {n['electrical']['Iq_rms_A']:.2f}
Arms, {n['electrical']['phase_peak_V']:.2f} V phase peak,
{n['temperatures_C']['winding']:.1f} deg C average winding temperature and
{n['electrical']['DC_input_W']:.1f} W DC input. Motor efficiency is
{100*n['electrical']['motor_efficiency']:.1f} percent; this excludes gearbox and
inverter losses. Average temperature is not the hot-spot acceptance metric.
The DC input figure includes the gearbox heat boundary and the assumed
97-percent inverter efficiency; it is a system power budget at this duty.

The motor is therefore a plausible electrical/thermal match for the stated
actuator duty after the winding/cooling correction. It is not a released build:
magnet knee curves, retention materials, winding manufacture, bearings and
hardware correlation remain explicit acceptance requirements below.

## 2. Requirements and adopted boundaries

| Quantity | Value and status |
| --- | --- |
| Continuous actuator output | 220 N m; user requirement |
| Motor arrangement | Separate removable inrunner; user requirement |
| Output speed | 10 rpm; adopted assumption |
| Gear ratio / efficiency | 63:1 / 0.80 budgeting assumption |
| Required motor shaft torque | 4.365 N m before motor losses |
| Motor speed | 630 rpm at the adopted output point |
| DC bus | 42 V minimum, 48 V nominal; adopted assumptions |
| Inverter phase-current limit | 22 Arms; proposed drive requirement |
| Sink temperature | 50 deg C nominal, 70 deg C stress scenario |
| Optional peak | 400 N m output for 5 s, running and stationary screens |
| Thermal limits | 130 deg C winding hot spot; 150 deg C magnet screen |

The 30 W non-copper-loss case is a sensitivity test, not a measured or proven
upper bound. An actual mission duty, external inertia, environmental loads and
space qualification standard have not been invented. A five-second pulse is
evaluated from the stated continuous equilibrium; no arbitrary repeated-pulse
mission rating is inferred.

## 3. Exact motor candidate

The active geometry is 12 slots, 10 poles, a 52 mm bare magnet OD, 53 mm stator
bore, 96 mm stator OD and 85 mm stack. The winding has 12 turns per coil,
48 series turns per phase and two parallel 0.95 mm bare copper strands.
The native winding model gives {100*c['winding']['bare_copper_fill']:.1f} percent
bare copper fill and {c['winding']['R100_ohm']:.5f} ohm phase resistance at
100 deg C. Active stator/rotor material mass is {c['active_motor_mass_kg']:.3f} kg;
this excludes the complete housing, bearing, sensor and actuator mass.

Material inputs remain a generic SmCo-like recoil model, Br20=1.05 T,
mu_r=1.05, alpha_Br=-0.0003/K, and the bundled M270-35A B-H exemplar.
The imported curve is not a certified supplier dataset, especially above its
last 1.8 T point. Native peak-field statistics are retained for material review.

Changing wire diameter at fixed slots, turns and prescribed ampere-turns leaves
the DC magnetic geometry unchanged. Native resistance/mass and the spatial
thermal model are updated. The separately tested stepped skew is an option,
not silently inserted into the unskewed 27-point map.

## 4. Executed software and numerical controls

Official Pyleecan execution includes MagFEMM/FEMM, Electrical/EEC_PMSM flux-linkage
coupling, VarLoadCurrent, LUTdq, Bertotti, Joule/skin, proximity, magnet loss,
ForceMT, NSGA-II/DEAP optimization, PostFunction checkpoints and two-slice Skew.
Gmsh/scikit-fem provide independently identified magnetic cross-checks and
motor stator conduction/elasticity; SciPy provides thermal and drive dynamics.
These project integrations are not claimed as native Pyleecan structural modules.

Three integration problems were detected rather than accepted as physics:

- A partial-file race in the Linux FEMM link is guarded by atomic requests and
  complete-response reads. Official simulation algorithms remain unchanged.
- Reduced stator time periodicity was unsuitable for rotor losses; geometry
  reported per_t_R=1. Accepted rotor losses use a full mechanical revolution.
- A reused FEMM file retained old currents when zero input was represented by
  None. The invalid no-load result was archived; fresh zero-current references
  and no-load torque checks validate the accepted maps.

Native generated callbacks also required cloudpickle checkpoints. Every completed
map point now has its own saved output. Export failures did not become accepted
numerical results. The accepted 27 points span magnet temperatures 20/80/150 C,
Id=-12/-6/0 Arms and Iq=0/10.814/22 Arms. Their maximum mean FE/dq torque
discrepancy is {max(abs(r['FE_mean_torque_Nm']-r['dq_torque_Nm']) for r in maps['rows']):.5f} N m.

The installed StructElmer.gen_case was actually attempted for this surface-PM
LamSlotMag rotor and failed with a missing hole attribute. Its exact traceback
is retained. The installed MagElmer source has unfinished air-gap/flux extraction.
Those alternative routes are not claimed as executed solutions. FEMM is the
working official electromagnetic route for this motor.

## 5. Accepted loss convergence

All rows below use a full mechanical revolution at 630 rpm, 10.814 Arms,
80 C magnets and 100 C winding loss resistance. Spatial symmetry is retained;
rotor time periodicity is not shortened.

| Full time positions | Global mesh factor | Mean torque N m | Stator loss W | Rotor loss W | Magnet loss W |
| --- | --- | --- | --- | --- | --- |
{lossrows}

The 144-to-288 refinement changes magnet loss by
{100*abs(full[1]['loss_W']['magnets']/full[0]['loss_W']['magnets']-1):.3f} percent
and rotor core loss by
{100*abs(full[1]['loss_W']['rotor_bertotti']/full[0]['loss_W']['rotor_bertotti']-1):.3f} percent.
The separate spatial refinement changes each non-copper loss by less than
5 percent. Reference non-copper loss is {p['reference_noncu_loss_W']:.3f} W.
These checks establish numerical stability at the reference, not measured loss
accuracy or full 3-D/PWM eddy-current validation. The speed/load envelope uses
these native frequency laws with approximate dq-flux load scaling and wider
10/30 W sensitivities.
'''
    op_rows='\n'.join(f"| {name} | {v['electrical']['Iq_rms_A']:.3f} | {v['electrical']['phase_peak_V']:.3f} | {v['electrical']['copper_W']:.2f} | {v['temperatures_C']['winding']:.2f} | {v['temperatures_C']['magnet']:.2f} |" for name,v in [('Running, 50 C',n),('Running, 70 C / 30 W',stress),('Holding, 50 C',c['holding_50C']),('Holding, 70 C',c['holding_70C'])])
    thermal_rows=[]
    for name,h,wire in [('Earlier 0.90 mm, Rwc=.25',h0,.9),('Wire only 0.95 mm, Rwc=.25',h0,.95),('Candidate, coarse mesh',h1,.95),('Candidate, fine mesh',h2,.95)]:
        rows=[v for v in h['scenarios'] if v['wire_mm']==wire]
        peak=max(v['transient'].get('buffered_hotspot_C',v['transient']['maximum_winding_hotspot_C']) for v in rows)
        thermal_rows.append(f"| {name} | {max(v['winding_hotspot_C'] for v in rows):.2f} | {peak:.2f} | {'pass' if peak<=130 else 'exceeds 130 C'} |")
    pwm_rows='\n'.join(f"| {v['bus_V']} | {v['winding_C']} / {v['magnet_C']} | {v['deadtime_bias_s']*1e6:.0f} | {v['maximum_current_vector_Arms']:.3f} | {v['maximum_phase_instantaneous_A']:.3f} | {100*v['peak_tracking_error_relative']:.3f} |" for v in drive['switched_PWM'])
    fault_rows='\n'.join(f"| {v['motor_rpm']} | {v['magnet_and_winding_C']} | {v['peak_current_vector_Arms']:.2f} | {v['minimum_Id_Arms']:.2f} |" for v in drive['short_circuit_transients'])
    knee_rows='\n'.join(f"| {v['fault_reference_rpm']} | {v['magnet_C']} | {v['H_parallel_min_kA_m']:.2f} | {v['required_negative_knee_magnitude_with_20pct_screen_kA_m']:.2f} |" for v in fault['cases'])
    struct_rows='\n'.join(f"| {v['support']} | {v['h_m']*1000:.1f} | {v['max_snapshot_displacement_um']:.3f} | {v['snapshot_von_mises_p99_MPa']:.3f} | {min(v['first_16_modes_Hz']):.0f} |" for v in structure['cases'])
    pareto_rows='\n'.join(f"| {v['turns']} | {v['wire_mm']:.2f} | {v['copper_mass_kg']:.4f} | {v['copper_loss_W']:.2f} | {100*v['bare_fill']:.1f} |" for v in opt['pareto'])
    text+=f'''
## 6. Running capability, voltage and map limits

The candidate uses the native 27-point, rotor-averaged map, with trilinear
interpolation inside its characterized current/temperature box. RMS dq voltage
includes native temperature-dependent resistance and an assumed 80 microhenry
per-phase end leakage. Shaft demand includes the native loss-law drag and a
3 W friction allowance at 630 rpm. The gearbox contributes a fixed load and
heat boundary, not an additional motor electromagnetic model.

| Candidate condition | Iq Arms | Phase peak V | Copper W | Mean winding C | Mean magnet C |
| --- | --- | --- | --- | --- | --- |
{op_rows}

The design voltage budget is 0.9 times 42/sqrt(3) = 21.824 V phase peak;
the 10 percent reserve covers control/transient headroom. At the 10 rpm
continuous point the candidate has substantial mean voltage/current margin.
The stress case raises the native non-copper reference from about
{p['reference_noncu_loss_W']:.2f} W to 30 W and sets the sink to 70 C.

The earlier .90 mm mean-temperature model reached the Id=0 voltage budget at
{p['conditional_limits']['fixed_Id0_voltage_limited_output_rpm_220Nm']:.2f}
output rpm at 220 N m. Its Id grid extends to -12 Arms for field-weakening
exploration. This is not a rated speed envelope for the corrected build: local
hot spots are only accepted for the explicitly tested 0/10 rpm duty. Some
rectangular map corners exceed the 22 Arms current circle; they characterize
fields and are excluded from current-limited operation. Temperature roots
outside 20..150 C are flagged; they cannot establish acceptance by clipping.

The 400 N m / 5 s running thermal screens use maximum currents
{p['peak_400Nm_5s'][0]['maximum_current_Arms']:.2f} and
{p['peak_400Nm_5s'][1]['maximum_current_Arms']:.2f} Arms from the warmer earlier
.90 mm design. These provide conservative imposed currents for the improved
candidate's pulse-temperature calculation. Stationary peak currents instead
come from the native angle-dependent holding torque curves. Their 1 percent
allowance covers a small torque penalty if the skew option is later selected;
it does not validate a complete skewed operating map.

## 7. Spatial heating, holding duty and cooling design

The thermal finite-element model uses the actual Pyleecan winding connection
matrix and slotted geometry. Running current distributes average heat across
the phases; holding uses the native instantaneous phase currents at eight
sampled positions. Holding current is inverted from the native torque waveform
at each position. For the candidate, every position is subjected to the largest
sampled required holding current plus 1 percent. Copper resistivity is iterated
with the local element temperature to convergence.

The original model prescribed a case temperature and calibrated the average
winding-to-case path to 0.25 K/W. Both wire sizes failed local hot holding.
The candidate calibrates that path to 0.12 K/W. Its case has distributed contact
to the sink over the full stack length, equivalent to 0.05 K/W in total, with
an assumed 8 mm aluminum circumferential wall (167 W/m/K) and 600 J/K case
capacity. The finite-element boundary includes contact, circumferential
spreading and case heat capacity. A single end-flange mount does not meet this
model definition. No radiative heat rejection is credited to the candidate.

| Winding / cooling case | Maximum steady hot spot C | Maximum 5 s screen C | Outcome |
| --- | --- | --- | --- |
{chr(10).join(thermal_rows)}

The earlier rows use the resolved 2-D temperature maximum; candidate rows add
the separately calculated conservative end-turn and case-energy bounds. Thus
even the less conservative original screen fails, while the buffered candidate
passes. End-turn heat and capacity are spread into the active slot in the 2-D
model; a 1-D adiabatic-end conduction offset at an assumed effective axial
conductivity of 25 W/m/K is added afterward. A separate total pulse-energy /
600 J/K case-rise allowance is also added, although the distributed model
already includes case capacity. This conservative superposition is a screen,
not a resolved 3-D end-turn/contact solution.

The coarse/fine candidate meshes contain {h1['nodes']} / {h2['nodes']} thermal
nodes. Each sampled .95 mm case changes by less than 2 C with refinement.
The calibrated transverse conductivities are
{h1['effective_winding_k_W_mK']:.3f} / {h2['effective_winding_k_W_mK']:.3f}
W/m/K. They represent the assumed assembled path rather than measured copper
conductivity. The calibrated whole-slot parameter includes the declared path;
it is not a minimum bulk potting conductivity. Demonstrate the assembled
0.12 / 0.05 K/W paths, including liners, impregnation, interfaces and mounting.
The additional construction study separately evaluates coated wires, potting and
slot-liner interfaces; use that result when specifying components.
The margin is about {130-buffered:.1f} C against the
chosen limit, not a material or mission uncertainty allowance.

The separate four-node thermal system has stable local eigenvalues and
2400-second warm-up integrations. It is useful for average temperatures and
feedback, but it did not replace the spatial holding check. Gear efficiency,
ambient boundary, loss coefficients and thermal contacts remain assumptions.

## 8. Switched drive, short circuits and magnet requirements

A 20 kHz three-phase SVPWM model integrates actual switch-state voltages with
80 substeps per switching period, checked against 160. It uses a 300 Hz dq PI
controller, anti-windup, native-map-derived constant differential inductances
and an assumed dead-time bias. The controller can use the full linear SVPWM
range; the operating design calculation retains its 10 percent voltage reserve.
The run is 100 ms with a 50 ms peak-current command, separate from the five-second
thermal pulse. This demonstrates the modeled drive response, not firmware,
power-semiconductor switching loss or a coupled nonlinear transient FE solution.

| Bus V | Winding / magnet C | Dead time us | Max vector Arms | Max phase A | Peak tracking error % |
| --- | --- | --- | --- | --- | --- |
{pwm_rows}

All simulated drive cases remain below 22 Arms vector magnitude and
31.113 A instantaneous phase magnitude. The native EEC_PMSM steady short-circuit
solution is checked against a 100 ms dq fault transient at fixed speed.

| Motor rpm | Winding / magnet C | Fault peak Arms | Minimum Id Arms |
| --- | --- | --- | --- |
{fault_rows}

Short-circuit currents exceed the nominal inverter current rating. Fault
isolation, current withstand and braking-energy handling must be designed for
these transients. Fixed speed and constant inductances simplify the fault model;
rotor deceleration, device faults, saturation and external inertia can change
the actual response. These results are not a certified fault-current bound.

Native FEMM H fields were then solved at four dynamic-fault dq extrema. H is
projected along each magnet's actual polarity. The following supplier knee
magnitudes include a 20 percent screening allowance:

| Fault rpm | Magnet C | Minimum parallel H kA/m | Required negative-knee magnitude kA/m |
| --- | --- | --- | --- |
{knee_rows}

An irreversible demagnetization pass is deliberately unset: no supplier
temperature-dependent knee curve was supplied. The FEMM recoil-line coercivity
is not that knee. Local magnet edge refinement, supplier curves and a saturation-
aware fault model are required to close this gate. The prescribed generic
Br20 must be at least {req['magnet_requirement']['Br20_min_T']:.2f} T and Br150
at least {req['magnet_requirement']['Br150_min_T']:.4f} T to preserve this design basis.

At cold 22 Arms, native stator B has a 99th-percentile value of about 1.82 T
and a local maximum around 2.68 T; approximately 1.45 percent of stator
element/time samples exceed the exemplar curve's 1.8 T endpoint. Those are
sample statistics rather than volume-weighted material certification. A
supplier high-field B-H curve is needed before trusting peak saturation margins.

## 9. Motor-specific mechanics and magnetic-force coupling

Official ForceMT bore pressure is transferred to the actual stator teeth in a
quadratic 2-D plane-stress elasticity model. The load transfer preserves net
force and torque, including a balancing couple, to less than 1e-6 in N / N m.
Every retained force snapshot is solved. Two meshes and clamped / compliant
distributed supports are evaluated. Winding mass is included without assigning
it structural stiffness. The table uses the cold 22 Arms native peak field.

| Support | Mesh mm | Maximum displacement um | Stress p99 MPa | First mode Hz |
| --- | --- | --- | --- | --- |
{struct_rows}

Sixteen modes and harmonic responses at 630/1890 rpm use an assumed 2 percent
modal damping. Results describe this stator/support idealization; end bells,
housing, bearings, shaft bending modes and PWM acoustic excitation are absent.
Low in-plane motion supports the clearance screen but is not a complete NVH
or assembled rotor-dynamics result.

The 12 mm shaft with an assumed 113 mm bearing span has a simple supported-beam
first critical-speed estimate of {mech['simply_supported_first_critical_rpm']:.0f}
rpm, well above the modeled 630 rpm point. Peak 8.5 N m shaft torsion gives
about {mech['shaft_torsion'][1]['von_mises_MPa']:.1f} MPa equivalent stress.
These results omit actual fits, shoulders, bearing stiffness and fatigue loads.

Thermal growth leaves a worst screened bare radial gap of
{min(v['thermal_only_gap_mm'] for v in mech['thermal_airgap']):.3f} mm before
retention, adhesive, tolerances and dynamic motion. Centrifugal pressure is
small at the duty speed; magnetic peel and differential thermal expansion
dominate the proposed retention screen. Stiff full-length adhesive can develop
large thermal edge stress, so its strength cannot be inferred from low speed.

## 10. Winding optimization and separate skew option

The actual Pyleecan OptiGenAlgNsga2Deap solver performed
{opt['native_evaluations']} evaluations. Its finite design space, six turn
counts times six wire diameters, was also evaluated exhaustively: 36 candidates,
{opt['grid_feasible']} feasible under its mean-temperature/fill/current/voltage
surrogate constraints. The nondominated results are:

| Turns per coil | Wire mm, two strands | Copper mass kg | Nominal copper W | Bare fill % |
| --- | --- | --- | --- | --- |
{pareto_rows}

The turn-scaled flux surrogate uses native resistance/mass and electrical
methods. It is not a nonlinear FE solve of each optimization individual.
Its mean-temperature feasibility did not establish holding hot-spot feasibility;
the later spatial analysis found that omission. The chosen 12-turn / .95 mm
winding adds about 41 g of copper versus .90 mm, while preserving the
characterized magnetic ampere-turn geometry. The 13-turn alternative has not
received the same full native map, fault and holding verification.

The official two-slice Skew calculation offsets two 42.5 mm axial sections by
3 mechanical degrees. Mean torque changes from {full[1]['torque_Nm']:.5f} to
{skew['torque_Nm']:.5f} N m; sampled peak-to-peak ripple changes from
{ripple0:.5f} to {ripple1:.5f} N m, a
{100*(1-ripple1/ripple0):.1f} percent reduction. Mean torque is consistent with
the two-slice cos(7.5 electrical degrees) factor. Manufacturing, axial end
effects, axial forces and a complete skewed operating map are not solved.
Use the unskewed candidate as the quantitative baseline; the skew result is a
specific promising refinement with separately stated remaining work.

## 11. Conditional construction and acceptance requirements

The build-requirements JSON translates the screens into proposed specifications:

| Item | Requirement or result |
| --- | --- |
| Winding | 12 turns/coil, two .95 mm strands; 47.6 percent bare fill; verify insulation and winding insertion |
| Thermal path | Winding-case <= .12 K/W; distributed case-sink <= .05 K/W, no radiation credit |
| Retaining wrap | .20 mm insulating nonmagnetic hoop composite; proposed hot hoop modulus {wrap['assumed_hoop_modulus_GPa']:.0f} GPa |
| Wrap hot hoop strength | At least {wrap['required_hot_hoop_strength_with_factor2_MPa']:.1f} MPa including the stated factor two |
| Wrap hot interlaminar shear | At least {wrap['required_hot_interlaminar_shear_with_factor2_MPa']:.1f} MPa in the simplified screen |
| Remaining screened gap | {wrap['conservative_remaining_gap_mm']:.3f} mm including wrap, bond, tolerance and retained elastic-deflection screens |
| Magnet bond | .05 mm compliant bond, assumed hot shear modulus 1 MPa, four axial segments |
| Required hot bond shear | At least {bond['required_hot_bond_shear_with_factor2_MPa']:.2f} MPa including factor two |
| Bearing interface concept | 12 x 32 x 10 mm nominal; grade/preload selection remains open |
| Bearing life screen | Required C >= {req['bearing_interface']['required_dynamic_capacity_N']:.0f} N for the declared 100 N / 10000 h scenario |

The wrap screen combines membrane, unsupported-gap bending, thermal mismatch
and interference stresses. The bond uses an elastic shear-lag approximation
plus torque shear. These are conditional material requirements, not strength
passes for a selected composite/adhesive. Actual laminate/contact/end retention,
creep, fatigue, vacuum compatibility and tolerances need detailed construction
and supplier properties. The assumed 8 mm full-length housing wall alone has
nonzero mass beyond the reported active motor mass; no complete mass claim is
made. The earlier concept CAD is not a released drawing of these revisions.

The motor's computed duty is credible under the stated assumptions, but release
requires measured assembled thermal paths, supplier magnet knee and high-field
steel curves, verified retention materials/geometry, protected inverter hardware
and a correlated prototype torque/loss/temperature test. Environmental and life
acceptance depend on actual mission requirements. They cannot be completed by
adding software features or interpreting test-count success as hardware proof.

## 12. Artifacts, reproduction and scope of completion

Primary machine/configuration: configs/motor_candidate.json and
results/motor/candidate/machine.json. Native maps, full-period convergence,
candidate drive, fault fields, hot spots, structural response, optimization and
construction requirements have separate component folders under results/motor.
The coverage record identifies the executed official modules and project adapters.
The reproduction manifest records source/result hashes and installed-upstream
integrity. Trusted native raw checkpoints are retained locally; portable packages
omit large pickles, solver runtimes and raw FEMM files.

Reproduction commands from the repository root:

    bash scripts/setup.sh
    python scripts/setup_extended.py
    python scripts/setup_femm.py
    OPENBLAS_NUM_THREADS=1 .venv/bin/python -m actuator.motor_study
    OPENBLAS_NUM_THREADS=1 .venv/bin/python -m pytest -q

The runner reuses complete native checkpoints and regenerates missing ones.
FEMM jobs run sequentially because the Wine/file-link session is shared.
An independent full native rerun takes substantial time. The reference loss
coefficients, 2-D constitutive/end assumptions and cooling targets remain
uncalibrated even when numerical refinement and consistency tests pass.

Pyleecan models the electric motor; it does not directly model planetary gears
as an actuator transmission. The existing actuator study uses external tools
and remains preliminary. Its gearbox ratio/efficiency are held fixed here,
as requested for this motor-first assessment. This report supersedes earlier
motor thermal conclusions, particularly average-only continuous ratings. It
does not claim every Pyleecan class applies to this PMSM, nor that all physical
product acceptance gates have been closed.
'''
    extra=out/'extensions/assessment.json'
    if extra.exists():
        text+='''
## 13. Additional verification update

Read results/motor/extensions/report.pdf for the completed additional campaign:
independent map holdouts and corner refinements, hot full-period 22 Arms losses,
real FEMM geometry optimization and material/gap/stack perturbations, static
eccentricity and magnetic-pull stability, nonlinear fault/PWM coupling and end-
leakage sensitivity, updated fault H fields, AC conductive-reaction calculations,
coated-wire/liner thermal construction and angle-resolved torque feedforward.

The 220 N m angle-resolved current/voltage screen fits the 42 V design budget.
The optional 400 N m trajectory exceeds the reserved voltage budget even when
mean voltage passes. Its combined material/geometry perturbation plus declared
loss-stress screen also does not retain the same mean-torque margin. Treat the
400 N m pulse calculations earlier in this report as nominal/sensitivity results,
not an accepted robust constant-output-torque rating. No new geometry or skewed
operating map is silently adopted. The approximate 119 C thermal result retains
its original construction and loss assumptions.
'''
    figures=make_figures(out,maps,full,fine,skew,h0,h1,h2,drive,opt,structure)
    (out/'report.md').write_text(text+'\n'+''.join(f'\n![{f.replace("_"," ")}]({f})\n' for f in figures))
    body=markdown.markdown(text,extensions=['tables','fenced_code'])
    imgs=''.join('<figure><img src="data:image/png;base64,'+base64.b64encode((out/f).read_bytes()).decode()+'"><figcaption>'+f.replace('_',' ')+'</figcaption></figure>' for f in figures)
    (out/'report.html').write_text('<!doctype html><meta charset="utf-8"><title>Space-octopus motor assessment</title><style>body{font:16px/1.6 system-ui;max-width:1100px;margin:40px auto;padding:20px;color:#152537}table{border-collapse:collapse;font-size:14px}td,th{border:1px solid #ccd5de;padding:7px}h1,h2{line-height:1.2}img{max-width:100%}pre{background:#eef2f6;padding:15px;overflow:auto}</style>'+body+imgs)
    make_pdf(out,text,figures)
    dump(out/'coverage.json',dict(status='completed',assessment='Conditional motor duty match after specified winding/cooling changes; original holding screen fails',
        official_executed=['MagFEMM/FEMM','Electrical/EEC_PMSM(fluxlink=MagFEMM)','VarLoadCurrent','LUTdq','Bertotti/Joule/Proximity/Magnet losses','ForceMT','OptiGenAlgNsga2Deap','PostFunction','two-slice Skew'],
        external_executed=['Gmsh/scikit-fem nonlinear magnetic cross-check','Spatial nonlinear thermal FE and implicit pulses','Force-conserving P2 stator elasticity/modes','SciPy thermal dynamics and switched SVPWM/fault ODE','Analytical shaft/retention/bearing/conduction screens'],
        alternatives={'StructElmer':'gen_case actually attempted; LamSlotMag.hole AttributeError before solver','MagElmer':'Installed flux/airgap extraction unfinished; not executed'},
        physical_validation=False,construction_release=False,report='report.pdf',
        additional_assessment='extensions/assessment.json' if extra.exists() else None,
        additional_report='extensions/report.pdf' if extra.exists() else None))
    return text


def make_figures(out,maps,full,fine,skew,h0,h1,h2,drive,opt,structure):
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'white'})
    figures=[]
    def save(fig,name):
        fig.tight_layout();fig.savefig(out/name,dpi=155,bbox_inches='tight');plt.close(fig);figures.append(name)
    fig,ax=plt.subplots(figsize=(9,4.8))
    for name,label in [('full_period/288','Unskewed'),('skew','Two slices, 3 mechanical degrees')]:
        torque=np.load(out/name/'native_fields.npz')['torque_Nm'];angle=np.arange(len(torque))* (360/len(torque) if name.startswith('full') else 36/len(torque))
        take=angle<36;ax.plot(angle[take],torque[take],'.-',label=label)
    ax.set(xlabel='Mechanical angle (degrees)',ylabel='Electromagnetic torque (N m)',title='Native FEMM ripple at 10.814 Arms, 80 C magnets');ax.legend();save(fig,'torque_and_skew.png')
    fig,axes=plt.subplots(1,2,figsize=(10,4.2))
    for T in [20,80,150]:
        rows=sorted([r for r in maps['rows'] if r['magnet_C']==T and r['Id_rms_A']==0],key=lambda r:r['Iq_rms_A'])
        axes[0].plot([r['Iq_rms_A'] for r in rows],[r['FE_mean_torque_Nm'] for r in rows],'o-',label=f'{T} C')
    axes[0].set(xlabel='Iq (Arms)',ylabel='Mean EM torque (N m)',title='Native map, Id = 0');axes[0].legend()
    for k,label in [('stator_bertotti','Stator core'),('magnets','Magnets')]:
        axes[1].plot(range(3),[v['loss_W'][k] for v in full+[fine]],'o-',label=label)
    axes[1].set(xticks=range(3),xticklabels=['144','288','144 finer mesh'],ylabel='Loss (W)',title='Full mechanical-period loss convergence');axes[1].legend();save(fig,'maps_and_losses.png')
    fig,axes=plt.subplots(1,2,figsize=(11,4.7));labels=[];values=[]
    for label,h,wire in [('Earlier .90',h0,.9),('Wire-only .95',h0,.95),('Candidate coarse',h1,.95),('Candidate fine',h2,.95)]:
        a=[v for v in h['scenarios'] if v['wire_mm']==wire];labels.append(label);values.append(max(v['transient'].get('buffered_hotspot_C',v['transient']['maximum_winding_hotspot_C']) for v in a))
    axes[0].bar(range(4),values,color=['#c84d4d','#c84d4d','#267c90','#267c90']);axes[0].set(xticks=range(4),xticklabels=labels,ylabel='Maximum 5 s temperature screen (C)',title='Original fails; revised cooling passes');axes[0].tick_params(axis='x',rotation=20)
    for h,label in [(h1,'Coarse'),(h2,'Fine')]:
        a=[v for v in h['scenarios'] if v['wire_mm']==.95 and v['case'].startswith('hold70')];axes[1].plot(range(len(a)),[v['transient']['buffered_hotspot_C'] for v in a],'o-',label=label)
    for ax in axes:ax.axhline(130,color='#ad3232',ls='--',label='130 C limit')
    axes[1].set(xlabel='Sampled holding position',ylabel='Buffered 5 s hot spot (C)',title='400 N m pulse after 220 N m hold, 70 C sink');axes[1].legend();save(fig,'holding_hotspots.png')
    fig,axes=plt.subplots(2,1,figsize=(9,6),sharex=True);a=np.load(out/'candidate_drive/PWM_42_1e-06_130C.npz')['data'];step=10
    axes[0].plot(a[::step,0]*1000,a[::step,2],label='Iq');axes[0].plot(a[::step,0]*1000,a[::step,6],ls='--',label='Command');axes[0].axhline(22,color='#ad3232',ls=':');axes[0].set(ylabel='Iq (Arms)',title='42 V / 20 kHz switched drive, winding 130 C / magnets 150 C');axes[0].legend()
    for j,label in enumerate(['ia','ib','ic']):axes[1].plot(a[::step,0]*1000,a[::step,3+j],lw=.8,label=label)
    axes[1].set(xlabel='Time (ms)',ylabel='Instantaneous phase current (A)');axes[1].legend(ncol=3);save(fig,'switched_drive.png')
    fig,axes=plt.subplots(1,2,figsize=(10,4.4));faults=drive['short_circuit_transients']
    for T in [20,150]:
        a=[v for v in faults if v['magnet_and_winding_C']==T];axes[0].plot([v['motor_rpm'] for v in a],[v['peak_current_vector_Arms'] for v in a],'o-',label=f'{T} C')
    axes[0].axhline(22,color='#ad3232',ls='--',label='Nominal inverter limit');axes[0].set(xlabel='Motor speed (rpm)',ylabel='Fault peak current vector (Arms)',title='Fixed-speed short-circuit transient');axes[0].legend()
    for feasible,col,label in [(False,'#bfc8ce','Excluded'),(True,'#267c90','Mean-model feasible')]:
        a=[v for v in opt['grid'] if v['feasible']==feasible];axes[1].scatter([v['copper_mass_kg'] for v in a],[v['copper_loss_W'] for v in a],c=col,label=label)
    axes[1].set(xlabel='Winding copper mass (kg)',ylabel='Nominal copper loss (W)',title='Native NSGA-II + exhaustive 36-point grid');axes[1].legend();save(fig,'faults_and_optimization.png')
    fig,axes=plt.subplots(1,2,figsize=(10,4.2));a=[v for v in structure['cases'] if v['h_m']==.0012];x=np.arange(len(a))
    axes[0].bar(x,[v['max_snapshot_displacement_um'] for v in a],color='#267c90');axes[0].set(xticks=x,xticklabels=[v['support'] for v in a],ylabel='Peak displacement (um)',title='Cold 22 Arms stator, refined mesh')
    axes[1].bar(x,[min(v['first_16_modes_Hz'])/1000 for v in a],color='#267c90');axes[1].set(xticks=x,xticklabels=[v['support'] for v in a],ylabel='First in-plane mode (kHz)',title='Sensitivity to assumed mounting')
    for ax in axes:ax.tick_params(axis='x',rotation=15)
    save(fig,'motor_structure.png');return figures


if __name__=='__main__':build()
