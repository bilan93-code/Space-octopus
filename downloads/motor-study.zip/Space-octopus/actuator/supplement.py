"""Computed mass and air-gap force screens, usable after a saved run."""
import numpy as np
from .magnetics import MagneticModel,MU0
from .run import phase_q


def supplement(machine,config,fe=None,sol=None):
    if fe is None:
        fe=MagneticModel(machine,config,h=.0008)
    if sol is None:
        no=fe.nonlinear(fe.solve())
        sol=fe.nonlinear(fe.solve(9*phase_q(no['phase_flux_Wb'])))
    radius=(machine.rotor.comp_radius_mec()+machine.stator.comp_radius_mec())/2
    br,bt=fe.airgap_fields(sol,radius)
    theta=np.arange(len(br))*2*np.pi/len(br)
    normal=(br**2-bt**2)/(2*MU0);tangent=br*bt/MU0
    # Integrate traction over the cylindrical rotor surface. Symmetry should
    # cancel the net force in the ideal concentric model, not the local pressure.
    fx=2*np.pi*radius*machine.rotor.L1*np.mean(normal*np.cos(theta)-tangent*np.sin(theta))
    fy=2*np.pi*radius*machine.rotor.L1*np.mean(normal*np.sin(theta)+tangent*np.cos(theta))
    # Pressure is interface data for future structural solves; no structural
    # finite-element result is claimed here.
    mass_rotor=machine.rotor.comp_masses();mass_stator=machine.stator.comp_masses()
    mass_shaft=np.pi*config['motor']['shaft_radius_m']**2*.13*config['motor']['steel_density_kg_m3']
    return dict(mass_screen=dict(rotor=mass_rotor,stator=mass_stator,shaft_assumed_kg=mass_shaft,motor_material_total_kg=mass_rotor['Mtot']+mass_stator['Mtot']+mass_shaft,excludes='motor housing, bearings, coupling, encoder, gearbox and drive electronics'),force_screen=dict(normal_pressure_peak_Pa=float(normal.max()),normal_pressure_mean_Pa=float(normal.mean()),net_force_x_N=float(fx),net_force_y_N=float(fy),net_force_N=float(np.hypot(fx,fy)),note='Ideal concentric 2-D, 9 Arms; net-force residual includes discretization. Eccentricity and external arm loads not modelled.'))
