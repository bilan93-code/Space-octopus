"""Motor suitability using native rotor-averaged FEMM maps and native loss laws."""
import copy,json,pickle
from pathlib import Path
import numpy as np
from scipy.interpolate import RegularGridInterpolator
from scipy.optimize import root,brentq
from scipy.integrate import solve_ivp
from .machine import build_machine
from .coupled import thermal_outflow
from .run import dump
ROOT=Path(__file__).resolve().parents[1]


class MotorModel:
    def __init__(self):
        self.c=json.loads((ROOT/'configs/revised.json').read_text());self.m=build_machine(self.c)
        rows=json.loads((ROOT/'results/motor/maps/summary.json').read_text())['rows']
        self.axes=([20.,80.,150.],[-12.,-6.,0.],[0.,10.814,22.]);self.lookup={}
        for name in ['Phid_rms_Wb','Phiq_rms_Wb','FE_mean_torque_Nm']:
            values=np.array([next(r[name] for r in rows if r['magnet_C']==T and r['Id_rms_A']==Id and r['Iq_rms_A']==Iq) for T in self.axes[0] for Id in self.axes[1] for Iq in self.axes[2]]).reshape(3,3,3)
            self.lookup[name]=RegularGridInterpolator(self.axes,values,bounds_error=True)
        with (ROOT/'results/motor/full_period/288/native_output.pkl').open('rb') as f:native=pickle.load(f)
        self.loss_coeff={k:v.coeff_dict.copy() for k,v in native.loss.loss_dict.items()}
        self.reference_flux2=sum(float(self.lookup[n]([80,0,10.814]))**2 for n in ['Phid_rms_Wb','Phiq_rms_Wb'])
        self.reference_noncu=sum(self.loss(k,52.5) for k in ['stator_bertotti','rotor_bertotti','magnets'])

    def loss(self,name,f):return sum(value*f**float(power) for power,value in self.loss_coeff[name].items())

    def state(self,temperatures,Tout,rpm_out,c,Id=0.,core_ref_W=None):
        Tw,Tm,case,gear=temperatures;n=rpm_out*63;omega=n*2*np.pi/60;freq=abs(n)*5/60
        Tmap=float(np.clip(Tm,20,150));R=self.m.stator.comp_resistance_wind(float(Tw));limit=np.sqrt(max(0,22**2-Id**2))
        core_factor=1 if core_ref_W is None else core_ref_W/self.reference_noncu
        def quantities(Iq):
            point=[Tmap,Id,Iq];pd=float(self.lookup['Phid_rms_Wb'](point));pq=float(self.lookup['Phiq_rms_Wb'](point));torque=float(self.lookup['FE_mean_torque_Nm'](point))
            flux2=(pd*pd+pq*pq)/self.reference_flux2
            losses={k:self.loss(k,freq)*flux2*core_factor for k in ['stator_bertotti','rotor_bertotti','magnets','proximity']}
            friction=3*abs(n)/630;drag=(sum(losses[k] for k in ['stator_bertotti','rotor_bertotti','magnets'])+friction)/abs(omega) if omega else 0
            return pd,pq,torque,losses,friction,drag
        target=Tout/(63*.8)
        available=quantities(limit);qmax_net=available[2]-available[5]
        Iq=brentq(lambda q:quantities(q)[2]-quantities(q)[5]-target,0,limit) if target<=qmax_net else limit
        pd,pq,Tem,losses,friction,drag=quantities(Iq)
        Lend=c['motor']['assumed_end_leakage_H']
        Ud=R*Id-2*np.pi*freq*(pq+Lend*Iq);Uq=R*Iq+2*np.pi*freq*(pd+Lend*Id)
        copper=3*R*(Id*Id+Iq*Iq)+(self.loss('copper',freq)-self.loss('copper',0))*(Id*Id+Iq*Iq)/10.814**2
        power_out=Tout*rpm_out*2*np.pi/60;gearheat=abs(power_out)*(.8**-1-1)
        heat=np.array([copper+losses['proximity'],losses['rotor_bertotti']+losses['magnets']+.5*friction,losses['stator_bertotti']+.5*friction,gearheat])
        pin=power_out+heat.sum();vp=np.sqrt(2)*np.hypot(Ud,Uq)
        row=dict(Id_rms_A=Id,Iq_rms_A=Iq,current_vector_Arms=float(np.hypot(Id,Iq)),phase_peak_V=float(vp),
            electromagnetic_torque_Nm=Tem,shaft_torque_Nm=Tem-drag,required_shaft_torque_Nm=target,
            copper_W=copper,loss_W=losses,friction_W=friction,output_power_W=power_out,heat_W=float(heat.sum()),
            DC_input_W=float(pin/.97),motor_efficiency=float((Tem-drag)*omega/(Tem*omega+copper+losses['proximity'])) if n else 0.,
            system_efficiency=float(power_out/(pin/.97)) if power_out else 0.,
            voltage_ok=bool(vp<=c['drive']['bus_min_V']*.9/np.sqrt(3)),torque_ok=bool(target<=qmax_net),
            map_temperature_ok=bool(20<=Tm<=150),loss_model='Native full-period reference loss laws with dq-flux magnitude scaling; load dependence approximate')
        row['continuous_current_density_A_mm2']=float(np.hypot(Id,Iq)/(self.m.stator.winding.conductor.comp_surface_active()*1e6))
        row['current_density_10A_mm2_screen']=row['continuous_current_density_A_mm2']<=10
        return heat,row

    def steady(self,Tout=220,rpm_out=10,sink=50,Rwc=.25,Rcase=.15,core_ref_W=None,Id=0.):
        c=copy.deepcopy(self.c);c['thermal'].update(sink_C=sink,R_winding_case_K_W=Rwc,R_motor_case_sink_K_W=Rcase)
        def residual(t):return thermal_outflow(c,t)[0]-self.state(t,Tout,rpm_out,c,Id,core_ref_W)[0]
        sol=root(residual,np.array([80,70,65,75])+sink-50)
        if not sol.success or np.max(np.abs(residual(sol.x)))>1e-5:raise RuntimeError('Native-map thermal solve failed: '+sol.message)
        heat,e=self.state(sol.x,Tout,rpm_out,c,Id,core_ref_W)
        return dict(temperatures_C=dict(zip(['winding','magnet','case','gear'],sol.x.tolist())),electrical=e,
            thermal_residual_W=float(np.max(np.abs(residual(sol.x)))),thermal_ok=bool(sol.x[0]<=130 and sol.x[1]<=150),
            overall_conditional_pass=bool(sol.x[0]<=130 and sol.x[1]<=150 and e['voltage_ok'] and e['torque_ok'] and e['map_temperature_ok']))


def run(out):
    out.mkdir(parents=True,exist_ok=True);model=MotorModel();nominal=model.steady()
    scenarios=[]
    for sink in [50,70]:
        for Rwc in [.25,.5,.8]:
            for Rcase in [.15,.35]:
                for core in [None,10.,30.]:
                    r=model.steady(sink=sink,Rwc=Rwc,Rcase=Rcase,core_ref_W=core)
                    scenarios.append(dict(sink_C=sink,R_winding_case_K_W=Rwc,R_case_sink_K_W=Rcase,core_reference_W=core,**r))
    robust=model.steady(sink=70,core_ref_W=30)
    duty=[]
    for sink,core,initial in [(50,None,nominal),(70,30,robust)]:
        c=copy.deepcopy(model.c);c['thermal']['sink_C']=sink
        capacity=np.array([c['thermal'][k] for k in ['C_winding_J_K','C_rotor_J_K','C_motor_case_J_K','C_gear_case_J_K']])
        start=np.array(list(initial['temperatures_C'].values()))
        def rhs(t,T):return (model.state(T,400,10,c,core_ref_W=core)[0]-thermal_outflow(c,T)[0])/capacity
        sol=solve_ivp(rhs,[0,5],start,t_eval=np.linspace(0,5,101),rtol=1e-7,atol=1e-8)
        if not sol.success:raise RuntimeError(sol.message)
        electrical=[model.state(T,400,10,c,core_ref_W=core)[1] for T in sol.y.T]
        duty.append(dict(sink_C=sink,core_reference_W=core,time_s=sol.t.tolist(),temperatures_C=sol.y.T.tolist(),
            maximum_current_Arms=max(v['current_vector_Arms'] for v in electrical),maximum_phase_peak_V=max(v['phase_peak_V'] for v in electrical),
            thermal_ok=bool(sol.y[0].max()<=130 and sol.y[1].max()<=150),
            voltage_current_ok=all(v['voltage_ok'] and v['torque_ok'] for v in electrical)))
    envelope=[]
    for speed in [0,5,10,12,14,15,17.5,20]:
        for torque in [110,220,302.4,400]:
            cases=[dict(Id_command_Arms=id,**model.steady(torque,speed,Id=id)) for id in [0,-3,-6,-9,-12]]
            valid=[v for v in cases if v['overall_conditional_pass']]
            best=min(valid,key=lambda v:v['electrical']['DC_input_W']) if valid else cases[0]
            envelope.append(dict(output_rpm=speed,output_Nm=torque,any_characterized_Id_pass=bool(valid),best=best,Id0=cases[0]))
    def crossing(fun,lo,hi):
        try:return float(brentq(fun,lo,hi,xtol=1e-5))
        except ValueError:return None
    limits=dict(critical_winding_case_K_W_at_70C_sink_30W_reference=crossing(lambda R:model.steady(sink=70,Rwc=R,core_ref_W=30)['temperatures_C']['winding']-130,.1,1.),
        critical_case_sink_K_W_at_70C_sink_30W_reference=crossing(lambda R:model.steady(sink=70,Rcase=R,core_ref_W=30)['temperatures_C']['winding']-130,.05,.8),
        fixed_Id0_voltage_limited_output_rpm_220Nm=crossing(lambda speed:model.steady(rpm_out=speed)['electrical']['phase_peak_V']-42*.9/np.sqrt(3),5,25))
    hold=model.steady(220,0)
    stability=[]
    capacity=np.array([model.c['thermal'][k] for k in ['C_winding_J_K','C_rotor_J_K','C_motor_case_J_K','C_gear_case_J_K']])
    for sink,core,r in [(50,None,nominal),(70,30,robust)]:
        c=copy.deepcopy(model.c);c['thermal']['sink_C']=sink;t=np.array(list(r['temperatures_C'].values()))
        def flow(T):return (model.state(T,220,10,c,core_ref_W=core)[0]-thermal_outflow(c,T)[0])/capacity
        jac=np.column_stack([(flow(t+np.eye(4)[j]*.01)-flow(t-np.eye(4)[j]*.01))/.02 for j in range(4)])
        eigen=np.linalg.eigvals(jac)
        warm=solve_ivp(lambda time,T:flow(T),[0,2400],[sink]*4,t_eval=np.linspace(0,2400,121),rtol=1e-7,atol=1e-8)
        if not warm.success:raise RuntimeError(warm.message)
        stability.append(dict(sink_C=sink,core_reference_W=core,thermal_eigenvalues_real_per_s=eigen.real.tolist(),
            locally_stable=bool(np.max(eigen.real)<0),time_s=warm.t.tolist(),warmup_temperatures_C=warm.y.T.tolist()))
    old=model.m;model.m=build_machine(dict(model.c,motor=dict(model.c['motor'],wire_diameter_m=.00095)))
    wire_proposal=dict(nominal=model.steady(),robust=model.steady(sink=70,core_ref_W=30),
        assumption='Same magnetic geometry and DC ampere-turn fields; change only conductor diameter to 0.95 mm and native resistance/mass. Winding conductivity/capacity unchanged conservatively.')
    model.m=old
    summary=dict(status='completed',engine='Native rotor-averaged FEMM maps and native full-period loss coefficients -> nonlinear thermal/voltage/current coupling',
        reference_noncu_loss_W=model.reference_noncu,native_loss_coefficients=model.loss_coeff,nominal=nominal,robust_declared_contacts=robust,
        holding=hold,thermal_contact_scenarios=scenarios,peak_400Nm_5s=duty,torque_speed_Id_sweep=envelope,conditional_limits=limits,
        thermal_stability_and_warmup=stability,wire_0p95mm_proposal=wire_proposal,
        limitations=['42 V minimum bus, 10 rpm output, 0.8 gearbox efficiency and cooling are assumptions from the design brief',
            'Native loss coefficients are calibrated only to the simulated reference; load scaling by dq flux magnitude is approximate',
            '10/30 W references are sensitivity cases, not measured or proven upper bounds',
            '80 microhenry end leakage is assumed per phase; supplier/hardware correlation is absent',
            'Current/temperature interpolation stays inside the characterized map; no unrestricted extrapolation',
            'The gearbox is a fixed load/heat boundary here, not a new actuator design'])
    dump(out/'summary.json',summary)
    pd=float(model.lookup['Phid_rms_Wb']([80,0,0]));pq=float(model.lookup['Phiq_rms_Wb']([80,0,10.814]))
    ld=(float(model.lookup['Phid_rms_Wb']([80,0,10.814]))-float(model.lookup['Phid_rms_Wb']([80,-6,10.814])))/6+.00008
    lq=pq/10.814+.00008
    dump(ROOT/'results/motor/performance_parameters.json',dict(psi80_rms_Wb=pd,Ld_H=ld,Lq_H=lq,
        continuous_Iq_Arms=nominal['electrical']['Iq_rms_A'],peak_Iq_Arms=max(max(v['maximum_current_Arms'] for v in duty),model.state([130,150,100,100],400,10,model.c,core_ref_W=30)[1]['Iq_rms_A']),
        reference_noncu_W=model.reference_noncu,
        source='Native map finite differences plus assumed 80 microhenry end leakage'))
    return summary


if __name__=='__main__':run(ROOT/'results/motor/performance')
