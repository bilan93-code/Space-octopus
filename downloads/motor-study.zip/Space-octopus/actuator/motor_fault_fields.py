"""Native magnet-H snapshots at the nonlinear map-driven fault extrema."""
import json,pickle
import numpy as np
from .motor_campaign import solve_case
from .runtime import ROOT
from .run import dump


def run(summary):
    out=ROOT/'results/motor/extensions/nonlinear_fault_fields';out.mkdir(parents=True,exist_ok=True)
    if (out/'summary.json').exists():return json.loads((out/'summary.json').read_text())
    with (ROOT/'results/motor/full_period/288/native_output.pkl').open('rb') as f:ref=pickle.load(f)
    ms=ref.mag.meshsolution;xy=ms.mesh.node.coordinate;tri=ms.mesh.element_dict['triangle'].connectivity.astype(int)
    centers=xy[tri].mean(axis=1);phi=np.arctan2(centers[:,1],centers[:,0])
    bx=ms.solution_dict['B'].field.components['comp_x'].values;by=ms.solution_dict['B'].field.components['comp_y'].values
    polarity={}
    for name,ids in ms.group.items():
        if name.startswith('rotor magnets_'):
            ids=np.asarray(ids);polarity[name]=float(np.sign(np.median(bx[:,ids]*np.cos(phi[ids])+by[:,ids]*np.sin(phi[ids]))))
    del ref,ms,bx,by
    c=json.loads((ROOT/'configs/motor_candidate.json').read_text());rows=[]
    for row in summary['faults']:
        if row['mode']!='fixed speed' or row['motor_rpm']==945:continue
        choices=[row]+[v for v in summary['end_leakage_sensitivity'] if v['T_C']==row['T_C'] and v['motor_rpm']==row['motor_rpm']]
        row=min(choices,key=lambda v:v['minimum_Id_Arms'])
        folder=out/f"{row['T_C']}C_{row['motor_rpm']}rpm"
        solve_case(c,folder,require_output=True,nt=240,na=32,Id=row['minimum_Id_Arms'],Iq=row['Iq_at_minimum_Id_Arms'],
            rpm=float(row['motor_rpm']),magnet_C=row['magnet_C'],winding_C=row['winding_C'])
        with (folder/'native_output.pkl').open('rb') as f:r=pickle.load(f)
        mesh=r.mag.meshsolution;xy=mesh.mesh.node.coordinate;tri=mesh.mesh.element_dict['triangle'].connectivity.astype(int)
        ctr=xy[tri].mean(axis=1);phi=np.arctan2(ctr[:,1],ctr[:,0]);values=[]
        hx=mesh.solution_dict['H'].field.components['comp_x'].values;hy=mesh.solution_dict['H'].field.components['comp_y'].values
        for name,ids in mesh.group.items():
            if name.startswith('rotor magnets_'):
                ids=np.asarray(ids);values.append((polarity[name]*(hx[:,ids]*np.cos(phi[ids])+hy[:,ids]*np.sin(phi[ids]))).ravel())
        h=np.concatenate(values);rows.append(dict(magnet_C=row['magnet_C'],winding_C=row['winding_C'],motor_rpm=row['motor_rpm'],
            end_leakage_H=row.get('end_leakage_H',.00008),
            sampled_peak_outward_magnetic_traction_MPa=max(0.,-float(r.force.AGSF.components['radial'].values.min()))/1e6,
            Id_Arms=row['minimum_Id_Arms'],Iq_Arms=row['Iq_at_minimum_Id_Arms'],H_parallel_min_kA_m=float(h.min()/1000),
            required_negative_knee_magnitude_with_20pct_screen_kA_m=float(-1.2*h.min()/1000),irreversible_demagnetization_pass=None))
        dump(out/'progress.json',rows)
    result=dict(status='completed',engine='Official MagFEMM H fields at nonlinear map-driven fixed-speed fault extrema',cases=rows,
        snapshot_selection='Most negative Id among 0/80/160 microhenry declared end-leakage cases at each temperature/speed',
        limitations=['Supplier irreversible knee/recoil curves still absent; no irreversible-demagnetization pass',
            'Rotor-averaged dynamic trajectory followed by spatial H snapshots, not full transient electromagnetic FE',
            'Reduced-period histories sample H extrema only; associated rotor-loss exports are not accepted loss qualification'])
    dump(out/'summary.json',result);return result
