"""Angle-resolved current/voltage needed for constant actuator torque.

Uses native instantaneous FE torque and dq flux waveforms, not just their means.
This is a quasistatic feedforward trajectory, not implemented servo firmware.
"""
import json,cloudpickle
import numpy as np
from scipy.interpolate import CubicSpline
from .machine import build_machine
from pyleecan.Functions.Electrical.dqh_transformation import n2dqh_DataTime
from .runtime import ROOT
from .run import dump


def run():
    out=ROOT/'results/motor/extensions/torque_feedforward';out.mkdir(parents=True,exist_ok=True)
    c=json.loads((ROOT/'configs/motor_candidate.json').read_text());m=build_machine(c)
    period=2*np.pi/10;theta=np.arange(720)*period/720;omega=630*2*np.pi/60;rows=[]
    for T in [20,80,150]:
        curves=[]
        for iq in [0.,10.814,22.]:
            with (ROOT/f'results/motor/maps/{T}C/point_0.0_{iq}.pkl').open('rb') as f:r=cloudpickle.load(f)
            winding=r.mag.Phi_wind_slice[r.simu.machine.stator.get_label()].get_data_along('time','phase','z=integrate')
            dq=n2dqh_DataTime(winding,is_dqh_rms=True,phase_dir=r.elec.phase_dir);values=dq.get_along('time','phase')[dq.symbol]
            torque=r.mag.Tem.values.ravel();N=len(torque);grid=np.linspace(0,period,N+1)
            samples=np.c_[torque,values[:N,:2]]
            curves.append(CubicSpline(grid,np.vstack([samples,samples[:1]]),bc_type='periodic')(theta))
        curves=np.array(curves)
        for target in [220,400]:
            for drag in [6.5,33.]:
                required=target/(63*.8)+drag/omega
                wanted=[];phi=[];actual=[]
                for j in range(len(theta)):
                    torques=curves[:,j,0]
                    if not np.all(np.diff(torques)>0):raise RuntimeError('Nonmonotone native instantaneous torque interpolation')
                    iq=float(np.interp(required,torques,[0.,10.814,22.]))
                    # Preserve the required value beyond 22 as a failed limit,
                    # rather than hiding it behind np.interp endpoint clipping.
                    if required>torques[-1]:iq=22+(required-torques[-1])/(torques[-1]-torques[-2])*(22-10.814)
                    wanted.append(iq);clipped=min(iq,22.)
                    phi.append([float(np.interp(clipped,[0.,10.814,22.],curves[:,j,k])) for k in [1,2]])
                    actual.append(float(np.interp(clipped,[0.,10.814,22.],torques)))
                iq=np.array(wanted);flux=np.asarray(phi);flux[:,1]+=.00008*np.minimum(iq,22.)
                derivative=CubicSpline(np.r_[theta,period],np.vstack([flux,flux[:1]]),bc_type='periodic')(theta,1)*omega
                R=m.stator.comp_resistance_wind(130);ud=derivative[:,0]-5*omega*flux[:,1]
                uq=R*np.minimum(iq,22.)+derivative[:,1]+5*omega*flux[:,0];vp=np.sqrt(2)*np.hypot(ud,uq)
                feasible=bool(iq.max()<=22 and vp.max()<=42*.9/np.sqrt(3))
                row=dict(magnet_C=T,winding_C=130,output_torque_Nm=target,motor_drag_allowance_W=drag,
                    minimum_required_Iq_Arms=float(iq.min()),maximum_required_Iq_Arms=float(iq.max()),
                    maximum_phase_voltage_peak_V=float(vp.max()),fraction_positions_exceed_current_limit=float(np.mean(iq>22)),
                    design_voltage_budget_V=float(42*.9/np.sqrt(3)),full_linear_SVPWM_V=float(42/np.sqrt(3)),
                    mean_feasible_output_with_22A_clipping_Nm=float((np.mean(actual)-drag/omega)*63*.8),
                    quasistatic_current_and_voltage_screen=feasible)
                rows.append(row)
                np.savez_compressed(out/f'{T}C_{target}Nm_{drag}W.npz',theta=theta,Iq=iq,phase_voltage_peak=vp,
                    output_torque_clipped_Nm=(np.array(actual)-drag/omega)*63*.8)
    result=dict(status='completed',engine='Native angle-resolved nonlinear FEMM torque/flux waveforms -> inverse torque and full dq flux-derivative voltage',
        cases=rows,limitations=['Quasistatic feedforward requirement, not verified closed-loop firmware or sensor timing',
            '24 native positions per 36 mechanical degrees, periodic cubic angle interpolation and piecewise current interpolation',
            'Currents above 22 Arms are flagged; associated flux/voltage is evaluated only at the characterized 22 Arms ceiling',
            'No gearbox backlash/compliance or arm mechanical filtering; output torque uses a fixed ratio/efficiency boundary',
            'Skew remains separately evaluated; its complete angle/temperature/current map is not substituted here'])
    dump(out/'summary.json',result);return result


if __name__=='__main__':run()
