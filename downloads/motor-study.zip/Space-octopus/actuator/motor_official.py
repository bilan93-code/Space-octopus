"""Reproduce the installed structural-coupling compatibility check honestly."""
import json,traceback
from pyleecan.Classes.StructElmer import StructElmer
from pyleecan.Classes.Simu1 import Simu1
from pyleecan.Classes.Output import Output
from .machine import build_machine
from .runtime import ROOT
from .run import dump


def run():
    out=ROOT/'results/motor/official_couplings';out.mkdir(parents=True,exist_ok=True)
    c=json.loads((ROOT/'configs/motor_candidate.json').read_text())
    struct=StructElmer(include_magnets=True)
    simu=Simu1(machine=build_machine(c),struct=struct)
    output=Output(simu=simu,path_result=str(out))
    try:
        struct.gen_case(output,{'rotor':['Rotor_Lamination_Body','Rotor_Magnet_0_Body']})
    except Exception as exc:
        (out/'struct_elmer_exception.txt').write_text(traceback.format_exc())
        result=dict(status='blocked',native_solver_executed=False,exception=repr(exc),
            stage='Unmodified StructElmer.gen_case for actual LamSlotMag surface-PM rotor',
            fallback='Motor-specific analytical/mechanical FE screens; not claimed as native StructElmer')
    else:
        result=dict(status='case_generated_solver_not_run',native_solver_executed=False,
            note='Compatibility changed; case generation alone is not structural analysis')
    dump(out/'struct_elmer_status.json',result)
    return result


if __name__=='__main__':run()
