"""Spatial winding hot spots, including static phase heating and 5 s pulses.

Effective transverse winding conductivity is calibrated to the declared average
winding-to-case thermal resistance, not presented as a measured material property.
"""
import json,cloudpickle
import numpy as np
from scipy.optimize import brentq
from scipy.sparse.linalg import splu
from skfem import MeshTri,Basis,FacetBasis,ElementTriP1,BilinearForm,LinearForm,asm
from skfem.helpers import dot,grad
from pyleecan.Functions.labels import decode_label
from .machine import build_machine
from .magnetics import MagneticModel
from .run import dump
from .runtime import ROOT
from .motor_performance import MotorModel


def run(out,Rtarget=.25,h=.0015):
    out.mkdir(parents=True,exist_ok=True);c=json.loads((ROOT/'configs/revised.json').read_text());m=build_machine(c)
    performance=json.loads((ROOT/'results/motor/performance/summary.json').read_text())
    model=MotorModel();waveforms=[]
    if Rtarget<=.12:model.c['thermal']['case_emissivity']=0.
    for temp in [20,80,150]:
        loaded=[]
        for iq in [0.,10.814,22.]:
            with (ROOT/f'results/motor/maps/{temp}C/point_0.0_{iq}.pkl').open('rb') as stream:point=cloudpickle.load(stream)
            loaded.append(np.asarray(point.mag.Tem.values).ravel())
            if temp==80 and iq==10.814:phase_units=point.elec.get_Is().values[:8]/iq
        waveforms.append(loaded)
    waveforms=np.asarray(waveforms)
    def position_current(Tmag,pose,Tout):
        torque=[np.interp(Tmag,[20,80,150],waveforms[:,j,pose]) for j in range(3)]
        return float(np.interp(Tout/(63*.8),torque,[0.,10.814,22.]))
    fe=MagneticModel(m,c,h=h)
    chosen=np.array([('Stator' in fe.labels[r] and ('_Lamination' in fe.labels[r] or '_Winding' in fe.labels[r])) for r in fe.region])
    tri=fe.mesh.t[:,chosen];nodes=np.unique(tri);mesh=MeshTri(fe.mesh.p[:,nodes],np.searchsorted(nodes,tri),sort_t=False)
    basis=Basis(mesh,ElementTriP1());area=basis.dx.sum(axis=1);regions=fe.region[chosen]
    copper=np.array(['_Winding' in fe.labels[r] for r in regions]);steel=~copper
    boundary=np.where(np.isclose(np.linalg.norm(mesh.p,axis=0),m.stator.Rext,atol=1e-8))[0];free=basis.complement_dofs(boundary)
    conn=m.stator.winding.get_connection_mat(12);L=c['motor']['stack_m']
    @BilinearForm
    def conduct(u,v,w):return w.k*dot(grad(u),grad(v))
    @LinearForm
    def heat(v,w):return w.q*v
    def rhs(power):return asm(heat,basis,q=(power/(area*L))[:,None]*np.ones_like(basis.dx))
    def mean_winding(T):return float(np.sum(area[copper]*basis.interpolate(T).value.mean(axis=1)[copper])/area[copper].sum())
    unit=np.zeros(mesh.nelements);unit[copper]=area[copper]/area[copper].sum();bunit=rhs(unit)
    def stiffness(kw):
        k=np.full(mesh.nelements,20.);k[copper]=kw
        return asm(conduct,basis,k=k[:,None]*np.ones_like(basis.dx))
    def resistance(kw):
        K=stiffness(kw);x=np.zeros(basis.N);x[free]=splu(K[free][:,free].tocsc()).solve(bunit[free]);return mean_winding(x)
    kw=brentq(lambda k:resistance(k)-Rtarget,.005,2.)
    calibrated_resistance=resistance(kw)
    K=stiffness(kw);factor=splu(K[free][:,free].tocsc());alpha=.00393
    distributed=Rtarget<=.12
    if distributed:
        edges=mesh.boundary_facets();centers=mesh.p[:,mesh.facets[:,edges]].mean(axis=1)
        outer=edges[np.linalg.norm(centers,axis=0)>m.stator.Rext-.0001]
        fb=FacetBasis(mesh,ElementTriP1(),facets=outer);circumference=2*np.pi*m.stator.Rext
        hcontact=1/(.05*circumference*L)
        @BilinearForm
        def contact(u,v,w):return hcontact*u*v
        @BilinearForm
        def spreading(u,v,w):
            du=-w.n[1]*u.grad[0]+w.n[0]*u.grad[1];dv=-w.n[1]*v.grad[0]+w.n[0]*v.grad[1]
            return 167*.008*du*dv
        @BilinearForm
        def case_capacity(u,v,w):return 600/(circumference*L)*u*v
        @LinearForm
        def edge_unit(v,w):return v
        edge=asm(edge_unit,fb);sink_vector=hcontact*edge
        K=K+asm(contact,fb)+asm(spreading,fb);free=np.arange(basis.N)
        factor=splu(K.tocsc());Mcase=asm(case_capacity,fb)
    results=[]
    for wire in [.0009,.00095]:
        cm=dict(c,motor=dict(c['motor'],wire_diameter_m=wire));machine=build_machine(cm);R20=machine.stator.comp_resistance_wind(20)
        fill=48*np.pi*(wire/2)**2/machine.stator.slot.comp_surface_active()
        rhoCp=np.full(mesh.nelements,7650*.95*460.)
        rhoCp[copper]=(fill*8960*385+(1-fill)*1400*1000)*(1+2*.012/.085)
        @BilinearForm
        def capacity(u,v,w):return w.C*u*v
        M=asm(capacity,basis,C=rhoCp[:,None]*np.ones_like(basis.dx))
        if distributed:M=M+Mcase
        def powers(Iq,T,phase_unit=None):
            phase2=np.ones(3)*Iq**2 if phase_unit is None else Iq**2*phase_unit**2
            weights=np.zeros(mesh.nelements);te=basis.interpolate(T).value.mean(axis=1)
            for rid in np.unique(regions[copper]):
                d=decode_label(fe.labels[rid]);current_weight=np.abs(conn[d['R_id'],d['T_id'],d['S_id']])@phase2
                pick=regions==rid;weights[pick]=current_weight*area[pick]/area[pick].sum()
            weights*=3*R20*Iq**2/weights.sum()
            return weights*(1+alpha*(te-20))
        model.m=machine
        cases=[('nominal',model.steady(Rwc=Rtarget,Rcase=.05 if distributed else .15),None),('robust',model.steady(sink=70,Rwc=Rtarget,Rcase=.05 if distributed else .15,core_ref_W=30),None)]
        for sink in [50,70]:
            condition=model.steady(220,0,sink=sink,Rwc=Rtarget,Rcase=.05 if distributed else .15)
            cases += [(f'hold{sink}_pose{j}',condition,j) for j in range(8)]
        for label,condition,pose in cases:
            phase_unit=None if pose is None else phase_units[pose]
            e=condition['electrical'];case=condition['temperatures_C']['case'];T=np.ones(basis.N)*condition['temperatures_C']['winding']
            sink=50 if label=='nominal' or label.startswith('hold50') else 70
            boundary_temperature=sink if distributed else case
            other_power=sum(e['loss_W'][k] for k in ['rotor_bertotti','magnets'])+e['friction_W']+max(0.,(condition['temperatures_C']['gear']-sink)/2)
            boundary_rhs=sink_vector*sink+edge*other_power/(circumference*L) if distributed else np.zeros(basis.N)
            Iq=e['Iq_rms_A'] if pose is None else position_current(condition['temperatures_C']['magnet'],pose,220)
            if pose is not None and Rtarget<=.12:
                Iq=1.01*max(position_current(condition['temperatures_C']['magnet'],j,220) for j in range(8))
            core=np.zeros(mesh.nelements);core[steel]=e['loss_W']['stator_bertotti']*area[steel]/area[steel].sum()
            for _ in range(30):
                pcu=powers(Iq,T,phase_unit);p=pcu+core
                corrected_case=0. if distributed else case+.15*max(0.,pcu.sum()-e['copper_W'])
                load=rhs(p)+boundary_rhs;nextT=np.full(basis.N,corrected_case)
                nextT[free]+=factor.solve((load-K@np.full(basis.N,corrected_case))[free])
                error=np.max(np.abs(nextT-T));T=nextT
                if error<1e-6:break
            if error>=1e-6:raise RuntimeError('Spatial electrothermal iteration did not converge')
            generated_heat=float(pcu.sum()+core.sum()+other_power)
            sink_heat=float(hcontact*edge@(T-sink)*L) if distributed else None
            row=dict(wire_mm=wire*1000,case=label,mean_network_case_C=case,winding_average_C=mean_winding(T),
                winding_hotspot_C=float(T.max()),copper_W=float(powers(Iq,T,phase_unit).sum()),holding_Iq_Arms=Iq if pose is not None else None,
                sink_C=sink,generated_heat_W=generated_heat,conducted_sink_heat_W=sink_heat,
                steady_heat_balance_residual_W=abs(sink_heat-generated_heat) if distributed else None,
                copper_hotspot_limit_C=130,steady_hotspot_ok=bool(T.max()<=130),transient=None)
            if pose is None:
                duty=next(v for v in performance['peak_400Nm_5s'] if v['sink_C']==(50 if label=='nominal' else 70))
                Ipeak=duty['maximum_current_Arms'];dt=.05;A=K+M/dt;trans=splu(A[free][:,free].tocsc());Tpeak=T.copy();maximum=float(T.max())
                for _ in range(100):
                    p=powers(Ipeak,Tpeak)+core;load=rhs(p)+boundary_rhs+(M@Tpeak)/dt
                    nextT=np.full(basis.N,corrected_case);nextT[free]=trans.solve((load-A@np.full(basis.N,corrected_case))[free])+corrected_case
                    Tpeak=nextT;maximum=max(maximum,float(Tpeak.max()))
                row['transient']=dict(duration_s=5,peak_current_Arms=Ipeak,maximum_winding_hotspot_C=maximum,hotspot_ok=bool(maximum<=130),imposed_case_temperature_constant=not distributed)
            else:
                Ipeak=position_current(condition['temperatures_C']['magnet'],pose,400);dt=.05;A=K+M/dt
                if Rtarget<=.12:Ipeak=1.01*max(position_current(condition['temperatures_C']['magnet'],j,400) for j in range(8))
                trans=splu(A[free][:,free].tocsc());Tpeak=T.copy();maximum=float(T.max())
                for _ in range(100):
                    load=rhs(powers(Ipeak,Tpeak,phase_unit))+boundary_rhs+(M@Tpeak)/dt
                    nextT=np.full(basis.N,corrected_case);nextT[free]=trans.solve((load-A@np.full(basis.N,corrected_case))[free])+corrected_case
                    Tpeak=nextT;maximum=max(maximum,float(Tpeak.max()))
                row['transient']=dict(duration_s=5,peak_current_Arms=Ipeak,maximum_winding_hotspot_C=maximum,hotspot_ok=bool(maximum<=130),stationary_output_torque_Nm=400)
            ppeak=float(powers(Ipeak,Tpeak,phase_unit).sum())
            area_total=m.stator.slot.comp_surface_active()*12;end_fraction=.024/.109
            end_bound=ppeak*end_fraction*.012/(4*25*area_total)
            case_bound=5*(ppeak+core.sum()+(0 if pose is not None else 400*10*2*np.pi/60*.25))/600
            row['transient'].update(peak_copper_W=ppeak,endturn_bound_at_k25_C=end_bound,case_energy_bound_C=case_bound,
                buffered_hotspot_C=maximum+end_bound+case_bound,buffered_hotspot_ok=bool(maximum+end_bound+case_bound<=130))
            results.append(row)
            if wire==.0009 and label=='robust':np.savez_compressed(out/'robust_temperature.npz',p=mesh.p,t=mesh.t,T=T)
    summary=dict(status='completed',engine='Pyleecan coil map -> nonlinear spatial scikit-fem conduction and implicit heat transient',
        nodes=mesh.nvertices,elements=mesh.nelements,h_m=h,effective_winding_k_W_mK=kw,calibrated_average_R_winding_case_K_W=calibrated_resistance,scenarios=results,
        radiation_credit=bool(Rtarget>.12),holding_current_margin_for_skew=1.01 if Rtarget<=.12 else 1.,
        distributed_case_model=distributed,case_sink_K_W=.05 if distributed else .15,
        limitations=['Effective conductivity calibrated to the declared winding-case path; not a measured validation',
            'Candidate uses distributed full-length housing contact, 8 mm aluminum circumferential spreading and 600 J/K case capacity; original uses a fixed case',
            'Steel and impregnated-winding heat capacities are assumed; 3-D end-turn temperature offset screened separately',
            'Hotspot temperature is a resolved-mesh maximum; supplier insulation/contact data are still required'])
    dump(out/'summary.json',summary);return summary


if __name__=='__main__':run(ROOT/'results/motor/hotspot')
