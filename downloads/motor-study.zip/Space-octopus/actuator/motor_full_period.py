"""Correct rotor loss sampling: full mechanical revolution, no time reduction."""
import json
from pathlib import Path
from .motor_campaign import solve_case,ROOT
from .run import dump


def run():
    config=json.loads((ROOT/'configs/revised.json').read_text())
    out=ROOT/'results/motor/full_period';rows=[]
    for nt in [144,288]:
        row=solve_case(config,out/str(nt),nt=nt,na=64,Iq=10.814,time_periodicity=False)
        rows.append(row);dump(out/'progress.json',rows)
    dump(out/'summary.json',dict(status='completed',cases=rows,reason='OutGeo.per_t_R=1: rotor fields need the full mechanical period. Reduced stator-time history is unsuitable for rotor loss qualification.'))


if __name__=='__main__':run()
