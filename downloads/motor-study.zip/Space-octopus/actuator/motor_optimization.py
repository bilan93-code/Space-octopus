"""Native Pyleecan NSGA-II winding trade, verified against its finite design grid.

The evaluation uses native machine mass/resistance and EEC plus the existing
coupled thermal model. Flux scales with turns at fixed ampere-turn loading;
geometry/topology are fixed. This is not a nonlinear FE solve per individual.
"""
import copy,json,random
from pathlib import Path
import numpy as np
from pyleecan.Classes.OptiProblem import OptiProblem
from pyleecan.Classes.OptiObjective import OptiObjective
from pyleecan.Classes.OptiConstraint import OptiConstraint
from pyleecan.Classes.OptiDesignVarSet import OptiDesignVarSet
from pyleecan.Classes.OptiGenAlgNsga2Deap import OptiGenAlgNsga2Deap
from pyleecan.Classes.Simu1 import Simu1
from .machine import build_machine,winding_summary
from .coupled import steady_state,electrical_point,transient
from .run import dump
ROOT=Path(__file__).resolve().parents[1]


def set_turns(simu,value):
    simu.machine.stator.winding.Ntcoil=int(value)
    simu.machine.stator.winding.wind_mat=None


def set_wire(simu,value):simu.machine.stator.winding.conductor.Wwire=float(value)


def run(out):
    out.mkdir(parents=True,exist_ok=True)
    base=json.loads((ROOT/'configs/revised.json').read_text())
    reference=json.loads((ROOT/'results/extended/redesign/redesign_summary.json').read_text())['parameters']
    calibrated=ROOT/'results/motor/performance_parameters.json'
    if calibrated.exists():
        native=json.loads(calibrated.read_text())
        reference.update(psi_pm_rms_Wb=native['psi80_rms_Wb'],torque_constant_Nm_per_Arms=15*native['psi80_rms_Wb'],Ld_H=native['Ld_H'],Lq_H=native['Lq_H'])
        reference['core_loss_ref_W']=native.get('reference_noncu_W',3.)
    cache={}
    def evaluate_values(turns,wire):
        key=(int(turns),round(float(wire),9))
        if key in cache:return cache[key]
        c=copy.deepcopy(base);c['motor'].update(turns_per_coil=key[0],wire_diameter_m=key[1])
        m=build_machine(c);ratio=key[0]/base['motor']['turns_per_coil'];p=dict(reference)
        p['psi_pm_rms_Wb']*=ratio;p['torque_constant_Nm_per_Arms']*=ratio
        p['Ld_H']*=ratio**2;p['Lq_H']*=ratio**2
        normal=steady_state(m,c,p,220,10)
        robust_c=copy.deepcopy(c);robust_c['thermal']['sink_C']=70
        robust_p=dict(p,core_loss_ref_W=30)
        robust=steady_state(m,robust_c,robust_p,220,10)
        # Hot voltage/current screen conservatively uses the declared limits.
        torque=400/(63*.8)+33/(630*2*np.pi/60)
        peak=electrical_point(m,c,p,torque,630,130,150)
        winding=winding_summary(m);area=winding['copper_area_per_turn_mm2']
        row=dict(turns=key[0],wire_mm=key[1]*1000,copper_mass_kg=m.stator.comp_masses()['Mwind'],
            copper_loss_W=normal['electrical']['copper_loss_W'],bare_fill=winding['bare_copper_fill'],
            insulated_fill=winding['bare_copper_fill']*((key[1]+.00005)/key[1])**2,
            robust_winding_C=robust['temperatures_C']['winding'],robust_magnet_C=robust['temperatures_C']['rotor'],
            robust_continuous_peak_phase_V=robust['electrical']['phase_voltage_peak_V'],
            hot_peak_phase_V=peak['phase_voltage_peak_V'],hot_peak_Arms=peak['Iq_rms_A'],
            current_density_cont_A_mm2=robust['electrical']['Iq_rms_A']/area,
            normal=normal,robust=robust,parameters=p)
        constraints=dict(bare_fill=.5,insulated_fill=.6,robust_winding_C=130,robust_magnet_C=150,
            robust_continuous_peak_phase_V=42*.9/np.sqrt(3),hot_peak_phase_V=42*.9/np.sqrt(3),
            hot_peak_Arms=22,current_density_cont_A_mm2=10)
        row['violations']=[k for k,limit in constraints.items() if row[k]>limit]
        row['feasible']=not row['violations'];cache[key]=row
        return row
    def metric(output):
        w=output.simu.machine.stator.winding
        return evaluate_values(w.Ntcoil,w.conductor.Wwire)
    turns=[10,11,12,13,14,15];wires=[v*1e-3 for v in [.8,.85,.9,.95,1.,1.05]]
    variables=[OptiDesignVarSet(name='Turns per coil',symbol='Nt',space=turns,get_value=random.choice,setter=set_turns),
        OptiDesignVarSet(name='Bare wire diameter',symbol='wire',unit='m',space=wires,get_value=random.choice,setter=set_wire)]
    objectives=[OptiObjective(name='Copper mass',symbol='Mcu',unit='kg',keeper=lambda o:metric(o)['copper_mass_kg']),
        OptiObjective(name='Continuous copper loss',symbol='Pcu',unit='W',keeper=lambda o:metric(o)['copper_loss_W'])]
    limits=dict(bare_fill=.5,insulated_fill=.6,robust_winding_C=130,robust_magnet_C=150,
        robust_continuous_peak_phase_V=42*.9/np.sqrt(3),hot_peak_phase_V=42*.9/np.sqrt(3),hot_peak_Arms=22,current_density_cont_A_mm2=10)
    constraints=[OptiConstraint(name=k,symbol=k,type_const='<=',value=float(v),keeper=lambda o,k=k:metric(o)[k]) for k,v in limits.items()]
    problem=OptiProblem(simu=Simu1(machine=build_machine(base),elec=None,mag=None,force=None,struct=None),
        design_var=variables,obj_func=objectives,constraint=constraints,eval_func=metric)
    random.seed(93);np.random.seed(93)
    solver=OptiGenAlgNsga2Deap(problem=problem,size_pop=24,nb_gen=12,p_mutate=.5,is_keep_all_output=False)
    result=solver.solve()
    native_rows=[]
    for i in range(result.nb_simu):
        native_rows.append(dict(turns=float(result.paramexplorer_list[0].value[i]),wire_m=float(result.paramexplorer_list[1].value[i]),
            copper_mass_kg=float(result.xoutput_dict['Mcu'].result[i]),copper_loss_W=float(result.xoutput_dict['Pcu'].result[i]),
            feasible=bool(result.xoutput_dict['is_valid'].result[i])))
    # Exhaustive check of the small discrete space gives a global result for this
    # declared surrogate/grid, without claiming a global motor-topology optimum.
    grid=[evaluate_values(n,d) for n in turns for d in wires]
    valid=[r for r in grid if r['feasible']]
    def dominates(a,b):return a['copper_mass_kg']<=b['copper_mass_kg'] and a['copper_loss_W']<=b['copper_loss_W'] and (a['copper_mass_kg']<b['copper_mass_kg'] or a['copper_loss_W']<b['copper_loss_W'])
    front=[r for r in valid if not any(dominates(other,r) for other in valid)]
    # Keep the declared 12-turn candidate as the evaluated design. Alternatives
    # are reviewable proposals until independently checked with nonlinear FEMM.
    baseline=evaluate_values(12,.0009)
    selected=min(valid,key=lambda r:r['copper_loss_W']) if valid else None
    summary=dict(status='completed',engine='Official Pyleecan OptiGenAlgNsga2Deap.solve / DEAP NSGA-II',
        native_evaluations=result.nb_simu,native_valid_evaluations=sum(r['feasible'] for r in native_rows),
        grid_size=len(grid),grid_feasible=len(valid),grid=grid,pareto=front,native_history=native_rows,
        evaluated_candidate=baseline,lowest_copper_loss_grid_candidate=selected,
        assumptions=dict(max_bare_fill=.5,max_insulated_fill=.6,max_cont_current_density_A_mm2=10,hot_voltage_screen_C=[130,150],robust_sink_C=70,robust_core_rotor_W=30),
        limitations=['Turn-scaled magnetic surrogate at fixed stator geometry; FE validation required for selected alternatives',
            'Native algorithm executed; exhaustive verification applies only to these 36 declared winding combinations',
            'Fill/current density/cooling/material assumptions are engineering screens, not manufacturing qualification'])
    dump(out/'summary.json',summary)
    if selected:
        c=copy.deepcopy(base);c['motor'].update(turns_per_coil=selected['turns'],wire_diameter_m=selected['wire_mm']/1000)
        c['provenance']='Motor winding optimization proposal; separate from evaluated revised.json; nonlinear FEMM verification required.'
        dump(out/'proposed_config.json',c)
    print('Native optimization completed;',len(valid),'feasible grid candidates;',len(front),'Pareto designs.')
    return summary


if __name__=='__main__':run(ROOT/'results/motor/optimization')
