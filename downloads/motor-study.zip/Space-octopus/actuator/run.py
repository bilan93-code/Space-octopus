"""Run with: .venv/bin/python -m actuator.run"""
import argparse
import copy
import csv
import json
import math
import platform
import importlib.metadata as metadata
from pathlib import Path
import numpy as np
from .machine import build_machine,winding_summary
from .magnetics import MagneticModel,MU0
from .coupled import gear_geometry,gear_loads,steady_state,transient,operating_limits
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]


def dump(path,value):
    def convert(v):
        if isinstance(v,np.ndarray): return v.tolist()
        if isinstance(v,np.generic): return v.item()
        raise TypeError('Unsupported result type: '+str(type(v)))
    path.write_text(json.dumps(value,indent=2,allow_nan=False,default=convert)+'\n')


def phase_q(flux):
    # Balanced vector 90 electrical degrees ahead of PM flux; max RMS component=1.
    v=np.asarray(flux)-np.mean(flux)
    q=-np.array([v[1]-v[2],v[2]-v[0],v[0]-v[1]])/np.sqrt(3)
    return q/np.sqrt(np.mean(q*q))


def run(out,config):
    out.mkdir(parents=True,exist_ok=True)
    c=config['motor'];m=build_machine(config);ws=winding_summary(m)
    m.save(str(out/'machine.json'))
    fig,ax=m.plot(is_show_fig=False);fig.savefig(out/'machine.png',dpi=180);plt.close(fig)
    dump(out/'inputs.json',config)
    dump(out/'winding.json',ws)
    # Full electrical period: 72 mechanical degrees; 24 quasi-static positions.
    angles=np.linspace(0,2*np.pi/c['pole_pairs'],24,endpoint=False)
    sweep=[];flux=[];cog=[]
    ref=None;solution=None
    for k,angle in enumerate(angles):
        print('Rotor position',k+1,'/',len(angles),flush=True)
        fe=MagneticModel(m,config,h=.0015,angle=float(angle))
        nl=fe.nonlinear(fe.solve())
        unit=phase_q(nl['phase_flux_Wb'])
        loaded=fe.nonlinear(fe.solve(9*unit))
        metrics=fe.metrics(loaded);no=fe.metrics(nl)
        sweep.append(dict(angle_mech_deg=float(np.rad2deg(angle)),no_load=no,load_9Arms=metrics,nonlinear_iterations=loaded['nonlinear_iterations'],nonlinear_residual=loaded['nonlinear_residual'],BH_extrapolated_iron_area_fraction=loaded['iron_area_BH_extrapolated_fraction']))
        dump(out/'rotor_sweep_checkpoint.json',sweep)
        flux.append(nl['phase_flux_Wb']);cog.append(no['torque_Nm'])
        if k==0:ref=fe;solution=loaded;no_load=nl
    flux=np.asarray(flux);theta=angles*c['pole_pairs']
    # Fourier fit: fundamental amplitude and harmonics from an actual rotor sweep.
    fundamental=2/len(angles)*np.sum(flux*np.exp(-1j*theta[:,None]),axis=0)
    amp=float(np.mean(np.abs(fundamental)));psi=amp/np.sqrt(2)
    harmonics={str(h):float(np.mean(np.abs(2/len(angles)*np.sum(flux*np.exp(-1j*h*theta[:,None]),axis=0)))/amp) for h in [3,5,7,9,11]}
    # Differential inductance around no-load in the direction of flux and quadrature.
    f0=no_load['phase_flux_Wb'];d=(f0-np.mean(f0));d=d/np.sqrt(np.mean(d*d));q=phase_q(f0)
    ind={}
    for name,axis in [('d',d),('q',q)]:
        plus=ref.nonlinear(ref.solve(axis));minus=ref.nonlinear(ref.solve(-axis))
        differential=(plus['phase_flux_Wb']-minus['phase_flux_Wb'])/2
        # For a balanced peak phase vector with RMS amplitude sqrt(mean(i²))=1,
        # sum(axis²)=3; projection gives per-phase differential inductance.
        ind[name]=float(np.dot(differential,axis)/3)
    # Frequency-scaled local |B| screening. No rotor time-history loss integration.
    # Stator only: each point is assumed to experience its sampled magnitude as
    # sinusoidal amplitude. This is an explicitly uncalibrated loss proxy.
    iron=np.array([('_Lamination' in ref.labels[rid] and 'Stator' in ref.labels[rid]) for rid in ref.region])
    B=np.linalg.norm(solution['B'],axis=0)
    f=c['pole_pairs']*630/60
    mass_elem=ref.areas*c['stack_m']*.95*c['steel_density_kg_m3']
    # 25% allowance for harmonics, rotor and magnet losses (assumed).
    core=float(np.sum(mass_elem[iron]*c['core_loss_W_kg_at_50Hz_1p5T']*(B[iron]/1.5)**2)*(.6*f/50+.4*(f/50)**2)*1.25)
    params=dict(psi_pm_rms_Wb=psi,psi_pm_peak_Wb=amp,Ld_H=ind['d']+c['assumed_end_leakage_H'],Lq_H=ind['q']+c['assumed_end_leakage_H'],Ld_2D_H=ind['d'],Lq_2D_H=ind['q'],core_loss_ref_W=core,torque_constant_Nm_per_Arms=3*c['pole_pairs']*psi,phase_flux_harmonics_relative=harmonics)
    # Mesh convergence uses identical geometry, nonlinear material, and phase current.
    convergence=[]
    for h in [.002,.0012,.0008]:
        fe=MagneticModel(m,config,h=h)
        n=fe.nonlinear(fe.solve());loaded=fe.nonlinear(fe.solve(9*phase_q(n['phase_flux_Wb'])))
        v=fe.metrics(loaded)
        convergence.append(dict(h_m=h,nodes=fe.mesh.nvertices,elements=fe.mesh.nelements,torque_Nm=v['torque_Nm'],phase_flux_norm_Wb=float(np.linalg.norm(n['phase_flux_Wb'])),radial_checks_Nm=v['torque_radial_checks_Nm']))
        if h==.0008:
            fine_fe=fe;fine_solution=loaded
    # Independent torque check via virtual work on PM flux at fixed phase currents.
    delta=np.deg2rad(.25);derivatives=[]
    for angle in [-delta,delta]:
        fe=MagneticModel(m,config,h=.0012,angle=float(angle))
        derivatives.append(fe.nonlinear(fe.solve())['phase_flux_Wb'])
    virtual=float(9*q@((derivatives[1]-derivatives[0])/(2*delta)))
    # Symmetric positions cover a full electrical period and provide a coarse
    # envelope. 24 positions cannot establish high-order cogging extrema.
    torque_mean=float(np.mean([v['load_9Arms']['torque_Nm'] for v in sweep]))
    torque_eec=3*c['pole_pairs']*psi*9
    checks=dict(mesh_torque_change_relative=abs(convergence[-1]['torque_Nm']/convergence[-2]['torque_Nm']-1),mesh_flux_change_relative=abs(convergence[-1]['phase_flux_norm_Wb']/convergence[-2]['phase_flux_norm_Wb']-1),FE_mean_torque_9Arms_Nm=torque_mean,EEC_torque_9Arms_Nm=torque_eec,FE_EEC_difference_relative=abs(torque_mean/torque_eec-1),virtual_work_torque_9Arms_Nm=virtual,virtual_work_vs_fine_FE_relative=abs(virtual/convergence[-1]['torque_Nm']-1),cogging_sample_peak_to_peak_Nm=float(np.ptp(cog)))
    # Operating points, including holding, 10 rpm, 30 rpm, and proposed peak.
    ops={}
    tc=config['operating']['output_continuous_Nm'];nout=config['operating']['output_rpm'];tp=config['operating']['peak_Nm']
    for name,torque,speed in [('hold',tc,0),('continuous',tc,nout),('higher_speed',tc,3*nout),('peak_steady_not_a_rating',tp,nout),('motor_6Nm_equivalent_output',6*63*.8,nout)]:
        ops[name]=steady_state(m,config,params,torque,speed)
    initial=list(ops['continuous']['temperatures_C'].values())
    peak=transient(m,config,params,initial,tp,nout,config['operating']['peak_s'])
    warmup=transient(m,config,params,[config['thermal']['sink_C']]*4,tc,nout,3600)
    # Deterministic boundary-condition sensitivities, no fabricated probabilities.
    sensitivity=[]
    for sink in [30,50,70]:
        for efficiency in [.73,.8,.8464]:
            cc=copy.deepcopy(config);cc['thermal']['sink_C']=sink
            r=steady_state(m,cc,params,220,10,efficiency)
            sensitivity.append(dict(sink_C=sink,gearbox_efficiency=efficiency,**r))
    # Torque-speed envelope with voltage and thermal constraints, no field weakening.
    envelope=[]
    for rpm in [0,5,10,15,20,25,30,40]:
        for torque in [110,165,220,275,302.4]:
            r=steady_state(m,config,params,torque,rpm)
            e=r['electrical']
            envelope.append(dict(output_rpm=rpm,output_torque_Nm=torque,winding_C=r['temperatures_C']['winding'],Iq_rms_A=e['Iq_rms_A'],voltage_peak_V=e['phase_voltage_peak_V'],thermal_ok=r['thermal_ok'],current_ok=e['current_ok'],voltage_ok=e['voltage_ok']))
    gears=[gear_geometry(s) for s in config['gearbox']['stages']]
    result=dict(winding=ws,magnetic_parameters=params,magnetic_checks=checks,mesh_convergence=convergence,rotor_sweep=sweep,operating_points=ops,gear_geometry=gears,gear_loads_continuous=gear_loads(config,220),gear_loads_peak=gear_loads(config,400),thermal_sensitivity=sensitivity,peak_transient=peak,warmup=warmup,torque_speed_screen=envelope,versions={p:metadata.version(p) for p in ['pyleecan','swat-em','numpy','scipy','gmsh','scikit-fem']},python=platform.python_version())
    from .supplement import supplement
    result.update(supplement(m,config,fine_fe,fine_solution))
    result['conditional_limits']=operating_limits(m,config,params,ops['continuous'],peak)
    dump(out/'analysis.json',result)
    with (out/'torque_speed.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(envelope[0]));w.writeheader();w.writerows(envelope)
    plot_results(out,result,fine_fe,fine_solution)
    from .report import write_report
    write_report(out,result,config)
    print(json.dumps(dict(params=params,checks=checks,continuous=ops['continuous']),indent=2),flush=True)
    # Fail the run if numerical verification failed, not when a candidate exceeds
    # an engineering limit: candidate failures remain legitimate analysis results.
    if checks['mesh_torque_change_relative']>.05 or checks['mesh_flux_change_relative']>.02 or checks['FE_EEC_difference_relative']>.12:
        raise RuntimeError('Magnetic numerical checks outside declared tolerances; inspect results')
    return result


def plot_results(out,r,fe,s):
    plt.rcParams.update({'font.size':10,'figure.dpi':130})
    fig,ax=plt.subplots(figsize=(8,7))
    B=np.linalg.norm(s['B'],axis=0)
    col=ax.tripcolor(fe.mesh.p[0]*1000,fe.mesh.p[1]*1000,fe.mesh.t.T,facecolors=B,vmin=0,vmax=2,cmap='viridis',rasterized=True)
    ax.set_aspect('equal');ax.set(xlabel='x [mm]',ylabel='y [mm]',title='2-D nonlinear magnetic screening model, 9 Arms')
    fig.colorbar(col,ax=ax,label='|B| [T] (scale clipped at 2 T)');fig.tight_layout();fig.savefig(out/'flux_density.png',dpi=170);plt.close(fig)
    a=np.array([v['angle_mech_deg'] for v in r['rotor_sweep']]);flux=np.array([v['no_load']['phase_flux_Wb'] for v in r['rotor_sweep']]);torque=np.array([v['load_9Arms']['torque_Nm'] for v in r['rotor_sweep']])
    fig,axes=plt.subplots(2,1,figsize=(8,7),sharex=True)
    axes[0].plot(a,flux);axes[0].set(ylabel='Phase linkage [Wb turns]',title='Nonlinear rotor-position sweep');axes[0].legend(['A','B','C'])
    axes[1].plot(a,torque,'o-',label='FE torque at 9 Arms');axes[1].axhline(r['magnetic_checks']['EEC_torque_9Arms_Nm'],color='gray',ls='--',label='Pyleecan EEC fundamental');axes[1].set(xlabel='Rotor angle [mechanical degrees]',ylabel='Torque [N m]');axes[1].legend()
    for ax in axes:ax.grid(alpha=.25)
    fig.tight_layout();fig.savefig(out/'flux_torque_sweep.png',dpi=170);plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(11,4))
    for key,ax,scale in [('warmup',axes[0],60),('peak_transient',axes[1],1)]:
        v=r[key];ax.plot(np.array(v['time_s'])/scale,np.array(v['temperatures_C']));ax.grid(alpha=.25);ax.set(xlabel='Time [min]' if scale==60 else 'Time [s]',ylabel='Temperature [°C]',title='220 N m warm-up' if scale==60 else '400 N m peak from hot equilibrium')
    axes[0].legend(['Winding','Rotor','Motor case','Gear case']);fig.tight_layout();fig.savefig(out/'thermal_transients.png',dpi=170);plt.close(fig)
    fig,ax=plt.subplots(figsize=(8,5))
    for e in r['torque_speed_screen']:
        ok=e['thermal_ok'] and e['current_ok'] and e['voltage_ok']
        ax.scatter(e['output_rpm'],e['output_torque_Nm'],c='seagreen' if ok else 'firebrick',marker='o' if ok else 'x',s=60)
    ax.set(xlabel='Output speed [rpm]',ylabel='Output torque [N m]',title='Conditional envelope: green passes; red exceeds ≥1 assumed limit');ax.grid(alpha=.25);fig.tight_layout();fig.savefig(out/'operating_envelope.png',dpi=170);plt.close(fig)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--config',type=Path,default=ROOT/'configs/baseline.json');p.add_argument('--out',type=Path,default=ROOT/'results/baseline');a=p.parse_args()
    run(a.out,json.loads(a.config.read_text()))
