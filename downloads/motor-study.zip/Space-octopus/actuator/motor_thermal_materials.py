"""Explicit coated-wire homogenization and slot-liner interface conduction.

Declared material scenarios, not measured properties or a released coil drawing.
Unlike the earlier conductivity calibration, these conductivities are inputs.
"""
import json
import gmsh
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import splu
from skfem import MeshTri,Basis,ElementTriP1,BilinearForm,LinearForm,asm
from skfem.helpers import dot,grad
from .machine import build_machine
from .magnetics import MagneticModel
from .runtime import ROOT
from .run import dump


@BilinearForm
def stiffness(u,v,w):return w.k*dot(grad(u),grad(v))


def microstructure(h):
    fill=.475852425711573;r=.000475;outer=.0005;pitch=np.sqrt(np.pi*r*r/fill)
    gmsh.initialize()
    try:
        gmsh.option.setNumber('General.Terminal',0);occ=gmsh.model.occ
        box=occ.addRectangle(-pitch/2,-pitch/2,0,pitch,pitch)
        cu=occ.addDisk(0,0,0,r,r);coat=occ.addDisk(0,0,0,outer,outer)
        _,mapping=occ.fragment([(2,box)],[(2,cu),(2,coat)]);occ.synchronize()
        copper={t for d,t in mapping[1] if d==2};coating={t for d,t in mapping[2] if d==2}-copper
        gmsh.model.mesh.setSize(gmsh.model.getEntities(0),h)
        gmsh.option.setNumber('Mesh.MeshSizeMin',h/2);gmsh.option.setNumber('Mesh.MeshSizeMax',h)
        gmsh.model.mesh.generate(2);tags,xyz,_=gmsh.model.mesh.getNodes();order=np.argsort(tags);tags=np.array(tags)[order]
        xy=np.asarray(xyz).reshape(-1,3)[order,:2];tri=[];kind=[]
        for _,tag in gmsh.model.getEntities(2):
            types,_,nodes=gmsh.model.mesh.getElements(2,tag)
            for typ,nn in zip(types,nodes):
                if typ!=2:raise RuntimeError('Non-triangle in winding unit cell')
                cells=np.searchsorted(tags,np.asarray(nn).reshape(-1,3));tri.extend(cells)
                kind.extend([0 if tag in copper else 1 if tag in coating else 2]*len(cells))
        mesh=MeshTri(xy.T,np.asarray(tri).T,sort_t=False);basis=Basis(mesh,ElementTriP1());kind=np.asarray(kind)
        left=np.flatnonzero(np.isclose(mesh.p[0],-pitch/2,atol=1e-10));right=np.flatnonzero(np.isclose(mesh.p[0],pitch/2,atol=1e-10))
        free=basis.complement_dofs(np.r_[left,right]);T=np.zeros(basis.N);T[right]=1;rows=[]
        for resin in [.1,.2,.4,.6,1.]:
            for void in [0.,.2]:
                matrix_k=resin*2*(1-void)/(2+void)
                ks=np.choose(kind,[390.,.2,matrix_k]);K=asm(stiffness,basis,k=ks[:,None]*np.ones_like(basis.dx))
                current=T.copy();current[free]=splu(K[free][:,free].tocsc()).solve(-(K@T)[free]);energy=float(current@(K@current))
                rows.append(dict(resin_k_W_mK=resin,assumed_resin_void_fraction=void,void_effective_matrix_k_W_mK=matrix_k,
                    effective_transverse_k_W_mK=energy,h_m=h,nodes=basis.N))
        return rows
    finally:gmsh.finalize()


def assembly(rows):
    c=json.loads((ROOT/'configs/motor_candidate.json').read_text());m=build_machine(c);fe=MagneticModel(m,c,h=.0015)
    chosen=np.array([('Stator' in fe.labels[r] and ('_Lamination' in fe.labels[r] or '_Winding' in fe.labels[r])) for r in fe.region])
    tri=fe.mesh.t[:,chosen];nodes=np.unique(tri);mesh=MeshTri(fe.mesh.p[:,nodes],np.searchsorted(nodes,tri),sort_t=False)
    copper=np.array(['_Winding' in fe.labels[r] for r in fe.region[chosen]])
    adjacent=mesh.f2t;internal=(adjacent>=0).all(axis=0);interfaces=np.flatnonzero(internal & (copper[adjacent[0]]!=copper[adjacent[1]]))
    edges=mesh.facets[:,interfaces];interface_nodes=np.unique(edges);dup=np.full(mesh.nvertices,-1,dtype=int);dup[interface_nodes]=mesh.nvertices+np.arange(len(interface_nodes))
    t=mesh.t.copy()
    for index in np.flatnonzero(copper):
        ids=t[:,index];pick=dup[ids]>=0;t[pick,index]=dup[ids[pick]]
    split=MeshTri(np.c_[mesh.p,mesh.p[:,interface_nodes]],t,sort_t=False);basis=Basis(split,ElementTriP1());areas=basis.dx.sum(axis=1)
    boundary=np.flatnonzero(np.isclose(np.linalg.norm(split.p,axis=0),m.stator.Rext,atol=1e-8));free=basis.complement_dofs(boundary)
    @LinearForm
    def heating(v,w):return w.q*v
    q=np.zeros(split.nelements);q[copper]=1/(areas[copper].sum()*.085);b=asm(heating,basis,q=q[:,None]*np.ones_like(basis.dx))
    length=np.linalg.norm(mesh.p[:,edges[1]]-mesh.p[:,edges[0]],axis=0)
    shape=np.array([[2,1,-2,-1],[1,2,-1,-2],[-2,-1,2,1],[-1,-2,1,2]])/6
    dofs=np.array([edges[0],edges[1],dup[edges[0]],dup[edges[1]]]).T
    ri=[];ci=[];vv=[]
    for ids,ell in zip(dofs,length):
        ri.extend(np.repeat(ids,4));ci.extend(np.tile(ids,4));vv.extend((shape*ell).ravel())
    contact=coo_matrix((vv,(ri,ci)),shape=(basis.N,basis.N)).tocsr();results=[]
    for row in rows:
        if row['h_m']!=.0000125:continue
        k=np.full(split.nelements,20.);k[copper]=row['effective_transverse_k_W_mK'];bulk=asm(stiffness,basis,k=k[:,None]*np.ones_like(basis.dx))
        for liner in [0.,.0001,.0002]:
            conductance=1e9 if not liner else .12/liner;K=bulk+contact*conductance
            T=np.zeros(basis.N);T[free]=splu(K[free][:,free].tocsc()).solve(b[free])
            values=basis.interpolate(T).value.mean(axis=1);average=float(np.sum(values[copper]*areas[copper])/areas[copper].sum())
            results.append(dict(**row,liner_mm=liner*1000,liner_k_W_mK=.12,mean_R_winding_case_K_W=average,
                unit_heat_peak_R_K_W=float(T.max()),meets_declared_average_path=bool(average<=.12)))
    return results,float(length.sum()*.085)


def run():
    out=ROOT/'results/motor/extensions/thermal_materials';out.mkdir(parents=True,exist_ok=True)
    rows=[]
    for h in [.000025,.0000125]:rows+=microstructure(h)
    assemblies,interface_area=assembly(rows)
    result=dict(status='completed',engine='Gmsh/scikit-fem coated-wire unit cell -> actual slotted stator with explicit temperature-jump liner interfaces',
        microstructure=rows,assembly_scenarios=assemblies,slot_steel_contact_area_m2=interface_area,
        assumptions=dict(copper_k_W_mK=390,enamel_k_W_mK=.2,enamel_radial_thickness_um=25,native_bare_slot_fill=.475852425711573,
            stator_steel_k_W_mK=20,liner_k_W_mK=.12,target_average_path_K_W=.12),
        limitations=['Periodic square packing represented by symmetry boundaries; real placement/void connectivity unmeasured',
            'Void effect uses a Maxwell dilute insulating-pore approximation, not a resolved void network',
            'Slot liner represented by a zero-thickness thermal jump; actual liner volume reduces usable winding area',
            'Native slot copper-envelope fill is retained; winding insertion and post-liner packing still need construction checks',
            'Steady 1 W uniform phase heat; holding/pulse acceptance remains the separate nonlinear spatial model',
            'Contact quality, temperature-dependent properties and assembled thermal-path tests remain necessary'])
    dump(out/'summary.json',result);return result


if __name__=='__main__':run()
