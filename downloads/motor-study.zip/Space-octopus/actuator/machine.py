"""Pyleecan machine construction; all dimensions in SI units."""
import os
from pathlib import Path
os.environ.setdefault('MPLBACKEND', 'Agg')
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
os.environ.setdefault('MPLCONFIGDIR', str(Path(__file__).resolve().parents[1] / '.local/matplotlib'))
import numpy as np
from pyleecan.Classes.MachineSIPMSM import MachineSIPMSM
from pyleecan.Classes.LamSlotWind import LamSlotWind
from pyleecan.Classes.LamSlotMag import LamSlotMag
from pyleecan.Classes.SlotW10 import SlotW10
from pyleecan.Classes.SlotM11 import SlotM11
from pyleecan.Classes.Winding import Winding
from pyleecan.Classes.CondType12 import CondType12
from pyleecan.Classes.Magnet import Magnet
from pyleecan.Classes.Shaft import Shaft
from pyleecan.Classes.Material import Material
from pyleecan.Classes.MatMagnetics import MatMagnetics
from pyleecan.Classes.MatElectrical import MatElectrical
from pyleecan.Classes.Lamination import Lamination
from pyleecan.Functions.load import load
from pyleecan.definitions import DATA_DIR


def build_machine(config):
    c = config['motor']
    steel = Material(name='Generic steel linear screen', mag=MatMagnetics(mur_lin=c['steel_mu_r'], Wlam=.00035))
    steel.mag.BH_curve = load(DATA_DIR + '/Material/M270-35A.json').mag.BH_curve.copy()
    steel.struct.rho = c['steel_density_kg_m3']
    steel.struct.Ex = steel.struct.Ey = steel.struct.Ez = 210e9
    steel.struct.nu_xy = steel.struct.nu_xz = steel.struct.nu_yz = .3
    copper = Material(name='Copper assumed 20C', elec=MatElectrical(rho=1.724e-8, alpha=.00393))
    copper.struct.rho = 8960
    pm = Material(name='Generic SmCo-like assumption', mag=MatMagnetics(mur_lin=c['magnet_mu_r'], Brm20=c['magnet_Br20_T'], alpha_Br=c['magnet_alpha_per_K']))
    pm.struct.rho = 8300
    pm.elec.rho = c.get('magnet_resistivity_ohm_m', .9e-6)
    pm.elec.alpha = c.get('magnet_resistivity_alpha_per_K', .0003)
    stator = LamSlotWind(Rint=c['stator_bore_radius_m'], Rext=c['stator_outer_radius_m'], L1=c['stack_m'], Kf1=.95, is_internal=False, is_stator=True, mat_type=steel)
    stator.slot = SlotW10(Zs=c['slots'], **c['slot'])
    stator.winding = Winding(qs=3, p=c['pole_pairs'], Nlayer=2, coil_pitch=1, Ntcoil=c['turns_per_coil'], Npcp=1, Lewout=c['half_turn_end_length_m'], end_winding=None)
    stator.winding.conductor = CondType12(Wwire=c['wire_diameter_m'], Wins_wire=.000025, Wins_cond=0, Nwppc=c['strands'], cond_mat=copper)
    rotor = LamSlotMag(Rint=c['shaft_radius_m'], Rext=c['rotor_iron_radius_m'], L1=c['stack_m'], Kf1=.95, is_stator=False, is_internal=True, mat_type=steel)
    arc = c['magnet_arc_fraction']*np.pi/c['pole_pairs']
    rotor.slot = SlotM11(Zs=2*c['pole_pairs'], W0=arc, W1=arc, H0=0, H1=c['magnet_thickness_m'])
    rotor.magnet = Magnet(mat_type=pm, type_magnetization=0, Lmag=c['stack_m'])
    if c.get('step_skew_degrees'):
        from pyleecan.Classes.Skew import Skew
        rotor.skew=Skew(type_skew='linear',rate=None,is_step=True,Nstep=2,angle_overall=float(np.deg2rad(c['step_skew_degrees'])))
    machine = MachineSIPMSM(name='SpaceOctopus_12s10p_v1', stator=stator, rotor=rotor, shaft=Shaft(Drsh=2*c['shaft_radius_m'], Lshaft=.13, mat_type=steel), frame=None)
    # Pyleecan 1.5.2 LamSlot.check uses super(type(self), self), which
    # recurses for LamSlotMag. Apply its constituent checks explicitly.
    for lam in [stator, rotor]:
        Lamination.check(lam)
        lam.slot.check()
        if lam.comp_height_yoke() <= 0:
            raise ValueError('Nonpositive yoke thickness')
    if machine.comp_width_airgap_mec() <= 0:
        raise ValueError('Nonpositive mechanical air gap')
    return machine


def winding_summary(machine):
    s = machine.stator
    w = s.winding
    conn = w.get_connection_mat(s.slot.Zs)
    area = s.slot.comp_surface_active()
    wire_area = w.conductor.comp_surface_active()
    turns = np.abs(conn).sum(axis=(0,1,2))/2
    fill = np.max(np.abs(conn).sum(axis=(0,1,3)))*wire_area/area
    return dict(connection_matrix=conn.tolist(), turns_per_phase=turns.tolist(), winding_factors=w.comp_winding_factor([1,3,5,7]).tolist(), slot_active_area_mm2=area*1e6, copper_area_per_turn_mm2=wire_area*1e6, bare_copper_fill=fill, R20_ohm=s.comp_resistance_wind(20), R100_ohm=s.comp_resistance_wind(100), airgap_mm=(s.comp_radius_mec()-machine.rotor.comp_radius_mec())*1000)
