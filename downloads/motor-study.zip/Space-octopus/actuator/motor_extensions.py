"""Additional native FEMM coverage, independent of the accepted baseline study.

Every point is checkpointed and is a real rotor-averaged nonlinear FEMM solve.
Jobs are sequential because the official file link shares one Wine prefix.
"""
import copy,json,os,subprocess
from functools import partial
from pathlib import Path
import cloudpickle
import numpy as np
from pyleecan.Classes.Simu1 import Simu1
from pyleecan.Classes.InputCurrent import InputCurrent
from pyleecan.Classes.OPdq import OPdq
from pyleecan.Classes.VarLoadCurrent import VarLoadCurrent
from pyleecan.Classes.XOutput import XOutput
from pyleecan.Classes.PostFunction import PostFunction
from .machine import build_machine
from .native_femm import magnetic_module
from .motor_maps import checkpoint_point
from .motor_campaign import solve_case
from .runtime import ROOT,headless_environment
from .femm_transport import reliable_femm_transport
from .run import dump

OUT=ROOT/'results/motor/extensions'


def batch(folder,temp,points,nt=240,kmesh=1):
    folder.mkdir(parents=True,exist_ok=True)
    c=json.loads((ROOT/'configs/motor_candidate.json').read_text())
    points=[(float(d),float(q)) for d,q in points]
    signature=dict(config=c,magnet_C=temp,points=points,nt=nt,kmesh=kmesh)
    spec=folder/'input_spec.json'
    if spec.exists() and json.loads(spec.read_text())!=json.loads(json.dumps(signature)):
        raise RuntimeError('Changed batch specification: choose a new output folder')
    dump(spec,signature)
    cached={}
    for d,q in points:
        path=folder/f'point_{d}_{q}.pkl'
        if path.exists():
            with path.open('rb') as f:cached[d,q]=cloudpickle.load(f)
    missing=[p for p in points if p not in cached]
    if missing:
        missing.sort(key=lambda p:(p!=(0.,0.),p[0],p[1]))
        var=VarLoadCurrent(is_keep_all_output=True,stop_if_error=True,is_reuse_femm_file=True,is_reuse_LUT=False,
            post_keeper_postproc_list=[PostFunction(run=partial(checkpoint_point,folder=str(folder)))])
        var.set_OP_array(np.array([[630,d,q] for d,q in missing]),'N0','Id','Iq',is_update_input=False)
        mag=magnetic_module(magnet_C=temp,kmesh=kmesh);mag.is_get_meshsolution=False
        simu=Simu1(name='Extension_'+folder.name+'_'+str(temp),machine=build_machine(c),
            input=InputCurrent(OP=OPdq(Id_ref=0.,Iq_ref=0.,N0=630.),Nt_tot=nt,Na_tot=32,Nrev=1),
            elec=None,mag=mag,force=None,loss=None,struct=None,var_simu=var)
        XOutput(simu=simu,path_result=str(folder.resolve()))
        with headless_environment(folder/'display.log') as env,reliable_femm_transport() as transport:
            keys=['PATH','DISPLAY','WINEPREFIX','LD_LIBRARY_PATH','XDG_RUNTIME_DIR'];before={k:os.environ.get(k) for k in keys}
            try:
                subprocess.run([str(ROOT/'.local/sysroot/usr/lib/wine/wineserver64'),'-k'],env=env)
                for k in keys:os.environ[k]=env[k]
                result=simu.run()
            finally:
                for k,v in before.items():
                    if v is None:os.environ.pop(k,None)
                    else:os.environ[k]=v
        dump(folder/'transport.json',transport)
        for result_point in result.output_list:
            op=result_point.simu.input.OP;cached[float(op.Id_ref),float(op.Iq_ref)]=result_point
    rows=[]
    for d,q in points:
        path=folder/f'point_{d}_{q}.json'
        row=json.loads(path.read_text())
        r=cached[d,q]
        row.update(torque_min_Nm=float(np.min(r.mag.Tem.values)),torque_max_Nm=float(np.max(r.mag.Tem.values)),
            solved_time_steps=len(r.mag.Tem.values),requested_time_steps=nt,kmesh=kmesh,
            dq_torque_Nm=float(15*(row['Phid_rms_Wb']*q-row['Phiq_rms_Wb']*d)))
        rows.append(row)
    dump(folder/'summary.json',dict(status='completed',engine='Official VarLoadCurrent -> nonlinear MagFEMM; independent point checkpoints',rows=rows))
    return rows


def run():
    OUT.mkdir(parents=True,exist_ok=True)
    # Mid-cell points are not used to construct the existing 27-point map.
    for T,points in [(80,[(-9,5.407),(-9,16.407),(-3,5.407),(-3,16.407)]),
                     (50,[(-6,10.814)]),(115,[(-6,10.814)])]:
        batch(OUT/'map_holdouts'/f'{T}C',T,points)
    # Wide current domain brackets the preceding fixed-inductance fault paths.
    for T in [20,150]:
        batch(OUT/'fault_maps'/f'{T}C',T,[(d,q) for d in [-60,-30,0] for q in [-24,0,24]])
        batch(OUT/'fault_holdouts'/f'{T}C',T,[(d,q) for d in [-45,-15] for q in [-12,12]])
    c=json.loads((ROOT/'configs/motor_candidate.json').read_text())
    for arc in [.7,.8,.9]:
        for gap in [.0004,.0005,.0006]:
            variant=copy.deepcopy(c);variant['motor'].update(magnet_arc_fraction=arc,stator_bore_radius_m=.026+gap)
            solve_case(variant,OUT/'geometry'/f'arc{arc}_gap{gap*1000:.1f}',nt=240,na=32,Iq=10.814,full_fields=False)
    # Physical envelope screening at hot magnets and maximum drive current.
    for name,changes in [('reference',{}),('Br_minus5pct',{'magnet_Br20_T':1.05*.95}),
        ('gap_plus50um',{'stator_bore_radius_m':.02655}),('stack_minus0p5mm',{'stack_m':.0845}),
        ('combined_low_flux',{'magnet_Br20_T':1.05*.95,'stator_bore_radius_m':.02655,'stack_m':.0845})]:
        variant=copy.deepcopy(c);variant['motor'].update(changes)
        solve_case(variant,OUT/'tolerances'/name,nt=240,na=32,Iq=22.,magnet_C=150.,winding_C=130.,full_fields=False)
    # Reference-map corner checks are independent time and spatial refinements.
    for label,nt,kmesh in [('time',480,1),('mesh',240,1.5)]:
        batch(OUT/'map_refinements'/label,20,[(-12,22)],nt=nt,kmesh=kmesh)
    # Full-period loaded loss case, not reduced stator-period losses.
    for nt in [144,288]:
        solve_case(c,OUT/'peak_losses'/str(nt),nt=nt,na=32,Iq=22.,magnet_C=150.,winding_C=130.,time_periodicity=False)
    dump(OUT/'native_campaign.json',dict(status='completed',
        stages=['map_holdouts','fault_maps','fault_holdouts','geometry','tolerances','map_refinements','peak_losses'],
        statement='Additional executed native simulations; numerical and product acceptance require the separate assessment.'))


if __name__=='__main__':run()
