"""Native Pyleecan motor-only campaign; cases retain actual solver outputs."""
import json
from pathlib import Path
from .native_femm import run_native_femm
from .run import dump

ROOT=Path(__file__).resolve().parents[1]


def solve_case(config,folder,require_output=False,**settings):
    status=folder/'status.json'
    if not status.exists() or json.loads(status.read_text()).get('status')!='completed' or (require_output and not (folder/'native_output.pkl').exists()):
        run_native_femm(config,folder,**settings)
    return json.loads(status.read_text())


def run():
    out=ROOT/'results/motor';out.mkdir(parents=True,exist_ok=True)
    config=json.loads((ROOT/'configs/revised.json').read_text())
    rows=[]
    for nt in [240,480,960]:
        name='time_'+str(nt)
        r=solve_case(config,out/'convergence'/name,nt=nt,Iq=10.814,magnet_C=80)
        rows.append(dict(case=name,**r));dump(out/'convergence/progress.json',rows)
    for kmesh,gap in [(1.5,.0000833333333333),(2.,.0000625)]:
        name='mesh_'+str(kmesh).replace('.','p')
        r=solve_case(config,out/'convergence'/name,nt=480,Iq=10.814,magnet_C=80,kmesh=kmesh,gap_mesh=gap)
        rows.append(dict(case=name,**r));dump(out/'convergence/progress.json',rows)
    dump(out/'convergence/summary.json',dict(status='completed',cases=rows))


if __name__=='__main__':run()
