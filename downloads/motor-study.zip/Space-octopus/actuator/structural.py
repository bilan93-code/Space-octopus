"""Gmsh quadratic solids -> CalculiX carrier strength and modal screening.

Dimensions in mm; N, MPa, tonne, seconds. Loads are balanced tractions on
three pin bores; clamp is the central output hub, not a model of bearing preload.
"""
import json,subprocess,re,os
from pathlib import Path
import numpy as np
import gmsh
from .coupled import gear_loads
from .run import dump

ROOT=Path(__file__).resolve().parents[1]


def carrier_mesh(out,h=2.5):
    gmsh.initialize()
    try:
        gmsh.option.setNumber('General.Terminal',0);gmsh.option.setNumber('General.NumThreads',2)
        gmsh.model.add('stage2 carrier plate')
        o=gmsh.model.occ
        plate=o.addCylinder(0,0,0,0,0,8,52)
        holes=[(2*np.pi*i/3,31.5*np.cos(2*np.pi*i/3),31.5*np.sin(2*np.pi*i/3)) for i in range(3)]
        tools=[(3,o.addCylinder(0,0,-1,0,0,10,12))]+[(3,o.addCylinder(x,y,-1,0,0,10,6)) for _,x,y in holes]
        o.cut([(3,plate)],tools);o.synchronize()
        gmsh.option.setNumber('Mesh.MeshSizeMin',h/2);gmsh.option.setNumber('Mesh.MeshSizeMax',h)
        gmsh.option.setNumber('Mesh.MeshSizeFromCurvature',24)
        gmsh.model.mesh.generate(3);gmsh.model.mesh.setOrder(2)
        tags,xyz,_=gmsh.model.mesh.getNodes();order=np.argsort(tags);tags=np.array(tags)[order];xyz=np.array(xyz).reshape(-1,3)[order]
        types,etags,con=gmsh.model.mesh.getElements(3)
        if list(types)!=[11]:raise ValueError('Expected quadratic tetrahedra')
        elems=np.searchsorted(tags,np.asarray(con[0]).reshape(-1,10))+1
        # Gmsh tetra10 ends with edges 3-2, 3-1; Abaqus/CalculiX expects
        # 3-1, 3-2. Wrong midside ordering produces negative Jacobians.
        elems=elems[:,[0,1,2,3,4,5,6,7,9,8]]
        pins=[];support=[]
        for _,surf in gmsh.model.getEntities(2):
            box=o.getBoundingBox(2,surf)
            # Cylinder surfaces span the complete plate thickness; planar faces do not.
            if box[5]-box[2]<7.9:continue
            _,coords,_=gmsh.model.mesh.getNodes(2,surf,includeBoundary=True)
            pp=np.array(coords).reshape(-1,3)
            radius=np.mean(np.hypot(pp[:,0],pp[:,1]))
            if radius<13:
                nd,_,_=gmsh.model.mesh.getNodes(2,surf,includeBoundary=True)
                support=np.searchsorted(tags,nd)+1
            elif radius<45:
                center=np.mean(pp[:,:2],axis=0)
                j=int(np.argmin([np.linalg.norm(center-np.array([x,y])) for _,x,y in holes]))
                tt,_,nn=gmsh.model.mesh.getElements(2,surf)
                weights=np.zeros(len(tags))
                for kind,nodes in zip(tt,nn):
                    if kind!=9:raise ValueError('Expected quadratic surface triangles')
                    triangles=np.searchsorted(tags,np.array(nodes).reshape(-1,6))
                    for tri in triangles:
                        a,b,c=xyz[tri[:3]];area=np.linalg.norm(np.cross(b-a,c-a))/2
                        weights[tri[3:]]+=area/3
                pins.append((j,weights/weights.sum()))
        if len(pins)!=3 or len(support)==0:raise RuntimeError('Carrier support/pin surfaces not identified')
        out.mkdir(parents=True,exist_ok=True)
        gmsh.write(str(out/f'carrier_h{h:g}.msh'))
        return xyz,elems,support,pins
    finally:gmsh.finalize()


def deck(xyz,elems,support,pins,pinforce,modal=False):
    lines=['*HEADING','Space-octopus carrier: trial quadratic-solid screening','*NODE']
    lines.extend(f'{i+1},'+','.join(f'{v:.10g}' for v in p) for i,p in enumerate(xyz))
    lines+=['*ELEMENT,TYPE=C3D10,ELSET=ALL']
    lines.extend(f'{i+1},'+','.join(map(str,e)) for i,e in enumerate(elems))
    lines+=['*NSET,NSET=HUB']
    lines.extend(','.join(map(str,support[i:i+12])) for i in range(0,len(support),12))
    lines+=['*NSET,NSET=ALLN','1,'+str(len(xyz))] if False else []
    lines+=['*NSET,NSET=ALLN,GENERATE',f'1,{len(xyz)},1','*MATERIAL,NAME=TRIAL_STEEL','*ELASTIC','210000,0.3','*DENSITY','7.85e-9','*SOLID SECTION,ELSET=ALL,MATERIAL=TRIAL_STEEL','*BOUNDARY','HUB,1,3']
    if modal:
        lines+=['*STEP','*FREQUENCY','8','*NODE FILE','U','*END STEP']
    else:
        lines+=['*STEP','*STATIC','*CLOAD']
        for j,weights in pins:
            ang=j*2*np.pi/3;direction=np.array([-np.sin(ang),np.cos(ang)])
            for node in np.where(weights>0)[0]:
                for dof in range(2):
                    if abs(direction[dof])>1e-12:lines.append(f'{node+1},{dof+1},{pinforce*direction[dof]*weights[node]:.10g}')
        lines+=['*NODE PRINT,NSET=ALLN','U','*EL PRINT,ELSET=ALL','S','*NODE FILE','U','*EL FILE','S','*END STEP']
    return '\n'.join(lines)+'\n'


def parse_dat(path,ne):
    lines=path.read_text().splitlines();u=[];s=[];mode=None
    for line in lines:
        low=line.lower()
        if 'displacements' in low:mode='u';continue
        if 'stresses' in low:mode='s';continue
        fields=line.split()
        try:
            vals=[float(x.replace('D','E')) for x in fields]
        except ValueError:continue
        if mode=='u' and len(vals)==4:u.append(vals)
        if mode=='s' and len(vals)==8:s.append(vals)
    if not u or len(s)<ne:raise RuntimeError('Missing complete structural displacement/stress data')
    u=np.array(u);s=np.array(s);sx,sy,sz,txy,txz,tyz=s[:,2:].T
    vm=np.sqrt(.5*((sx-sy)**2+(sy-sz)**2+(sz-sx)**2)+3*(txy**2+txz**2+tyz**2))
    return dict(max_displacement_mm=float(np.linalg.norm(u[:,1:],axis=1).max()),von_mises_max_MPa=float(vm.max()),von_mises_p99_MPa=float(np.quantile(vm,.99)),integration_points=len(s))


def run_carrier(config,out):
    f=gear_loads(config,220)[-1]['nominal_pin_force_N']/2*config['gearbox']['load_factor_screen']
    exe=ROOT/'.local/bin/ccx';env=os.environ.copy();env.update(OMP_NUM_THREADS='2',CCX_NPROC_EQUATION_SOLVER='2',OPENBLAS_NUM_THREADS='1')
    results=[]
    for h in [3.,2.]:
        xyz,elems,support,pins=carrier_mesh(out,h)
        name=f'carrier_h{h:g}';(out/(name+'.inp')).write_text(deck(xyz,elems,support,pins,f))
        proc=subprocess.run([str(exe),'-i',name],cwd=out,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=180)
        (out/(name+'.log')).write_text(proc.stdout)
        if proc.returncode or '*ERROR' in proc.stdout:raise RuntimeError(proc.stdout[-3000:])
        result=parse_dat(out/(name+'.dat'),len(elems));result.update(h_mm=h,nodes=len(xyz),elements=len(elems),pin_force_per_plate_N=f)
        results.append(result)
    (out/'carrier_modes.inp').write_text(deck(xyz,elems,support,pins,f,modal=True))
    proc=subprocess.run([str(exe),'-i','carrier_modes'],cwd=out,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=180)
    (out/'carrier_modes.log').write_text(proc.stdout)
    if proc.returncode or '*ERROR' in proc.stdout:raise RuntimeError(proc.stdout[-2000:])
    frequencies=[]
    text=(out/'carrier_modes.dat').read_text()
    for line in text.splitlines():
        v=line.split()
        if len(v)==5 and v[0].isdigit():
            try:
                z=[float(x) for x in v]
                if z[3]>0:frequencies.append(z[3])
            except ValueError:pass
    if not frequencies:raise RuntimeError('No structural modes found')
    summary=dict(engine='CalculiX 2.20, Gmsh C3D10 quadratic solids',mesh_convergence=results,displacement_change_relative=abs(results[-1]['max_displacement_mm']/results[-2]['max_displacement_mm']-1),stress_p99_change_relative=abs(results[-1]['von_mises_p99_MPa']/results[-2]['von_mises_p99_MPa']-1),clamped_plate_modes_Hz=frequencies,load_case='220 N m, conservative mesh-derived pin reactions, factor 1.5, half reaction on each 8 mm carrier plate',material='assumed E=210 GPa, nu=0.3, density=7850 kg/m3; no certified fatigue allowable',limitations=['Hub fully clamped; actual bearings/bolts/preload not modelled','Pin-bore distributed traction omits bearing contact compliance','No tooth contact, assembly contact or launch analysis','Clamped plate modes are not full-actuator modes'])
    dump(out/'carrier_summary.json',summary)
    return summary
