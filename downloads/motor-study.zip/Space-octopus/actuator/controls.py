"""Native Pyleecan LUT interpolation and short-circuit EEC, plus idealized PI plant."""
import json
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp
from pyleecan.Classes.LUTdq import LUTdq
from pyleecan.Classes.VarLoadCurrent import VarLoadCurrent
from pyleecan.Classes.Simu1 import Simu1
from pyleecan.Classes.Electrical import Electrical
from pyleecan.Classes.EEC_PMSM import EEC_PMSM
from pyleecan.Classes.OPdq import OPdq
from .machine import build_machine
from .run import dump


def run_controls(config,redesign,out):
    out.mkdir(parents=True,exist_ok=True);m=build_machine(config);p=redesign['parameters'];maps=redesign['flux_map']
    interpolation=[]
    for temp in [20,80,140]:
        rows=[x for x in maps if x['magnet_C']==temp]
        array=np.array([[630,r['Id_rms_A'],r['Iq_rms_A']] for r in rows],dtype=float)
        flux=np.array([[r['Phid_rms_Wb'],r['Phiq_rms_Wb'],0] for r in rows])
        var=VarLoadCurrent();var.set_OP_array(array,'N0','Id','Iq',is_update_input=False)
        e=EEC_PMSM(Phid_mag=next(r['Phid_rms_Wb'] for r in rows if r['Id_rms_A']==r['Iq_rms_A']==0),Phiq_mag=0.)
        lut=LUTdq(Phi_dqh_mean=flux,simu=Simu1(machine=m,elec=Electrical(eec=e),mag=None,force=None,struct=None,var_simu=var))
        sample=lut.interp_Phi_dqh(-3.,12.)
        # Verify interpolation at every original grid point, not only that a method returns.
        error=max(np.max(np.abs(lut.interp_Phi_dqh(float(r['Id_rms_A']),float(r['Iq_rms_A']))[:2,0]-flux[j,:2])) for j,r in enumerate(rows))
        lut.save(str(out/f'native_LUTdq_{temp}C.json'))
        interpolation.append(dict(magnet_C=temp,Id_rms_A=-3,Iq_rms_A=12,interpolated_flux_rms_Wb=sample[:,0].tolist(),grid_reconstruction_max_error_Wb=float(error)))
    R=m.stator.comp_resistance_wind(100);Ld=p['Ld_H'];Lq=p['Lq_H'];psi=p['psi_pm_rms_Wb'];we=2*np.pi*52.5
    vlimit=config['drive']['bus_min_V']*config['drive']['modulation_margin']/np.sqrt(6)
    iq_cont=redesign['continuous']['electrical']['Iq_rms_A'];iq_peak=redesign['conditional_limits']['peak_drive_start_end'][0]['Iq_rms_A']
    bandwidth=300.;wc=2*np.pi*bandwidth
    def target(t):return 0 if t<.01 else iq_peak if .10<=t<.105 else iq_cont
    def rhs(t,x):
        id,iq,vdint,vqint=x;err=np.array([-id,target(t)-iq])
        ff=np.array([R*id-we*Lq*iq,R*iq+we*(Ld*id+psi)])
        unsat=ff+np.array([Ld,Lq])*wc*err+np.array([vdint,vqint])
        v=unsat*min(1.,vlimit/max(np.linalg.norm(unsat),1e-12))
        di=np.array([(v[0]-R*id+we*Lq*iq)/Ld,(v[1]-R*iq-we*(Ld*id+psi))/Lq])
        dintegral=R*wc*err+1000*(v-unsat)
        return np.r_[di,dintegral]
    sol=solve_ivp(rhs,[0,.2],[0,0,0,0],t_eval=np.linspace(0,.2,2001),rtol=1e-7,atol=1e-8,max_step=1/20000)
    if not sol.success:raise RuntimeError(sol.message)
    step=np.where((sol.t>.01)&(sol.y[1]>=.9*iq_cont))[0]
    faults=[]
    for temp in [20,80,140]:
        psi_t=psi*(1+config['motor']['magnet_alpha_per_K']*(temp-20))/(1+config['motor']['magnet_alpha_per_K']*60)
        for rpm in [630,1890]:
            op=OPdq(Ud_ref=0.,Uq_ref=0.,N0=float(rpm),felec=float(5*rpm/60))
            e=EEC_PMSM(OP=op,R1=R,Ld=Ld,Lq=Lq,Phid_mag=psi_t,Phiq_mag=0.,type_skin_effect=0)
            r=e.solve();current=float(np.hypot(r['Id'],r['Iq']))
            faults.append(dict(magnet_C=temp,motor_rpm=rpm,Id_rms_A=float(r['Id']),Iq_rms_A=float(r['Iq']),current_rms_A=current,phase_current_peak_A=current*np.sqrt(2),outside_characterized_flux_map=bool(r['Id'] < -12 or r['Iq'] < 0)))
    summary=dict(native_LUTdq_interpolation=interpolation,short_circuit_native_EEC=faults,ideal_PI=dict(bandwidth_Hz=bandwidth,time_to_90pct_s=float(sol.t[step[0]]-.01) if len(step) else None,max_Iq_rms_A=float(sol.y[1].max()),reference_continuous_Arms=iq_cont,reference_peak_Arms=iq_peak,voltage_limit_rms_V=vlimit),limitations=['PI plant is continuous averaged dq at fixed speed, not switched PWM or validated firmware','LUT is a static-rotor FE map, not rotor-averaged and not a measured motor map','Short-circuit values are steady linear-EEC estimates, not peak transients','Fault currents leave the characterized flux-map domain; no demagnetization/drive protection pass is claimed'])
    dump(out/'controls_summary.json',summary);np.savez_compressed(out/'pi_response.npz',t=sol.t,state=sol.y,reference=np.array([target(t) for t in sol.t]))
    return summary
