"""Finish the queued extension stages without concurrent Wine/FEMM jobs."""
import argparse,json,time,traceback
from .runtime import ROOT
from .run import dump


def run(wait_for_native=False):
    out=ROOT/'results/motor/extensions';marker=out/'native_campaign.json'
    if wait_for_native:
        while not marker.exists() or json.loads(marker.read_text()).get('status')!='completed':time.sleep(5)
    from .motor_fault_nonlinear import extend_maps,run as fault
    from .motor_harmonics import run as harmonics
    from .motor_geometry_optimization import run as geometry
    cached={
        'extended_native_fault_map':[out/'fault_expanded'/f'{T}C/summary.json' for T in [20,150]]+[out/'fault_lower_holdouts'/f'{T}C/summary.json' for T in [20,150]],
        'AC_harmonic_FEMM':[out/'harmonics/wire_summary.json',out/'harmonics/magnet_summary.json'],
        'nonlinear_fault_and_PWM':[out/'nonlinear_drive/summary.json',out/'nonlinear_fault_fields/summary.json'],
        'native_geometry_optimization':[out/'geometry_optimization/summary.json']}
    results=[]
    for name,func in [('extended_native_fault_map',extend_maps),('AC_harmonic_FEMM',harmonics),
        ('nonlinear_fault_and_PWM',fault),('native_geometry_optimization',geometry)]:
        print('Starting extension stage:',name,flush=True)
        try:
            paths=cached[name]
            complete=all(p.exists() and json.loads(p.read_text()).get('status')=='completed' for p in paths)
            if name=='nonlinear_fault_and_PWM' and complete:
                complete=json.loads(paths[0].read_text()).get('schema_version')==2
            if not complete:func()
            results.append(dict(stage=name,status='completed'))
        except Exception as exc:
            results.append(dict(stage=name,status='failed',reason=repr(exc),traceback=traceback.format_exc()))
            print(traceback.format_exc(),flush=True)
        dump(out/'remaining_stages.json',results)
    dump(out/'remaining_status.json',dict(status='completed' if all(v['status']=='completed' for v in results) else 'incomplete',stages=results))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--wait-for-native',action='store_true');a=p.parse_args();run(a.wait_for_native)
