"""Static eccentricity with an explicitly custom nonlinear open-source FE route.

No sliding-band symmetry is assumed: translated rotor/shaft geometry is meshed
inside the complete stator. Maxwell forces use closed contours about the stator.
"""
import copy,json
import numpy as np
from .machine import build_machine
from .magnetics import MagneticModel,MU0
from .run import phase_q,dump
from .runtime import ROOT


def run():
    out=ROOT/'results/motor/extensions/eccentricity';out.mkdir(parents=True,exist_ok=True)
    c=json.loads((ROOT/'configs/motor_candidate.json').read_text());cases=[]
    for h in [.0018,.0012]:
        for offset in [[0.,0.],[.00005,0.],[0.,.00005]]:
            label=f'h{h}_x{offset[0]}_y{offset[1]}';folder=out/label;folder.mkdir(exist_ok=True)
            path=folder/'summary.json'
            if path.exists():cases.append(json.loads(path.read_text()));continue
            variant=copy.deepcopy(c);variant['motor']['static_eccentricity_m']=offset;m=build_machine(variant)
            checkpoint=folder/'progress.json';rows=json.loads(checkpoint.read_text()) if checkpoint.exists() else []
            for index,angle in enumerate(np.arange(36)*np.deg2rad(2)):
                if index<len(rows):continue
                fe=MagneticModel(m,variant,h=h,angle=float(angle))
                no=fe.nonlinear(fe.solve(temperature_C=80));currents=phase_q(no['phase_flux_Wb'])*10.814
                loaded=fe.nonlinear(fe.solve(currents=currents,temperature_C=80))
                contours=[]
                for fraction in [.35,.5,.65]:
                    r=.026+.0005*fraction;br,bt=fe.airgap_fields(loaded,r);theta=np.arange(len(br))*2*np.pi/len(br)
                    pr=(br*br-bt*bt)/(2*MU0);pt=br*bt/MU0;L=m.stator.L1;ds=2*np.pi*r/len(br)
                    fx=L*ds*np.sum(pr*np.cos(theta)-pt*np.sin(theta));fy=L*ds*np.sum(pr*np.sin(theta)+pt*np.cos(theta))
                    torque=L*ds*r*np.sum(pt)-(offset[0]*fy-offset[1]*fx)
                    contours.append(dict(Fx_N=float(fx),Fy_N=float(fy),rotor_center_torque_Nm=float(torque)))
                rows.append(dict(angle_mechanical_deg=float(np.rad2deg(angle)),contours=contours,
                    nonlinear_residual=loaded['nonlinear_residual'],current_ABC_A=currents.tolist()))
                dump(checkpoint,rows)
            fx=np.array([v['contours'][1]['Fx_N'] for v in rows]);fy=np.array([v['contours'][1]['Fy_N'] for v in rows])
            result=dict(status='completed',engine='Project Pyleecan-surfaces -> Gmsh -> nonlinear scikit-fem; not MagFEMM',
                h_m=h,eccentricity_m=offset,poses=rows,mean_Fx_N=float(fx.mean()),mean_Fy_N=float(fy.mean()),
                maximum_radial_force_N=float(np.hypot(fx,fy).max()),mean_torque_Nm=float(np.mean([v['contours'][1]['rotor_center_torque_Nm'] for v in rows])),
                physical_minimum_bare_gap_mm=(.0005-np.linalg.norm(offset))*1000)
            dump(path,result);cases.append(result)
    dump(out/'summary.json',dict(status='completed',cases=cases,limitations=[
        'Generic extrapolated B-H material; static displacement only, not dynamic whirl/contact',
        'Sampled mechanical period 72 degrees with 36 positions; forces are screening loads, not hardware measurements',
        'The contour and mesh sensitivity are retained rather than hidden by a single force estimate']))


if __name__=='__main__':run()
