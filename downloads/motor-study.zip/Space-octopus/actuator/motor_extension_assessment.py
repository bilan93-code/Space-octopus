"""Assess the additional calculations, preserving failed/open acceptance gates."""
import json
import numpy as np
from scipy.interpolate import RegularGridInterpolator
from .runtime import ROOT
from .motor_extensions import OUT
from .motor_fault_nonlinear import FluxMap
from .run import dump


def run():
    def read(path):return json.loads((OUT/path).read_text())
    old=json.loads((ROOT/'results/motor/maps/summary.json').read_text())['rows'];axes=([20,80,150],[-12,-6,0],[0,10.814,22])
    interpolators={}
    for key in ['Phid_rms_Wb','Phiq_rms_Wb','FE_mean_torque_Nm']:
        values=np.array([next(v[key] for v in old if v['magnet_C']==T and v['Id_rms_A']==d and v['Iq_rms_A']==q) for T in axes[0] for d in axes[1] for q in axes[2]]).reshape(3,3,3)
        interpolators[key]=RegularGridInterpolator(axes,values)
    holds=[]
    for path in sorted((OUT/'map_holdouts').glob('*C/summary.json')):
        for row in json.loads(path.read_text())['rows']:
            point=[row['magnet_C'],row['Id_rms_A'],row['Iq_rms_A']]
            predicted={k:float(f(point)) for k,f in interpolators.items()}
            actual=np.array([row['Phid_rms_Wb'],row['Phiq_rms_Wb']]);pred=np.array([predicted[k] for k in ['Phid_rms_Wb','Phiq_rms_Wb']])
            holds.append(dict(point=point,relative_flux_vector_error=float(np.linalg.norm(pred-actual)/np.linalg.norm(actual)),
                relative_torque_error=float(abs(predicted['FE_mean_torque_Nm']/row['FE_mean_torque_Nm']-1))))
    fault_holds=[]
    for T in [20,150]:
        flux=FluxMap(T)
        for name in ['fault_holdouts','fault_lower_holdouts']:
            for row in read(f'{name}/{T}C/summary.json')['rows']:
                i=[row['Id_rms_A'],row['Iq_rms_A']];phi,_=flux.evaluate(i);phi-=np.array(i)*.00008
                actual=np.array([row['Phid_rms_Wb'],row['Phiq_rms_Wb']])
                fault_holds.append(dict(T_C=T,Id=i[0],Iq=i[1],flux_error_Wb=float(np.linalg.norm(phi-actual)),
                    relative_flux_vector_error=float(np.linalg.norm(phi-actual)/max(np.linalg.norm(actual),.005))))
    ref=next(v for v in old if v['magnet_C']==20 and v['Id_rms_A']==-12 and v['Iq_rms_A']==22)
    refinements=[]
    for key in ['time','mesh']:
        r=read(f'map_refinements/{key}/summary.json')['rows'][0]
        refinements.append(dict(case=key,torque_relative_change=float(abs(r['FE_mean_torque_Nm']/ref['FE_mean_torque_Nm']-1)),
            flux_vector_relative_change=float(np.linalg.norm(np.array([r['Phid_rms_Wb']-ref['Phid_rms_Wb'],r['Phiq_rms_Wb']-ref['Phiq_rms_Wb']]))/
                np.hypot(ref['Phid_rms_Wb'],ref['Phiq_rms_Wb']))))
    peak=[read(f'peak_losses/{nt}/status.json') for nt in [144,288]]
    convergence={k:float(abs(peak[1]['loss_W'][k]/peak[0]['loss_W'][k]-1)) for k in ['stator_bertotti','rotor_bertotti','magnets']}
    tolerance=[];base=read('tolerances/reference/status.json')
    for path in sorted((OUT/'tolerances').glob('*/status.json')):
        r=json.loads(path.read_text());rpm=630;w=rpm*2*np.pi/60
        # Retain the explicit 30 W non-copper + 3 W friction stress allowance.
        shaft=r['torque_Nm']-33/w;output=shaft*63*.8
        tolerance.append(dict(case=path.parent.name,torque_Nm=r['torque_Nm'],relative_torque_change=r['torque_Nm']/base['torque_Nm']-1,
            conditional_output_torque_at_22Arms_with_33W_drag_Nm=output,continuous_220Nm_screen=bool(output>=220),optional_400Nm_screen=bool(output>=400)))
    eccentricity=read('eccentricity/summary.json')['cases'];stiffness=[]
    E=210e9;span=.113;shaft_k=48*E*np.pi*.012**4/(64*span**3)
    for row in eccentricity:
        e=np.asarray(row['eccentricity_m']);enorm=np.linalg.norm(e)
        if not enorm:continue
        parallel=(row['mean_Fx_N']*e[0]+row['mean_Fy_N']*e[1])/enorm
        kmag=parallel/enorm
        minimum_bearing=kmag*shaft_k/(shaft_k-kmag) if 0<kmag<shaft_k else None
        scenarios=[]
        for kb in [1e6,1e7,1e8]:
            effective=1/(1/kb+1/shaft_k);stable=effective>kmag
            amplification=effective/(effective-kmag) if stable else None
            scenarios.append(dict(assumed_bearing_pair_radial_stiffness_N_m=kb,combined_shaft_bearing_stiffness_N_m=effective,
                local_linear_static_stability=bool(stable),eccentricity_amplification=amplification,
                added_radial_displacement_um=(amplification-1)*enorm*1e6 if stable else None))
        stiffness.append(dict(h_m=row['h_m'],offset_m=row['eccentricity_m'],parallel_magnetic_pull_N=float(parallel),
            magnetic_negative_stiffness_N_m=float(kmag),shaft_midspan_stiffness_N_m=float(shaft_k),
            minimum_pair_bearing_stiffness_N_m=minimum_bearing,scenarios=scenarios))
    wire=read('harmonics/wire_summary.json')['rows'];magnet=read('harmonics/magnet_summary.json')['rows'];acmesh=[]
    materials=read('thermal_materials/summary.json');feedforward=read('torque_feedforward/summary.json')
    for T in [80,150]:
        a=next(v for v in magnet if v['magnet_C']==T and v['frequency_Hz']==20000 and v['magnet_mesh_m']==.0003)
        b=next(v for v in magnet if v['magnet_C']==T and v['frequency_Hz']==20000 and v['magnet_mesh_m']==.00015)
        acmesh.append(dict(T_C=T,frequency_Hz=20000,
            q_loss_relative_change=float(abs(b['unit_basis_losses_W']['q']/a['unit_basis_losses_W']['q']-1)),
            d_loss_relative_change=float(abs(b['unit_basis_losses_W']['d']/a['unit_basis_losses_W']['d']-1))))
    result=dict(status='completed',normal_map_holdouts=holds,fault_map_holdouts=fault_holds,map_corner_refinements=refinements,
        peak_loss_time_refinement_relative_change=convergence,tolerances=tolerance,magnetic_pull_stability=stiffness,
        AC_wire_maximum_fine_mesh_analytic_error=max(abs(v['relative_error']) for v in wire if v['wire_radius_mesh_divisor']==24),
        AC_magnet_mesh_refinement=acmesh,thermal_material_scenarios=materials['assembly_scenarios'],
        torque_feedforward_cases=feedforward['cases'],
        gates=dict(normal_map_holdout_0p5pct=all(v['relative_flux_vector_error']<.005 and v['relative_torque_error']<.005 for v in holds),
            fault_map_holdout_2pct=all(v['relative_flux_vector_error']<.02 for v in fault_holds),
            peak_loss_time_refinement_3pct=all(v<.03 for v in convergence.values()),
            optional_peak_tolerance_robust=all(v['optional_400Nm_screen'] for v in tolerance),
            physical_validation=False,product_release=False),
        statement='Finite verification campaign; additional solver use does not close material/mission/hardware acceptance gates')
    dump(OUT/'assessment.json',result);return result


if __name__=='__main__':run()
