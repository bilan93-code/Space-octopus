"""Reproduce primary and additional motor analysis, checks, reports and package."""
import os,subprocess,sys
from .runtime import ROOT


def run():
    from .motor_study import run as original
    from .motor_extensions import run as native
    from .motor_eccentricity import run as eccentricity
    from .motor_loss_extensions import run as loss
    from .motor_remaining import run as remaining
    from .motor_candidate_envelope import run as envelope
    from .motor_thermal_materials import run as thermal_materials
    from .motor_torque_feedforward import run as feedforward
    from .motor_mechanics import run as mechanics
    from .motor_requirements import run as requirements
    from .motor_pwm_loss_coupling import run as PWM_loss
    from .motor_extension_assessment import run as assess
    from .motor_extension_report import build as report
    from .motor_report import build as primary_report
    original();native();eccentricity();loss();thermal_materials();remaining();envelope();feedforward()
    mechanics(ROOT/'results/motor/mechanics');requirements();PWM_loss();assess();report();primary_report()
    env=dict(os.environ,OPENBLAS_NUM_THREADS='1')
    with (ROOT/'results/motor/verification.txt').open('w') as log:
        result=subprocess.run([sys.executable,'-m','pytest','-q'],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
    if result.returncode:raise RuntimeError('Verification failed; see results/motor/verification.txt')
    subprocess.run([sys.executable,'scripts/prepare_motor_cad_package.py'],cwd=ROOT,env=env,check=True)
    subprocess.run(['bash','scripts/freecad_python.sh','scripts/export_motor_active_cad.py'],cwd=ROOT,check=True)
    subprocess.run([sys.executable,'scripts/record_provenance.py'],cwd=ROOT,env=env,check=True)
    subprocess.run([sys.executable,'scripts/package_study.py'],cwd=ROOT,check=True)
    print('Additional motor report:',ROOT/'results/motor/extensions/report.pdf',flush=True)


if __name__=='__main__':run()
