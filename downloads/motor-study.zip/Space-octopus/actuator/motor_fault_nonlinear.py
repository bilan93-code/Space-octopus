"""FEMM flux-map dynamics: differential saturation, short circuit and PWM.

This is a project integration around official nonlinear MagFEMM solutions,
not a claim that magnetostatic FEMM is a time-domain eddy-current solver.
"""
import json,shutil
import numpy as np
from scipy.integrate import solve_ivp
from .motor_extensions import OUT,batch
from .runtime import ROOT
from .machine import build_machine
from .run import dump

D=[-60.,-30.,0.,6.];Q=[-36.,-24.,0.,24.]


def extend_maps():
    for T in [20,150]:
        folder=OUT/'fault_expanded'/f'{T}C';folder.mkdir(parents=True,exist_ok=True)
        previous=OUT/'fault_maps'/f'{T}C'
        for path in previous.glob('point_*'):
            if path.suffix in ['.pkl','.json'] and not (folder/path.name).exists():shutil.copy2(path,folder/path.name)
        batch(folder,T,[(d,q) for d in D for q in Q])
        batch(OUT/'fault_lower_holdouts'/f'{T}C',T,[(d,-30.) for d in [-45.,-15.]])


class FluxMap:
    def __init__(self,T):
        rows=[]
        for temp in [20,150]:rows.append(json.loads((OUT/'fault_expanded'/f'{temp}C/summary.json').read_text())['rows'])
        a=[]
        for tab in rows:
            a.append([[[next(v[k] for v in tab if v['Id_rms_A']==d and v['Iq_rms_A']==q) for k in ['Phid_rms_Wb','Phiq_rms_Wb']] for q in Q] for d in D])
        weight=(T-20)/130
        if not 0<=weight<=1:raise ValueError('Temperature outside native map domain')
        self.values=(1-weight)*np.array(a[0])+weight*np.array(a[1]);self.end=.00008

    def evaluate(self,current):
        d,q=current
        if d<D[0]-1e-6 or d>D[-1]+1e-6 or q<Q[0]-1e-6 or q>Q[-1]+1e-6:
            raise ValueError('Fault/drive state outside characterized map: '+str(current))
        i=int(np.clip(np.searchsorted(D,d,side='right')-1,0,len(D)-2));j=int(np.clip(np.searchsorted(Q,q,side='right')-1,0,len(Q)-2))
        dx=D[i+1]-D[i];dy=Q[j+1]-Q[j];x=(d-D[i])/dx;y=(q-Q[j])/dy
        v00=self.values[i,j];v10=self.values[i+1,j];v01=self.values[i,j+1];v11=self.values[i+1,j+1]
        phi=(1-x)*(1-y)*v00+x*(1-y)*v10+(1-x)*y*v01+x*y*v11+self.end*np.array(current)
        dd=((1-y)*(v10-v00)+y*(v11-v01))/dx
        dq=((1-x)*(v01-v00)+x*(v11-v10))/dy
        J=np.column_stack([dd,dq])+self.end*np.eye(2)
        return phi,J

    def derivative(self,current,voltage,omega,R):
        phi,J=self.evaluate(current);f=np.asarray(voltage)-R*np.asarray(current)+omega*np.array([phi[1],-phi[0]])
        det=J[0,0]*J[1,1]-J[0,1]*J[1,0]
        if det<=0:raise ValueError('Nonpositive incremental map determinant')
        return np.array([J[1,1]*f[0]-J[0,1]*f[1],-J[1,0]*f[0]+J[0,0]*f[1]])/det


def nonlinear_PWM(flux,R,substeps=40,bus=42):
    fs=20000;dt=1/(fs*substeps);omega=2*np.pi*52.5;wc=2*np.pi*300
    current=np.zeros(2);integral=np.zeros(2);command=np.zeros(2);records=[]
    for n in range(int(.1/dt)):
        t=n*dt;theta=omega*t;cs=np.cos(theta-np.arange(3)*2*np.pi/3);sn=np.sin(theta-np.arange(3)*2*np.pi/3)
        ref=0 if t<.002 else 21.3 if .02<=t<.07 else 10.84
        if n%substeps==0:
            phi,J=flux.evaluate(current);err=np.array([-current[0],ref-current[1]])
            ff=R*current+omega*np.array([-phi[1],phi[0]])
            unsat=ff+wc*(J@err)+integral;command=unsat*min(1.,bus/np.sqrt(6)/max(np.linalg.norm(unsat),1e-12))
            integral+=(R*wc*err+1000*(command-unsat))/fs
        vref=np.sqrt(2)*(command[0]*cs-command[1]*sn);offset=(vref.max()+vref.min())/2
        duty=np.clip(.5+(vref-offset)/bus,0,1);carrier=abs(2*(n%substeps)/substeps-1)
        switch=(duty>carrier).astype(float);iabc=np.sqrt(2)*(current[0]*cs-current[1]*sn)
        vabc=bus*(switch-switch.mean())-bus*1e-6*fs*np.sign(iabc);vabc-=vabc.mean()
        v=np.array([2/(3*np.sqrt(2))*(vabc@cs),-2/(3*np.sqrt(2))*(vabc@sn)])
        current+=dt*flux.derivative(current,v,omega,R)
        if n%4==0:records.append([t,*current,*iabc,ref])
    a=np.array(records);steady=a[a[:,0]>.085];peak=a[(a[:,0]>.06)&(a[:,0]<.07)]
    return a,dict(substeps=substeps,PWM_Hz=fs,bus_V=bus,deadtime_s=1e-6,
        maximum_current_vector_Arms=float(np.hypot(a[:,1],a[:,2]).max()),maximum_phase_instantaneous_A=float(np.abs(a[:,3:6]).max()),
        steady_mean_Iq_Arms=float(steady[:,2].mean()),peak_mean_Iq_Arms=float(peak[:,2].mean()),
        steady_tracking_error_relative=float(abs(steady[:,2].mean()/10.84-1)),peak_tracking_error_relative=float(abs(peak[:,2].mean()/21.3-1)))


def run():
    out=OUT/'nonlinear_drive';out.mkdir(parents=True,exist_ok=True)
    c=json.loads((ROOT/'configs/motor_candidate.json').read_text());m=build_machine(c);faults=[];jacobians=[];pwm=[];end_sensitivity=[]
    rho=c['motor']['steel_density_kg_m3'];L=.085
    Jrotor=.5*rho*.95*np.pi*(.023**4-.006**4)*L+.5*(8300*.8*np.pi*(.026**4-.023**4)*L)+.5*rho*np.pi*.006**4*.13
    for T in [20,150]:
        flux=FluxMap(T);Tw=min(T,130);R=m.stator.comp_resistance_wind(Tw)
        for d in np.linspace(D[0],D[-1],21):
            for q in np.linspace(Q[0],Q[-1],21):
                _,J=flux.evaluate([d,q]);eig=np.linalg.eigvalsh((J+J.T)/2)
                jacobians.append(dict(T_C=T,Id=d,Iq=q,min_differential_inductance_H=float(eig.min()),
                    reciprocity_error_H=float(abs(J[0,1]-J[1,0]))))
        for rpm in [630,945,1890]:
            omega=2*np.pi*5*rpm/60
            sol=solve_ivp(lambda t,i:flux.derivative(i,[0,0],omega,R),[0,.1],[0,10.84],
                t_eval=np.linspace(0,.1,4001),max_step=2e-5,rtol=2e-7,atol=1e-8)
            if not sol.success:raise RuntimeError(sol.message)
            phi=np.array([flux.evaluate(i)[0] for i in sol.y.T]);torque=15*(phi[:,0]*sol.y[1]-phi[:,1]*sol.y[0])
            row=dict(T_C=T,magnet_C=T,winding_C=Tw,motor_rpm=rpm,mode='fixed speed',peak_current_vector_Arms=float(np.hypot(*sol.y).max()),
                minimum_Id_Arms=float(sol.y[0].min()),maximum_Id_Arms=float(sol.y[0].max()),minimum_Iq_Arms=float(sol.y[1].min()),
                Iq_at_minimum_Id_Arms=float(sol.y[1,np.argmin(sol.y[0])]),
                torque_min_Nm=float(torque.min()),torque_max_Nm=float(torque.max()),
                copper_energy_J=float(np.trapz(3*R*np.sum(sol.y**2,axis=0),sol.t)))
            faults.append(row);np.savez_compressed(out/f'fault_{T}C_{rpm}rpm.npz',t=sol.t,current=sol.y.T,torque=torque)
        for end in [0.,.00016]:
            flux.end=end
            for rpm in [630,1890]:
                omega=2*np.pi*5*rpm/60
                sol=solve_ivp(lambda t,i:flux.derivative(i,[0,0],omega,R),[0,.1],[0,10.84],
                    t_eval=np.linspace(0,.1,4001),max_step=2e-5,rtol=2e-7,atol=1e-8)
                if not sol.success:raise RuntimeError(sol.message)
                phi=np.array([flux.evaluate(i)[0] for i in sol.y.T]);torque=15*(phi[:,0]*sol.y[1]-phi[:,1]*sol.y[0])
                index=int(np.argmin(sol.y[0]));end_sensitivity.append(dict(T_C=T,magnet_C=T,winding_C=Tw,
                    motor_rpm=rpm,end_leakage_H=end,mode='end leakage sensitivity',
                    torque_min_Nm=float(torque.min()),torque_max_Nm=float(torque.max()),
                    peak_current_vector_Arms=float(np.hypot(*sol.y).max()),minimum_Id_Arms=float(sol.y[0,index]),
                    Iq_at_minimum_Id_Arms=float(sol.y[1,index])))
        flux.end=.00008
        # Mechanical coast-down scenarios: specified output inertia reflected
        # through 63:1, without inventing an actual robot-arm inertia.
        for Jout in [0.,1.,10.,100.]:
            total=Jrotor+Jout/63**2
            def rhs(t,state):
                i=state[:2];w=state[2];phi,_=flux.evaluate(i);torque=15*(phi[0]*i[1]-phi[1]*i[0])
                return [*flux.derivative(i,[0,0],5*w,R),(torque-4.365079365)/total]
            def stop(t,state):return state[2]
            stop.terminal=True;stop.direction=-1
            sol=solve_ivp(rhs,[0,.1],[0,10.84,630*2*np.pi/60],events=stop,max_step=2e-5,rtol=2e-7,atol=1e-8)
            if not sol.success:raise RuntimeError(sol.message)
            faults.append(dict(T_C=T,magnet_C=T,winding_C=Tw,motor_rpm=630,mode='coast down',assumed_output_inertia_kg_m2=Jout,
                rotor_inertia_kg_m2=Jrotor,total_reflected_inertia_kg_m2=total,
                peak_current_vector_Arms=float(np.hypot(sol.y[0],sol.y[1]).max()),
                minimum_Id_Arms=float(sol.y[0].min()),time_simulated_s=float(sol.t[-1]),
                final_motor_rpm=float(sol.y[2,-1]*60/(2*np.pi))))
        # Hot winding resistance with independently selected magnet temperature.
        for substeps in [40,80]:
            a,row=nonlinear_PWM(flux,m.stator.comp_resistance_wind(130),substeps=substeps)
            row.update(magnet_C=T,winding_C=130);pwm.append(row)
            np.savez_compressed(out/f'PWM_{T}C_substeps{substeps}.npz',data=a)
    summary=dict(status='completed',schema_version=2,engine='Native nonlinear FEMM flux interpolation and differential Jacobian -> project switched drive/fault dynamics',
        current_domain_Arms=dict(Id=D,Iq=Q),temperature_endpoints_C=[20,150],faults=faults,switched_PWM=pwm,
        end_leakage_sensitivity=end_sensitivity,
        minimum_sampled_incremental_inductance_H=min(v['min_differential_inductance_H'] for v in jacobians),
        maximum_sampled_reciprocity_error_H=max(v['reciprocity_error_H'] for v in jacobians),
        limitations=['Rotor-averaged magnetostatic map, not transient electromagnetic eddy-current FE',
            '80 microhenry assumed end leakage; map interpolation requires the independent holdout checks',
            'Coast-down inertia values are declared scenarios; real arm inertia and load are unavailable',
            'Coast-down uses ideal reciprocal kinematics for reflected inertia and fixed resisting shaft torque',
            'No semiconductor commutation/EMC model, irreversible magnet recoil or hardware protection verification'])
    dump(out/'summary.json',summary)
    from .motor_fault_fields import run as update_fields
    update_fields(summary)
    return summary


if __name__=='__main__':
    extend_maps();run()
