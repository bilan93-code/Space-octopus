"""Official Pyleecan loss and force postprocessing of labelled FE fields.

The magnetic source is explicitly the project's Gmsh/scikit-fem adapter unless
native_femm.py has produced a verified FEMM result. No native magnetic solve is
implied by using native postprocessing classes.
"""
from pathlib import Path
import json
import numpy as np
from SciDataTool import DataTime,Data1D,DataLinspace,VectorField
from pyleecan.Classes.MeshMat import MeshMat
from pyleecan.Classes.NodeMat import NodeMat
from pyleecan.Classes.ElementMat import ElementMat
from pyleecan.Classes.RefTriangle3 import RefTriangle3
from pyleecan.Classes.FPGNTri import FPGNTri
from pyleecan.Classes.ScalarProductL2 import ScalarProductL2
from pyleecan.Classes.MeshSolution import MeshSolution
from pyleecan.Classes.SolutionVector import SolutionVector
from pyleecan.Classes.SolutionData import SolutionData
from pyleecan.Classes.Simu1 import Simu1
from pyleecan.Classes.Output import Output
from pyleecan.Classes.OPdq import OPdq
from pyleecan.Classes.InputCurrent import InputCurrent
from pyleecan.Classes.Loss import Loss
from pyleecan.Classes.LossModelBertotti import LossModelBertotti
from pyleecan.Classes.LossModelMagnet import LossModelMagnet
from pyleecan.Classes.LossModelJoule import LossModelJoule
from pyleecan.Classes.LossModelProximity import LossModelProximity
from pyleecan.Classes.ForceMT import ForceMT
from .magnetics import MagneticModel
from .run import phase_q,dump


def make_native_output(machine,fe,B,A,gap,nrpm=630,iq=9):
    nt,ne,_=B.shape;freq=machine.get_pole_pair_number()*nrpm/60
    # Full mechanical turn is necessary for rotor-material-frame periodicity.
    Time=DataLinspace(name='time',unit='s',initial=0,final=60/nrpm,number=nt,include_endpoint=False)
    Ind=Data1D(name='indice',values=np.arange(ne),is_components=True)
    Z=Data1D(name='z',unit='m',values=[machine.stator.L1/2])
    axes=[Time,Ind,Z]
    components={k:DataTime(name=k,symbol=k,unit='T',axes=axes,values=B[:,:,j,None]) for j,k in enumerate(['comp_x','comp_y'])}
    vec=VectorField(name='FE material-frame B',symbol='B',components=components)
    mesh=MeshMat(dimension=2,node=NodeMat(coordinate=fe.mesh.p.T,nb_node=int(fe.mesh.nvertices),indice=np.arange(fe.mesh.nvertices)))
    mesh.element_dict['triangle']=ElementMat(connectivity=fe.mesh.t.T,nb_element=int(ne),nb_node_per_element=3,indice=np.arange(ne),ref_element=RefTriangle3(),gauss_point=FPGNTri(nb_gauss_point=1),scalar_product=ScalarProductL2())
    groups={name:[] for name in ['stator core','rotor core','stator winding','rotor magnets']}
    for rid,label in fe.labels.items():
        ids=np.where(fe.region==rid)[0].tolist()
        if 'Stator' in label and '_Lamination' in label:groups['stator core']+=ids
        if 'Rotor' in label and '_Lamination' in label:groups['rotor core']+=ids
        if '_Winding' in label:groups['stator winding']+=ids
        if '_Magnet' in label:
            from pyleecan.Functions.labels import decode_label
            n=decode_label(label)['S_id'];groups['rotor magnets_'+str(n)]=ids;groups['rotor magnets']+=ids
    ms=MeshSolution(mesh=mesh,group=groups)
    ms.solution_dict['B']=SolutionVector(label='B',field=vec,type_element='triangle')
    ms.solution_dict['A_z^{element}']=SolutionData(label='A_z^{element}',field=DataTime(name='potential',symbol='A_z^{element}',unit='Wb/m',axes=axes,values=A[:,:,None]),type_element='triangle')
    # Synthetic coefficient split reproduces 3 W/kg at 50 Hz, 1.5 T.
    # These are declared assumptions, NOT experimentally identified coefficients.
    kh=1.8/(50*1.5**2);ke=1.05/(50*1.5)**2;kex=.15/(50*1.5)**1.5
    loss=Loss(Tsta=100,Trot=80,is_get_meshsolution=True,model_dict={
        'stator_bertotti':LossModelBertotti(group='stator core',k_hy=kh,k_ed=ke,k_ex=kex),
        'rotor_bertotti':LossModelBertotti(group='rotor core',k_hy=kh,k_ed=ke,k_ex=kex),
        'copper':LossModelJoule(group='stator winding',type_skin_effect=1),
        'proximity':LossModelProximity(group='stator winding'),
        'magnets':LossModelMagnet(group='rotor magnets')})
    simu=Simu1(machine=machine,elec=None,mag=None,force=ForceMT(is_periodicity_a=False,is_periodicity_t=False),struct=None,loss=loss)
    out=Output(simu=simu)
    out.geo.per_a=1;out.geo.is_antiper_a=False
    out.elec.OP=OPdq(Id_ref=0.,Iq_ref=float(iq),N0=float(nrpm),felec=float(freq))
    out.simu.input=InputCurrent(OP=out.elec.OP.copy(),Nt_tot=int(nt),Na_tot=int(gap.shape[1]),Nrev=1,current_dir=1,rot_dir=1,angle_rotor_initial=0.)
    out.geo.per_t_S=1;out.geo.per_t_R=1
    out.mag.meshsolution=ms
    angle=DataLinspace(name='angle',unit='rad',initial=0,final=2*np.pi,number=gap.shape[1],include_endpoint=False)
    gap_axes=[Time,angle,Z]
    out.mag.Rag=(machine.rotor.comp_radius_mec()+machine.stator.comp_radius_mec())/2
    out.mag.B=VectorField(name='Air gap B',symbol='B',components={k:DataTime(name=k,symbol=k,unit='T',axes=gap_axes,values=gap[:,:,j,None]) for j,k in enumerate(['radial','tangential'])})
    out.mag.axes_dict={'time':Time,'angle':angle,'z':Z}
    return out,dict(k_hy=kh,k_ed=ke,k_ex=kex)


def run_native_history(machine,config,outdir,nt=144):
    outdir.mkdir(parents=True,exist_ok=True)
    reference=MagneticModel(machine,config,h=.002)
    resume=outdir/'history_checkpoint.npz'
    existing=None
    if resume.exists():
        from skfem import MeshTri,Basis,ElementTriP1
        saved=np.load(outdir/'reference_mesh.npz')
        reference.mesh=MeshTri(saved['p'],saved['t'],sort_t=False)
        reference.basis=Basis(reference.mesh,ElementTriP1())
        reference.centers=reference.mesh.p[:,reference.mesh.t].mean(axis=1)
        reference.areas=reference.basis.dx.sum(axis=1)
        reference.region=saved['region'];reference.kind=saved['kind']
        reference.labels={int(k):v for k,v in json.loads((outdir/'reference_labels.json').read_text()).items()}
        existing=np.load(resume)
    np.savez_compressed(outdir/'reference_mesh.npz',p=reference.mesh.p,t=reference.mesh.t,region=reference.region,kind=reference.kind)
    dump(outdir/'reference_labels.json',reference.labels)
    ctr=reference.centers
    # Keep material-centre queries away from boundary chord differences.
    rotor=np.array([('Rotor' in reference.labels[x]) for x in reference.region])
    B=[];A=[];gap=[];metrics=[]
    if existing is not None:
        B=list(existing['B']);A=list(existing['A']);gap=list(existing['gap'])
        if B[0].shape[0]!=reference.mesh.nelements:raise ValueError('History/reference mesh mismatch')
    for k,angle in enumerate(np.linspace(0,2*np.pi,nt,endpoint=False)):
        if k<len(B):continue
        print('Native postprocessing history',k+1,'/',nt,flush=True)
        fe=reference if k==0 else MagneticModel(machine,config,h=.002,angle=float(angle))
        no=fe.nonlinear(fe.solve());s=fe.nonlinear(fe.solve(9*phase_q(no['phase_flux_Wb'])))
        # Rotor material rotates: query in global frame then transform B back.
        z=ctr[0]+1j*ctr[1];query=z.copy();query[rotor]*=np.exp(1j*angle)
        # Keep exterior probes inside both polygonal approximations of the
        # circular boundary. Boundaries differ slightly after remeshing.
        radius=np.abs(query);outer=machine.stator.Rext-.0001
        clipped=radius>outer;query[clipped]*=outer/radius[clipped]
        from matplotlib.tri import Triangulation
        finder=Triangulation(fe.mesh.p[0],fe.mesh.p[1],fe.mesh.t.T).get_trifinder()
        idx=np.asarray(finder(query.real,query.imag))
        if np.any(idx<0):raise ValueError('Material probe outside magnetic mesh')
        bb=s['B'][:,idx].copy();bc=bb[0]+1j*bb[1];bc[rotor]*=np.exp(-1j*angle)
        B.append(np.column_stack([bc.real,bc.imag]))
        tri=fe.mesh.t[:,idx]
        p0=fe.mesh.p[:,tri[0]];v1=fe.mesh.p[:,tri[1]]-p0;v2=fe.mesh.p[:,tri[2]]-p0
        rr=np.array([query.real,query.imag])-p0
        det=v1[0]*v2[1]-v1[1]*v2[0]
        u=(rr[0]*v2[1]-rr[1]*v2[0])/det;v=(v1[0]*rr[1]-v1[1]*rr[0])/det
        A.append((1-u-v)*s['a'][tri[0]]+u*s['a'][tri[1]]+v*s['a'][tri[2]])
        br,bt=fe.airgap_fields(s,(machine.rotor.comp_radius_mec()+machine.stator.comp_radius_mec())/2)
        gap.append(np.column_stack([br,bt]));metrics.append(fe.metrics(s))
        if (k+1)%12==0 or k==nt-1:
            np.savez_compressed(outdir/'history_checkpoint.npz',B=np.array(B),A=np.array(A),gap=np.array(gap))
    B=np.array(B);A=np.array(A);gap=np.array(gap)
    return reprocess_history(machine,config,outdir)


def reprocess_history(machine,config,outdir):
    """Run native postprocessing from retained fields, without rerunning magnetics."""
    from types import SimpleNamespace
    from skfem import MeshTri
    z=np.load(outdir/'reference_mesh.npz');ref=SimpleNamespace()
    ref.mesh=MeshTri(z['p'],z['t'],sort_t=False);ref.region=z['region'];ref.kind=z['kind']
    ref.labels={int(k):v for k,v in json.loads((outdir/'reference_labels.json').read_text()).items()}
    h=np.load(outdir/'history_checkpoint.npz');B=h['B'];A=h['A'];gap=h['gap']
    if len(B)!=144:raise RuntimeError('Full 144-position mechanical history is required')
    o,coeff=make_native_output(machine,ref,B,A,gap)
    o.simu.loss.run();o.simu.force.run()
    losses={k:float(v.get_loss_scalar(52.5)) for k,v in o.loss.loss_dict.items()}
    f=o.force.AGSF.get_rphiz_along('time','angle','z=mean')
    pr=f['radial'];pt=f['tangential'];np.savez_compressed(outdir/'native_force_fields.npz',radial_Pa=pr,tangential_Pa=pt)
    summary=dict(engine='Official Pyleecan LossModelBertotti, LossModelMagnet, LossModelJoule (skin), LossModelProximity, ForceMT',magnetic_source='Custom Gmsh/scikit-fem solver; NOT a native MagFEMM solve',samples=144,span='one full mechanical revolution',motor_rpm=630,excitation_Arms=9,mesh_elements=int(ref.mesh.nelements),loss_W=losses,bertotti_coefficients_assumed=coeff,force_radial_min_Pa=float(pr.min()),force_radial_max_Pa=float(pr.max()),force_tangential_peak_Pa=float(np.max(np.abs(pt))),nyquist_frequency_Hz=144/2*630/60,limitations=['Coefficients reproduce a generic 3 W/kg point; no calibration dataset','Material-frame fields transferred between meshes; exterior probes clipped 0.1 mm inside outer CAD circle','Resolved frequencies only; PWM switching loss not represented','Magnet resistivity assumed 0.9 microohm m; no supplier data','Native SlotM11 segmentation correction uses equal-area-square dimensions','2-D field losses omit conductive-field reaction and full 3-D end effects'])
    dump(outdir/'native_models.json',summary)
    return summary
