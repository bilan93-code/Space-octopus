"""Guard Pyleecan 1.5.2's Linux file link against partial request/response files.

Only transport is scoped here; official geometry, field solving and postprocessing
methods are unchanged. The installed Pyleecan/FEMM files are never edited.
"""
import ast,importlib,os,time
from contextlib import contextmanager
from pathlib import Path


def numeric_expression(node):
    """Decode FEMM's a+I*b numeric syntax without evaluating executable code."""
    if isinstance(node,ast.Expression):return numeric_expression(node.body)
    if isinstance(node,ast.List):return [numeric_expression(v) for v in node.elts]
    if isinstance(node,ast.Constant) and isinstance(node.value,(int,float,complex)):return node.value
    if isinstance(node,ast.UnaryOp) and isinstance(node.op,(ast.UAdd,ast.USub)):
        value=numeric_expression(node.operand)
        if not isinstance(value,(int,float,complex)):raise ValueError('Non-numeric operand in FEMM response')
        return value if isinstance(node.op,ast.UAdd) else -value
    if isinstance(node,ast.BinOp) and isinstance(node.op,(ast.Add,ast.Sub,ast.Mult)):
        left=numeric_expression(node.left);right=numeric_expression(node.right)
        if not isinstance(left,(int,float,complex)) or not isinstance(right,(int,float,complex)):
            raise ValueError('Non-numeric operand in FEMM response')
        if isinstance(node.op,ast.Add):return left+right
        if isinstance(node.op,ast.Sub):return left-right
        return left*right
    raise ValueError('Non-numeric expression in FEMM response')


def file_call(handler,command,stats=None,timeout=90,poll_interval=.002):
    module=importlib.import_module('pyleecan.Classes._FEMMHandler')
    request=Path(module.ifile);response=Path(module.ofile)
    if response.exists():raise RuntimeError('Unexpected stale FEMM response; run one job per project Wine prefix')
    deadline=time.monotonic()+timeout
    while request.exists():
        if time.monotonic()>=deadline:raise TimeoutError('Previous FEMM request has not been consumed')
        time.sleep(poll_interval)
    temporary=request.with_name(request.name+'.'+str(os.getpid())+'.tmp')
    temporary.write_text('flput('+command+')')
    os.replace(str(temporary),str(request))
    deadline=time.monotonic()+timeout
    while True:
        try:raw=response.read_text().strip()
        except FileNotFoundError:raw=''
        if raw.startswith('e'):
            response.unlink()
            raise RuntimeError(raw)
        if raw.startswith('[') and raw.endswith(']'):
            encoded=raw.replace('[ ','[').replace(' ]',']').replace(' ', ',').replace('I','1j')
            try:values=ast.literal_eval(encoded)
            except (ValueError,SyntaxError):values=numeric_expression(ast.parse(encoded,mode='eval'))
            # The FEMM file-link protocol returns a bracketed numeric list.
            if not isinstance(values,list):raise RuntimeError('Invalid FEMM response')
            response.unlink()
            if stats is not None:stats['commands']+=1
            return values[0] if len(values)==1 else values
        if time.monotonic()>=deadline:raise TimeoutError('Incomplete FEMM file-link response to '+command[:100])
        if stats is not None:stats['response_polls']+=1
        time.sleep(poll_interval)


@contextmanager
def reliable_femm_transport():
    module=importlib.import_module('pyleecan.Classes._FEMMHandler')
    cls=module._FEMMHandler;original=cls.callfemm_Linux
    stats=dict(commands=0,response_polls=0,poll_interval_s=.002,request_writes='atomic rename',response_reads='complete bracketed list')
    def guarded(self,command):return file_call(self,command,stats)
    cls.callfemm_Linux=guarded
    try:yield stats
    finally:cls.callfemm_Linux=original
