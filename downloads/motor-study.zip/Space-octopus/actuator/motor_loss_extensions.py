"""Additional official loss formulations and measured-in-simulation PWM spectra."""
import json,pickle
import numpy as np
from scipy.special import jv
from pyleecan.Classes.Loss import Loss
from pyleecan.Classes.LossModelWinding import LossModelWinding
from pyleecan.Classes.LossModelSteinmetz import LossModelSteinmetz
from pyleecan.Classes.LossModelWindagePyrhonen import LossModelWindagePyrhonen
from .machine import build_machine
from .runtime import ROOT
from .run import dump


def wire_factor(f,T=100):
    f=np.asarray(f,dtype=float);rho=1.724e-8*(1+.00393*(T-20));a=.00095/2
    z=np.sqrt(-1j*2*np.pi*f*4e-7*np.pi/rho)*a
    safe=np.where(f>0,z,1e-10+0j)
    ratio=np.real(safe*jv(0,safe)/(2*jv(1,safe)))
    return np.where(f>0,ratio,1.)


def spectrum(path):
    a=np.load(path)['data'];a=a[a[:,0]>.075];t=a[:,0];dt=float(np.median(np.diff(t)))
    X=np.column_stack([np.ones(len(t)),np.cos(2*np.pi*52.5*t),np.sin(2*np.pi*52.5*t)])
    phase=a[:,3:6];residual=phase-X@np.linalg.lstsq(X,phase,rcond=None)[0]
    w=np.hanning(len(t));s=np.fft.rfft(residual*w[:,None],axis=0)/(len(t)*np.sqrt(np.mean(w*w)))
    powers=2*np.abs(s)**2;powers[0]*=.5
    powers[-1]*=.5
    return np.fft.rfftfreq(len(t),dt),powers


def run():
    out=ROOT/'results/motor/extensions/loss_formulations';out.mkdir(parents=True,exist_ok=True)
    with (ROOT/'results/motor/full_period/288/native_output.pkl').open('rb') as f:r=pickle.load(f)
    c=json.loads((ROOT/'configs/motor_candidate.json').read_text());r.simu.machine=build_machine(c)
    r.simu.loss=Loss(Tsta=100,Trot=80,is_get_meshsolution=True,model_dict={
        'winding':LossModelWinding(group='stator winding',type_skin_effect=1),
        'stator_steinmetz':LossModelSteinmetz(group='stator core',k_hy=1.8/(50*1.5**2),k_ed=1.2/(50*1.5)**2,alpha_f=1.,alpha_B=2.),
        'rotor_steinmetz':LossModelSteinmetz(group='rotor core',k_hy=1.8/(50*1.5**2),k_ed=1.2/(50*1.5)**2,alpha_f=1.,alpha_B=2.),
        'air_windage':LossModelWindagePyrhonen(group='rotor core')})
    r.simu.loss.run()
    values={k:float(v.get_loss_scalar(52.5)) for k,v in r.loss.loss_dict.items()}
    kskin=float(r.simu.loss.model_dict['winding'].comp_coeff(T_op=100))
    spectral=[]
    for path in sorted((ROOT/'results/motor/candidate_drive').glob('PWM_*.npz')):
        T=130 if '130C' in path.name else 100;freq,powers=spectrum(path);pick=freq>=1000
        R=r.simu.machine.stator.comp_resistance_wind(T)
        iso=float(np.sum(powers[pick]*wire_factor(freq[pick,None],T))*R)
        # The low-frequency Pyrhonen expansion is retained as a sensitivity,
        # not extrapolated silently into a validated high-frequency result.
        case_kskin=float(r.simu.loss.model_dict['winding'].comp_coeff(T_op=T))
        pyr=float(np.sum(powers[pick]*(1+case_kskin*freq[pick,None]**2))*R)
        dc=float(powers[pick].sum()*R)
        spectral.append(dict(case=path.name,winding_C=T,ripple_phase_variance_sum_A2=float(powers[pick].sum()),
            harmonic_copper_W_Rdc=dc,harmonic_copper_W_isolated_round_wire=iso,
            harmonic_copper_W_Pyrhonen_low_frequency_expansion=pyr))
    np.savez_compressed(out/'wire_skin_reference.npz',frequency_Hz=np.geomspace(100,200000,120),
        ratio100C=wire_factor(np.geomspace(100,200000,120),100),ratio130C=wire_factor(np.geomspace(100,200000,120),130))
    result=dict(status='completed',official_models_executed=values,round_wire_Pyrhonen_k_Hz_minus2=kskin,
        PWM_harmonic_screens=spectral,harmonic_frequency_min_Hz=1000,
        limitations=['Steinmetz/Bertotti coefficients share an assumed 3 W/kg calibration point, not supplier loss data',
            'Native WindagePyrhonen hard-codes atmospheric air density/viscosity and rotor iron radius; not a vacuum windage prediction',
            'Isolated round-wire Bessel impedance omits neighboring-conductor proximity',
            'The Pyrhonen low-frequency polynomial is a sensitivity at PWM frequencies, not a validated bound',
            'Current spectrum comes from the ideal-switch controller; device rise times and common-mode paths are absent'])
    dump(out/'summary.json',result);return result


if __name__=='__main__':run()
