"""Required allowable stresses and life-capacity screens, not certified ratings."""
import math
from .coupled import gear_geometry,gear_loads
from .run import dump


def run_mechanical(c,out):
    g=c['gearbox'];hours=10000;rows=[];n=630
    for j,(s,loads) in enumerate(zip(g['stages'],gear_loads(c,220))):
        ratio=gear_geometry(s)['ratio'];nc=n/ratio;nr=n-nc;rp=s['module_m']*s['planet']/2;rs=s['module_m']*s['sun']/2
        alpha=math.radians(20);Fn=loads['nominal_mesh_tangential_N']/math.cos(alpha)*g['load_factor_screen']
        reff=1/(1/(rs*math.sin(alpha))+1/(rp*math.sin(alpha)));Estar=210e9/(2*(1-.3**2))
        contact=math.sqrt(Fn*Estar/(math.pi*s['face_m']*reff))/1e9
        planet_speed=nr*s['sun']/s['planet'];bearing_P=loads['nominal_pin_force_N']*g['load_factor_screen'];life_million=planet_speed*60*hours/1e6
        rows.append(dict(stage=j+1,input_rpm=n,carrier_rpm=nc,planet_relative_rpm=planet_speed,sun_tooth_cycles_at_10000h=nr*s['planets']*60*hours,ring_tooth_cycles_at_10000h=nc*s['planets']*60*hours,pitch_line_speed_carrier_frame_m_s=rs*nr*2*math.pi/60,factored_Hertz_sun_planet_pitch_GPa=contact,required_contact_allowable_for_1p3_margin_GPa=1.3*contact,required_bending_allowable_for_1p5_margin_MPa=1.5*loads['factored_bending_screen_MPa'],planet_bearing_required_C_for_10000h_kN=bearing_P*life_million**.3/1000,planet_bearing_required_C0_for_S0_2_at_400Nm_kN=2*bearing_P*400/220/1000))
        n=nc
    pinF=gear_loads(c,220)[-1]['nominal_pin_force_N']*1.5;pin_stress=8*pinF*.032/(math.pi*.012**3)/1e6
    summary=dict(assumed_life_hours=hours,gear_and_planet_bearing_screens=rows,stage2_pin_screen=dict(support_span_mm=32,diameter_mm=12,continuous_factored_bending_MPa=pin_stress,peak_factored_bending_MPa=pin_stress*400/220),output_interface_trade=dict(proposed_bolts='6 x M6, nominal preload 8 kN/bolt, 55 mm effective friction radius',friction_torque_capacity_Nm_at_mu_0p08=.08*6*8000*.055,friction_torque_capacity_Nm_at_mu_0p12=.12*6*8000*.055,peak_400Nm_friction_only_supported=False,proposed_positive_torque_feature='3 x 5 mm dowels at 45 mm radius; not included in current CAD',dowel_shear_at_400Nm_MPa=400/(3*.045)/(math.pi*.005**2/4)/1e6),limitations=['10000 h is an analysis scenario, not a user requirement','Hertz pitch-point contact and Lewis factor screens are not ISO 6336 ratings','Required material allowables are outputs to specify and verify, not assumed certified strengths','Planet load sharing, reversed planet-tooth fatigue, lubrication and rim flexibility unresolved','Bearing formulas apply assumed constant radial load to planetary pin bearings; no output-bearing selection from driving torque alone','The bolt preload circle is an interface trade, not the current flange CAD: a 55 mm circle radius requires a flange larger than 104 mm OD','Bolt preload/friction scatter, thermal relaxation, joint separation and contact preload require detailed design'])
    dump(out,summary);return summary
