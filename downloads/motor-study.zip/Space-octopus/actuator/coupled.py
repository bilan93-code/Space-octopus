"""Gear, Pyleecan RMS dq electrical, and SciPy thermal coupling."""
import numpy as np
from scipy.optimize import root
from scipy.integrate import solve_ivp
from pyleecan.Classes.EEC_PMSM import EEC_PMSM
from pyleecan.Classes.OPdq import OPdq
from pyleecan.Classes.Simu1 import Simu1
from pyleecan.Classes.Electrical import Electrical


def gear_geometry(stage):
    s,p,r,n,m,b=[stage[k] for k in ['sun','planet','ring','planets','module_m','face_m']]
    a=m*(s+p)/2
    return dict(ratio=1+r/s,closure_ok=(r==s+2*p),assembly_ok=((s+r)%n==0),planet_tip_clearance_mm=1000*(2*a*np.sin(np.pi/n)-m*(p+2)),ring_pitch_mm=1000*m*r,ring_root_mm=1000*m*(r+2.5),sun_root_mm=1000*m*(s-2.5),sun_pitch_mm=1000*m*s,planet_center_radius_mm=1000*a)


def gear_loads(config, output_Nm):
    c=config['gearbox'];stages=c['stages']; ratios=[gear_geometry(s)['ratio'] for s in stages]
    # Use consistent conservative total efficiency spread equally over stages.
    eta=c['efficiency_budget']**(1/len(stages))
    tin=output_Nm/(np.prod(ratios)*c['efficiency_budget'])
    out=[]
    for stage,i in zip(stages,ratios):
        ft=2*tin/(stage['planets']*stage['module_m']*stage['sun'])
        sig=ft*c['load_factor_screen']/(stage['face_m']*stage['module_m']*c['lewis_factor_screen'])
        out.append(dict(input_torque_Nm=tin,nominal_mesh_tangential_N=ft,factored_bending_screen_MPa=sig/1e6,nominal_pin_force_N=2*ft,nominal_pin_bending_MPa=8*(2*ft)*c['pin_span_m']/(np.pi*c['pin_diameter_m']**3)/1e6))
        tin*=i*eta
    return out


def electrical_point(machine, config, params, torque_Nm, rpm, winding_C, magnet_C):
    """Pyleecan uses RMS dq currents, voltages and PM linkage.

    Therefore torque=3*p*psi_rms*Iq_rms and sinusoidal amplitude is sqrt(2)*RMS.
    All finite-element phase linkages arrive as instantaneous Wb-turns.
    """
    c=config['motor'];p=c['pole_pairs']
    scale=(1+c['magnet_alpha_per_K']*(magnet_C-20))/(1+c['magnet_alpha_per_K']*(c['magnet_reference_C']-20))
    psi=params['psi_pm_rms_Wb']*scale
    iq=torque_Nm/(3*p*psi)
    # Speed-zero torque equation remains well defined; no power/speed division.
    resistance=machine.stator.comp_resistance_wind(float(winding_C))
    op=OPdq(Id_ref=0.,Iq_ref=float(iq),N0=float(rpm),felec=float(p*rpm/60))
    eec=EEC_PMSM(OP=op,R1=resistance,Ld=params['Ld_H'],Lq=params['Lq_H'],Phid_mag=psi,Phiq_mag=0.,Phid=psi,Phiq=params['Lq_H']*iq,type_skin_effect=0)
    # Parent linkage is required by native comp_torque_sync_rel.
    simu=Simu1(machine=machine,elec=Electrical(eec=eec),mag=None,force=None,struct=None)
    e=simu.elec.eec
    values=e.solve()
    losses=e.comp_joule_losses(values,machine)
    ts,tr=e.comp_torque_sync_rel()
    vrms=np.hypot(values['Ud'],values['Uq'])
    vlimit=config['drive']['bus_min_V']*config['drive']['modulation_margin']/np.sqrt(6)
    return dict(Iq_rms_A=iq,Ud_rms_V=float(values['Ud']),Uq_rms_V=float(values['Uq']),phase_voltage_peak_V=float(vrms*np.sqrt(2)),voltage_rms_V=float(vrms),voltage_limit_rms_V=float(vlimit),copper_loss_W=float(losses['Pj_losses']),electromagnetic_torque_Nm=float(ts+tr),phase_resistance_ohm=resistance,voltage_ok=bool(vrms<=vlimit),current_ok=bool(iq<=config['drive']['phase_current_limit_rms_A']))


def loss_and_electrical(machine,config,params,temps,output_Nm,output_rpm,eta=None):
    if eta is None: eta=config['gearbox']['efficiency_budget']
    ratio=np.prod([gear_geometry(s)['ratio'] for s in config['gearbox']['stages']])
    nm=output_rpm*ratio; wm=nm*2*np.pi/60
    pout=output_Nm*output_rpm*2*np.pi/60
    gear_heat=abs(pout)*(1/eta-1)
    # Assumed loss law; stator hysteresis+eddy mix, uncalibrated harmonic allowance.
    # params core_ref derived from FEA local B amplitudes at 630 rpm.
    scale=abs(nm)/630
    core=params['core_loss_ref_W']*(.6*scale+.4*scale**2)
    friction=config['operating']['parasitic_motor_loss_W_at_630rpm']*scale
    shaft_torque=output_Nm/(ratio*eta)
    loss_torque=(core+friction)/wm if abs(wm)>1e-12 else 0.
    elec=electrical_point(machine,config,params,shaft_torque+loss_torque,nm,temps[0],temps[1])
    rotor_loss=.15*core+.5*friction
    stator_case_loss=.85*core+.5*friction
    heat=np.array([elec['copper_loss_W'],rotor_loss,stator_case_loss,gear_heat])
    pin=pout+heat.sum()
    elec.update(output_power_W=pout,gearbox_heat_W=gear_heat,core_loss_W=core,friction_loss_W=friction,motor_shaft_torque_Nm=shaft_torque,motor_rpm=nm,inverter_loss_W=pin*(1/config['drive']['inverter_efficiency']-1),bus_input_W=pin/config['drive']['inverter_efficiency'],system_efficiency=(pout/(pin/config['drive']['inverter_efficiency']) if pin>0 else 0.))
    return heat,elec


def thermal_outflow(config,t):
    c=config['thermal'];w,r,m,g=t;s=c['sink_C'];sig=5.670374419e-8
    wm=(w-m)/c['R_winding_case_K_W'];rm=(r-m)/c['R_rotor_case_K_W']
    mg=(m-g)/c['R_case_coupling_K_W']
    radm=c['case_emissivity']*sig*c['motor_radiating_area_m2']*((m+273.15)**4-c['radiative_surroundings_K']**4)
    radg=c['case_emissivity']*sig*c['gear_radiating_area_m2']*((g+273.15)**4-c['radiative_surroundings_K']**4)
    return np.array([wm,rm,(m-s)/c['R_motor_case_sink_K_W']+mg+radm-wm-rm,(g-s)/c['R_gear_case_sink_K_W']-mg+radg]),radm+radg


def steady_state(machine,config,params,output_Nm=220,output_rpm=10,eta=None):
    def residual(t):
        heat,_=loss_and_electrical(machine,config,params,t,output_Nm,output_rpm,eta)
        return thermal_outflow(config,t)[0]-heat
    sol=root(residual,np.array([90.,85.,70.,75.])+config['thermal']['sink_C']-50)
    if not sol.success or np.max(np.abs(residual(sol.x)))>1e-5:
        raise RuntimeError('Thermal equilibrium did not converge: '+str(sol.message))
    t=sol.x
    heat,elec=loss_and_electrical(machine,config,params,t,output_Nm,output_rpm,eta)
    out,rad=thermal_outflow(config,t)
    c=config['thermal'];conducted=(t[2]-c['sink_C'])/c['R_motor_case_sink_K_W']+(t[3]-c['sink_C'])/c['R_gear_case_sink_K_W']
    return dict(temperatures_C=dict(zip(['winding','rotor','motor_case','gear_case'],map(float,t))),electrical=elec,total_actuator_heat_W=float(sum(heat)),radiated_heat_W=float(rad),conducted_to_sink_W=float(conducted),thermal_residual_W=float(np.max(np.abs(out-heat))),thermal_ok=bool(t[0]<=c['winding_limit_C'] and t[1]<=c['magnet_screen_limit_C']))


def transient(machine,config,params,initial,torque_Nm,rpm,duration_s):
    c=config['thermal'];cap=np.array([c[k] for k in ['C_winding_J_K','C_rotor_J_K','C_motor_case_J_K','C_gear_case_J_K']])
    def rhs(time,t):
        heat,_=loss_and_electrical(machine,config,params,t,torque_Nm,rpm)
        return (heat-thermal_outflow(config,t)[0])/cap
    sol=solve_ivp(rhs,[0,duration_s],initial,t_eval=np.linspace(0,duration_s,101),rtol=1e-7,atol=1e-8)
    if not sol.success: raise RuntimeError(sol.message)
    return dict(time_s=sol.t.tolist(),temperatures_C=sol.y.T.tolist())


def operating_limits(machine,config,params,continuous,peak):
    """Conditional, fixed-Id=0 operating limits; no FEA or hardware rating implied."""
    from scipy.optimize import brentq
    tc=config['operating']['output_continuous_Nm'];speed=config['operating']['output_rpm']
    def margin(torque,rpm,which):
        r=steady_state(machine,config,params,torque,rpm);e=r['electrical']
        if which=='voltage': return e['voltage_rms_V']-e['voltage_limit_rms_V']
        if which=='current': return e['Iq_rms_A']-config['drive']['phase_current_limit_rms_A']
        return r['temperatures_C']['winding']-config['thermal']['winding_limit_C']
    def crossing(fun,lower,upper):
        if fun(lower)>0: return None
        if fun(upper)<0: return None
        return float(brentq(fun,lower,upper,xtol=1e-6))
    vmax=crossing(lambda rpm:margin(tc,rpm,'voltage'),0,40)
    limits={k:crossing(lambda torque:margin(torque,speed,k),0,400) for k in ['voltage','current','thermal']}
    # Evaluate actual pulse trajectory endpoints instead of using a hypothetical
    # steady 400 N m winding temperature to infer short-pulse drive demand.
    ep=[]
    for temps in [peak['temperatures_C'][0],peak['temperatures_C'][-1]]:
        _,e=loss_and_electrical(machine,config,params,temps,config['operating']['peak_Nm'],speed)
        ep.append(e)
    bus_needed=max(e['phase_voltage_peak_V'] for e in ep)*np.sqrt(3)/config['drive']['modulation_margin']
    return dict(voltage_limited_output_rpm_at_required_torque=vmax,output_torque_limits_Nm_at_design_speed=limits,peak_drive_start_end=ep,peak_required_bus_V_with_modulation_margin=float(bus_needed))
