"""Evidence-based extended product/design report from executed component results."""
import json,shutil,base64,math
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
import markdown
from .report import make_pdf
from .run import dump


def build_report(out):
    def read(p):return json.loads((out/p).read_text())
    n=read('electromagnetics/native_models.json');s=read('structural/carrier_summary.json');r=read('redesign/redesign_summary.json');ctrl=read('controls/controls_summary.json');th=read('thermal/thermal_fea_summary.json');cad=read('cad/cad_status.json');g=read('mechanical_screens.json');fm=read('native_femm/status.json');ee=read('native_electrical/status.json')
    base=json.loads((out.parent/'baseline/analysis.json').read_text());cont=r['continuous'];e=cont['electrical'];lim=r['conditional_limits'];stress=s['mesh_convergence'][-1];maps=r['flux_map']
    if fm.get('status')!='completed' or ee.get('status')!='completed':raise RuntimeError('Native solver/electrical evidence is incomplete')
    comparison=abs(fm['torque_Nm']/base['magnetic_checks']['FE_mean_torque_9Arms_Nm']-1)
    convergence=read('native_femm/convergence.json')
    refinements='\n'.join(f"| {v['case'].replace('_',' ')} | {v['requested_time_steps']} | {v['gap_mesh_m']*1e6:.1f} | {v['torque_Nm']:.5f} | {v['torque_change_relative']*100:.3f} | {v['loss_W']['stator_bertotti']:.4f} | {v['loss_W']['rotor_bertotti']:.4f} | {v['loss_W']['magnets']:.4f} |" for v in convergence['cases'])
    time_refined=next(v for v in convergence['cases'] if v['case']=='time_refined')
    losses=n['loss_W'];noncu=sum(v for k,v in losses.items() if k not in ['copper','proximity'])
    sens=[]
    for v in r['thermal_loss_scenarios']:
        sens.append(f"| {v['sink_C']} | {v['assumed_core_rotor_loss_W']} | {v['output_torque_Nm']} | {v['temperatures_C']['winding']:.1f} | {'pass' if v['thermal_ok'] else 'exceeds limit'} |")
    mech=[]
    for x in g['gear_and_planet_bearing_screens']:
        mech.append(f"| {x['stage']} | {x['factored_Hertz_sun_planet_pitch_GPa']:.3f} | {x['required_contact_allowable_for_1p3_margin_GPa']:.3f} | {x['required_bending_allowable_for_1p5_margin_MPa']:.1f} | {x['planet_bearing_required_C_for_10000h_kN']:.2f} |")
    lr='\n'.join(f'| {k} | {v:.4f} |' for k,v in losses.items())
    trs='\n'.join(f"| {x['winding_effective_k_W_mK']} | {x['winding_average_C']:.2f} | {x['winding_node_max_C']:.2f} | {x['R_average_winding_case_K_W']:.4f} |" for x in th['scenarios'])
    dr='\n'.join(f"| {v['stator_OD_mm']} | {v['motor_active_mass_kg']:.3f} | {v['params']['torque_constant_Nm_per_Arms']:.4f} | {v['magnetic_screen']['iron_B_p99_T']:.3f} |" for v in r['discrete_trade'])
    text=f'''# Space-octopus: extended analysis and design proposal

Motor rating update: this report records the earlier actuator/concept study.
The motor-first report at results/motor/report.pdf supersedes its motor thermal
conclusions. Native full-mechanical-period rotor losses and spatial stationary
holding checks found limits missed by average-temperature calculations. Use
configs/motor_candidate.json and the motor report for the corrective winding,
distributed cooling, drive/fault and construction requirements. The earlier
concept CAD and actuator screens remain preliminary.

## 1. What this study establishes

The original preliminary study has been extended with official Pyleecan MagFEMM,
electrical-to-FEMM flux linkage, loss, force, lookup-table interpolation and fault
electrical calculations; nonlinear
current/temperature field maps; CalculiX 3-D carrier strength and modes; 2-D stator
thermal finite elements; a winding/cooling trade study; and FreeCAD concept CAD.

A revised candidate uses 12 turns per coil instead of 15, two 0.9 mm copper strands
instead of 0.8 mm, a 96 mm stator OD, a 22 Arms phase-current inverter, and tighter
thermal-interface requirements. At 220 N m and 10 output rpm, its nominal scenario
calculates {e['Iq_rms_A']:.2f} Arms, {e['phase_voltage_peak_V']:.2f} V phase peak,
and {cont['temperatures_C']['winding']:.1f} deg C winding temperature at a 50 deg C sink.
The nominal model assumes 3 W core/rotor loss, with 10/30 W alternatives below.
These values depend on cooling targets, not demonstrated thermal hardware.

Both the custom magnetic solver and official Pyleecan MagFEMM now execute.
The native solver predicts {fm['torque_Nm']:.4f} N m at 9 Arms, within
{100*comparison:.2f} percent of the independent custom FE mean. The revised
motor also executes Electrical(EEC_PMSM(fluxlink=MagFEMM)); its hot comparison
point requires {ee['phase_voltage_peak_V']:.2f} V phase peak and produces
{ee['total_torque_Nm']:.3f} N m. This verifies real solver couplings rather than
only creating runner files. The installed FEMM binary came from a public cache
and matches the official release checksum byte-for-byte.

This remains an engineering study and a concept design, not completion of all
Pyleecan capabilities or a product release. Loss convergence, supplier data,
complete mechanical interfaces and physical qualification remain open. No
standards compliance or flight qualification is inferred from numerical tests.

## 2. Exact capability coverage

| Capability | Actual execution | Boundary |
| --- | --- | --- |
| Machine, slots, winding, resistance, material masses | Official Pyleecan classes | Generic material data |
| Nonlinear magnetic FE | Official MagFEMM/FEMM and independent custom Gmsh/scikit-fem | Generic materials, 2-D model |
| Core losses | Official LossModelBertotti | Assumed coefficient split, actual FE time history |
| Copper/skin and proximity losses | Official LossModelJoule and LossModelProximity | Frequency-limited model, no switched inverter |
| Magnet eddy-current loss | Official LossModelMagnet | 2-D postprocessing, assumed resistivity and simplified arc dimensions |
| Air-gap force fields | Official ForceMT module | Not a complete vibroacoustic assembly model |
| Current/temperature flux maps | Nonlinear FE, 27 operating points | Static rotor position, not rotor-averaged maps |
| Lookup-table interpolation | Official LUTdq at three temperatures | Built from those static FE maps |
| dq electrical/fault calculations | Official EEC_PMSM, including MagFEMM flux linkage | Steady linear fault estimates, not fault transients |
| Current controller | SciPy averaged dq PI plant | No PWM, DSP firmware, timing or hardware validation |
| Carrier strength and eigenmodes | CalculiX 2.20, quadratic 3-D elements | Clamped single plate, assumed steel |
| Stator conduction | scikit-fem 2-D transverse FE | No axial/end-turn/contact-resolved thermal model |
| Gear/bearing/interface screens | Explicit analytical equations | Not ISO fatigue/contact or output-bearing certification |
| Concept CAD | FreeCAD 1.0.0, native file and STEP | Individual solids valid; full assembly clearance unverified |
| Official MagFEMM | Executed under Wine, with native ForceMT and loss models | Coarse time/mesh validation; not a converged full loss map |
| MagElmer/StructElmer | Not executed | This release contains unfinished extraction and skipped structural validation tests |
| Hardware and mission qualification | Not performed | Requires physical components and mission requirements |

The official Pyleecan Elmer source and tests were inspected. Unfinished flux
extraction is visible in MagElmer.solve_FEA, and StructElmer validation tests in
Tests/Simulation/test_StructElmer.py are skipped as needing correction. That is
why these interfaces are not claimed as validated alternatives here.

## 3. Full-revolution field history and official loss/force coupling

The baseline 15-turn motor was solved at 9 Arms and 630 rpm, with 80 deg C magnet
properties. The history contains {n['samples']} positions over one complete mechanical
revolution. A full revolution, rather than one electrical period, makes the
rotor-material sampling periodic as it passes the stator slots. Stator samples
remain fixed in space; rotor samples and vector components are transformed into
rotor material coordinates. The reference mesh has {n['mesh_elements']} triangles.

For this 144-position history, the magnetic source is the custom nonlinear solver.
An independent official MagFEMM run is compared in section 11. Fields Bx, By and A_z
were packaged in official Pyleecan MeshMat/MeshSolution, SolutionVector and
SolutionData objects, then passed through native Loss and ForceMT run methods.
Native copper loss uses a 100 deg C winding resistance. The history is not the
same operating point as the redesigned candidate or a measured motor.

Bertotti model: p = k_h f B squared + k_e (f B) squared + k_ex (f B)^1.5.
Coefficients are {n['bertotti_coefficients_assumed']}, selected to reproduce a
generic 3 W/kg point at 50 Hz and 1.5 T, not fitted to a certified dataset.
Native magnet loss uses J = -sigma d(A_z - magnet-area-mean A_z)/dt, and integrates
J squared / sigma. Assumed magnet resistivity is 0.9 microohm m. Native SlotM11
geometry is reduced to equal-area square dimensions in its segmentation correction.
No conductive-field feedback or full 3-D eddy-current solution is implied.

| Native loss source | Computed W at this history point |
| --- | --- |
{lr}

The summed core-plus-magnet result is {noncu:.4f} W. This replaces neither a
calibrated material loss map nor the redesigned machine's own full history.
The redesigned study deliberately includes 3/10/30 W loss sensitivities.

The Nyquist limit is {n['nyquist_frequency_Hz']:.1f} Hz; PWM switching losses above
that are absent. Mesh-to-mesh interpolation introduces additional uncertainty,
especially for high-frequency loss terms. Exterior probes are clipped 0.1 mm
inside the outer circle to avoid different mesh chord approximations. Loss
convergence with time step and mesh has NOT been established; a 144-sample run
must not be described as a converged PWM or eddy-current loss prediction.

Native ForceMT computes p_r = -(Br squared - Bt squared)/(2 mu0) and
p_t = -Br Bt/mu0 with its stator traction convention. Recorded radial extrema are
{n['force_radial_min_Pa']/1000:.1f} to {n['force_radial_max_Pa']/1000:.1f} kPa;
peak tangential traction magnitude is {n['force_tangential_peak_Pa']/1000:.1f} kPa.
These are air-gap tractions, not external arm bearing forces. The pressure
spectrum is available for later structural transfer; it was not applied as a
load on the gearbox carrier, where gear-pin reactions are the physical loads.

## 4. Winding and stator design trade

| Trial stator OD mm | Iron + winding + magnet mass kg | Static torque constant N m/Arms | Loaded iron B p99 T |
| --- | --- | --- | --- |
{dr}

These trials use the same 52 mm magnet OD, 53 mm stator bore, 85 mm active stack,
12 slots, 10 poles and 63:1 gearbox. The selected 96 mm stator is a conservative
intermediate design retaining more yoke than the 92 mm candidate. It is not a
global optimum; no mission mass/size requirement or manufacturing cost model was
provided. These masses exclude shaft, frame, bearings and the complete gearbox.

For fixed slot copper fill, fewer turns lower voltage demand but raise phase
current. Approximately, psi is proportional to N, L to N squared, and R to N/A.
The two 0.9 mm strands maintain a similar copper-fill level while reducing
resistance. The inverter must support 22 Arms, or 31.1 A sinusoidal phase peak,
plus a separately designed fault-protection margin.

The revised model's conditional voltage-limited speed at 220 N m is
{lim['voltage_limited_output_rpm_at_required_torque']:.2f} output rpm, compared
with {base['conditional_limits']['voltage_limited_output_rpm_at_required_torque']:.2f}
for the baseline. Its 400 N m, five-second thermal-load scenario requires about
{lim['peak_drive_start_end'][-1]['Iq_rms_A']:.2f} Arms and
{lim['peak_drive_start_end'][-1]['phase_voltage_peak_V']:.2f} V phase peak at the
pulse endpoint. The minimum DC bus implied by the same modulation margin is
{lim['peak_required_bus_V_with_modulation_margin']:.2f} V. This passes the assumed
42 V bus/current screens, but does not establish gear, bearing or demagnetization
peak capability.

## 5. Nonlinear current/temperature maps and native LUTdq

Twenty-seven FE points cover Id = -12/-6/0 Arms, Iq = 0/9/18 Arms, and magnet
T = 20/80/140 deg C. Each point includes nonlinear residual, RMS dq flux,
torque/voltage, B-H extrapolated area, and the reverse magnetizing field.
The map uses a single rotor position. It therefore cannot claim rotor-averaged
MTPA, calibrated field weakening, full efficiency maps or torque-ripple optima.

Official LUTdq objects were created at each temperature and interp_Phi_dqh ran
both off-grid and at every original grid point. Maximum grid reconstruction
error is {max(x['grid_reconstruction_max_error_Wb'] for x in ctrl['native_LUTdq_interpolation']):.3g} Wb.
This verifies the interpolation pipeline, not the accuracy of sparse interpolation
between nonlinear operating points. The native objects are saved as JSON.

The magnet screen computes H_parallel = (B_parallel - Br)/(mu0 mu_r).
Worst sampled H_parallel is {min(x['magnet_H_parallel_min_kA_m'] for x in maps):.1f}
kA/m; the most negative recorded first-percentile value is
{min(x['magnet_H_parallel_p01_kA_m'] for x in maps):.1f} kA/m. Corner minima are
mesh-sensitive. Without grade-specific temperature-dependent recoil/knee curves,
these fields cannot prove irreversible-demagnetization safety. No arbitrary
coercivity number was substituted to manufacture a pass.

## 6. Drive, control and electrical faults

An idealized continuous dq PI model uses a 300 Hz target bandwidth, feed-forward
decoupling, vector voltage saturation and anti-windup at the 42 V minimum bus.
Current demand steps to the continuous point at 10 ms and includes a separate
5 ms exploratory current pulse at 100 ms. This is not the five-second thermal
pulse. The model reaches 90 percent of continuous current in approximately
{ctrl['ideal_PI']['time_to_90pct_s']*1000:.2f} ms. It is a fixed-speed, averaged
plant with known R and L, not switched PWM or sampled DSP firmware.

The native EEC also solved Ud=Uq=0 steady three-phase short-circuit conditions at
630 and 1890 rpm and three magnet temperatures. The largest estimated current is
{max(x['current_rms_A'] for x in ctrl['short_circuit_native_EEC']):.2f} Arms, or
{max(x['phase_current_peak_A'] for x in ctrl['short_circuit_native_EEC']):.2f} A
sinusoidal phase peak. All those currents lie outside the characterized FE map
because negative Iq and more negative Id are involved. Consequently no fault
survival, transient current bound or demagnetization pass is claimed. A protection
and braking architecture must be designed from component limits and mission loads.

## 7. Three-dimensional carrier strength and modal model

The final-stage carrier uses two 8 mm steel plates, 104 mm OD, 24 mm hub bore,
and three 12 mm pin holes at 31.5 mm radius. One plate is solved with a fully
clamped hub and half the conservative pin reaction, multiplied by a 1.5 load
factor. Each pin bore receives {stress['pin_force_per_plate_N']:.1f} N distributed
traction. Equal sharing, rigid hub support and E=210 GPa, nu=0.3 are assumptions.

Gmsh quadratic tetrahedra are explicitly reordered to CalculiX C3D10 conventions.
Two meshes contain {s['mesh_convergence'][0]['elements']} and
{stress['elements']} elements. Peak displacement is
{stress['max_displacement_mm']*1000:.3f} micrometres; maximum integration-point
von Mises stress is {stress['von_mises_max_MPa']:.2f} MPa, with p99
{stress['von_mises_p99_MPa']:.2f} MPa. Displacement changes by
{100*s['displacement_change_relative']:.3f} percent and stress p99 by
{100*s['stress_p99_change_relative']:.2f} percent between meshes.

These results do not include pin/bearing contact compliance, output-bearing
preload, bolts, carrier assemblies, real fits, launch loads or fatigue allowables.
A low plate stress does not prove the gear teeth or complete actuator is safe.
The first clamped-plate eigenfrequency is {s['clamped_plate_modes_Hz'][0]:.1f} Hz.
This is not the full-actuator resonance: bearing, arm and gear compliance can
introduce much lower modes. No acoustic or complete forced-vibration prediction
has been made.

## 8. Gear, pin, bearing-life and interface requirements

The gearbox remains 18/63/144 teeth at module 0.75 and 18/45/108 at module 1,
three planets each, ratios 9 and 7. Geometry closure and adjacent-planet clearance
pass their nominal screens. Manufactured tooth profiles, load sharing and ring
flexibility are not validated.

A 10000-hour constant-load scenario gives the following REQUIRED values. These
are not certified allowables or safety-factor claims:

| Stage | Factored pitch-point Hertz GPa | Required contact allowable for 1.3 margin GPa | Required bending allowable for 1.5 margin MPa | Required pin-bearing C kN |
| --- | --- | --- | --- | --- |
{chr(10).join(mech)}

Pitch-point contact uses Fn = K Ft/cos(alpha), 1/R_eff = 1/(rs sin(alpha)) +
1/(rp sin(alpha)), and sigma_H = sqrt(Fn E_star/(pi b R_eff)). This smooth-cylinder
screen is not an ISO 6336 rating. Tooth-root Lewis Y and all factors remain
assumptions; certification needs actual geometry, material treatment, life and
lubrication data. Planet teeth can experience reversed bending, which a static
yield-strength ratio does not address.

Planet-bearing life uses C/P = L10_millions^(3/10) for a roller-bearing scenario,
with planet spin relative to its carrier, not motor speed. Output bearings remain
unselected because external radial/axial/overturning loads are unspecified. The
32 mm pin support-centre span implied by 8 mm plates is used in the revised pin
screen, yielding {g['stage2_pin_screen']['continuous_factored_bending_MPa']:.1f}
MPa continuous and {g['stage2_pin_screen']['peak_factored_bending_MPa']:.1f} MPa
peak bending screens before bearing/contact fatigue assessment.

A friction-only example with six M6 bolts, 8 kN preload each, and 55 mm effective
radius carries only {g['output_interface_trade']['friction_torque_capacity_Nm_at_mu_0p08']:.1f}
N m at mu=0.08, below continuous torque. At mu=0.12 it still cannot carry 400 N m.
This proposed preload circle requires a larger flange than the present CAD and
is an interface trade, not an installed detail. Positive torque features such as
three 5 mm dowels at 45 mm radius give a nominal
{g['output_interface_trade']['dowel_shear_at_400Nm_MPa']:.1f} MPa shear screen at
400 N m; fits, edge distances, bearing stress and fatigue remain to design.

## 9. Thermal finite elements and coupled uncertainty

The revised thermal requirements are winding-to-case 0.25 K/W and case-to-sink
0.15 K/W. They are substantially tighter than the baseline. The CAD includes a
0.1 mm bond-layer envelope, but no measured bond conductivity, contact conductance
or complete end-turn heat path. No convection is used in vacuum.

A separate 2-D stator conduction solve uses the actual Pyleecan cross-section,
20 W/mK iron and three effective winding conductivities. All copper loss is
conservatively placed in active slots, including the end-turn loss allowance.
The exterior case is fixed at {th['imposed_outer_case_C']:.2f} deg C; source power
is {th['total_distributed_copper_W']:.2f} W. This calculation tests the transverse
path, not end-turn hot spots or mounting contacts.

| Effective winding k W/mK | Average winding C | Maximum node C | Effective transverse R K/W |
| --- | --- | --- | --- |
{trs}

All three cases close heat balance within
{max(x['power_residual_W'] for x in th['scenarios']):.3g} W. Unresolved insulation,
liners, voids and interfaces are represented only through effective conductivity.
The lower effective transverse resistances do not verify the complete 0.25 K/W
winding-to-case requirement in actual hardware.

| Sink C | Assumed core/rotor loss W | Output torque N m | Lumped winding C | Thermal screen |
| --- | --- | --- | --- | --- |
{chr(10).join(sens)}

The 302.4 N m row corresponds to a 6 N m motor-shaft target with 63:1 and 0.80
efficiency. The 70 deg C sink / 30 W loss case exceeds the winding limit at that
target. Therefore the revised design is NOT robustly established as a 6 N m
continuous motor across the tested uncertainty range, even though it improves the
nominal scenario and supports 220 N m in these scenarios.

## 10. CAD and integration status

FreeCAD produced {cad['objects']} individually valid concept solids, a native
FCStd file and a {cad['step_bytes']/1e6:.1f} MB STEP assembly, plus individual
STEP components and a volume/material BOM. Coil solids are slot envelopes, not
solid copper: mass requires the actual fill factor and native winding model.
The BOM is not a manufacturing release. Motor surfaces originate from native
Pyleecan lines/arcs. Gear flanks use sampled involutes; root fillets are not
manufacturing trochoids. Modelled envelope is approximately 140 mm OD by 219 mm
axial, before unresolved connectors, supports and interface details.

This CAD is NOT a manufacturing release. Assembly clearance and tooth phasing
have not been verified, and the current model omits the detailed stage-1 carrier,
interstage supports, bearing seats/preloads, retaining sleeve, seals, vents,
encoder, launch restraint and fastener/dowel interfaces. Coupling and output
support remain concept envelopes. These omissions mean the current CAD does not
establish a complete load path or final overall length/mass. Individual-solid
validity is a geometry-kernel test, not assembly acceptance.

## 11. Executed official magnetic and electrical couplings

Native MagFEMM executed: **{fm['native_MagFEMM_executed']}**.
Native Electrical-to-MagFEMM coupling executed:
**{ee['native_Electrical_MagFEMM_executed']}**.

The official FEMM download remains blocked directly by network policy, but a
cached installer on an accessible public GitHub course repository matched the
FEMM project's published SourceForge SHA-256 exactly:
17384e8990b6305ec8ffef1f75b6ef091a266b6e49b30c151cd1daca2e952043.
Its source, pinned commit, checksum and extraction method are recorded in
docs/femm-distribution.json. No network-policy bypass or verification disabling
was used; the same official bytes were obtained through an allowed host.

The x64 payload was extracted from its 32-bit installer wrapper with innoextract.
The bundled x64 VC++ runtime was installed through its MSI under Wine, and the
actual FEMM GUI/Lua file link was verified. An additive filesystem alias fixes a
mixed Windows/Linux separator in Pyleecan 1.5.2's Lua resource path; no solver or
Pyleecan implementation file was edited. These steps are reproducible in
scripts/setup_femm.py.

The first time-refined attempt failed when the Linux file-link handler returned
a list where the torque routine expected a scalar. The raw reply was not retained.
Inspection found that the handler can read an output file before a complete
response is written; the failure is consistent with this file-link race. The
project now scopes a transport
guard around native jobs: atomic request delivery, waiting for a complete numeric
reply, rejection of stale replies, and a bounded timeout. A regression check
reproduces an empty file followed by a delayed valid torque response. This guard
replaces only the in-process Linux communication method during the job; the
official geometry, field solver, torque and loss algorithms are unchanged.
The failed attempt contributes no accepted numerical result. Completed refinement
transport diagnostics are retained with the corresponding results.

The native magnetic model uses the same baseline geometry, 9 Arms, 630 rpm and
80 deg C magnet properties. A 0.125 mm gap mesh and space/time symmetry were used.
Pyleecan solved {fm['solved_time_steps']} time positions after reducing the requested
{fm['requested_time_steps']} full-revolution sample grid. It ran magnetic analysis,
ForceMT and all five loss models as a native simulation pipeline.

Independent one-step refinements double the full-revolution time grid or reduce
the air-gap element target from 125 to 83.3 micrometres, keeping the other setting
fixed. Their absolute results and torque changes relative to the reference are:

| Native case | Full time grid | Gap mesh µm | Torque N m | Torque change percent | Stator W | Rotor W | Magnet W |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Reference | {fm['requested_time_steps']} | 125.0 | {fm['torque_Nm']:.5f} | 0 | {fm['loss_W']['stator_bertotti']:.4f} | {fm['loss_W']['rotor_bertotti']:.4f} | {fm['loss_W']['magnets']:.4f} |
{refinements}

The largest mean-torque change in these checks is
{max(v['torque_change_relative'] for v in convergence['cases'])*100:.3f} percent.
These are separate single-point checks, not an asymptotic convergence proof,
a full mesh refinement of every region, or a converged operating-domain loss map.
Loss changes are retained individually in native_femm/convergence.json, including
results that are less stable than the mean torque. Supplier loss data and
independent material-frame/harmonic validation are still needed.

The time refinement changes sampled torque peak-to-peak from
{fm['torque_max_Nm']-fm['torque_min_Nm']:.4f} to
{time_refined['torque_peak_to_peak_Nm']:.4f} N m. The larger sampled ripple is
{time_refined['torque_peak_to_peak_Nm']/time_refined['torque_Nm']*100:.1f} percent
of mean motor torque. Coarse sampling misses important ripple extrema even when
the mean is stable. Neither ripple value is a validated final specification;
additional time steps and mechanical torsional transfer are required.

| Quantity | Custom field history | Official MagFEMM pipeline |
| --- | --- | --- |
| Mean motor torque N m | {base['magnetic_checks']['FE_mean_torque_9Arms_Nm']:.4f} | {fm['torque_Nm']:.4f} |
| Stator core loss W | {n['loss_W']['stator_bertotti']:.4f} | {fm['loss_W']['stator_bertotti']:.4f} |
| Rotor core loss W | {n['loss_W']['rotor_bertotti']:.4f} | {fm['loss_W']['rotor_bertotti']:.4f} |
| Magnet loss W | {n['loss_W']['magnets']:.4f} | {fm['loss_W']['magnets']:.4f} |
| Copper/skin loss W | {n['loss_W']['copper']:.4f} | {fm['loss_W']['copper']:.4f} |

Torque agreement is {100*comparison:.2f} percent. This supports implementation
consistency for a shared assumed geometry/material model, not measured accuracy.
The rotor and magnet loss differences are much larger proportionally; different
time reduction, material-frame sampling, meshing and numerical derivatives remain
unconverged. Neither rotor/magnet value is presented as a verified loss rating.
Their absolute difference is small relative to total copper/gear heat but still
requires time/mesh convergence and material correlation for detailed design.

For the revised motor, native Electrical(EEC_PMSM(fluxlink=MagFEMM)) performed
open-circuit and loaded FEMM calculations, extracted dq flux and solved the
voltage/torque/copper-loss equations. At {ee['Iq_rms_A']:.3f} Arms, Id=0, 630 rpm,
100 deg C winding and 80 deg C magnets it gives:

| Native revised electrical quantity | Result |
| --- | --- |
| PM linkage RMS Wb turns | {ee['PM_flux_rms_Wb']:.6f} |
| Loaded Phid / Phiq RMS Wb turns | {ee['Phid_rms_Wb']:.6f} / {ee['Phiq_rms_Wb']:.6f} |
| Phase resistance ohm | {ee['resistance_ohm']:.5f} |
| Phase voltage peak V | {ee['phase_voltage_peak_V']:.3f} |
| Electromagnetic torque N m | {ee['total_torque_Nm']:.4f} |
| Copper loss W | {ee['copper_loss_W']:.3f} |

The native secant Ld is undefined at Id=0 and is retained as null, not invented.
These fixed hot temperatures differ from the nominal thermal equilibrium in the
redesign table. Coarse temporal coupling checks do not replace a rotor-averaged,
current/temperature map with demonstrated convergence. The coupled pipeline is
working; product qualification and the limitations elsewhere in this report
remain unchanged.

## 12. Product release gates

The engineering package is useful for refining and reviewing the concept. To
release a product requires mission loads and life/backlash/stiffness requirements,
supplier material curves and temperature-dependent magnet knee data, actual
thermal contacts, winding manufacture, catalog bearing/encoder/inverter selection,
complete toleranced CAD and contact analysis, full gear fatigue/contact ratings,
protection and control validation, and hardware correlation.

Tests to obtain that evidence include winding resistance/inductance/back-EMF,
dynamometer torque/loss maps, gearbox efficiency/backlash/load sharing, bearing
and lubricant life, thermal contact characterization and vacuum hot/cold torque
runs. Space environmental acceptance criteria depend on the actual mission;
launch vibration, outgassing/contamination, EMC and radiation requirements have
not been guessed from the word space. No numeric reliability or flight-readiness
score is assigned without evidence.

## 13. Reproduction and artifacts

Run from /workspace/Space-octopus:

    bash scripts/setup.sh
    python scripts/setup_extended.py
    python scripts/setup_femm.py
    OPENBLAS_NUM_THREADS=1 .venv/bin/python -m actuator.extended
    OPENBLAS_NUM_THREADS=1 .venv/bin/python -m pytest -q

The extended runner reuses retained validated results unless --refresh is passed.
Native magnetic field histories are large and ignored by Git, but remain in this
workspace/snapshot. Reproduction packages use pinned SHA-256 values from signed
Debian indexes without modifying host packages. The present state is prepared in
this instance; environment publication/fresh-instance restoration is not verified.

See configs/revised.json, component JSON data, CalculiX input decks, the native
LUTdq files, CAD/BOM, thermal plots and controller data. Native FEMM and electrical execution evidence have separate JSON records. Software tests verify numerical invariants and stated
coverage; their pass count is not a substitute for the product gates above.
'''
    (out/'extended_report.md').write_text(text)
    figures=make_figures(out,n,s,r,ctrl)
    body=markdown.markdown(text,extensions=['tables','fenced_code'])
    imgs=''.join('<figure><img style="max-width:100%" src="data:image/png;base64,'+base64.b64encode((out/f).read_bytes()).decode()+'"><figcaption>'+f+'</figcaption></figure>' for f in figures)
    (out/'extended_report.html').write_text('<!doctype html><meta charset="utf-8"><title>Space-octopus extended analysis</title><style>body{font:16px/1.6 system-ui;max-width:1100px;margin:40px auto;padding:20px;color:#152537}table{border-collapse:collapse;font-size:14px}td,th{border:1px solid #ccd5de;padding:6px}h1,h2{line-height:1.2}pre{background:#eef2f6;padding:14px;overflow:auto}</style>'+body+imgs)
    make_pdf(out,text,figures)
    (out/'report.pdf').replace(out/'extended_report.pdf')
    dump(out/'coverage.json',dict(native_MagFEMM_executed=fm['native_MagFEMM_executed'],native_Electrical_MagFEMM_executed=ee['native_Electrical_MagFEMM_executed'],native_Pyleecan_executed=['MagFEMM','Electrical(fluxlink=MagFEMM)','geometry','winding','resistance','mass','EEC_PMSM','LUTdq','LossModelBertotti','LossModelJoule skin','LossModelProximity','LossModelMagnet','ForceMT'],external_solvers_executed=['FEMM 4.2','Wine 10','Gmsh','scikit-fem','CalculiX','FreeCAD','SciPy'],product_released=False,physical_validation_performed=False))


def make_figures(out,n,s,r,ctrl):
    files=[]
    fig,ax=plt.subplots(figsize=(8,4));ax.bar(list(n['loss_W']),list(n['loss_W'].values()),color='#347e9f');ax.set(ylabel='Loss [W]',title='Native Pyleecan loss models: baseline 9 Arms, 630 rpm');ax.tick_params(axis='x',rotation=20);fig.tight_layout();fig.savefig(out/'native_loss_breakdown.png',dpi=170);plt.close(fig);files.append('native_loss_breakdown.png')
    f=np.load(out/'electromagnetics/native_force_fields.npz');pr=np.squeeze(f['radial_Pa'])
    fig,ax=plt.subplots(figsize=(9,4));im=ax.imshow(pr[:,::4]/1000,origin='lower',aspect='auto',extent=[0,360,0,60/630*1000],cmap='viridis');ax.set(xlabel='Air-gap angle [degrees]',ylabel='Time [ms]',title='Official ForceMT radial traction over a mechanical revolution');fig.colorbar(im,ax=ax,label='Radial traction [kPa]');fig.tight_layout();fig.savefig(out/'native_force_history.png',dpi=170);plt.close(fig);files.append('native_force_history.png')
    fig,axes=plt.subplots(1,2,figsize=(10,4))
    for temp in [20,80,140]:
        rows=sorted([x for x in r['flux_map'] if x['magnet_C']==temp and x['Id_rms_A']==0],key=lambda x:x['Iq_rms_A']);axes[0].plot([x['Iq_rms_A'] for x in rows],[x['torque_Nm'] for x in rows],'o-',label=f'{temp} C')
    axes[0].set(xlabel='Iq [Arms]',ylabel='Static-position torque [N m]',title='Nonlinear FE temperature map, Id=0');axes[0].legend();axes[0].grid(alpha=.3)
    rows=r['discrete_trade'];axes[1].plot([x['stator_OD_mm'] for x in rows],[x['motor_active_mass_kg'] for x in rows],'o-');axes[1].set(xlabel='Stator OD [mm]',ylabel='Active material mass [kg]',title='Discrete geometric trade');axes[1].grid(alpha=.3);fig.tight_layout();fig.savefig(out/'redesign_trade.png',dpi=170);plt.close(fig);files.append('redesign_trade.png')
    shutil.copyfile(out/'thermal/stator_temperature.png',out/'thermal_conduction.png');files.append('thermal_conduction.png')
    pi=np.load(out/'controls/pi_response.npz');fig,ax=plt.subplots(figsize=(8,4));ax.plot(pi['t']*1000,pi['state'][1],label='Iq');ax.plot(pi['t']*1000,pi['reference'],'--',label='Reference');ax.set(xlabel='Time [ms]',ylabel='Current [Arms]',title='Idealized averaged dq PI response; no switched PWM');ax.grid(alpha=.3);ax.legend();fig.tight_layout();fig.savefig(out/'current_control.png',dpi=170);plt.close(fig);files.append('current_control.png')
    fig,axes=plt.subplots(1,2,figsize=(10,4));cv=s['mesh_convergence'];axes[0].plot([x['elements'] for x in cv],[x['von_mises_p99_MPa'] for x in cv],'o-');axes[0].set(xlabel='Quadratic tetrahedra',ylabel='Stress p99 [MPa]',title='Carrier mesh check');axes[1].bar(np.arange(1,9),s['clamped_plate_modes_Hz']);axes[1].set(xlabel='Isolated plate mode',ylabel='Frequency [Hz]',title='Clamped carrier-plate modes');fig.tight_layout();fig.savefig(out/'carrier_checks.png',dpi=170);plt.close(fig);files.append('carrier_checks.png')
    cv=json.loads((out/'native_femm/convergence.json').read_text())
    fig,axes=plt.subplots(1,2,figsize=(11,4))
    for case,label,nt in [('', 'Reference',120),('time_refined','Time refined',240),('mesh_refined','Gap mesh refined',120)]:
        torque=np.load(out/'native_femm'/case/'native_fields.npz')['torque_Nm']
        axes[0].plot(np.arange(len(torque))*360/nt,torque,'o-',ms=3,label=label)
    axes[0].set(xlabel='Rotor mechanical angle [degrees]',ylabel='Motor torque [N m]',title='Mean agreement can conceal missed ripple');axes[0].grid(alpha=.3);axes[0].legend(fontsize=8)
    loss_keys=['stator_bertotti','rotor_bertotti','magnets'];x=np.arange(3)
    for j,v in enumerate(cv['cases']):axes[1].bar(x+(j-.5)*.35,[100*v['loss_change_relative'][k] for k in loss_keys],width=.35,label=v['case'].replace('_',' '))
    axes[1].set(xticks=x,xticklabels=['Stator','Rotor','Magnets'],ylabel='Absolute change from reference [%]',title='Single-point native loss sensitivity');axes[1].legend(fontsize=8)
    fig.tight_layout();fig.savefig(out/'native_refinement.png',dpi=170);plt.close(fig);files.append('native_refinement.png')
    return files
