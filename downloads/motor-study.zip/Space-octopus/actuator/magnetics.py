"""Pyleecan geometry -> Gmsh -> scikit-fem 2-D magnetostatic adapter.

Linear isotropic steel screening model, with explicit saturation indicators.
No vendor Pyleecan files are modified. Full circle, A_z=0 at stator OD.
"""
from pathlib import Path
import json
import numpy as np
import gmsh
from scipy.sparse.linalg import splu
from skfem import MeshTri, Basis, ElementTriP1, BilinearForm, LinearForm, asm
from skfem.helpers import dot, grad
from pyleecan.Functions.labels import decode_label

MU0 = 4e-7*np.pi


class MagneticModel:
    def __init__(self, machine, config, h=.0012, angle=0., save=None):
        self.machine, self.config = machine, config
        self.angle = angle
        self.eccentricity=complex(*config['motor'].get('static_eccentricity_m',[0.,0.]))
        if abs(self.eccentricity)>=machine.comp_width_airgap_mec():
            raise ValueError('Eccentricity closes the mechanical gap')
        self.mesh_geometry(h, save)
        print('FE mesh:', self.mesh.nvertices, 'nodes,', self.mesh.nelements, 'triangles', flush=True)
        self.basis = Basis(self.mesh, ElementTriP1())
        self.areas = self.basis.dx.sum(axis=1)
        self.centers = self.mesh.p[:, self.mesh.t].mean(axis=1)
        self.nu = np.ones(self.mesh.nelements)/MU0
        self.nu[self.kind == 1] /= config['motor']['steel_mu_r']
        self.nu[self.kind == 2] /= config['motor']['magnet_mu_r']
        self.free = self.basis.complement_dofs(self.basis.get_dofs())
        @BilinearForm
        def stiffness(u, v, w):
            return w.nu*dot(grad(u), grad(v))
        self.K = asm(stiffness, self.basis, nu=self.nu[:, None]*np.ones_like(self.basis.dx))
        self.factor = splu(self.K[self.free][:, self.free].tocsc())
        # Each phase source has units turns/m², obtained directly from Pyleecan
        # connection matrix. Uniform current density in each active half-slot.
        self.winding_density = np.zeros((3,self.mesh.nelements))
        conn = machine.stator.winding.get_connection_mat(machine.stator.slot.Zs)
        for region, label in self.labels.items():
            if '_Wind' not in label:
                continue
            d = decode_label(label)
            idx = self.region == region
            actual_area = self.areas[idx].sum()
            conductors = conn[d['R_id'],d['T_id'],d['S_id'],:]
            self.winding_density[:,idx] = conductors[:,None]/actual_area
        @LinearForm
        def current(v,w):
            return w.j*v
        self.phase_rhs = np.array([asm(current,self.basis,j=d[:,None]*np.ones_like(self.basis.dx)) for d in self.winding_density])

    def mesh_geometry(self,h,save):
        gmsh.initialize()
        try:
            gmsh.option.setNumber('General.Terminal',0)
            gmsh.option.setNumber('General.NumThreads',2)
            gmsh.model.add('Pyleecan actuator')
            occ = gmsh.model.occ
            pts = {}
            def point(z):
                k=(round(z.real,12),round(z.imag,12))
                if k not in pts: pts[k]=occ.addPoint(k[0],k[1],0)
                return pts[k]
            def loop(s):
                lines=[]
                for l in s.get_lines():
                    if type(l).__name__ == 'Segment':
                        lines.append(occ.addLine(point(l.get_begin()),point(l.get_end())))
                    else:
                        # Split arcs into < pi sweeps; preserve circular geometry.
                        pp=l.discretize(2)
                        center=point(l.get_center())
                        for a,b in zip(pp[:-1],pp[1:]):
                            lines.append(occ.addCircleArc(point(a),center,point(b)))
                return occ.addCurveLoop(lines)
            def surface(s):
                if type(s).__name__ == 'SurfRing':
                    # OCC wire orientation is significant for noncircular bores.
                    outer=occ.addPlaneSurface([loop(s.out_surf)])
                    inner=occ.addPlaneSurface([loop(s.in_surf)])
                    cut,_=occ.cut([(2,outer)],[(2,inner)])
                    pts.clear()
                    if len(cut)!=1: raise ValueError('Unexpected ring topology')
                    return cut[0][1]
                return occ.addPlaneSurface([loop(s)])
            src=[]
            for lam,angle in [(self.machine.rotor,self.angle),(self.machine.stator,0.)]:
                for s in lam.build_geometry(alpha=angle):
                    if not lam.is_stator and self.eccentricity:s.translate(self.eccentricity)
                    tag=surface(s)
                    expected=s.comp_surface()
                    if not np.isclose(occ.getMass(2,tag),expected,rtol=1e-4,atol=1e-10):
                        raise ValueError('Pyleecan/OCC area mismatch '+s.label+': '+str((occ.getMass(2,tag),expected)))
                    src.append((tag,s.label))
            # Shaft is modelled with the same linear steel as rotor.
            src.append((occ.addDisk(self.eccentricity.real,self.eccentricity.imag,0,self.machine.rotor.Rint,self.machine.rotor.Rint),'Rotor-0_LamShaft'))
            domain=occ.addDisk(0,0,0,self.machine.stator.Rext,self.machine.stator.Rext)
            _,maps=occ.fragment([(2,domain)],[(2,i) for i,_ in src])
            occ.synchronize()
            entity_labels={}
            for (_,label),mapped in zip(src,maps[1:]):
                for dim,tag in mapped:
                    if dim==2: entity_labels[tag]=label
            # Refine the complete magnetic gap and nearby iron to capture Maxwell stress.
            field=gmsh.model.mesh.field
            f=field.add('MathEval')
            ro=self.machine.rotor.comp_radius_mec()
            ri=self.machine.stator.comp_radius_mec()
            mid=(ri+ro)/2
            gap_h=min(h/12,(ri-ro)/4)
            field.setString(f,'F',f'{h} - ({h}-{gap_h})*Exp(-1*(((Sqrt(x*x+y*y)-{mid})/{.002})^4))')
            field.setAsBackgroundMesh(f)
            gmsh.option.setNumber('Mesh.MeshSizeMin',gap_h)
            gmsh.option.setNumber('Mesh.MeshSizeMax',h)
            gmsh.option.setNumber('Mesh.MeshSizeFromPoints',0)
            gmsh.option.setNumber('Mesh.MeshSizeFromCurvature',0)
            gmsh.option.setNumber('Mesh.MeshSizeExtendFromBoundary',0)
            gmsh.option.setNumber('Mesh.Algorithm',6)
            gmsh.model.mesh.generate(2)
            print('Gmsh meshing complete', flush=True)
            tags,coords,_=gmsh.model.mesh.getNodes()
            order=np.argsort(tags)
            node_tags=np.asarray(tags)[order]
            xy=np.asarray(coords).reshape(-1,3)[order,:2]
            tris=[];regions=[];kinds=[];self.labels={}
            for rid,(_,tag) in enumerate(gmsh.model.getEntities(2)):
                label=entity_labels.get(tag,'Air')
                self.labels[rid]=label
                kind=2 if '_Magnet' in label else (1 if '_Lam' in label else 0)
                types,_,nodes=gmsh.model.mesh.getElements(2,tag)
                for et,nn in zip(types,nodes):
                    if et!=2: raise ValueError('Only linear triangles supported')
                    tt=np.searchsorted(node_tags,np.asarray(nn).reshape(-1,3))
                    tris.extend(tt);regions.extend([rid]*len(tt));kinds.extend([kind]*len(tt))
            triangles=np.asarray(tris)
            used=np.unique(triangles)
            self.mesh=MeshTri(xy[used].T,np.searchsorted(used,triangles).T,sort_t=False)
            self.region=np.asarray(regions); self.kind=np.asarray(kinds)
            if save:
                np.savez_compressed(str(save),p=self.mesh.p,t=self.mesh.t,region=self.region,kind=self.kind)
        finally:
            gmsh.finalize()

    def solve(self, currents=(0,0,0), temperature_C=None, pm_scale=1.):
        c=self.config['motor']
        if temperature_C is None: temperature_C=c['magnet_reference_C']
        Br=c['magnet_Br20_T']*(1+c['magnet_alpha_per_K']*(temperature_C-20))*pm_scale
        # Radial alternating remanence; Pyleecan magnet labels preserve pole index.
        xy=self.basis.global_coordinates()
        phi=np.arctan2(xy[1]-self.eccentricity.imag,xy[0]-self.eccentricity.real)
        sign=np.zeros(self.mesh.nelements)
        for rid,label in self.labels.items():
            if '_Magnet' in label:
                sign[self.region==rid]=(-1)**decode_label(label)['S_id']
        bx=Br*sign[:,None]*np.cos(phi)
        by=Br*sign[:,None]*np.sin(phi)
        @LinearForm
        def magnet(v,w):
            # B = curl(Az) = (dAz/dy, -dAz/dx)
            return w.nu*(w.bx*v.grad[1]-w.by*v.grad[0])
        rhs=asm(magnet,self.basis,nu=self.nu[:,None]*np.ones_like(phi),bx=bx,by=by)+np.asarray(currents)@self.phase_rhs
        a=np.zeros(self.basis.N)
        a[self.free]=self.factor.solve(rhs[self.free])
        g=self.basis.interpolate(a).grad.mean(axis=2)
        B=np.array([g[1],-g[0]])
        flux=self.machine.stator.L1*(self.phase_rhs@a)
        return dict(a=a,B=B,phase_flux_Wb=flux,currents=np.array(currents),rhs=rhs)

    def nonlinear(self, linear_solution, tolerance=1e-7):
        """Newton solve with bundled M270-35A exemplar B-H data.

        Curve beyond its final 1.8 T point uses an explicit, artificial linear
        differential-permeability extension. Results report extrapolated area.
        """
        from pyleecan.Functions.load import load
        from pyleecan.definitions import DATA_DIR
        curve=np.asarray(load(DATA_DIR+'/Material/M270-35A.json').mag.BH_curve.get_data())
        hh=curve[:,0];bb=curve[:,1]
        iron=self.kind==1
        slopes=np.diff(hh)/np.diff(bb)
        def constitutive(a):
            g=self.basis.interpolate(a).grad.mean(axis=2)
            b=np.linalg.norm(g,axis=0)
            H=np.interp(b,bb,hh)
            extended=b>bb[-1]
            H[extended]=hh[-1]+(b[extended]-bb[-1])*slopes[-1]
            idx=np.clip(np.searchsorted(bb,b,side='right')-1,0,len(slopes)-1)
            dh=slopes[idx]
            nu=self.nu.copy();nu[iron]=np.divide(H[iron],b[iron],out=np.full(iron.sum(),slopes[0]),where=b[iron]>1e-12)
            coeff=np.zeros_like(b)
            coeff[iron]=(dh[iron]-nu[iron])/np.maximum(b[iron]**2,1e-20)
            return g,nu,coeff,extended
        @LinearForm
        def residual_form(v,w):
            return w.nu*dot(w.g,grad(v))
        @BilinearForm
        def tangent_form(u,v,w):
            return w.nu*dot(grad(u),grad(v))+w.coeff*dot(w.g,grad(u))*dot(w.g,grad(v))
        def residual(a):
            g,nu,coeff,ext=constitutive(a)
            q=np.ones_like(self.basis.dx)
            residual=asm(residual_form,self.basis,nu=nu[:,None]*q,g=g[:,:,None]*np.ones((1,1,q.shape[1])))-linear_solution['rhs']
            return residual,g,nu,coeff,ext
        a=linear_solution['a'].copy();reference=np.linalg.norm(linear_solution['rhs'][self.free])
        for iteration in range(40):
            res,g,nu,coeff,ext=residual(a)
            err=np.linalg.norm(res[self.free])/max(reference,1e-20)
            if err<tolerance: break
            q=np.ones_like(self.basis.dx)
            K=asm(tangent_form,self.basis,nu=nu[:,None]*q,coeff=coeff[:,None]*q,g=g[:,:,None]*np.ones((1,1,q.shape[1])))
            step=np.zeros_like(a)
            step[self.free]=splu(K[self.free][:,self.free].tocsc()).solve(-res[self.free])
            scale=1.
            for _ in range(15):
                trial=a+scale*step
                er=np.linalg.norm(residual(trial)[0][self.free])/max(reference,1e-20)
                if er<err: break
                scale*=.5
            else: raise RuntimeError('Nonlinear magnetic line search failed')
            a=trial
        else: raise RuntimeError('Nonlinear magnetic solve did not converge')
        return dict(a=a,B=np.array([g[1],-g[0]]),phase_flux_Wb=self.machine.stator.L1*(self.phase_rhs@a),currents=linear_solution['currents'],rhs=linear_solution['rhs'],nonlinear_iterations=iteration,nonlinear_residual=err,iron_area_BH_extrapolated_fraction=float(self.areas[iron&ext].sum()/self.areas[iron].sum()))

    def metrics(self,solution):
        B=solution['B'];x,y=self.centers;r=np.hypot(x,y)
        Br=(B[0]*x+B[1]*y)/r;Bt=(-B[0]*y+B[1]*x)/r
        ro=self.machine.rotor.comp_radius_mec();ri=self.machine.stator.comp_radius_mec()
        torque=[]
        for fraction in [.3,.5,.7]:
            radius=ro+(ri-ro)*fraction
            br,bt=self.airgap_fields(solution,radius)
            torque.append(self.machine.stator.L1/MU0*radius**2*2*np.pi*np.mean(br*bt))
        iron=self.kind==1
        bmag=np.linalg.norm(B,axis=0)
        knee=self.config['motor']['steel_B_knee_T']
        iron_area=self.areas[iron].sum()
        return dict(torque_Nm=float(torque[1]),torque_radial_checks_Nm=torque,iron_B_p99_T=float(np.quantile(bmag[iron],.99)),iron_B_max_T=float(bmag[iron].max()),iron_area_above_knee_fraction=float(self.areas[iron&(bmag>knee)].sum()/iron_area),airgap_Br_peak_T=float(np.max(np.abs(Br[(r>ro)&(r<ri)]))),phase_flux_Wb=solution['phase_flux_Wb'].tolist())

    def airgap_fields(self,solution,radius):
        count=2048
        theta=np.arange(count)*2*np.pi/count
        radial_step=(self.machine.stator.comp_radius_mec()-self.machine.rotor.comp_radius_mec())*.08
        def sample(rad):
            points=np.array([rad*np.cos(theta),rad*np.sin(theta)])
            return self.basis.probes(points)@solution['a']
        a=sample(radius)
        # Spectral derivative of continuous P1 potential. Remove very high
        # spatial orders dominated by mesh interpolation; retain 150 orders.
        spec=np.fft.rfft(a);orders=np.arange(len(spec));spec[orders>150]=0
        br=np.fft.irfft(1j*orders*spec,n=count)/radius
        bt=-(sample(radius+radial_step)-sample(radius-radial_step))/(2*radial_step)
        return br,bt
