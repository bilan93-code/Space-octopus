"""Native ForceMT -> project scikit-fem stator elasticity and modal response.

Actual Pyleecan stator cross-section; force transfer preserves total force and
moment. Axial/end effects and the detailed housing/bearing assembly are omitted.
"""
import json,pickle
from pathlib import Path
import numpy as np
from scipy.sparse.linalg import splu,eigsh
from skfem import Basis,FacetBasis,ElementTriP2,ElementVector,BilinearForm,asm
from skfem.helpers import dot
from skfem.models.elasticity import linear_elasticity
from .machine import build_machine
from .magnetics import MagneticModel
from .run import dump
ROOT=Path(__file__).resolve().parents[1]


def force_transfer(basis,facets,angles,radial,tangential,radius,length):
    candidates=basis.get_dofs(facets=facets).all()
    ix=np.intersect1d(candidates,basis.split_indices()[0]);iy=ix+1
    xy=basis.doflocs[:,ix];theta=np.mod(np.arctan2(xy[1],xy[0]),2*np.pi)
    order=np.argsort(theta);theta=theta[order];ix=ix[order];iy=iy[order];xy=xy[:,order]
    # Place each air-gap quadrature force between its two nearest tooth-tip
    # locations, including slot openings. Add a zero-resultant couple correction.
    a=np.mod(angles,2*np.pi);right=np.searchsorted(theta,a)%len(theta);left=(right-1)%len(theta)
    span=np.mod(theta[right]-theta[left],2*np.pi);weight=np.mod(a-theta[left],2*np.pi)/span
    c=np.cos(a);s=np.sin(a);da=2*np.pi/len(a)
    fx=(radial*c-tangential*s)*radius*length*da
    fy=(radial*s+tangential*c)*radius*length*da
    F=np.zeros((basis.N,radial.shape[0]))
    for j in range(len(a)):
        F[ix[left[j]]]+=fx[:,j]*(1-weight[j]);F[iy[left[j]]]+=fy[:,j]*(1-weight[j])
        F[ix[right[j]]]+=fx[:,j]*weight[j];F[iy[right[j]]]+=fy[:,j]*weight[j]
    target_torque=np.sum(tangential,axis=1)*radius**2*length*da
    actual=np.sum(xy[0,:,None]*F[iy]-xy[1,:,None]*F[ix],axis=0)
    dx=-xy[1]+xy[1].mean();dy=xy[0]-xy[0].mean()
    couple=np.sum(xy[0]*dy-xy[1]*dx);correction=(target_torque-actual)/couple
    F[ix]+=dx[:,None]*correction;F[iy]+=dy[:,None]*correction
    error_F=np.max(np.abs(np.vstack([F[ix].sum(axis=0)-fx.sum(axis=1),F[iy].sum(axis=0)-fy.sum(axis=1)])))
    error_T=np.max(np.abs(np.sum(xy[0,:,None]*F[iy]-xy[1,:,None]*F[ix],axis=0)-target_torque))
    return F,dict(force_balance_residual_N=float(error_F),torque_balance_residual_Nm=float(error_T),tip_dof_pairs=len(ix))


def run(out,source=None):
    out.mkdir(parents=True,exist_ok=True)
    c=json.loads((ROOT/'configs/revised.json').read_text());m=build_machine(c)
    if source is None:source=ROOT/'results/motor/convergence/time_480/native_output.pkl'
    with source.open('rb') as stream:native=pickle.load(stream)
    data=native.force.AGSF.get_rphiz_along('time','angle','z=mean')
    pr=np.squeeze(data['radial']);pt=np.squeeze(data['tangential']);angles=np.asarray(data['angle'])
    # Reconstructed native time series retains the exact native pressure symmetry.
    t=np.asarray(data['time']);length=c['motor']['stack_m'];E=210e9;nu=.3;thick=length*.95
    rows=[]
    for h in [.002,.0012]:
        fe=MagneticModel(m,c,h=h)
        keep=np.array([('Stator' in fe.labels[r] and '_Lamination' in fe.labels[r]) for r in fe.region])
        mesh=fe.mesh.restrict(np.where(keep)[0]);basis=Basis(mesh,ElementVector(ElementTriP2()))
        centers=mesh.p[:,mesh.facets].mean(axis=1);r=np.linalg.norm(centers,axis=0)
        boundary=mesh.boundary_facets();outer=boundary[r[boundary]>m.stator.Rext-.0001]
        ends=np.linalg.norm(mesh.p[:,mesh.facets],axis=0)
        inner=boundary[np.max(np.abs(ends[:,boundary]-m.stator.Rint),axis=0)<1e-7]
        if len(inner)<12:raise RuntimeError('Stator bore facets not identified')
        lam=E*nu/(1-nu**2);mu=E/(2*(1+nu))
        K=asm(linear_elasticity(Lambda=lam,Mu=mu),basis)*thick
        # Spread winding mass over the steel cross-section for modal screening;
        # winding stiffness is neglected. This is explicitly an approximation.
        rho=7650*(1+m.stator.comp_masses()['Mwind']/m.stator.comp_masses()['Mlam'])
        @BilinearForm
        def mass(u,v,w):return rho*thick*dot(u,v)
        M=asm(mass,basis)
        fb=FacetBasis(mesh,ElementVector(ElementTriP2()),facets=outer)
        @BilinearForm
        def foundation(u,v,w):return thick*dot(u,v)
        S=asm(foundation,fb)
        F,balance=force_transfer(basis,inner,angles,pr,pt,native.force.Rag,length)
        if balance['force_balance_residual_N']>1e-7 or balance['torque_balance_residual_Nm']>1e-7:raise RuntimeError('Force transfer lost force or moment')
        load_index=int(np.argmax(np.linalg.norm(F,axis=0)));f=F[:,load_index]
        for support in ['clamped','spring_1e10','spring_1e12']:
            KK=K if support=='clamped' else K+S*float(support.split('_')[1])
            free=basis.complement_dofs(basis.get_dofs(facets=outer)) if support=='clamped' else np.arange(basis.N)
            factor=splu(KK[free][:,free].tocsc())
            unique_steps=native.force.AGSF.components['radial'].values.shape[0]
            all_u=np.zeros((basis.N,unique_steps));all_u[free]=factor.solve(F[free,:unique_steps])
            max_displacement=float(np.hypot(all_u[0::2],all_u[1::2]).max())
            worst_vm=-1.;worst_p99=0.
            for j in range(unique_steps):
                uj=all_u[:,j];grad=basis.interpolate(uj).grad
                ex=grad[0,0].mean(axis=-1);ey=grad[1,1].mean(axis=-1);exy=(grad[0,1]+grad[1,0]).mean(axis=-1)/2
                sx=lam*(ex+ey)+2*mu*ex;sy=lam*(ex+ey)+2*mu*ey;txy=2*mu*exy
                vmj=np.sqrt(sx*sx+sy*sy-sx*sy+3*txy*txy)
                worst_p99=max(worst_p99,float(np.quantile(vmj,.99)))
                if vmj.max()>worst_vm:worst_vm=float(vmj.max());u=uj;vm=vmj
            vals,modes=eigsh(KK[free][:,free],M=M[free][:,free],k=16,sigma=0,which='LM')
            order=np.argsort(vals);vals=vals[order];modes=modes[:,order];freq=np.sqrt(np.maximum(vals,0))/(2*np.pi)
            # Modal force spectra at 630 and 1890 rpm. Damping ratio 2% is an
            # assumption; mode shapes are mass normalized by eigsh.
            modalF=modes.T@F[free];coeff=np.fft.rfft(modalF,axis=1)/len(t)*2;coeff[:,0]/=2
            frequencies=np.fft.rfftfreq(len(t),float(np.mean(np.diff(t))))
            harmonic=[]
            for speed in [630,1890]:
                omega=2*np.pi*frequencies*speed/630
                denom=vals[:,None]-omega[None,:]**2+2j*.02*np.sqrt(vals)[:,None]*omega[None,:]
                q=coeff/denom;response=modes@q
                max_per_bin=np.max(np.abs(response),axis=0)
                top=np.argsort(max_per_bin[1:])[-5:]+1
                harmonic.append(dict(motor_rpm=speed,largest_nonDC_modal_displacement_um=float(max_per_bin[1:].max()*1e6),dominant_frequencies_Hz=(omega[top]/(2*np.pi)).tolist()))
            row=dict(h_m=h,support=support,nodes=mesh.nvertices,elements=mesh.nelements,dofs=basis.N,
                time_snapshots_checked=unique_steps,max_snapshot_displacement_um=max_displacement*1e6,
                snapshot_von_mises_p99_MPa=worst_p99/1e6,snapshot_von_mises_max_MPa=worst_vm/1e6,
                first_16_modes_Hz=freq.tolist(),harmonic_response=harmonic,force_transfer=balance)
            rows.append(row);dump(out/'progress.json',rows)
            if h==.0012 and support=='clamped':
                np.savez_compressed(out/'stator_solution.npz',p=mesh.p,t=mesh.t,vm_MPa=vm/1e6,u=u,doflocs=basis.doflocs)
    summary=dict(status='completed',engine='Official native ForceMT fields -> project Gmsh/scikit-fem P2 stator elasticity and modal response',
        source=str(source.relative_to(ROOT)),cases=rows,plane_stress_E_Pa=E,poisson=nu,material_steel_fraction=.95,damping_ratio=.02,
        limitations=['Two-dimensional stator only; no complete motor housing/bearings/end-bell assembly',
            'Clamped and spring supports bracket declared assumptions, not measured mount stiffness',
            'Tooth-tip force projection preserves resultant/moment but local slot/conductor force transfer is approximate',
            'Winding mass is distributed over steel; winding stiffness and axial modes are omitted',
            'Linear modal response excludes PWM magnetic forces, contact nonlinearities, launch loads and acoustic radiation'])
    dump(out/'summary.json',summary);return summary


if __name__=='__main__':run(ROOT/'results/motor/structure')
