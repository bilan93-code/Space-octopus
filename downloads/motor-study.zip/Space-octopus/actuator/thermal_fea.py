"""2-D transverse stator conduction model; no vacuum convection."""
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from scipy.sparse.linalg import spsolve
from skfem import MeshTri,Basis,ElementTriP1,asm,BilinearForm,LinearForm
from skfem.helpers import dot,grad
from .machine import build_machine
from .magnetics import MagneticModel
from .run import dump


def run_thermal_fea(config,redesign,out):
    out.mkdir(parents=True,exist_ok=True);machine=build_machine(config);fe=MagneticModel(machine,config,h=.0015)
    chosen=np.array([('Stator' in fe.labels[r] and ('_Lamination' in fe.labels[r] or '_Winding' in fe.labels[r])) for r in fe.region])
    tri=fe.mesh.t[:,chosen];nodes=np.unique(tri)
    mesh=MeshTri(fe.mesh.p[:,nodes],np.searchsorted(nodes,tri),sort_t=False);basis=Basis(mesh,ElementTriP1())
    copper=np.array(['_Winding' in fe.labels[r] for r in fe.region[chosen]])
    areas=basis.dx.sum(axis=1);L=config['motor']['stack_m'];P=redesign['continuous']['electrical']['copper_loss_W']
    case=redesign['continuous']['temperatures_C']['motor_case']
    boundary=np.where(np.isclose(np.linalg.norm(mesh.p,axis=0),config['motor']['stator_outer_radius_m'],atol=1e-8))[0]
    free=basis.complement_dofs(boundary)
    @BilinearForm
    def conduction(u,v,w):return w.k*dot(grad(u),grad(v))
    @LinearForm
    def heat(v,w):return w.q*v
    source=np.zeros(mesh.nelements);source[copper]=P/(L*areas[copper].sum())
    rhs=asm(heat,basis,q=source[:,None]*np.ones_like(basis.dx))
    results=[]
    for kw in [.3,.6,1.2]:
        k=np.full(mesh.nelements,20.);k[copper]=kw
        K=asm(conduction,basis,k=k[:,None]*np.ones_like(basis.dx))
        dt=np.zeros(basis.N);dt[free]=spsolve(K[free][:,free],rhs[free])
        mean_elem=basis.interpolate(dt).value.mean(axis=1)
        avg=float((areas[copper]*mean_elem[copper]).sum()/areas[copper].sum())
        reacted=float(-(K@dt-rhs)[boundary].sum()*L)
        results.append(dict(winding_effective_k_W_mK=kw,winding_average_C=case+avg,winding_node_max_C=case+float(dt.max()),R_average_winding_case_K_W=avg/P,conducted_heat_W=reacted,power_residual_W=abs(reacted-P)))
        if kw==.6:
            fig,ax=plt.subplots(figsize=(7,6));im=ax.tripcolor(mesh.p[0]*1000,mesh.p[1]*1000,mesh.t.T,case+dt,shading='gouraud',cmap='inferno');ax.set_aspect('equal');ax.set(xlabel='x [mm]',ylabel='y [mm]',title='2-D transverse conduction, effective winding k=0.6 W/mK');fig.colorbar(im,ax=ax,label='Temperature [°C]');fig.tight_layout();fig.savefig(out/'stator_temperature.png',dpi=170);plt.close(fig)
    summary=dict(engine='Gmsh/Pyleecan geometry + scikit-fem scalar conduction',nodes=mesh.nvertices,elements=mesh.nelements,assumed_stator_k_W_mK=20,imposed_outer_case_C=case,total_distributed_copper_W=P,scenarios=results,limitations=['2-D transverse conduction only; end-turn hotspot and axial paths omitted','All copper loss, including end-turn allowance, distributed into active slots','Effective winding conductivity subsumes unresolved insulation/contact; not measured','Outer case is isothermal and fixed; case-to-spacecraft resistance remains assumed','Rotor/bearing thermal paths and radiation are in the separate lumped model'])
    dump(out/'thermal_fea_summary.json',summary);return summary
