"""Headless display lifecycle for the actual Wine/FEMM application."""
from contextlib import contextmanager
from pathlib import Path
import os,select,subprocess
ROOT=Path(__file__).resolve().parents[1]


@contextmanager
def headless_environment(log_path):
    env=os.environ.copy();env['PATH']=str(ROOT/'.local/bin')+os.pathsep+env['PATH']
    env['WINEPREFIX']=str(ROOT/'.local/wineprefix')
    env['LD_LIBRARY_PATH']=str(ROOT/'.local/sysroot/usr/lib/x86_64-linux-gnu')+(':'+env['LD_LIBRARY_PATH'] if env.get('LD_LIBRARY_PATH') else '')
    env['XDG_RUNTIME_DIR']=str(ROOT/'.local/runtime')
    Path('/tmp/.X11-unix').mkdir(exist_ok=True)
    log_path=Path(log_path);log_path.parent.mkdir(parents=True,exist_ok=True)
    with log_path.open('w') as log:
        proc=subprocess.Popen([str(ROOT/'.local/sysroot/usr/bin/Xvfb'),'-displayfd','1','-screen','0','1280x1024x24','-nolisten','tcp','-ac'],stdout=subprocess.PIPE,stderr=log,env=env,text=True)
        try:
            if not select.select([proc.stdout],[],[],10)[0]:raise RuntimeError('Headless display did not start')
            display=proc.stdout.readline().strip()
            if not display.isdigit():raise RuntimeError('Invalid headless display: '+display)
            env['DISPLAY']=':'+display
            yield env
        finally:
            proc.terminate()
            try:proc.wait(timeout=5)
            except subprocess.TimeoutExpired:proc.kill();proc.wait()
