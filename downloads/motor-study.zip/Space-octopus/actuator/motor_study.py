"""Reproduce the motor-first study, recovering omitted native checkpoints.

All FEMM stages are deliberately sequential: they share the Wine prefix.
--refresh invalidates motor component summaries, preserving historical sources.
"""
import argparse,json,os,subprocess,sys
from .runtime import ROOT


def completed(path):
    return path.exists() and json.loads(path.read_text()).get('status')=='completed'


def run(refresh=False):
    from . import motor_campaign,motor_full_period,motor_maps,motor_performance
    from . import motor_optimization,motor_drive,motor_followups,motor_structure
    from . import motor_mechanics,motor_hotspot,motor_candidate,motor_requirements,motor_report,motor_official
    out=ROOT/'results/motor'
    if refresh:
        # Remove only generated success markers, not user source/PDF material.
        for path in out.rglob('status.json'):
            if 'official_couplings' not in path.parts:path.unlink()
        for path in out.rglob('summary.json'):path.unlink()
        for path in (out/'maps').glob('*C/point_*.pkl'):path.unlink()
    # Portable packages retain summaries but omit native Python checkpoints.
    # Downstream field processing needs actual raw outputs, not a success marker.
    for folder in ['full_period/288','peak_fields']:
        if not (out/folder/'native_output.pkl').exists():
            (out/folder/'status.json').unlink(missing_ok=True)
    for T in [20,80,150]:
        folder=out/'maps'/f'{T}C'
        points=[folder/f'point_{d}_{q}.pkl' for d in [-12.,-6.,0.] for q in [0.,10.814,22.]]
        if not all(p.exists() for p in points):(folder/'summary.json').unlink(missing_ok=True)
    if not (ROOT/'results/extended/native_electrical/status.json').exists():
        raise RuntimeError('Run python -m actuator.run then python -m actuator.extended to create the prerequisite design/electrical study.')
    motor_campaign.run()  # Retains the diagnostic reduced-period comparisons.
    motor_full_period.run()
    motor_maps.run()
    if not completed(out/'performance/summary.json'):motor_performance.run(out/'performance')
    if not completed(out/'optimization/summary.json'):motor_optimization.run(out/'optimization')
    if not completed(out/'drive/summary.json'):motor_drive.run(out/'drive')
    followup_paths=['full_period/144_mesh1p5/status.json','skew/status.json','peak_fields/status.json','structure_peak/summary.json','fault_fields/summary.json']
    if not all(completed(out/p) for p in followup_paths):motor_followups.run()
    if not completed(out/'structure/summary.json'):motor_structure.run(out/'structure')
    motor_mechanics.run(out/'mechanics')
    if not completed(out/'hotspot/summary.json'):motor_hotspot.run(out/'hotspot')
    for folder,h in [('hotspot_candidate',.0015),('hotspot_candidate_fine',.001)]:
        if not completed(out/folder/'summary.json'):motor_hotspot.run(out/folder,Rtarget=.12,h=h)
    if not completed(out/'candidate/summary.json') or not completed(out/'candidate_drive/summary.json'):
        motor_candidate.run()
    # Rebuild H projections only when absent; completed field summaries suffice
    # for package review and do not require reopening every large fault pickle.
    if not completed(out/'fault_fields_candidate/summary.json'):motor_followups.run(candidate=True)
    motor_requirements.run()
    motor_official.run()
    motor_report.build()
    env=dict(os.environ,OPENBLAS_NUM_THREADS='1')
    with (out/'verification.txt').open('w') as log:
        check=subprocess.run([sys.executable,'-m','pytest','-q'],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
    if check.returncode:
        raise RuntimeError('Verification failed; see results/motor/verification.txt')
    subprocess.run([sys.executable,'scripts/record_provenance.py'],cwd=ROOT,env=env,check=True)
    print('Motor report:',out/'report.pdf',flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--refresh',action='store_true')
    run(parser.parse_args().refresh)
