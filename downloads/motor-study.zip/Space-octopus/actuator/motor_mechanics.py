"""Motor shaft, rotor retention, thermal-growth and end-turn screening equations."""
import json,pickle
from pathlib import Path
import numpy as np
from .machine import build_machine
from .run import dump
ROOT=Path(__file__).resolve().parents[1]


def run(out):
    out.mkdir(parents=True,exist_ok=True);c=json.loads((ROOT/'configs/revised.json').read_text());m=build_machine(c)
    d=2*c['motor']['shaft_radius_m'];L=.113;E=210e9;nu=.3;G=E/(2*(1+nu));J=np.pi*d**4/32;I=J/2
    rotor_mass=m.rotor.comp_masses()['Mtot'];shaft_mass=7650*np.pi*d*d/4*L
    critical_Hz=np.sqrt((48*E*I/L**3)/(rotor_mass+.5*shaft_mass))/(2*np.pi)
    torque_cases=[4.5,8.5]
    extended=ROOT/'results/motor/extensions/nonlinear_drive/summary.json'
    if extended.exists():
        data=json.loads(extended.read_text());fixed=[v for v in data['faults'] if v['mode']=='fixed speed']
        fixed += [v for v in data.get('end_leakage_sensitivity',[]) if 'torque_min_Nm' in v]
        torque_cases.append(max(max(abs(v['torque_min_Nm']),abs(v['torque_max_Nm'])) for v in fixed))
    torsion=[dict(torque_Nm=T,max_shear_MPa=16*T/(np.pi*d**3)/1e6,von_mises_MPa=np.sqrt(3)*16*T/(np.pi*d**3)/1e6,twist_deg=T*.137/(G*J)*180/np.pi) for T in torque_cases]
    retention=[]
    for rpm in [630,945,1890]:
        omega=rpm*2*np.pi/60;rad=.0245;t=.003;rho=8300
        retention.append(dict(motor_rpm=rpm,centrifugal_radial_bond_pressure_MPa=rho*t*rad*omega**2/1e6,thin_ring_equivalent_hoop_MPa=rho*(rad*omega)**2/1e6))
    # Elastic shear-lag model: two adherends coupled by a uniform adhesive layer.
    # Actual SmCo and adhesive properties are unavailable; these are explicit
    # assumed stiffnesses, producing required stresses rather than a strength pass.
    shear_lag=[]
    for deltaT in [50,130]:
        for Ga in [.01e9,.1e9,.5e9,1e9]:
            S=Ga/.0001;compliance=1/(150e9*.003)+1/(210e9*.017);beta=np.sqrt(S*compliance)
            for length,name in [(.085,'axial one segment'),(.085/4,'axial four segments'),(.085/8,'axial eight segments'),(.0245*.8*np.pi/5,'circumferential')]:
                tau=S*abs((12e-6-6e-6)*deltaT)/beta*np.tanh(beta*length/2)
                shear_lag.append(dict(delta_T_C=deltaT,adhesive_shear_modulus_GPa=Ga/1e9,direction=name,required_edge_shear_MPa=tau/1e6))
    # Differential growth from a common 20 C assembly state.
    gaps=[]
    for Ts,Tr in [(75,66),(20,150),(130,20),(130,150)]:
        drs=.0265*12e-6*(Ts-20)
        drr=.023*12e-6*(Tr-20)+.003*6e-6*(Tr-20)
        gaps.append(dict(stator_C=Ts,rotor_C=Tr,thermal_only_gap_mm=(.0005+drs-drr)*1000))
    # End-turn-only axial conduction bound. Native resistance includes 2*Lew per
    # half-turn. End lengths here represent thermal path assumptions, not a CAD loop.
    active_area=m.stator.slot.comp_surface_active()*12;Lew=m.stator.winding.comp_length_endwinding();active=c['motor']['stack_m']
    fraction=2*Lew/(active+2*Lew);hotspots=[]
    for copper_W in [65,250]:
        for k_axial in [5,25,170]:
            end_side_power=copper_W*fraction/2
            delta=end_side_power*Lew/(2*k_axial*active_area)
            hotspots.append(dict(total_copper_loss_W=copper_W,effective_axial_k_W_mK=k_axial,end_turn_fraction=fraction,
                adiabatic_end_hotspot_above_slot_exit_C=delta))
    peel=None
    source=ROOT/'results/motor/full_period/288/native_output.pkl'
    if source.exists():
        with source.open('rb') as f:native=pickle.load(f)
        peel=float(max(0.,-native.force.AGSF.components['radial'].values.min())/1e6)
    summary=dict(status='completed',engine='Explicit motor-specific mechanics and axial conduction screens',shaft_diameter_mm=d*1000,
        assumed_bearing_span_mm=L*1000,rotor_mass_kg=rotor_mass,shaft_torsion=torsion,
        simply_supported_first_critical_rpm=critical_Hz*60,centrifugal_retention=retention,adhesive_shear_lag=shear_lag,
        thermal_airgap=gaps,endturn_conduction=hotspots,reference_magnetic_surface_traction_MPa=peel,
        limitations=['Simply supported shaft with lumped rotor mass; no selected bearing/preload or full rotor-dynamic assembly',
            'Centrifugal bond stresses exclude electromagnetic peel, interference and local magnet edges',
            'Shear-lag uses assumed 150 GPa magnet modulus, 6 ppm/K magnet expansion and 0.1 mm adhesive; no supplier strength or creep data',
            'Thermal gap omits tolerances, eccentricity, shaft bending and retaining sleeve',
            'End-turn axial bound uses packed-slot area and effective axial conductivities; actual 3-D winding/contacts require detailed geometry'])
    dump(out/'summary.json',summary);return summary


if __name__=='__main__':run(ROOT/'results/motor/mechanics')
