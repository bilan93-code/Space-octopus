"""Quantitative build requirements; proposed retainer is not a qualified part."""
import json,pickle
import numpy as np
from .runtime import ROOT
from .run import dump


def run():
    with (ROOT/'results/motor/peak_fields/native_output.pkl').open('rb') as f:peak=pickle.load(f)
    pressure=max(0.,-float(peak.force.AGSF.components['radial'].values.min()))
    extended_fields=ROOT/'results/motor/extensions/nonlinear_fault_fields/summary.json'
    if extended_fields.exists():
        pressure=max(pressure,max(v['sampled_peak_outward_magnetic_traction_MPa']*1e6 for v in json.loads(extended_fields.read_text())['cases']))
    radius=.026;thickness=.0002;E=100e9;alpha_difference=6e-6;deltaT=130.;interference=.00001
    span=2*np.pi*radius/10*.2
    hoop=pressure*radius/thickness
    bending=3*pressure*span**2/(4*thickness**2)
    thermal=E*alpha_difference*deltaT;preload=E*interference/radius
    expansion=pressure*radius**2/(E*thickness)
    span_bending_displacement=5*pressure*span**4/(32*E*thickness**3)
    mechanical=json.loads((ROOT/'results/motor/mechanics/summary.json').read_text())
    thermal_gap=min(v['thermal_only_gap_mm'] for v in mechanical['thermal_airgap'])/1000
    bearing_displacement=0.;magnetic_stiffness=None;bearing_stiffness=1e7
    eccentric=ROOT/'results/motor/extensions/eccentricity/summary.json'
    if eccentric.exists():
        gradients=[]
        for row in json.loads(eccentric.read_text())['cases']:
            e=np.asarray(row['eccentricity_m']);squared=float(e@e)
            if squared:gradients.append((row['mean_Fx_N']*e[0]+row['mean_Fy_N']*e[1])/squared)
        magnetic_stiffness=max(gradients)
        shaft_stiffness=48*210e9*np.pi*.012**4/(64*.113**3)
        effective=1/(1/bearing_stiffness+1/shaft_stiffness)
        if effective<=magnetic_stiffness:raise RuntimeError('Assumed support fails magnetic-pull stability')
        bearing_displacement=.00005*magnetic_stiffness/(effective-magnetic_stiffness)
    free_gap=thermal_gap-thickness-.00005-.00005-bearing_displacement
    gap=free_gap-expansion-span_bending_displacement
    previous_gap_50GPa=free_gap-2*(expansion+span_bending_displacement)
    available=free_gap-.0001
    required_modulus=(expansion+span_bending_displacement)*E/available if available>0 else None
    # Four axial magnet segments and a compliant bond; two segments can be used
    # in each of the two separately evaluated skew sections.
    S=1e6/.00005;beta=np.sqrt(S*(1/(150e9*.003)+1/(210e9*.017)))
    bond_thermal=S*(6e-6*130)/beta*np.tanh(beta*(.085/4)/2)
    design_torque=8.5
    extended_dynamic=ROOT/'results/motor/extensions/nonlinear_drive/summary.json'
    if extended_dynamic.exists():
        data=json.loads(extended_dynamic.read_text());fixed=[v for v in data['faults'] if v['mode']=='fixed speed']
        fixed += [v for v in data.get('end_leakage_sensitivity',[]) if 'torque_min_Nm' in v]
        design_torque=max(design_torque,max(max(abs(v['torque_min_Nm']),abs(v['torque_max_Nm'])) for v in fixed))
    bond_radius=.023;magnet_area=10*bond_radius*.8*np.pi/5*.085;bond_torque=design_torque/(bond_radius*magnet_area)
    faults=json.loads((ROOT/'results/motor/fault_fields_candidate/summary.json').read_text())['cases']
    case_radial_R=np.log(.056/.048)/(2*np.pi*167*.085)
    requirement=dict(status='completed',type='Conditional material and construction specification, not hardware qualification',
        retaining_wrap=dict(proposal='Electrically insulating, nonmagnetic hoop-wound composite retaining wrap',thickness_mm=.2,
            assumed_hoop_modulus_GPa=E/1e9,maximum_magnetic_traction_MPa=pressure/1e6,
            hoop_expansion_mm=expansion*1000,span_bending_displacement_mm=span_bending_displacement*1000,
            additional_bearing_shaft_displacement_mm=bearing_displacement*1000,
            required_hot_hoop_modulus_from_gap_GPa=required_modulus/1e9 if required_modulus is not None else None,
            previous_50GPa_remaining_gap_including_bending_and_support_mm=previous_gap_50GPa*1000,
            previous_50GPa_gap_screen_pass=bool(previous_gap_50GPa>=.0001),
            proposed_bearing_pair_radial_stiffness_N_m=bearing_stiffness,nominal_field_magnetic_negative_stiffness_N_m=magnetic_stiffness,
            membrane_stress_MPa=hoop/1e6,unsupported_span_bending_bound_MPa=bending/1e6,
            thermal_stress_bound_MPa=thermal/1e6,preload_stress_MPa=preload/1e6,
            required_hot_hoop_strength_with_factor2_MPa=2*(hoop+bending+thermal+preload)/1e6,
            required_hot_interlaminar_shear_with_factor2_MPa=pressure*span/thickness/1e6,
            conservative_remaining_gap_mm=gap*1000,required_minimum_gap_mm=.1,
            magnetic_assumption='Relative permeability approximately one and negligible conductivity; DC field approximated by the original nonmagnetic gap',
            validation='Thin-ring/beam and nominal-field support screens including fault traction. Revised stiffness requirement; actual material/contact/end-retention design remains unqualified.'),
        compliant_magnet_bond=dict(axial_segments=4,bond_mm=.05,assumed_hot_shear_modulus_MPa=1,
            design_shaft_torque_including_fault_Nm=design_torque,bond_interface_radius_mm=23,
            thermal_edge_shear_MPa=bond_thermal/1e6,peak_torque_average_shear_MPa=bond_torque/1e6,
            required_hot_bond_shear_with_factor2_MPa=2*(bond_thermal+bond_torque)/1e6,
            validation='Elastic shear-lag approximation; creep, fatigue, surface preparation and vacuum compatibility unverified'),
        magnet_requirement=dict(Br20_min_T=1.05,Br150_min_T=1.05*(1-.0003*130),
            required_knee_fields=faults,statement='Supplier irreversible knee must remain more negative than the reported screened requirement at its temperature. FEMM Hc is not the irreversible knee.'),
        cooling_requirement=dict(winding_case_average_K_W_max=.12,case_sink_K_W_max=.05,
            housing_wall_mm=8,housing_conductivity_W_mK=167,case_capacity_J_K=600,
            housing_barrel_mass_kg=2700*np.pi*(.056**2-.048**2)*.085,
            housing_radial_resistance_K_W=case_radial_R,
            required_outer_barrel_contact_h_W_m2K=1/((.05-case_radial_R)*2*np.pi*.056*.085),
            contact_geometry='Distributed full-length barrel contact; a single end-flange contact is not covered',
            effective_transverse_winding_k_W_mK_min=.3,
            effective_k_interpretation='Calibrated whole-slot path parameter; not minimum bulk potting conductivity',
            proposed_potting_k_at130C_W_mK_min=.4,slot_liner_mm_max=.2,slot_liner_k_W_mK_min=.12,
            material_scenario_reference='results/motor/extensions/thermal_materials/summary.json; zero-thickness liner and assumed void topology, not measured validation',
            endturn_axial_screen_k_W_mK=25,radiation_credit=False),
        bearing_interface=dict(proposed_nominal_dimensions_mm=[12,32,10],catalog_grade_selected=False,
            declared_preload_and_load_screen_N=100,life_scenario_h=10000,
            required_dynamic_capacity_N=100*(60*630*10000/1e6)**(1/3)),
        limitations=['Material strengths/moduli are procurement requirements and assumptions, not supplied grade allowables',
            'Magnetic support stiffness is from nominal-field eccentricity; full fault-UMP/whirl/contact dynamics are not established',
            'Wrap/adhesive/end retention are proposed construction; no released drawing or 3-D contact solution',
            '0.05 mm bond and 0.05 mm total radial tolerance are allocated in the gap screen',
            'Mission vibration, radiation, vacuum contamination and lifetime acceptance require actual requirements and tests'])
    dump(ROOT/'results/motor/build_requirements.json',requirement);return requirement


if __name__=='__main__':run()
