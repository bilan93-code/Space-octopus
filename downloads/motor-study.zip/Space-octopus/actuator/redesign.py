"""Discrete design trade study and nonlinear current/temperature flux maps."""
import copy,json
from pathlib import Path
import numpy as np
from .machine import build_machine,winding_summary
from .magnetics import MagneticModel,MU0
from .run import dump,phase_q
from .coupled import steady_state,operating_limits,transient
from pyleecan.Classes.Simu1 import Simu1
from pyleecan.Classes.Output import Output
from pyleecan.Classes.Electrical import Electrical
from pyleecan.Classes.EEC_PMSM import EEC_PMSM
from pyleecan.Classes.OPdq import OPdq


def parameters(m,c):
    fe=MagneticModel(m,c,h=.0015);n=fe.nonlinear(fe.solve())
    f=n['phase_flux_Wb'];d=f-f.mean();d/=np.sqrt(np.mean(d*d));q=phase_q(f)
    psi=float(d@f/3);L=[]
    for axis in [d,q]:
        p=fe.nonlinear(fe.solve(axis));mi=fe.nonlinear(fe.solve(-axis))
        L.append(float(axis@(p['phase_flux_Wb']-mi['phase_flux_Wb'])/6)+c['motor']['assumed_end_leakage_H'])
    # Static phase-vector estimate: explicitly not a Fourier fit over a full turn.
    return fe,d,q,dict(psi_pm_rms_Wb=psi,Ld_H=L[0],Lq_H=L[1],core_loss_ref_W=3.,torque_constant_Nm_per_Arms=15*psi)


def run_redesign(baseline,out):
    out.mkdir(parents=True,exist_ok=True)
    candidate=copy.deepcopy(baseline)
    candidate['motor'].update(turns_per_coil=12,wire_diameter_m=.0009,stator_outer_radius_m=.048)
    candidate['drive']['phase_current_limit_rms_A']=22
    candidate['thermal'].update(R_winding_case_K_W=.25,R_motor_case_sink_K_W=.15)
    candidate['provenance']='Trial redesign: 12 turns/coil, two 0.9 mm strands, 96 mm stator OD, 22 Arms inverter, winding-case 0.25 K/W and case-sink 0.15 K/W requirements. Cooling not demonstrated.'
    dump(Path('configs/revised.json'),candidate)
    variants=[]
    for od in [100,96,92]:
        c=copy.deepcopy(candidate);c['motor']['stator_outer_radius_m']=od/2000
        m=build_machine(c);fe,d,q,params=parameters(m,c)
        s=fe.nonlinear(fe.solve(11.25*q));met=fe.metrics(s)
        op=steady_state(m,c,params,220,10)
        mass=m.stator.comp_masses()['Mtot']+m.rotor.comp_masses()['Mtot']
        variants.append(dict(stator_OD_mm=od,motor_active_mass_kg=mass,winding=winding_summary(m),params=params,magnetic_screen=met,continuous=op))
    c=candidate;m=build_machine(c);fe,d,q,params=parameters(m,c)
    rows=[]
    for temp in [20,80,140]:
        for idr in [-12,-6,0]:
            for iqr in [0,9,18]:
                print('Flux map',temp,idr,iqr,flush=True)
                sol=fe.nonlinear(fe.solve(idr*d+iqr*q,temperature_C=temp))
                phid=float(d@sol['phase_flux_Wb']/3);phiq=float(q@sol['phase_flux_Wb']/3)
                # Execute native Pyleecan dq solver with current-dependent FE flux.
                op=OPdq(Id_ref=float(idr),Iq_ref=float(iqr),N0=630.,felec=52.5)
                eec=EEC_PMSM(OP=op,R1=m.stator.comp_resistance_wind(100),Phid=phid,Phiq=phiq,Phid_mag=params['psi_pm_rms_Wb'],Phiq_mag=0.,Ld=params['Ld_H'],Lq=params['Lq_H'],type_skin_effect=0)
                simu=Simu1(machine=m,elec=Electrical(eec=eec),mag=None,force=None,struct=None)
                e=simu.elec.eec;el=e.solve();torque=float(3*5*(phid*iqr-phiq*idr))
                # Magnet recoil field projected along local magnetization.
                pp=fe.centers;phi=np.arctan2(pp[1],pp[0]);sgn=np.zeros(fe.mesh.nelements)
                from pyleecan.Functions.labels import decode_label
                for rid,label in fe.labels.items():
                    if '_Magnet' in label:sgn[fe.region==rid]=(-1)**decode_label(label)['S_id']
                Br=c['motor']['magnet_Br20_T']*(1+c['motor']['magnet_alpha_per_K']*(temp-20))
                bparallel=sgn*(sol['B'][0]*np.cos(phi)+sol['B'][1]*np.sin(phi))
                hh=(bparallel[fe.kind==2]-Br)/(MU0*c['motor']['magnet_mu_r'])
                row=dict(magnet_C=temp,Id_rms_A=idr,Iq_rms_A=iqr,Phid_rms_Wb=phid,Phiq_rms_Wb=phiq,torque_Nm=torque,phase_voltage_peak_V=float(np.sqrt(2)*np.hypot(el['Ud'],el['Uq'])),magnet_H_parallel_min_kA_m=float(hh.min()/1000),magnet_H_parallel_p01_kA_m=float(np.quantile(hh,.01)/1000),BH_extrapolated_area_fraction=sol['iron_area_BH_extrapolated_fraction'],nonlinear_residual=sol['nonlinear_residual'])
                rows.append(row);dump(out/'flux_map.json',rows)
    # Thermal/drive comparisons. Core-loss uncertainty is a deliberate sweep.
    scenarios=[]
    for sink in [50,70]:
        for core_loss in [3,10,30]:
            cc=copy.deepcopy(c);cc['thermal']['sink_C']=sink;pp=dict(params,core_loss_ref_W=core_loss)
            for torque in [220,302.4]:
                op=steady_state(m,cc,pp,torque,10)
                scenarios.append(dict(sink_C=sink,assumed_core_rotor_loss_W=core_loss,output_torque_Nm=torque,**op))
    cont=steady_state(m,c,params,220,10)
    peak=transient(m,c,params,list(cont['temperatures_C'].values()),400,10,5)
    limits=operating_limits(m,c,params,cont,peak)
    m.save(str(out/'revised_machine.json'))
    summary=dict(engine='Pyleecan geometry/winding/native EEC; custom nonlinear magnetic FE; SciPy thermal coupling',selected_config='configs/revised.json',discrete_trade=variants,flux_map=rows,thermal_loss_scenarios=scenarios,continuous=cont,conditional_limits=limits,parameters=params,limitations=['Static-position flux map, not a rotor-averaged current/temperature LUT','End leakage remains assumed','Loss coefficients remain uncalibrated; 3/10/30 W core-rotor sensitivity cases bracket model uncertainty, not measured bounds','Improved thermal paths are requirements, not demonstrated properties','22 Arms current limit is a new inverter requirement','Demagnetization requires supplier temperature-dependent recoil curves and coercivity; H-field alone is not a pass/fail criterion'])
    dump(out/'redesign_summary.json',summary)
    return summary
