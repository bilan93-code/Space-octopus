"""Corrective winding/cooling candidate, keeping the characterized magnetic geometry."""
import copy,json
from .motor_performance import MotorModel
from .machine import build_machine,winding_summary
from .runtime import ROOT
from .run import dump
from .motor_drive import run as run_drive


def run():
    c=json.loads((ROOT/'configs/revised.json').read_text())
    c['motor']['wire_diameter_m']=.00095;c['thermal']['R_winding_case_K_W']=.12
    c['thermal']['R_motor_case_sink_K_W']=.05
    c['thermal']['case_emissivity']=0.
    c['provenance']='Corrective motor candidate: two 0.95 mm strands, winding-case <=0.12 K/W and distributed case-sink <=0.05 K/W. No radiation credit. Magnetic geometry/turns unchanged; cooling targets must be demonstrated.'
    dump(ROOT/'configs/motor_candidate.json',c)
    model=MotorModel();model.c=c;model.m=build_machine(c)
    normal=model.steady(Rwc=.12,Rcase=.05);robust=model.steady(sink=70,Rwc=.12,Rcase=.05,core_ref_W=30)
    hold50=model.steady(220,0,Rwc=.12,Rcase=.05);hold70=model.steady(220,0,sink=70,Rwc=.12,Rcase=.05)
    mass=model.m.stator.comp_masses()['Mtot']+model.m.rotor.comp_masses()['Mtot']
    summary=dict(status='completed',config='configs/motor_candidate.json',nominal=normal,stress_scenario=robust,
        holding_50C=hold50,holding_70C=hold70,winding=winding_summary(model.m),active_motor_mass_kg=mass,
        magnetic_reuse_basis='Same slots, turns, PM/iron geometry and prescribed phase currents: conductor diameter changes DC resistance, mass and thermal properties, not the magnetostatic ampere-turn field.',
        thermal_validation='hotspot_candidate_fine/summary.json includes stationary phase heating, native-angle holding currents, 1% current allowance and end-turn/case-rise bounds',
        limitations=['Cooling path and materials are requirements, not measured properties',
            'Three-degree stepped rotor skew is a separately evaluated option; it is not silently inserted into this baseline map',
            'Magnet retention, winding manufacture and supplier knee/strength data remain build-release requirements'])
    out=ROOT/'results/motor/candidate';out.mkdir(parents=True,exist_ok=True);dump(out/'summary.json',summary)
    model.m.save(str(out/'machine.json'))
    run_drive(ROOT/'results/motor/candidate_drive',config=c)
    return summary


if __name__=='__main__':run()
