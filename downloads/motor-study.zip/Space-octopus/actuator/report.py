"""Generate readable Markdown, HTML and PDF from the executed analysis."""
from pathlib import Path
import html
import re
import markdown


def write_report(out,r,c):
    p=r['magnetic_parameters'];v=r['magnetic_checks'];w=r['winding'];ops=r['operating_points'];cont=ops['continuous'];e=cont['electrical'];g=r['gear_loads_continuous'][1]
    rows=[]
    for name,op in ops.items():
        x=op['electrical'];t=op['temperatures_C']
        rows.append(f"| {name} | {x['motor_rpm']:.0f} | {x['Iq_rms_A']:.2f} | {x['phase_voltage_peak_V']:.2f} | {x['copper_loss_W']:.1f} | {t['winding']:.1f} | {t['rotor']:.1f} | {t['gear_case']:.1f} | {'pass' if op['thermal_ok'] and x['current_ok'] and x['voltage_ok'] else 'exceeds limit'} |")
    sens=[]
    for s in r['thermal_sensitivity']:
        sens.append(f"| {s['sink_C']} | {s['gearbox_efficiency']:.4f} | {s['electrical']['Iq_rms_A']:.2f} | {s['temperatures_C']['winding']:.1f} | {s['total_actuator_heat_W']:.1f} |")
    meshes=[]
    for m in r['mesh_convergence']:
        meshes.append(f"| {m['h_m']*1000:.1f} | {m['nodes']} | {m['elements']} | {m['torque_Nm']:.4f} | {m['phase_flux_norm_Wb']:.6f} |")
    nonlinear_peak=max(x['load_9Arms']['iron_B_p99_T'] for x in r['rotor_sweep'])
    extrap=max(x['BH_extrapolated_iron_area_fraction'] for x in r['rotor_sweep'])
    mass=r['mass_screen'];force=r['force_screen'];limits=r['conditional_limits']
    status='passes the assumed current, voltage and temperature screens' if cont['thermal_ok'] and e['current_ok'] and e['voltage_ok'] else 'exceeds at least one assumed current, voltage or temperature screen'
    text=f'''# Space-octopus: coupled motor and planetary actuator analysis

## 1. Decision and scope

The 63:1 two-stage candidate at 220 N m and 10 output rpm **{status}**.
The model calculates {e['Iq_rms_A']:.2f} A RMS phase current,
{e['phase_voltage_peak_V']:.2f} V peak phase-voltage demand and
{cont['temperatures_C']['winding']:.1f} deg C winding temperature with an assumed
50 deg C conductive sink. It dissipates {cont['total_actuator_heat_W']:.1f} W in
the actuator, excluding {e['inverter_loss_W']:.1f} W in the external inverter.
These are conditional simulation results, not demonstrated continuous ratings.

This study uses actual Pyleecan machine and winding objects, native PMSM electrical
circuit methods, Gmsh meshing of Pyleecan surfaces, a custom scikit-fem 2-D magnetic
solver, and SciPy steady/transient thermal coupling. It does not claim that the
custom adapter is a native Pyleecan MagFEMM or MagElmer run.

The original PDFs remain in docs/sources. Their conversational instructions are
reference material. Inputs not established by the user are explicit assumptions in
configs/baseline.json. Results depend on unmeasured materials, cooling and losses.

## 2. Requirements and adopted design point

Confirmed project intent: 220 N m continuous joint output, space robot arm,
separate removable inrunner motor and planetary gearbox, and reproducible analysis
using open-source tools. The 10 rpm speed, 48 V nominal / 42 V minimum bus,
50 deg C sink, 400 N m five-second peak, and temperature limits were chosen for this
study. They are not confirmed mission requirements.

| Item | Trial value |
| --- | --- |
| Motor | Three-phase radial-flux surface-PM inrunner, 12 slots, 10 poles |
| Rotor iron OD / magnet OD | 46 / 52 mm |
| Stator bore / OD | 53 / 100 mm |
| Mechanical air gap | 0.5 mm; no retaining sleeve included |
| Active stack / assumed shaft diameter | 85 / 12 mm |
| Magnet thickness / arc coverage | 3 mm / 80 percent |
| Magnet data | Generic SmCo-like Br20 = 1.05 T, mu_r = 1.05, alpha = -0.0003/K |
| Winding | 15 turns/coil; 60 series turns/phase; double layer; tooth coils |
| Conductor | Two parallel 0.8 mm bare copper strands per turn |
| End-turn assumption | 12 mm additional length at each half-turn end |
| Stage 1 | 18 / 63 / 144 teeth, module 0.75 mm, face 12 mm, three planets |
| Stage 2 | 18 / 45 / 108 teeth, module 1 mm, face 24 mm, three planets |
| Gearbox housing OD | 140 mm trial envelope |
| Continuous limits used | 16 Arms phase, 130 deg C winding, 150 deg C rotor screen |

The 100 mm stator and 140 mm gearbox do not define the overall assembly length,
mass or bearing envelope. No full mechanical CAD assembly has been released.

Native Pyleecan material masses are {mass['stator']['Mlam']:.3f} kg stator iron,
{mass['stator']['Mwind']:.3f} kg winding including the modelled end turns,
{mass['rotor']['Mlam']:.3f} kg rotor iron and {mass['rotor']['Mmag']:.3f} kg magnets.
With the assumed 130 mm long, 12 mm solid steel shaft, modelled motor material
alone totals {mass['motor_material_total_kg']:.3f} kg, excluding housing, bearings,
coupling, encoder and the complete gearbox. The original approximately 4.8 kg
complete-actuator mass is not supported by this geometry.

## 3. Pyleecan geometry and winding model

MachineSIPMSM, LamSlotWind, SlotW10, Winding, CondType12, LamSlotMag, SlotM11,
Magnet and Shaft define the model. SWAT-EM generates the winding connection
matrix through Pyleecan. The serialized machine is machine.json.

The slots are SlotW10 with a 2 mm opening, 1 mm isthmus, 1 mm transition,
6 mm wedge width, 13 mm active height and 9 mm bottom width. SlotW10 uses its
opening width at the active-slot top; do not substitute the wedge width when
calculating active copper area.

| Calculated quantity | Result |
| --- | --- |
| Series turns per phase | {w['turns_per_phase']} |
| Fundamental winding factor | {w['winding_factors'][0]:.6f} |
| Third / fifth / seventh winding factors | {w['winding_factors'][1]:.4f} / {w['winding_factors'][2]:.4f} / {w['winding_factors'][3]:.4f} |
| Active slot area | {w['slot_active_area_mm2']:.3f} mm2 |
| Copper cross-section per turn | {w['copper_area_per_turn_mm2']:.4f} mm2 |
| Bare copper slot fill | {100*w['bare_copper_fill']:.2f} percent |
| Phase resistance at 20 / 100 deg C | {w['R20_ohm']:.4f} / {w['R100_ohm']:.4f} ohm |

R_phase(T) = rho20 [1 + alpha_Cu (T-20)] N_phase 2 (L_stack + 2 L_end) / A_turn.

The resistance comes from Pyleecan comp_resistance_wind, including the specified
end-turn allowance. The earlier PDF's 0.15 ohm hot resistance is not reproduced.
Fill excludes liners, wedges and packing defects; winding manufacture remains open.

Pyleecan 1.5.2 has a recursive super(type(self), self) call in LamSlot.check for
these subclasses. The project does not modify vendor files: it invokes the base
lamination checks, native slot checks, positive-yoke/airgap checks, geometric area
checks, and independent automated tests. It does not claim machine.check passed.

## 4. Magnetic finite-element formulation

A full-circle 2-D cross-section is meshed by Gmsh using exact circular arcs and
straight lines exported from Pyleecan. OpenCASCADE differences form annular
surfaces; fragmentation makes interfaces conformal. The adapter verifies each
source surface area against Pyleecan within 0.01 percent and preserves winding
and magnet labels. A_z is zero at the stator OD. Outer stray flux, axial end
fields, magnet segmentation, sleeve and manufacturing eccentricity are omitted.
Linear triangles approximate circular boundaries by chords: the coarse-mesh
magnet-area discrepancy is bounded to 0.5 percent by an independent analytic test.
The 2-D permeability model does not homogenize the 95 percent lamination packing;
stacking is included in mass, not in the constitutive magnetic law.

B = curl(A_z) = (dA_z/dy, -dA_z/dx).

Weak equation: integral nu grad(A_z) dot grad(v) dS = integral J_z v dS
+ integral nu [Br_x dv/dy - Br_y dv/dx] dS.

Current density is the native winding-matrix conductor count times phase current
divided by the actual meshed half-slot area. Flux linkage is extracted by
reciprocity: lambda_phase = L_stack integral (turn-density_phase) A_z dS.

The initial model uses constant mu_r = 1500 for steel. A Newton solve then uses
the B-H data bundled with Pyleecan as M270-35A. That bundled exemplar is not a
certified curve for procured steel. B-H data stop at 1.8 T; above that the last
H/B differential slope is extended linearly. This is an explicit uncertainty,
not a prediction of deep saturation. The largest extrapolated iron-area fraction
in the sampled loaded sweep is {100*extrap:.4f} percent. Local slot-corner maxima
are mesh-sensitive; the largest sampled 99th-percentile iron |B| is
{nonlinear_peak:.3f} T. The Newton residual must be below 1e-7 relative.

At 80 deg C reference magnet temperature:

| Magnetic/electrical parameter | Result |
| --- | --- |
| Fundamental PM phase linkage, peak | {p['psi_pm_peak_Wb']:.6f} Wb turns |
| Fundamental PM linkage, Pyleecan RMS dq | {p['psi_pm_rms_Wb']:.6f} Wb turns |
| Torque constant, fundamental | {p['torque_constant_Nm_per_Arms']:.4f} N m/Arms |
| Ld / Lq, 2-D differential, no-load | {1000*p['Ld_2D_H']:.4f} / {1000*p['Lq_2D_H']:.4f} mH |
| Ld / Lq with assumed 0.08 mH end leakage | {1000*p['Ld_H']:.4f} / {1000*p['Lq_H']:.4f} mH |
| Estimated core/rotor-loss proxy at 630 rpm | {p['core_loss_ref_W']:.2f} W |

A 24-position sweep spans one electrical period (72 mechanical degrees).
At each loaded position a balanced 9 Arms current vector tracks the local no-load
flux direction in quadrature. This is an idealized excitation, not a simulation
of a sampled-data inverter or a measured sinusoidal current controller.
The fundamental is Fourier-fitted from computed phase linkages. Sampled linkage
harmonics relative to fundamental are {p['phase_flux_harmonics_relative']}.
Triplen content can appear in phase linkage but cancels in balanced line voltage.

These samples illustrate torque variation. They do not resolve every high-order
cogging harmonic or establish the actual maximum cogging torque. Sampled no-load
peak-to-peak torque is {v['cogging_sample_peak_to_peak_Nm']:.4f} N m and includes
finite-element discretization error.

## 5. Numerical verification

Torque is evaluated from the Maxwell stress on three circular contours in the
magnetic gap:

T = L r squared / mu0 integral_0^2pi Br Btheta dtheta.

A_z is sampled at 2048 angular points; its angular derivative retains spatial
orders through 150 to suppress interpolation noise. The radial derivative uses
a centered interval of 8 percent of gap width. These are numerical choices,
not physical harmonic filtering. Virtual-work comparison checks their effect.

| Nominal bulk mesh size [mm] | Nodes | Triangles | Loaded torque [N m] | No-load linkage norm [Wb turns] |
| --- | --- | --- | --- | --- |
{chr(10).join(meshes)}

Medium-to-fine torque change: {100*v['mesh_torque_change_relative']:.2f} percent;
linkage-norm change: {100*v['mesh_flux_change_relative']:.2f} percent.
At 9 Arms, mean nonlinear FE torque is {v['FE_mean_torque_9Arms_Nm']:.4f} N m;
the Pyleecan fundamental EEC gives {v['EEC_torque_9Arms_Nm']:.4f} N m
({100*v['FE_EEC_difference_relative']:.2f} percent difference).

An independent PM virtual-work screen uses fixed phase currents and central
rotor displacements of +/-0.25 mechanical degree:
T_PM = sum_phase I_phase d(lambda_PM_phase)/d(theta_mech).
It gives {v['virtual_work_torque_9Arms_Nm']:.4f} N m versus the fine-mesh
loaded Maxwell-stress result ({100*v['virtual_work_vs_fine_FE_relative']:.2f}
percent difference). It omits current-induced reluctance torque and differs in
nonlinear magnetic state, so exact agreement is not expected.

Automatic thresholds are 5 percent mesh torque change, 2 percent mesh linkage
change and 12 percent FE/EEC disagreement. Passing these supports numerical
consistency of this screening model, not material accuracy or hardware validation.

The fine loaded mesh gives peak radial magnetic pressure
{force['normal_pressure_peak_Pa']/1000:.1f} kPa and mean pressure
{force['normal_pressure_mean_Pa']/1000:.1f} kPa. Integrated net force is
{force['net_force_N']:.3f} N in the ideal concentric model; it includes numerical
imbalance and does not predict eccentric magnetic pull or external bearing loads.
No modal, acoustic or structural finite-element solution is claimed.

## 6. Pyleecan PMSM electrical model and drive

The magnetic adapter supplies no-load fundamental flux and differential Ld/Lq to
Pyleecan EEC_PMSM. Native solve, comp_torque_sync_rel and comp_joule_losses
execute at each coupled point. Id = 0; field weakening and MTPA optimization are
not implemented. The EEC uses constant inductance and a fundamental torque
constant. Nonlinear loaded FE is a separate comparison; saturation is not
fully iterated over a current/temperature flux map.

All native dq quantities use RMS phase conventions:

omega_e = p omega_m.
Ud = R Id - omega_e Lq Iq.
Uq = R Iq + omega_e (Ld Id + psi_PM_rms).
T_em = 3 p [psi_PM_rms Iq + (Ld-Lq) Id Iq].
P_copper = 3 R (Id squared + Iq squared).
psi_peak = sqrt(2) psi_rms; Vphase_peak = sqrt(2) hypot(Ud,Uq).

For space-vector modulation, Vphase_peak_max = margin Vdc/sqrt(3).
At 42 V minimum and 0.9 margin this is {42*.9/(3**.5):.2f} V peak.
The coupling applies the magnet remanence temperature coefficient to psi_PM and
uses Pyleecan resistance at the solved winding temperature. Frequency-dependent
AC copper loss, switching ripple and inverter current-control dynamics are omitted.

## 7. Planetary kinematics, loads and rejected geometry

For each fixed-ring stage with sun input and carrier output:
Zr = Zs + 2 Zp; i = 1 + Zr/Zs; d = module Z.
Planet-center radius a = module (Zs+Zp)/2.
Adjacent planet-tip clearance c = 2 a sin(pi/Nplanets) - module (Zp+2).
Equally spaced assembly screen: (Zs+Zr)/Nplanets must be an integer.

The candidate stages give 9:1 and 7:1, hence 63:1. Both ring pitch diameters are
108 mm. Tip clearances are {r['gear_geometry'][0]['planet_tip_clearance_mm']:.3f}
and {r['gear_geometry'][1]['planet_tip_clearance_mm']:.3f} mm. A 140 mm OD
housing leaves approximately 14.75 mm radial material beyond the larger nominal
ring root before structural details. These are geometry checks, not tolerance,
interference or rim-strength verification. Stage-1 nominal sun root diameter is
11.625 mm, so the 12 mm motor shaft must couple to a separate, supported stepped
gearbox input stub; a 12 mm bore or spline through that sun is not feasible.

The original 12/36/84-tooth, module-1.25, four-planet stage has -5.074 mm
clearance and is rejected. Standard 12-tooth sun undercut and the undersized
input spline were separate unresolved problems in that concept.

T_motor_shaft = T_output/(i_total eta_total).
At eta_total = 0.80, 220 N m requires 4.365 N m shaft torque.
P_out = T_out 2 pi n_out/60 = 230.38 W at 10 rpm.
P_gear_heat = P_out (1/eta_total - 1) = 57.60 W.
At 30 rpm both output power and this assumed gearbox heat triple.

For consistent conservative stage loading, eta_stage = sqrt(0.80).
Nominal per-planet tangential load Ft = 2 T_sun/(Nplanets d_sun).
Stage-2 Ft = {g['nominal_mesh_tangential_N']:.1f} N.
A Lewis screen uses sigma = K Ft/(b module Y), with K=1.5 and Y=0.30,
giving {g['factored_bending_screen_MPa']:.1f} MPa. The factor is assumed;
no fatigue or contact safety factor is assigned. Nominal pin reaction is
2 Ft = {g['nominal_pin_force_N']:.1f} N. A central-load simply supported
12 mm pin over 28 mm gives sigma_pin = 8 F span/(pi d cubed) =
{g['nominal_pin_bending_MPa']:.1f} MPa before support and sharing factors.

ISO 6336 tooth contact/bending fatigue, planet load sharing, ring flexibility,
carrier/pin/bearing fatigue, lubricant life, backlash, stiffness and output-bearing
combined loads remain unverified. Driving torque alone cannot size the output
bearing. A constant efficiency is a budget, especially at zero speed: the holding
model uses static torque multiplication as an allowance, not a physical power
efficiency law at standstill.

## 8. Thermal and loss coupling

Four nodes represent winding, rotor/magnets, motor case and gearbox case.
Thermal paths: winding-to-motor case 0.5 K/W, rotor-to-motor case 3 K/W,
motor case-to-sink 0.3 K/W, gearbox case-to-sink 0.5 K/W, case-to-case 2 K/W.
These are engineering assumptions; they have not been derived from detailed CAD.

For each node: C dT/dt = P_generated - sum[(T-Tneighbor)/R] - Q_radiation.
Q_radiation = emissivity sigma area [(T+273.15)^4 - Tsurroundings_K^4].
The steady solve makes dT/dt zero while updating copper resistance and PM flux.
No vacuum convection is included. Assumed view factor to a 300 K surrounding
surface is one. This may overstate radiation if the arm shields the surface.

Core loss is a proxy: sampled stator FE |B| is treated as local sinusoidal peak;
3 W/kg at 1.5 T and 50 Hz, B squared scaling, 60 percent hysteresis and 40 percent
eddy frequency scaling, plus 25 percent allowance. The operating map scales this
reference with speed, not a full time-history Bertotti calculation. Rotor/magnet
eddy losses and bearing friction use allowances. No measured loss map is available.
Inverter efficiency is assumed 97 percent, with inverter heat rejected separately.

| Point | Motor rpm | Phase Arms | Phase Vpeak | Copper W | Winding C | Rotor C | Gear case C | Screen |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
{chr(10).join(rows)}

The 400 N m steady row tests the thermal equations; it is not a continuous or
peak rating. A separate five-second transient starts from the continuous hot
equilibrium. Its winding endpoint is {r['peak_transient']['temperatures_C'][-1][0]:.2f}
deg C. Thermal capacity cannot establish gear, magnet or inverter peak capability.
The pulse calculation prescribes torque even when the voltage screen fails: it
is a hypothetical thermal load, not a realizable pulse at the minimum bus. Native
electrical evaluation at the pulse endpoints requires approximately
{limits['peak_drive_start_end'][-1]['Iq_rms_A']:.2f} Arms and
{limits['peak_drive_start_end'][-1]['phase_voltage_peak_V']:.2f} V phase peak.
With the same modulation margin it needs at least
{limits['peak_required_bus_V_with_modulation_margin']:.2f} V on the DC bus.
Thus the 400 N m pulse does not pass the 42 V minimum-bus screen, even though the
five-second thermal rise is small. This is close to the 48 V nominal bus and
leaves essentially no allowance for additional model error or supply droop.
The warm-up uses 200/250/600/800 J/K winding/rotor/motor-case/gear-case capacities,
all assumed. Temperature-versus-time is conditional on those capacities.

At the continuous point, heat balance is {cont['conducted_to_sink_W']:.2f} W
conducted plus {cont['radiated_heat_W']:.2f} W radiated, matching
{cont['total_actuator_heat_W']:.2f} W generation. Largest node residual is
{cont['thermal_residual_W']:.3g} W. Energy conservation does not verify the
assumed thermal resistances.

## 9. Sensitivities and design implications

With fixed Id=0, the conditional voltage-limited speed at 220 N m is
{limits['voltage_limited_output_rpm_at_required_torque']:.2f} output rpm.
At 10 rpm, numerical threshold crossings are approximately
{limits['output_torque_limits_Nm_at_design_speed']['thermal']:.1f} N m for the
assumed winding-temperature limit and
{limits['output_torque_limits_Nm_at_design_speed']['voltage']:.1f} N m for the
minimum-bus voltage limit. These are model boundaries, not gearbox ratings.
The 220 N m design point has limited speed/voltage margin, and the motor's
proposed 6 N m continuous target is not supported by the adopted thermal paths.


| Sink C | Gearbox efficiency | Phase Arms | Winding C | Actuator heat W |
| --- | --- | --- | --- | --- |
{chr(10).join(sens)}

The torque-speed plot and CSV test 40 operating points against assumed current,
voltage and temperature limits. Red points are infeasible for this winding/bus
without design changes; green points are conditional screening passes. Constant
gearbox efficiency, fixed inductance and simplified core loss limit extrapolation.
No torque margin is claimed for uncomputed mission transients.

Retain the separated inrunner and 63:1 concept for continued development.
Do not freeze the prior 6 N m continuous motor target, total length, bearing size
or mass based on torque density estimates. Use the computed 6 N m-equivalent row
to judge whether improved thermal contacts, larger conductor area, longer stack
or a higher voltage/fewer turns trade is needed. Increasing wire area requires
rechecking slot fill and manufacturability; increasing stack length changes flux,
resistance, inductance and bus-speed margin together. A higher speed cannot be
obtained by reusing only the 10 rpm torque budget.

## 10. Reproduction, coverage and remaining limits

Run from /workspace/Space-octopus:

    bash scripts/setup.sh
    OPENBLAS_NUM_THREADS=1 .venv/bin/python -m actuator.run
    .venv/bin/python -m pytest -q

The environment uses Python {r['python']}; package versions: {r['versions']}.
The requirements lock records the full installed dependency set. Results include
inputs.json, machine.json, winding.json, analysis.json, torque_speed.csv and figures.
The HTML embeds images; the PDF is generated from the same calculated report.
No services or GUI are required. Re-run the analysis after changing assumptions.

Executed coverage: parametric geometry, native winding generation and resistance,
nonlinear 2-D magnetostatics, rotor-position sweep, differential inductance,
Pyleecan RMS dq voltage/torque/Joule loss, gearbox geometry and screening loads,
steady thermal feedback, transient heating, and deterministic sensitivities.

Not executed: native FEMM/Wine or Elmer magnetic solve, 3-D end effects, full
current/temperature flux-map coupling, AC/PWM loss, certified material loss model,
short-circuit/demagnetization fault analysis, mechanical modal/stress FE,
ISO fatigue/contact ratings, loaded bearing life, real gearbox losses, controls,
launch loads, vacuum/lubrication qualification, radiation qualification and hardware
tests. Demagnetization cannot be proven from a scalar temperature limit and linear
magnet recoil model. SmCo chemistry alone does not establish space suitability.

The detailed analytical and numerical checks reduce inconsistency in the starting
design. They do not establish flight qualification or a manufacturable final actuator.

## 11. Sources and provenance

- User-provided ChatGPT and Gemini PDFs, preserved under docs/sources.
- Pyleecan 1.5.2 source and bundled M270-35A material data:
  https://github.com/Eomys/pyleecan/tree/1.5.2
- Native winding, resistance, EEC_PMSM solve, torque and Joule-loss methods in
  pyleecan/Methods/Machine and pyleecan/Methods/Simulation in that release.
- Gmsh 4.13.1 OpenCASCADE Python API and scikit-fem 8.1.0 assembled P1 elements.
- Gear and vacuum thermal equations are explicitly stated here. No claim of
  compliance with an external engineering standard has been inferred from the PDFs.
'''
    (out/'report.md').write_text(text)
    body=markdown.markdown(text,extensions=['tables','fenced_code'])
    figures=['machine.png','flux_density.png','flux_torque_sweep.png','thermal_transients.png','operating_envelope.png']
    import base64
    imgs=''.join('<figure><img style="max-width:100%" src="data:image/png;base64,'+base64.b64encode((out/f).read_bytes()).decode()+'"><figcaption>'+f+'</figcaption></figure>' for f in figures)
    (out/'report.html').write_text('<!doctype html><meta charset="utf-8"><title>Space-octopus actuator analysis</title><style>body{font:16px/1.6 system-ui;max-width:1050px;margin:40px auto;padding:20px;color:#152537}table{border-collapse:collapse;font-size:14px}td,th{border:1px solid #ccd5de;padding:7px}h1,h2{line-height:1.2}pre{overflow:auto;background:#eef2f6;padding:15px}</style>'+body+imgs)
    make_pdf(out,text,figures)


def make_pdf(out,text,figures):
    from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,Image,PageBreak
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib import colors
    from reportlab.lib.utils import ImageReader
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from matplotlib import get_data_path
    fonts=Path(get_data_path())/'fonts/ttf'
    pdfmetrics.registerFont(TTFont('DejaVuSans',str(fonts/'DejaVuSans.ttf')))
    pdfmetrics.registerFont(TTFont('DejaVuSans-Bold',str(fonts/'DejaVuSans-Bold.ttf')))
    styles=getSampleStyleSheet()
    for name in ['BodyText','Normal']:
        styles[name].fontName='DejaVuSans';styles[name].fontSize=9;styles[name].leading=13
    for name in ['Title','Heading2']:
        styles[name].fontName='DejaVuSans-Bold'
    styles['Title'].fontSize=18;styles['Title'].leading=23
    styles['Heading2'].fontSize=12;styles['Heading2'].leading=16
    story=[];lines=text.splitlines();i=0
    def para(s,style='BodyText'):
        s=html.escape(s).replace('**','')
        return Paragraph(s,styles[style])
    while i<len(lines):
        line=lines[i]
        if line.startswith('|'):
            table=[]
            while i<len(lines) and lines[i].startswith('|'):
                row=[v.strip() for v in lines[i].strip('|').split('|')]
                if not all(re.fullmatch(r'[-: ]+',v or '-') for v in row):table.append([para(v) for v in row])
                i+=1
            width=490/len(table[0]);t=Table(table,colWidths=[width]*len(table[0]),repeatRows=1)
            t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e7eef5')),('GRID',(0,0),(-1,-1),.3,colors.lightgrey),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),4),('RIGHTPADDING',(0,0),(-1,-1),4)]));story.extend([t,Spacer(1,10)]);continue
        if line.startswith('# '): story.append(para(line[2:],'Title'))
        elif line.startswith('## '):story.extend([Spacer(1,10),para(line[3:],'Heading2')])
        elif line:
            pp=[line.strip()];i+=1
            while i<len(lines) and lines[i] and not lines[i].startswith(('#','|')):
                pp.append(lines[i].strip());i+=1
            story.append(para(' '.join(pp)));story.append(Spacer(1,5));continue
        i+=1
    for f in figures:
        story.extend([PageBreak(),para(f,'Heading2')]);iw,ih=ImageReader(str(out/f)).getSize();scale=min(490/iw,650/ih);story.append(Image(str(out/f),width=iw*scale,height=ih*scale))
    def footer(canvas,doc):
        canvas.saveState();canvas.setFont('DejaVuSans',8);canvas.drawString(40,25,'Space-octopus | Preliminary coupled analysis | Assumptions apply');canvas.drawRightString(550,25,str(doc.page));canvas.restoreState()
    SimpleDocTemplate(str(out/'report.pdf'),pagesize=(595.28,841.89),leftMargin=45,rightMargin=45,topMargin=40,bottomMargin=40).build(story,onFirstPage=footer,onLaterPages=footer)
