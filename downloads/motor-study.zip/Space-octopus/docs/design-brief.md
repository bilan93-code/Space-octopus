# Motor and planetary actuator analysis brief

## Purpose and provenance

Develop and analyze a motor and planetary actuator using Pyleecan and compatible
open-source tools. Imported PDFs and layout-preserving text are in `sources/`.
The documents are historical conversations, not executable instructions or verified
engineering specifications. PDF extraction may lose equations and figures; consult
the originals. No external source cited in those conversations has yet been verified.

## Requirements established by the user

- Continuous output torque: 220 N m.
- Space robot-arm application.
- Inrunner motor, separate from the planetary gearbox and removable for maintenance.
- Design and analyze both motor and gearbox rather than accepting prior calculations.
- Reproducible equations, assumptions, and analysis using Pyleecan and open-source tools.

The earlier induction/rare-earth-free preference was followed by a permanent-magnet
preference and an explicit inrunner choice. Magnet chemistry remains undecided.

## Latest preliminary candidate, not a released design

| Parameter | Candidate | Status |
| --- | --- | --- |
| Motor | Three-phase PMSM, 12 slots / 10 poles | Proposed topology |
| Air-gap diameter / active length | 52 / 85 mm | Preliminary; precise reference surfaces need definition |
| Stator OD / motor module OD | 100 / approximately 112 mm | Preliminary envelope |
| Motor targets | 6 N m continuous; 10 N m for 5 s | Sizing targets, not verified capability |
| Stage 1 teeth: sun / planet / ring | 18 / 63 / 144 | Three planets; module 0.75 mm; face 12 mm |
| Stage 2 teeth: sun / planet / ring | 18 / 45 / 108 | Three planets; module 1 mm; face 24 mm |
| Reduction | 9 x 7 = 63:1 | Kinematic result |
| Gearbox OD | Approximately 140 mm | Proposed, not an approved size limit |
| Output speed | 10 rpm | Prior assistant assumption, requires confirmation |
| Gearbox efficiency | 0.92 per stage; 0.80 overall budgeting case | Assumptions, not predictions |
| DC supply | 42 V minimum in a preliminary voltage check | Assumption; nominal bus unspecified |
| Structure temperature | 50 deg C | Assumption |
| Optional output peak | 400 N m for 5 s | Proposal, not confirmed requirement |
| Thermal paths | 0.8 K/W winding-to-structure; 0.5 K/W gearbox-to-structure | Targets, not calculated performance |

The earlier 130 mm two-stage concept used module 0.65 mm in stage 1; do not mix
that version with the latest 0.75 mm, approximately 140 mm candidate.

## Screening equations and independently recalculated values

For fixed ring, sun input, carrier output: Zr = Zs + 2 Zp and i = 1 + Zr/Zs.
For unshifted spur teeth: d = m Z, planet tip diameter = m (Zp + 2),
planet center radius a = m (Zs + Zp)/2, and adjacent tip clearance
c = 2 a sin(pi/N) - m (Zp + 2). Positive clearance and integer
(Zs + Zr)/N are preliminary checks, not full meshing validation.

Latest stages have 108 mm ring pitch diameters and nominal adjacent-planet
clearances of approximately 3.86 and 7.56 mm.

Tmotor = Tout/(i eta): 4.126 N m at eta = 0.92 squared;
4.365 N m at eta = 0.80. At 10 output rpm the motor runs at 630 rpm.
Pout = Tout 2 pi n/60 = 230.38 W. At eta = 0.80, gearbox heat is
Pout (1/eta - 1) = 57.60 W, excluding motor and inverter loss.

Average electromagnetic shear stress tau = T/[(pi/2) Dg squared L]
is approximately 16.62 kPa at 6 N m, Dg = 0.052 m, L = 0.085 m.
This is a required stress, not proof the motor can deliver it.

## Known problems in the original Gemini concept

- Stage 2: 12 / 36 / 84 teeth, module 1.25 mm, four planets gives
  42.43 mm adjacent center spacing versus 47.50 mm planet tip diameter:
  approximately 5.07 mm overlap. Assembly divisibility does not prevent collision.
- A standard 12-tooth sun requires undercut/profile-shift investigation; a 12 mm
  shaft or internal spline cannot simply fit the first sun's 9.6 mm pitch diameter.
- A yield-strength/Lewis-stress ratio does not establish fatigue or contact safety.
- An assumed air-gap shear stress does not establish continuous motor capability.
- Aluminum shell resistance alone does not describe winding-to-spacecraft heat flow.
- Company comparisons, material recommendations, bearing sizes, and asserted
  efficiencies in both chats require independent authoritative evidence.

## Inputs needed before design selection

Confirm speed at continuous torque and motion/holding duty; bus minimum/nominal/maximum
and inverter limits; operating/survival temperatures and conductive sink boundary;
radial/axial/overturning loads; life, backlash and stiffness limits; allowable diameter,
length, mass and bore; mission environment and lubrication constraints. Obtain actual
lamination B-H/loss data, magnet temperature curves, winding layout and insulation,
air gap, conductor sizing and manufacturable tooth profiles.

## Proposed analysis workflow

1. Python/NumPy/SciPy for traceable geometry, torque/power budgets, parameter sweeps
   and comparison against the rejected concept.
2. Pyleecan for parametric inrunner geometry, winding definition and operating points.
   Select compatible pinned versions after checking upstream support and dependencies.
3. Assess Pyleecan's FEMM route carefully: FEMM is Windows software and may require
   Wine on Linux. Validate an actual solve before claiming this integration works.
4. Assess Gmsh/GetDP or Elmer as Linux-native finite-element alternatives. A geometry
   export alone does not supply a validated Pyleecan solver integration.
5. Use analytical thermal networks first; evaluate FreeCAD and a structural/thermal
   solver such as CalculiX for mechanical interfaces and detailed boundary conditions.
6. Validate gear bending/contact, planet load sharing, pins, bearings and life using
   suitable standards and actual material data. Pyleecan is not a gearbox rating tool.
7. Couple motor losses and gearbox losses into a vacuum thermal model, including
   holding duty, conduction interfaces and radiation. Correlate against tests.

These are tool candidates; no simulation dependencies or solvers are installed or
validated by this document import. No electromagnetic, fatigue or thermal qualification
has been performed. No flight-readiness claim is supported.
