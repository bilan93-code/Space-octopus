# Executed model coverage

The [motor-first report](../results/motor/report.md) is the current motor
assessment. It supersedes average-only motor thermal conclusions in the earlier
baseline and extended actuator reports. The earlier design failed stationary
holding hot spots; the corrective winding/cooling candidate passes the explicitly
tested duty under its construction and material assumptions.

The [additional verification report](../results/motor/extensions/report.md)
records the subsequent campaign. It rejects the optional 400 N m trajectory
against the reserved 42 V angle-resolved voltage budget and rejects the earlier
50 GPa wrap assumption when bending/support deflection are included. Neither
software-test success nor nominal mean torque closes those physical gates.

| Domain | Executed engine and coupling | Practical limit |
| --- | --- | --- |
| Parametric motor | Pyleecan MachineSIPMSM, LamSlotWind/LamSlotMag, SlotW10/SlotM11, Shaft | Proposed geometry, generic materials |
| Winding/mass | Native winding matrix, SWAT-EM, fill, resistance, active masses | Insulation/manufacture and complete housing mass unverified |
| Official magnetic map | VarLoadCurrent -> MagFEMM/FEMM -> LUTdq; 27 rotor-averaged current/temperature points | Three levels each of Id/Iq/temperature; constrained interpolation domain |
| Independent magnetic check | Pyleecan surfaces -> Gmsh -> project nonlinear scikit-fem | Shared 2-D/material assumptions; independent implementation |
| Native losses | Bertotti, Joule/skin, proximity, magnet, Winding, Steinmetz and atmospheric WindagePyrhonen; full 144/288-position reference and hot 22 Arms histories | Coefficients/end effects remain uncalibrated; native atmospheric windage is not a vacuum prediction |
| Native electrical coupling | Electrical(EEC_PMSM(fluxlink=MagFEMM)); dq/FE torque consistency and native short-circuit equilibrium | End leakage assumed; fault saturation not fully characterized |
| Operating/thermal feedback | SciPy nonlinear equilibrium, warm-up, stability and Id/speed/current exploration | Average model is not local hot-spot acceptance |
| Local winding heating | Native phase/coil map -> nonlinear scikit-fem conduction, eight holding positions, running and 5 s pulses; two candidate meshes | Effective conductivity calibrated to assumed path; 3-D end-turn offset screened separately |
| Candidate cooling | Distributed case contact, circumferential aluminum spreading and case capacity; no radiation credit | Full-length barrel contact <=.05 K/W required; single-flange mounting not covered |
| Drive | Explicit 20 kHz SVPWM integration with native nonlinear flux Jacobian, PI/anti-windup and time-step checks; angle-resolved torque/flux feedforward voltage | Ideal switches; no firmware/device/EMC validation; 400 N m fails reserved-voltage trajectory screen |
| Faults/magnets | Wider native flux grid with holdouts; differential saturation, fixed-speed/coast-down and 0/80/160 uH end-leakage scenarios; updated native H snapshots | Declared inertia/end scenarios; supplier irreversible knee absent; demagnetization pass unset |
| Stator mechanics | ForceMT -> force/torque-conserving project P2 FE; two meshes, three supports, 16 modes/harmonic response; cold 22 Arms peak | 2-D stator, assumed supports/damping; complete housing/bearing NVH absent |
| Motor mechanics | Shaft torsion/critical-speed, growth, bond shear-lag, wrap and bearing/conduction screens | Conditional construction; no selected-material strength or complete rotor-dynamics pass |
| Native optimization | OptiGenAlgNsga2Deap/DEAP with 36-point winding surrogate and nine real nonlinear FEMM geometry evaluations | Finite grids, no global topology claim; alternatives do not inherit the baseline's complete assessment |
| Eccentricity/support | Custom full-circle translated-rotor FE, x/y 50 um offsets, two meshes, closed-contour force and support-stiffness screen | Static nominal-field pull; full fault-UMP/whirl and selected bearings absent |
| Thermal construction | Coated-wire unit-cell FE and explicit slot-liner temperature-jump interfaces; 30 material/liner cases | Declared resin/void topology; liner volume and actual manufacture unverified |
| Harmonic AC | Direct FEMM wire impedance versus exact Bessel result; DC-biased incremental AC with isolated conductive magnets and mesh checks; PWM spectrum sensitivity | Frozen position, assumed conductivity and frequency continuation; full 3-D/steel PWM loss not established |
| Native skew | Two-slice 3-degree mechanical stepped skew | Separate option; full skewed map/axial end effects/manufacture unverified |
| StructElmer alternative | Actual unmodified gen_case attempted for LamSlotMag; AttributeError on missing rotor.hole before solver | Unsupported route for this machine in installed release; traceback retained |
| MagElmer alternative | Installed solve_FEA inspected; flux/air-gap extraction unfinished | Not claimed as executed solver |
| Earlier actuator structure | CalculiX 2.20 quadratic 3-D carrier strength/refinement/modes | Isolated simplified plate; not full assembly |
| Earlier planetary/CAD work | Tooth spacing/load screens, bearing/pin/bolt calculations; FreeCAD 58-solid FCStd/STEP | Preliminary external-tool study; no certified fatigue/full clearance acceptance |
| Physical validation | Not performed | Supplier data, assembled thermal paths, prototype correlation and mission qualification remain open |

The motor [coverage record](../results/motor/coverage.json) and component JSON
files distinguish official modules from project adapters. Native stator time
reduction was unsuitable for rotor losses because `per_t_R=1`; accepted losses
use a full mechanical revolution. Reduced-period diagnostic/fault/skew cases
are not accepted as full rotor-loss qualification. A stale-current no-load map
was rejected, archived and recomputed from a fresh zero-current FEMM reference.
Accepted no-load mean torque is below .01 N m.

The FEMM installer is checksum verified against upstream; see
[distribution provenance](femm-distribution.json). An additive filesystem alias
handles a mixed-separator Lua path on Linux. The project scopes atomic requests,
complete-response reads and stale-response rejection to native jobs; regression
tests cover the observed partial-file failure. Installed Pyleecan/pyfemm Python
implementation hashes are compared against distribution RECORD entries.

Pyleecan 1.5.2's recursive `machine.check()` inheritance issue is handled by
constituent geometry checks and independent invariants, with no claim that the
full upstream check passed. Numerical tests support consistency under shared
assumptions. They do not establish measured accuracy, material qualification,
manufacturing release or flight readiness.
