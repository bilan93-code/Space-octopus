# Motor assessment: finite checks and open release gates

The original stop occurred after a preliminary campaign, before all relevant
software checks had been executed. It was a scope decision, not a missing user
permission. The extended campaign below follows the existing authorization.
Completion of an individual calculation is distinct from product acceptance.

| Check | Execution / evidence |
| --- | --- |
| Normal-operation nonlinear field map | Existing 27 native FEMM points; six new independent mid-cell/temperature holdouts |
| Map numerical refinement | Existing full-period reference time/mesh checks; new cold loaded map-corner time/mesh checks |
| Loaded losses | New 144/288-position full-mechanical-period hot 22 Arms history |
| Geometry optimization | Nine actual nonlinear FEMM geometry evaluations; native NSGA-II over their cached exact results |
| Material/tolerance sensitivity | Hot 22 Arms reference, Br -5%, gap +50 um, stack -0.5 mm and combined case |
| Static eccentricity | Custom Pyleecan-surface/Gmsh/scikit-fem route, two meshes, x/y 50 um offsets, closed-contour force and bearing-stiffness screen |
| Saturated drive and fault dynamics | Wider native flux map, independent holdouts, differential flux Jacobian, fixed-speed and coast-down faults, switched-controller refinement |
| Additional native loss models | LossModelWinding, LossModelSteinmetz and atmospheric WindagePyrhonen; assumptions retained |
| Harmonic conductor loss | Direct FEMM AC impedance versus Bessel round-wire solution; simulated PWM current spectra |
| Harmonic magnet loss | Direct FEMM incremental AC about native DC bias, finite conductivity and isolated zero-net-current magnets; local mesh check |
| Thermal construction | Coated-wire unit-cell FE, two meshes; actual slotted stator with separated liner interfaces; 30 material/liner scenarios |
| Angle-resolved torque control | Native instantaneous torque/flux trajectories determine current and full flux-derivative voltage for 220/400 N m; mean-only voltage passes are not sufficient |

The authoritative completion status is in component JSON files and the extension
assessment/report, not this list of intended checks. Running jobs and failed
attempts are not accepted as completed analyses. Additional results can reject
assumptions or narrow the recommendation; acceptance thresholds are not relaxed
to preserve the earlier conclusion.

The listed finite campaign completed on 2026-11-06. Its full workflow passes
54 automated checks. The 400 N m budget/perturbation and earlier 50 GPa wrap
screens fail as reported; passing software verification preserves these failed
engineering cases rather than converting them into accepted product ratings.

Open release gates cannot be closed by enumerating software features: supplier
temperature-dependent magnet knee/recoil curves, high-field and high-frequency
steel data, winding/contact manufacture, actual bearing/preload and retention
construction, real arm inertia and mission duty, environmental/life loads,
protected inverter hardware, assembled cooling measurements and prototype
torque/loss/temperature correlation. Three-dimensional end/segmentation/contact
effects remain separate from FEMM's two-dimensional calculation. StructElmer in
the installed release failed before solving this surface-PM geometry.
