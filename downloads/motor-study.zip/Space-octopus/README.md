# Space-octopus

Reproducible motor-first analysis for a **220 N m planetary actuator** using
Pyleecan and its official FEMM coupling, with open-source thermal, structural
and drive calculations. User-supplied PDFs remain reference material.

## Current motor decision

The earlier 12-turn / two-0.90 mm-strand design can deliver the required mean
torque, but **fails the local-temperature holding-duty screen**: the tested
hot holding / five-second pulse reaches approximately **172°C**. The earlier
average-temperature result missed phase-localized heating.

The corrective candidate uses **12 turns, two 0.95 mm strands, winding-to-case
resistance <=0.12 K/W and distributed case-to-sink resistance <=0.05 K/W**.
Its worst buffered temperature is approximately **119°C** against the assumed
130°C limit, without radiation credit. It conditionally matches the adopted
220 N m / 10 rpm output duty through a 63:1, 80%-efficient gearbox. The specified
housing contact geometry is essential. Cooling, magnet knee curves, retention,
protection and prototype correlation remain build-acceptance requirements.

The [additional verification report](results/motor/extensions/report.pdf)
adds independent map checks, nonlinear faults, actual FEMM geometry trades,
AC conductive-reaction calculations, winding/liner construction and eccentricity.
The **220 N m angle-resolved electrical screen passes** the adopted voltage
budget. The optional **400 N m constant-torque trajectory exceeds that reserved
budget**, despite passing the earlier mean-voltage check. A combined hot
material/geometry perturbation also misses 400 N m with the declared loss stress.
The earlier 50 GPa retaining-wrap assumption fails the corrected clearance
screen; a proposed 100 GPa hot hoop modulus and specified support stiffness
restore the modeled gap. These are construction requirements, not selected
and qualified parts.

- [Motor assessment PDF](results/motor/report.pdf), [standalone HTML](results/motor/report.html), [Markdown](results/motor/report.md)
- [Additional verification PDF](results/motor/extensions/report.pdf), [HTML](results/motor/extensions/report.html), [assessment data](results/motor/extensions/assessment.json)
- [Exact corrective configuration](configs/motor_candidate.json) and [native machine](results/motor/candidate/machine.json)
- [Construction requirements](results/motor/build_requirements.json), [executed coverage](results/motor/coverage.json), [provenance](results/motor/reproduction_manifest.json)
- [Portable review package](results/Space-octopus-study.zip), including source, reports, reference PDFs and earlier concept CAD
- [CAD starting guide](CAD_START_HERE.md) and [current motor-only STEP](results/motor/cad/SpaceOctopusMotorActive.step), with winding diagrams and dimension tables in `results/motor/cad/`
- [Detailed coverage and limits](docs/model-coverage.md), [design brief](docs/design-brief.md)

The motor study includes an official 27-point VarLoadCurrent/MagFEMM/LUTdq map;
full-mechanical-period native loss time/mesh checks; electrical/thermal feedback;
stationary phase hot spots and five-second pulses; switched SVPWM and fault ODEs;
fault-field demagnetization requirements; ForceMT-to-stator mechanics; native
NSGA-II winding trades; and a separately evaluated two-slice skew option.
It does not claim all Pyleecan features apply or that simulated duty is a
manufacturing or flight qualification.

## Reproduce the motor study

Use the existing checkout at `/workspace/Space-octopus`; the cloud task is already
isolated. No additional Git worktree is needed.

```sh
bash scripts/setup.sh
python scripts/setup_extended.py
python scripts/setup_femm.py
OPENBLAS_NUM_THREADS=1 .venv/bin/python -m actuator.motor_comprehensive
OPENBLAS_NUM_THREADS=1 .venv/bin/python -m pytest -q
```

Setup uses `uv`, CPython 3.8.20 and pinned dependencies compatible with Pyleecan
1.5.2, including DEAP. CalculiX, Wine, Xvfb and extraction tools use locally
extracted, checksum-verified Debian archives. FEMM's official installer bytes
are obtained from a pinned public cache and verified against the published
upstream SHA-256. Host packages and existing user configuration are preserved.
Network installation and user-data aliases may need managed sandbox escalation.

FEMM runs headlessly with temporary Xvfb/Wine sessions. **Do not run multiple
FEMM jobs or the FEMM installer concurrently**: they share the project Wine prefix.
A scoped file-link guard fixes partial-response delivery without altering
installed Pyleecan/FEMM algorithms. No persistent service is needed.

The comprehensive runner reuses completed results and regenerates missing required native
checkpoints, runs verification and records source/result hashes.
The earlier primary campaign remains available as `python -m actuator.motor_study`;
its `--refresh` reruns the primary native campaign. Preserve variants before
refreshing. The additional campaign uses its own point/component caches and
declared specifications. Complete native regeneration can take several hours.
The portable package omits large native pickles, raw solver output and runtimes;
its summaries and reports can be reviewed immediately. Fresh runs require the
setup dependencies and network access. FreeCAD's Python 3.13 modules are supplied
by the selected base image for the separate concept CAD stage.

## Earlier actuator and concept study

The [extended report](results/extended/extended_report.pdf) records the earlier
actuator work: three-planet/two-stage packaging, gear/bearing/interface screens,
CalculiX carrier strength/modes and a FreeCAD concept assembly. Its **motor thermal
ratings are superseded** by the motor-first report. The earlier concept CAD does
not incorporate all corrective winding, housing and retention requirements.
Pyleecan models the electric motor; planetary transmission calculations use
external tools and explicit engineering screens.

```sh
OPENBLAS_NUM_THREADS=1 .venv/bin/python -m actuator.run
OPENBLAS_NUM_THREADS=1 .venv/bin/python -m actuator.extended
python scripts/package_study.py
```

The baseline report is historical. Generic materials, loss coefficients, contacts,
load sharing and mission assumptions require product-specific data and hardware
validation. Successful software tests verify numerical consistency, not hardware
qualification. No complete actuator mass, fatigue life or flight readiness is claimed.
