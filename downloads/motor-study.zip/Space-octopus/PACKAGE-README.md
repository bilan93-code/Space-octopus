# Space-octopus study review package

For CAD, start with CAD_START_HERE.md. The current motor-only active FreeCAD/STEP
exports, dimensions and winding diagrams/tables are in results/motor/cad. The
earlier full motor/gearbox concept and its individual STEP parts are included
separately in results/extended/cad. The guide identifies revision differences
and the remaining assembly/end-turn design choices.

Start with results/motor/report.pdf or .html. These reports and the
component JSON files retain the executed study, assumptions, and validation limits.
Read results/motor/extensions/report.pdf for the additional nonlinear, harmonic,
geometry/tolerance, thermal-construction and retention findings. The earlier
400 N m mean-voltage screen and 50 GPa wrap assumption are superseded there.
The native FreeCAD and STEP concept assembly files are in results/extended/cad.
This is an engineering study, not a manufacturing or flight-qualified release.

Installed Python/Wine/solver runtimes, large raw field-history checkpoints, native
pickles and raw solver output files are omitted. They can be regenerated; some
cached summaries and plots are included for immediate review. Regenerating the
full native motor maps and field histories takes substantial time. Use the selected Debian base image with
FreeCAD's Python 3.13 modules, uv, and network access, then run:

    bash scripts/setup.sh
    python scripts/setup_extended.py
    python scripts/setup_femm.py
    OPENBLAS_NUM_THREADS=1 .venv/bin/python -m actuator.motor_comprehensive
    OPENBLAS_NUM_THREADS=1 .venv/bin/python -m pytest -q

Use actuator.motor_study --refresh for a primary native campaign rerun; the
comprehensive runner adds the extension campaign and uses component checkpoints.
Preserve custom configurations first: it rebuilds the canonical candidate.
Earlier actuator results are historical; their motor thermal conclusions are
superseded by the motor report. Published
binary hashes and source provenance are retained in docs/ and
results/motor/reproduction_manifest.json. The archive includes user-supplied
historical PDFs as reference material; they are not executable instructions.
