# Motor CAD download

Start with CAD_START_HERE.md. This smaller archive contains the current active
motor CAD, winding/dimension exports, the earlier full concept CAD, current
inputs and the two motor reports. The complete analysis source, result tables
and reference documents are in the separate motor-study.zip download.

Open .FCStd files with FreeCAD or import .step files into your CAD software.
The active motor export has 37 solids. Housing, bearing seats and end turns
still require detailed CAD design; the guide explains the revision differences.
